# Minimal reproducibility package

This package contains only the source code, exact saved inputs, directly bound
executed numerical data, independent controls, provenance records, and hashes
needed to reproduce or audit the numerical claims in the article
"Boundary-response closure and controlled intermittency tests for
Casimir-pressure fluctuations".

The complete development archive, caches, logs, superseded calculations,
historical benchmark, and ongoing follow-up research remain preserved by the
author and are intentionally excluded from this journal supplement.

The `paper/` source is the JSTAT scientific source used by the claim-to-data
verifier. Its evidence-binding record preserves the original frozen source
hash and records the journal-format adaptation; numerical fragments and
scientific body text are unchanged.

## Environment

- Python 3.11 or newer
- NumPy and SciPy versions specified in `requirements.txt`
- A BLAS implementation; the commands below use one thread for repeatability

Create an environment with:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Fast validation

Run from the extracted package root. Use a new, empty `verification/`
directory because each checker refuses to overwrite an existing result.

```sh
mkdir verification
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python research/stage2/check_second_order.py \
  --input results/stage2_2026-09-15/cosine_occupation14_16.json \
  --output verification/second_order.json
PYSCF_MAX_MEMORY=2048 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python research/stage3/check_ordered_matrix_cumulants.py \
  --output verification/ordered_matrix.json
python research/stage4/verify_paper1_claims.py \
  --output verification/claims.json
python VERIFY_PACKAGE.py
```

The first two commands rerun independent analytic, operator-ordering,
centering, occupation, and noncommuting-matrix controls. The third checks the
article's exact claim-to-data bindings and scope limitations. The final command
verifies every distributed file against `MANIFEST_SHA256.txt`.

## Scope

Saved-data verification does not establish persistent Casimir-pressure
intermittency. The article reports resolved nonlinear pressure-shape changes
and an incomplete static boundary closure, while the tested hierarchy does not
show a persistent anomalous exponent.
