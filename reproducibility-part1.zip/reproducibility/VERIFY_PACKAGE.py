#!/usr/bin/env python3
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = root / "MANIFEST_SHA256.txt"
checked = 0
for line in manifest.read_text(encoding="utf-8").splitlines():
    expected, rel = line.split("  ", 1)
    path = root / rel
    if not path.is_file():
        raise SystemExit(f"MISSING {rel}")
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f"HASH MISMATCH {rel}")
    checked += 1
print(f"PASS: {checked} files match MANIFEST_SHA256.txt")
