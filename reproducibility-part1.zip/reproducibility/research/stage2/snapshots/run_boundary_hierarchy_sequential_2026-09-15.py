"""Finite-mode physical boundary hierarchy and positive ordered increment moments.

All families preserve total static linear loading and total static quartic G.
They do not have a common all-frequency harmonic response across branch counts.
"""
from pathlib import Path
import sys,json,argparse,time,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research/agents')]
from distributed_line import Parameters
from nonlinear_pressure import continuum_pressure_modes
from higher_moment_gaussian import first_order_gaussian

def hierarchy(branches,rho,minimum=1.1):
    if branches<2 or rho<=1:raise ValueError('This shooting driver requires >=2 noncoincident branches and rho>1')
    omega=minimum*rho**np.arange(branches);S=np.ones(branches)/branches
    p=Parameters(Cr=tuple(S/omega**2),Kc=tuple(.25*S),Kg=tuple(.25*S),KJ=tuple(.5*S))
    p.validate()
    return p,omega

def allocations(omega,G):
    low=1/omega;low/=low.sum();high=omega/omega.sum()
    weights={'uniform':np.ones(len(omega))/len(omega)}
    weights.update({f'eta_{eta:g}':(1-eta)*low+eta*high for eta in [0,.5,1]})
    return {name:G*w/.25**4 for name,w in weights.items()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--branches',nargs='+',type=int,default=[2,4,6]);ap.add_argument('--modes',nargs='+',type=int,default=[8,12]);ap.add_argument('--tau',nargs='+',type=float,default=[.15,.3,.6,1.2,2.4]);ap.add_argument('--families',nargs='+',choices=['extend','extend_ir','densify'],default=['extend']);ap.add_argument('--G',type=float,default=-1e-7);ap.add_argument('--order',type=int,default=8);a=ap.parse_args()
    dest=(ROOT/a.output).resolve()
    if not dest.is_relative_to(ROOT) or dest.exists():raise ValueError('Use a new project-local output')
    dest.parent.mkdir(parents=True,exist_ok=True);begin=time.monotonic()
    sources=[Path(__file__),ROOT/'research/agents/higher_moment_gaussian.py']
    result={'status':'RUNNING','parameters':vars(a),'cases':[],'source_sha256':{str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sources},'scope':'first derivative at zero nonlinearity, exact algebra in selected modes; no intermittency verdict'}
    def save():
        result['elapsed_seconds']=time.monotonic()-begin;tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(result,indent=2));tmp.replace(dest)
    save()
    for family in a.families:
        for R in a.branches:
            rho=8.**(1/(R-1)) if family=='densify' else 2.
            minimum=8.8/rho**(R-1) if family=='extend_ir' else 1.1
            p,poles=hierarchy(R,rho,minimum);couplings=allocations(poles,a.G)
            for M in a.modes:
                modes=continuum_pressure_modes(M,p)
                variance=np.sum(modes.branch**2*p.hbar/(2*modes.omega)[None,:],axis=1)
                for tau in a.tau:
                    value=first_order_gaussian(modes.omega,modes.endpoint,modes.slope,modes.branch,couplings['uniform'],tau,a.order,p.C0,p.L0,p.hbar,True,memory_limit_mb=1024)
                    per_branch=value['branch_moment_coefficients'];per_k=value['branch_cumulant_coefficients'];hm=value['harmonic_moments'];hk=value['harmonic_cumulants'];allocated={}
                    for name,u in couplings.items():
                        dm={str(n):sum(float(ur)*r[str(n)] for ur,r in zip(u,per_branch)) for n in range(1,a.order+1)}
                        dk={str(n):sum(float(ur)*r[str(n)] for ur,r in zip(u,per_k)) for n in range(1,a.order+1)}
                        assert abs(sum(u)*.25**4-a.G)<1e-17
                        # A vanished numerical moment is unresolved, not a zero physical law.
                        resolved={str(n):bool(np.isfinite(hm[str(n)]) and hm[str(n)]>1e-250 and np.isfinite(dm[str(n)])) for n in range(2,a.order+1,2)}
                        A1={str(n):(dm[str(n)]/hm[str(n)]-(n/2)*dm['2']/hm['2'] if resolved[str(n)] and resolved['2'] else None) for n in range(2,a.order+1,2)}
                        beta_rows=[]
                        for beta in [0,.125,.25,.5,1.]:
                            approx={str(n):hm[str(n)]+beta*dm[str(n)] for n in range(2,a.order+1,2)}
                            beta_rows.append({'beta':beta,'first_order_even_moments':approx,'all_positive':all(x>0 for x in approx.values()),'resolved_moments':resolved,'max_relative_moment_correction':max([abs(beta*dm[str(n)]/hm[str(n)]) for n in range(2,a.order+1,2) if resolved[str(n)]] or [0.]) if all(resolved.values()) else None})
                        allocated[name]={'u':u.tolist(),'vacuum_phase_variance_at_beta_one':(-u*variance/np.asarray(p.KJ)).tolist(),'delta_moments':dm,'delta_cumulants':dk,'ratio_resolution_floor':1e-250,'resolved_moments':resolved,'log_standardized_harmonic_ratio_derivative':A1,'first_order_checks':beta_rows}
                    row={'family':family,'branches':R,'rho':rho,'bare_poles':poles.tolist(),'static_linear_loading':sum(np.asarray(p.Kc)*(1-.25)),'G':a.G,'modes':M,'omega_max':float(modes.omega[-1]),'tau':tau,'harmonic_moments':hm,'harmonic_cumulants':hk,'branch_moment_coefficients':per_branch,'branch_cumulant_coefficients':per_k,'allocations':allocated,'runtime_seconds':value['runtime_seconds'],'estimated_array_memory_mb':value['estimated_array_memory_mb']}
                    result['cases'].append(row);save();print(json.dumps({k:row[k] for k in ['family','branches','modes','tau','runtime_seconds']}),flush=True)
    result['status']='COMPLETED';save();print(json.dumps({'status':result['status'],'cases':len(result['cases']),'elapsed_seconds':result['elapsed_seconds']}),flush=True)
if __name__=='__main__':main()
