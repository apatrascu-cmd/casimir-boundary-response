"""Independent oscillator and completed-pilot second-order checks."""
from pathlib import Path
import sys,json,argparse,math
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(ROOT/'research/stage2')]
from nonlinear_pressure import FockRegulator,first_order_cumulants,exact_spectral_cumulants
from run_nonlinear_orders import vector

def oscillator_control():
    f=FockRegulator(np.array([1.]),16,max_dimension=100)
    even=np.flatnonzero(f.states.sum(axis=1)%2==0)
    b=f.ann[0]/np.sqrt(2)
    op=lambda n:f.normal_power(b,n)[even][:,even].toarray()
    E=f.energies[even];P=op(2);V=op(4)/24
    W=op(2)/64+op(4)/96+op(6)/720
    # These rational values follow independent Rayleigh--Schrodinger states,
    # explicitly recorded in docs/NEXT_COSINE_ORDER_2026-09-14.md.
    expected_vv=47/3072;expected_w=-3/128
    first=first_order_cumulants(E,P,V,0.,2)
    sextic=first_order_cumulants(E,P,W,0.,2)['delta_cumulants']['2']
    baseline=exact_spectral_cumulants(np.diag(E),P,0.,2)['2']
    a=[]
    for h in [.02,.01,.005]:
        kp=exact_spectral_cumulants(np.diag(E)+h*V,P,0.,2)['2']
        km=exact_spectral_cumulants(np.diag(E)-h*V,P,0.,2)['2']
        a.append((kp+km-2*baseline)/(2*h*h))
    vv=(4*a[2]-a[1])/3
    assert abs(baseline-.5)<1e-13
    assert abs(first['delta_cumulants']['2']+1/32)<1e-12
    assert abs(sextic-expected_w)<1e-12
    assert abs(vv-expected_vv)<2e-9,(vv,expected_vv)
    return dict(status='PASS',baseline=baseline,first=first['delta_cumulants']['2'],repeated_quartic=vv,expected_repeated_quartic=expected_vv,sextic_and_contractions=sextic,expected_sextic_and_contractions=expected_w,total=vv+sextic,expected_total=-25/3072,finite_difference_steps=[.02,.01,.005])

def analyze(data):
    assert data['status']=='COMPLETED'
    qs=sorted({r['quanta'] for r in data['cases']});rows=[]
    for r in data['cases']:
        if r['quanta']!=qs[-1]:continue
        prev=next(x for x in data['cases'] if x['quanta']==qs[-2] and all(x[k]==r[k] for k in ['eta','tau','increment']))
        for p in range(2,9):
            k=str(p);c2=r['second_total'][k]
            errors=r['cosine_checks'];betas=np.array([x['beta'] for x in errors])
            res1=np.abs([x['residual_after_first_order'][k] for x in errors]);res2=np.abs([x['residual_after_second_order'][k] for x in errors])
            rows.append(dict(eta=r['eta'],tau=r['tau'],increment=r['increment'],order=p,harmonic=r['harmonic_cumulants'][k],first=r['first_order'][k],second=c2,second_step_error=r['second_step_refinement_absolute'][k],second_occupation_change=abs(c2-prev['second_total'][k]),first_residual_slopes=(np.diff(np.log(res1))/np.diff(np.log(betas))).tolist(),second_residual_slopes=(np.diff(np.log(res2))/np.diff(np.log(betas))).tolist(),second_residual_improvement=(res1/res2).tolist(),cosine_occupation_absolute=[abs(x['exact_cumulants'][k]-y['exact_cumulants'][k]) for x,y in zip(errors,prev['cosine_checks'])]))
    return {'rows':rows,'scope':'finite-mode next-order verification; errors are reported, not converted to continuum or intermittency claims'}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    dest=ROOT/a.output
    if dest.exists():raise FileExistsError(dest)
    result={'oscillator_control':oscillator_control(),'pilot_analysis':analyze(json.loads((ROOT/a.input).read_text()))}
    dest.write_text(json.dumps(result,indent=2));print(json.dumps(result['oscillator_control']))
    for r in result['pilot_analysis']['rows']:
        print(json.dumps({k:r[k] for k in ['eta','increment','order','second','second_step_error','second_occupation_change','second_residual_slopes']}))
