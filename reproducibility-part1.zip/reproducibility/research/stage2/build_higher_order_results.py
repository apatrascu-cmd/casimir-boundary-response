"""Build manuscript artifacts from completed finite-mode cosine calculations.

This module performs saved-data validation, tabulation, and plotting only.  It
does not import a quantum solver, launch a calculation, or fit intermittency
exponents.  Run it through the project resource guard.  The four output names
are fixed so that the baseline manuscript, benchmark, and figures are preserved.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import tempfile
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA = "results/stage2_2026-09-15/cosine_occupation14_16.json"
DEFAULT_CHECKS = "results/stage2_2026-09-15/cosine_occupation14_16_checks.json"
OUTPUT_NAMES = {
    "tex": "paper/stage2_results.tex",
    "pdf": "paper/figures/stage2_second_order.pdf",
    "png": "paper/figures/stage2_second_order.png",
    "provenance": "paper/stage2_second_order_provenance.json",
}
TABLE_ORDERS = (2, 3, 4, 6, 8)
PLOT_ORDERS = (2, 4, 8)
QUANTA = (14, 16)
TAU = 0.2
ETA = 0.0
STATIC_G = -0.01
SHAPE_BETA = 0.25
EXPECTED_BETAS = {1 / 4, 1 / 8, 1 / 16, 1 / 32, 1 / 64}


def local_path(value: str | Path, *, must_exist: bool = False) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = ROOT / path
    path = path.resolve(strict=must_exist)
    if not path.is_relative_to(ROOT):
        raise ValueError(f"A project-local path is required: {value}")
    return path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def finite(value: Any, name: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"Nonfinite value in {name}: {value}")
    return result


def close(actual: float, expected: float, name: str) -> None:
    if not math.isclose(actual, expected, rel_tol=5e-10, abs_tol=1e-14):
        raise ValueError(f"Saved-data disagreement in {name}: {actual} != {expected}")


def matches(row: dict[str, Any]) -> bool:
    return (
        math.isclose(float(row["eta"]), ETA, rel_tol=0, abs_tol=1e-13)
        and math.isclose(float(row["tau"]), TAU, rel_tol=0, abs_tol=1e-13)
        and row["increment"] is False
    )


def unique(items: list[Any], description: str) -> Any:
    if len(items) != 1:
        raise ValueError(f"Expected one {description}, found {len(items)}")
    return items[0]


def tex_number(value: float, digits: int = 5) -> str:
    value = finite(value, "TeX number")
    if value == 0:
        return "0"
    mantissa, exponent = f"{value:.{digits}e}".split("e")
    return mantissa + r"\times10^{" + str(int(exponent)) + "}"


def shape(cumulants: dict[str, Any]) -> dict[str, float]:
    variance = finite(cumulants["2"], "shape variance")
    if variance <= 0:
        raise ValueError("Standardized cumulants require positive variance")
    return {
        "skewness": finite(cumulants["3"], "third cumulant") / variance**1.5,
        "standardized_fourth_cumulant": (
            finite(cumulants["4"], "fourth cumulant") / variance**2
        ),
    }


def load_selection(data_path: Path, checks_path: Path) -> dict[str, Any]:
    data = json.loads(data_path.read_text())
    checks = json.loads(checks_path.read_text())
    if data.get("status") != "COMPLETED":
        raise ValueError("The physical calculation is not marked COMPLETED")
    if checks.get("oscillator_control", {}).get("status") != "PASS":
        raise ValueError("The independent oscillator control did not pass")
    parameters = data["parameters"]
    if int(parameters["modes"]) != 3 or int(parameters["order"]) < 8:
        raise ValueError("This figure requires three retained modes through order eight")
    if sorted(parameters["quanta"]) != list(QUANTA):
        raise ValueError("This manuscript selection requires precisely Q14 and Q16")
    close(finite(parameters["G"], "G"), STATIC_G, "static quartic budget")

    indexed_cases = list(enumerate(data["cases"]))
    selected: dict[int, dict[str, Any]] = {}
    case_indices: dict[str, int] = {}
    for occupation in QUANTA:
        index, row = unique(
            [(i, r) for i, r in indexed_cases if r["quanta"] == occupation and matches(r)],
            f"Q={occupation}, eta=0, tau=0.2 ordinary-pressure case",
        )
        selected[occupation] = row
        case_indices[str(occupation)] = index

    reference = selected[16]
    lower = selected[14]
    beta_order = [finite(x["beta"], "beta") for x in reference["cosine_checks"]]
    if len(beta_order) < 3 or any(b <= 0 for b in beta_order):
        raise ValueError("A positive coupling-refinement sequence is required")
    if len(set(beta_order)) != len(beta_order):
        raise ValueError("Repeated beta values in selected case")
    if set(beta_order) != EXPECTED_BETAS:
        raise ValueError("The manuscript text requires beta=1/4 through 1/64 in factors of two")
    if set(beta_order) != {finite(x["beta"], "Q14 beta") for x in lower["cosine_checks"]}:
        raise ValueError("Q14 and Q16 use different beta grids")
    if SHAPE_BETA not in beta_order:
        raise ValueError("The requested beta=0.25 shape comparison is absent")

    indexed_checks = list(enumerate(checks["pilot_analysis"]["rows"]))
    table: list[dict[str, Any]] = []
    check_indices: dict[str, int] = {}
    for order in TABLE_ORDERS:
        key = str(order)
        index, checked = unique(
            [(i, r) for i, r in indexed_checks if r["order"] == order and matches(r)],
            f"independent saved analysis row for order {order}",
        )
        check_indices[key] = index
        row = {
            "order": order,
            "harmonic": finite(reference["harmonic_cumulants"][key], "harmonic"),
            "first": finite(reference["first_order"][key], "first coefficient"),
            "second_vv": finite(reference["second_repeated_quartic"][key], "VV coefficient"),
            "second_w": finite(reference["second_sextic_and_contractions"][key], "W coefficient"),
            "second_total": finite(reference["second_total"][key], "total coefficient"),
            "step_change": finite(reference["second_step_refinement_absolute"][key], "step change"),
            "occupation_change": abs(
                finite(reference["second_total"][key], "Q16 coefficient")
                - finite(lower["second_total"][key], "Q14 coefficient")
            ),
        }
        if row["step_change"] < 0:
            raise ValueError("A reported absolute step difference is negative")
        close(row["second_vv"] + row["second_w"], row["second_total"], f"VV+W at p={order}")
        for built, saved in [
            ("harmonic", "harmonic"), ("first", "first"),
            ("second_total", "second"), ("step_change", "second_step_error"),
            ("occupation_change", "second_occupation_change"),
        ]:
            close(row[built], finite(checked[saved], saved), f"p={order}, {saved}")
        close(row["harmonic"], finite(lower["harmonic_cumulants"][key], "Q14 harmonic"), "harmonic reference across Q")
        close(row["first"], finite(lower["first_order"][key], "Q14 first"), "first coefficient across Q")
        table.append(row)

    curves: dict[str, Any] = {}
    zero_points: list[dict[str, Any]] = []
    for order in PLOT_ORDERS:
        key = str(order)
        norm = abs(finite(reference["harmonic_cumulants"][key], "residual normalization"))
        if norm == 0:
            raise ValueError(f"Zero harmonic cumulant cannot normalize residual p={order}")
        curves[key] = {"normalization": norm, "occupations": {}}
        for occupation, case in selected.items():
            points = []
            for exact in sorted(case["cosine_checks"], key=lambda x: float(x["beta"])):
                beta = finite(exact["beta"], "beta")
                kappa = finite(exact["exact_cumulants"][key], "exact cumulant")
                e1 = finite(exact["residual_after_first_order"][key], "first residual")
                e2 = finite(exact["residual_after_second_order"][key], "second residual")
                expected1 = kappa - finite(case["harmonic_cumulants"][key], "harmonic") - beta * finite(case["first_order"][key], "first")
                expected2 = expected1 - beta**2 * finite(case["second_total"][key], "second")
                close(e1, expected1, f"first residual p={order}, Q={occupation}, beta={beta}")
                close(e2, expected2, f"second residual p={order}, Q={occupation}, beta={beta}")
                points.append({
                    "beta": beta,
                    "signed_residual_first": e1,
                    "signed_residual_second": e2,
                    "absolute_normalized_first": abs(e1) / norm,
                    "absolute_normalized_second": abs(e2) / norm,
                })
                for truncation, value in [(1, e1), (2, e2)]:
                    if value == 0:
                        zero_points.append({"p": order, "Q": occupation, "beta": beta, "truncation": truncation})
            curves[key]["occupations"][str(occupation)] = points
        # A guide is anchored at the largest-coupling Q16 point, not fitted.
        anchor = curves[key]["occupations"]["16"][-1]
        if anchor["absolute_normalized_second"] <= 0:
            raise ValueError("The requested cubic guide has a zero anchor")
        curves[key]["cubic_guide"] = {
            "power": 3,
            "beta_anchor": anchor["beta"],
            "height_anchor": anchor["absolute_normalized_second"],
            "interpretation": "visual coupling-refinement guide, not a fitted exponent",
        }

    harmonic_shape = shape(reference["harmonic_cumulants"])
    exact_shapes = {}
    for occupation, case in selected.items():
        exact = unique([x for x in case["cosine_checks"] if float(x["beta"]) == SHAPE_BETA], "shape beta")
        exact_shapes[str(occupation)] = shape(exact["exact_cumulants"])
    shapes = {
        "beta": SHAPE_BETA,
        "harmonic": harmonic_shape,
        "cosine_Q14": exact_shapes["14"],
        "cosine_Q16": exact_shapes["16"],
        "signed_nonlinear_change": {k: exact_shapes["16"][k] - harmonic_shape[k] for k in harmonic_shape},
        "absolute_occupation_change": {k: abs(exact_shapes["16"][k] - exact_shapes["14"][k]) for k in harmonic_shape},
    }
    return {
        "scope": "fixed three modes, ordinary pressure at tau=0.2, eta=0, G=-0.01; calibration through first order only",
        "selection": {"modes": 3, "tau": TAU, "eta": ETA, "G": STATIC_G, "increment": False, "quanta": list(QUANTA)},
        "source_case_indices": case_indices,
        "source_analysis_row_indices": check_indices,
        "coefficient_table": table,
        "curves": curves,
        "shape_comparison": shapes,
        "zero_residual_points_omitted_from_log_axes": zero_points,
        "source_beta_order": beta_order,
        "source_physical_parameters": parameters,
        "source_reported_driver_sha256": data.get("source_sha256"),
        "second_derivative_steps": reference["second_steps"],
        "independent_oscillator_control": checks["oscillator_control"],
    }


def write_figure(selected: dict[str, Any], pdf_path: Path, png_path: Path, dpi: int) -> str:
    config = local_path("tmp/matplotlib_stage2_higher_order")
    config.mkdir(parents=True, exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(config)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 8,
        "axes.labelsize": 8, "axes.titlesize": 9,
        "xtick.labelsize": 7, "ytick.labelsize": 7,
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.spines.top": False, "axes.spines.right": False,
        "text.usetex": False,
    })
    first_color, second_color = "#225ea8", "#d95f0e"
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 3.75))
    # Separate bands reserve space for the title and a common external legend.
    fig.subplots_adjust(left=0.105, right=0.988, bottom=0.29, top=0.78, wspace=0.40)
    fig.text(0.5, 0.97, "Coupling refinement of the three-mode cosine model", ha="center", va="top", fontsize=10)
    fig.text(0.5, 0.90, r"$\eta=0,\quad\tau=0.2,\quad G=-10^{-2}$", ha="center", va="top", fontsize=9)
    titles = (r"(a) $p=2$", r"(b) $p=4$", r"(c) $p=8$")
    for ax, order, title in zip(axes, PLOT_ORDERS, titles):
        curve = selected["curves"][str(order)]
        for occupation in QUANTA:
            points = curve["occupations"][str(occupation)]
            betas = [p["beta"] for p in points]
            for truncation, color, marker in [("first", first_color, "o"), ("second", second_color, "^")]:
                values = [p[f"absolute_normalized_{truncation}"] or math.nan for p in points]
                ax.loglog(
                    betas, values,
                    color=color, marker=marker,
                    linestyle="--" if occupation == 14 else "-",
                    linewidth=0.9 if occupation == 14 else 1.05,
                    markersize=6.0 if occupation == 14 else 2.7,
                    markerfacecolor="white" if occupation == 14 else color,
                    markeredgewidth=0.8,
                    zorder=3 if occupation == 14 else 4,
                )
        guide = curve["cubic_guide"]
        low, high = min(betas) / 1.13, max(betas) * 1.13
        guide_betas = [low * (high / low)**(i / 49) for i in range(50)]
        guide_values = [guide["height_anchor"] * (b / guide["beta_anchor"])**3 for b in guide_betas]
        ax.loglog(guide_betas, guide_values, ":", color="0.35", linewidth=1.2, zorder=2)
        ax.set_xlim(low, high)
        ax.set_xticks(betas)
        ax.set_xticklabels([f"{b:.3f}" for b in betas], rotation=35, ha="right")
        ax.minorticks_off()
        ax.set_xlabel(r"Coupling $\beta$", labelpad=2)
        ax.set_title(title, pad=5)
        ax.grid(axis="y", which="major", alpha=0.17, linewidth=0.5)
    fig.text(0.018, 0.56, r"Absolute residual $/\,|\kappa_p^{(0)}|$", rotation=90, ha="center", va="center", fontsize=9)
    handles = [
        Line2D([], [], color=first_color, marker="o", markersize=3, linewidth=1, label=r"First order, $Q=16$"),
        Line2D([], [], color=second_color, marker="^", markersize=3, linewidth=1, label=r"Second order, $Q=16$"),
        Line2D([], [], color="0.35", linestyle=":", linewidth=1.2, label=r"$\beta^3$ guide (not fitted)"),
        Line2D([], [], color=first_color, marker="o", markerfacecolor="white", markersize=5, linestyle="--", linewidth=0.9, label=r"First order, $Q=14$"),
        Line2D([], [], color=second_color, marker="^", markerfacecolor="white", markersize=5, linestyle="--", linewidth=0.9, label=r"Second order, $Q=14$"),
    ]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.53, 0.025), ncol=3,
               frameon=False, fontsize=7.5, columnspacing=1.1, handlelength=2.5)
    fig.savefig(pdf_path, format="pdf", metadata={"Title": "Finite-mode cosine coupling refinement", "Author": "Andrei Tudor Pătrașcu"})
    fig.savefig(png_path, format="png", dpi=dpi)
    plt.close(fig)
    return matplotlib.__version__


def manuscript_text(selected: dict[str, Any], data_path: Path, checks_path: Path) -> str:
    rows = selected["coefficient_table"]
    shapes = selected["shape_comparison"]
    lines = [
        "% Generated by research/stage2/build_higher_order_results.py; subsection content only.",
        "% Sources: " + str(data_path.relative_to(ROOT)) + "; " + str(checks_path.relative_to(ROOT)),
        r"The completed cosine refinement retains three continuum modes and compares total-occupation ceilings $Q=14$ and $Q=16$. The circuit is that of Sec.~\ref{sec:expanded-baseline}, with static quartic coefficient $G=-10^{-2}$. This nonlinear budget differs from the $G=-10^{-4}$ used for the bounded continuum variance example. The physical two-point response is calibrated only through first order; its second-order change remains part of the microscopic prediction.",
        r"Table~\ref{tab:stage2-second-order} selects the ordinary pressure observable at $\eta=0$ and $\tau=0.2$. It separates the repeated-quartic contribution $c_{p,2}^{VV}$ from $c_{p,1}[W]$, which includes the quadratic, quartic, and sextic terms in Eq.~\eqref{eq:s2-W}. Their sum is the coefficient of $\beta^2$ in Eq.~\eqref{eq:s2-cumulants}.",
        r"\begin{table*}[t]",
        r"\caption{Finite-three-mode pressure coefficients at $\eta=0$, $\tau=0.2$, $G=-10^{-2}$, and occupation ceiling $Q=16$. The coefficient $c_{p,2}=c_{p,2}^{VV}+c_{p,1}[W]$ multiplies $\beta^2$; it is not the unhalved second derivative. The absolute differences $\Delta_h$ and $\Delta_Q$ describe successive Richardson refinements and the change from $Q=14$ to $Q=16$, respectively. They are empirical diagnostics, not statistical error bars or continuum bounds.}",
        r"\label{tab:stage2-second-order}",
        r"\begingroup\setlength{\tabcolsep}{4pt}\small",
        r"\begin{ruledtabular}\begin{tabular}{ccccccc}",
        r"$p$ & $c_{p,1}$ & $c_{p,2}^{VV}$ & $c_{p,1}[W]$ & $c_{p,2}$ & $\Delta_h$ & $\Delta_Q$\\",
    ]
    for row in rows:
        fields = [str(row["order"])] + [
            "$" + tex_number(row[k]) + "$"
            for k in ("first", "second_vv", "second_w", "second_total", "step_change", "occupation_change")
        ]
        lines.append(" & ".join(fields) + r"\\")
    lines.extend([
        r"\end{tabular}\end{ruledtabular}\endgroup\end{table*}",
        r"Figure~\ref{fig:stage2-second-order} compares the residuals after the first- and complete second-order expansions over $\beta=1/64,1/32,1/16,1/8,1/4$. The displayed powers refer to refinement of the coupling multiplier at fixed averaging time, not to intermittency or a law in averaging scale. The $Q=14$ and $Q=16$ curves are shown separately even where they nearly coincide. The cubic guide is anchored at the largest-$\beta$ second-order residual for $Q=16$; it is not a fitted exponent. The selected comparison does not establish uniform cubic convergence over other allocations, averaging widths, cumulant orders, or mode limits.",
        r"\begin{figure*}[t]",
        r"\includegraphics[width=\textwidth]{figures/stage2_second_order.pdf}",
        r"\caption{Coupling refinement of the ordinary smeared pressure at three retained modes, $\eta=0$, $\tau=0.2$, and $G=-10^{-2}$. Panels show $p=2,4,8$. Blue curves display $|\mathcal E_p^{(1)}|/|\kappa_p^{(0)}|$ and orange curves display $|\mathcal E_p^{(2)}|/|\kappa_p^{(0)}|$, with the residuals defined in Eq.~\eqref{eq:expanded-residuals}. Hollow markers and dashed lines use $Q=14$; smaller filled markers and solid lines use $Q=16$. Dotted curves are anchored $\beta^3$ guides. Lines join calculated coupling values. No statistical error bars or universal residual exponent are inferred.}",
        r"\label{fig:stage2-second-order}\end{figure*}",
    ])
    if selected["zero_residual_points_omitted_from_log_axes"]:
        lines.append(r"Exactly zero residual entries in the saved floating-point data are omitted from logarithmic axes and recorded in the artifact provenance; no artificial positive floor is introduced.")
    lines.extend([
        r"The finite-coupling spectral shape can also be compared directly. At $\beta=1/4$, define the skewness $S_3=\kappa_3/\kappa_2^{3/2}$ and standardized fourth cumulant $S_4^{(c)}=\kappa_4/\kappa_2^2$. The latter equals the excess kurtosis and is distinct from the fourth standardized raw moment. Table~\ref{tab:stage2-shape} compares the harmonic pressure with the full projected cosine at the same $\eta$, $\tau$, and mode set. These are non-Gaussian-shape quantities at one width, not intermittency diagnostics; the harmonic pressure already has nonzero higher cumulants.",
        r"\begin{table*}[t]",
        r"\caption{Standardized pressure cumulants at $\eta=0$, $\tau=0.2$, three retained modes, and full-cosine coupling $\beta=1/4$. The signed change is the $Q=16$ cosine value minus the harmonic value. The last column is the absolute difference between cosine values at $Q=16$ and $Q=14$, not an uncertainty bound.}",
        r"\label{tab:stage2-shape}",
        r"\begin{ruledtabular}\begin{tabular}{ccccc}",
        r"Quantity & harmonic & cosine, $Q=16$ & signed change & occupation change\\",
    ])
    for name, label in [("skewness", r"$S_3$"), ("standardized_fourth_cumulant", r"$S_4^{(c)}$")]:
        fields = [label]
        fields.extend("$" + f"{shapes[k][name]:.9f}" + "$" for k in ("harmonic", "cosine_Q16"))
        fields.extend("$" + tex_number(shapes[k][name]) + "$" for k in ("signed_nonlinear_change", "absolute_occupation_change"))
        lines.append(" & ".join(fields) + r"\\")
    lines.extend([
        r"\end{tabular}\end{ruledtabular}\end{table*}",
        r"These results extend the comparison in nonlinear order at a fixed finite mode set. Agreement between occupation cutoffs, agreement of finite-difference steps, and convergence as line modes are added are separate requirements; the continuum variance bound does not supply a bound for the higher-order coefficients in this table.",
    ])
    return "\n\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default=DEFAULT_DATA, help="Completed project-local cosine JSON")
    parser.add_argument("--checks", default=DEFAULT_CHECKS, help="Project-local saved analysis JSON")
    parser.add_argument("--dpi", type=int, default=300, help="PNG resolution; PDF remains vector")
    args = parser.parse_args()
    if not 100 <= args.dpi <= 1200:
        parser.error("--dpi must be between 100 and 1200")
    data_path = local_path(args.data, must_exist=True)
    checks_path = local_path(args.checks, must_exist=True)
    destinations = {k: local_path(v) for k, v in OUTPUT_NAMES.items()}
    if data_path in destinations.values() or checks_path in destinations.values():
        raise ValueError("A source may not also be an output")
    selected = load_selection(data_path, checks_path)
    tex_source = manuscript_text(selected, data_path, checks_path)
    for path in destinations.values():
        path.parent.mkdir(parents=True, exist_ok=True)

    # Stage every deliverable inside this project; publish the provenance last.
    with tempfile.TemporaryDirectory(prefix=".stage2-second-order-", dir=local_path("paper")) as tmp:
        staged = {k: Path(tmp) / path.name for k, path in destinations.items()}
        matplotlib_version = write_figure(selected, staged["pdf"], staged["png"], args.dpi)
        staged["tex"].write_text(tex_source)
        sources = {"data": data_path, "checks": checks_path, "generator": Path(__file__).resolve()}
        record = {
            "schema_version": 1,
            "status": "ARTIFACTS_GENERATED_REQUIRES_VISUAL_REVIEW",
            "generated_utc": datetime.now(timezone.utc).isoformat(),
            "scope": selected["scope"],
            "sources": {k: {"path": str(v.relative_to(ROOT)), "sha256": sha256(v)} for k, v in sources.items()},
            "outputs": {k: {"path": str(destinations[k].relative_to(ROOT)), "sha256": sha256(staged[k]), "bytes": staged[k].stat().st_size} for k in ("tex", "pdf", "png")},
            "runtime": {"python": platform.python_version(), "matplotlib": matplotlib_version},
            "figure": {"inches": [7.2, 3.75], "png_dpi": args.dpi, "orders": list(PLOT_ORDERS), "error_bars": False},
            "selected_data": selected,
            "interpretation": "Coupling-order convergence and finite-width shape comparison; no intermittency or continuum verdict.",
        }
        staged["provenance"].write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
        for key in ("pdf", "png", "tex", "provenance"):
            staged[key].replace(destinations[key])
    print(json.dumps({
        "status": "ARTIFACTS_GENERATED_REQUIRES_VISUAL_REVIEW",
        "outputs": {k: str(v.relative_to(ROOT)) for k, v in destinations.items()},
        "selection": selected["selection"],
        "zero_residual_points": len(selected["zero_residual_points_omitted_from_log_axes"]),
    }))


if __name__ == "__main__":
    main()
