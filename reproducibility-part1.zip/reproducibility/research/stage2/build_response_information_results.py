"""Sharp finite-family pressure ranges from retained boundary response data.

Saved per-branch first-order coefficients are the only quantum input.  This
script runs small linear programs and produces manuscript artifacts; it never
recomputes line modes or pressure contractions.  Root runs it under the existing
resource guard.  Calibration frequencies depend only on the branch poles.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import tempfile
from typing import Any

import numpy as np

from build_higher_order_results import ROOT, local_path, sha256, tex_number

sys.path.insert(0, str(ROOT / "research/agents"))
from response_information_closure import calibration_matrix, closure_interval


DEFAULT_DATA = [
    "results/stage2_2026-09-15/infrared_r2_r6_modes12_16.json",
    "results/stage2_2026-09-15/infrared_r10_r14_modes20.json",
]
DEFAULT_CONTROLS = "results/stage2_2026-09-15/closure_information_controls.json"
BRANCH_COUNTS = (6, 10, 14)
ORDERS = (4, 6, 8)
MOMENT_FLOOR = 1e-250
OUTPUTS = {
    "tex": "paper/stage2_closure_results.tex",
    "pdf": "paper/figures/stage2_closure_information.pdf",
    "png": "paper/figures/stage2_closure_information.png",
    "provenance": "paper/stage2_closure_provenance.json",
}


def normalized_weights(case: dict[str, Any], allocation: str) -> np.ndarray:
    weights = np.asarray(case["allocations"][allocation]["u"], dtype=float) * 0.25**4 / float(case["G"])
    if not np.all(np.isfinite(weights)) or np.any(weights < 0) or abs(weights.sum() - 1) > 1e-12:
        raise ValueError("Stored nonlinear allocation does not define normalized nonnegative weights")
    if allocation == "uniform" and not np.allclose(weights, 1 / len(weights), rtol=0, atol=1e-13):
        raise ValueError("The stored uniform allocation is not uniform")
    return weights


def frequency_design(poles: list[float]) -> dict[str, Any]:
    """Endpoints, then widest log-interval bisection; no pressure input."""
    values = np.asarray(poles, dtype=float)
    if values.ndim != 1 or len(values) < 2 or not np.all(np.isfinite(values)):
        raise ValueError("A finite list of distinct positive branch poles is required")
    if np.any(values <= 0) or np.any(np.diff(values) <= 0):
        raise ValueError("Branch poles must be strictly increasing")
    logs = np.log(values)
    priority = [0, len(values) - 1]
    while len(priority) < len(values):
        ordered = sorted(priority)
        gaps = [(float(logs[j] - logs[i]), i, j) for i, j in zip(ordered[:-1], ordered[1:]) if j - i > 1]
        # Width first, then lower endpoint: deterministic ties.
        _, left, right = min(gaps, key=lambda item: (-round(item[0], 13), item[1]))
        midpoint = (logs[left] + logs[right]) / 2
        index = min(range(left + 1, right), key=lambda k: (round(abs(float(logs[k] - midpoint)), 13), k))
        priority.append(index)
    counts = sorted({0, 1, 2, 4, min(8, len(values)), len(values)})
    stages = []
    for count in counts:
        indices = priority[:count]
        stages.append({
            "positive_frequency_count": count,
            "pole_indices_zero_based": indices,
            "positive_frequencies": [float(values[i]) for i in indices],
            "all_poles": count == len(values),
        })
    return {
        "rule": "smallest pole, largest pole, then bisect widest remaining logarithmic pole interval; ties favor lower indices",
        "pressure_independent": True,
        "priority_pole_indices_zero_based": priority,
        "stages": stages,
    }


def load_cases(paths: list[Path]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    indexed: dict[tuple[int, int, float], dict[str, Any]] = {}
    sources = {}
    for path in paths:
        data = json.loads(path.read_text())
        if data.get("status") != "COMPLETED":
            raise ValueError(f"Input is not COMPLETED: {path.name}")
        sources[str(path.relative_to(ROOT))] = {
            "sha256": sha256(path), "parameters": data["parameters"],
            "reported_driver_hashes": data.get("source_sha256"),
        }
        for index, case in enumerate(data["cases"]):
            if case["family"] != "extend_ir" or int(case["branches"]) not in BRANCH_COUNTS:
                continue
            key = (int(case["branches"]), int(case["modes"]), float(case["tau"]))
            if key in indexed:
                raise ValueError(f"Duplicate physical case {key}; supply one source for each regulator and width")
            if len(case["branch_moment_coefficients"]) != key[0] or len(case["bare_poles"]) != key[0]:
                raise ValueError(f"Incomplete branch data at {key}")
            if not math.isclose(float(case["static_linear_loading"]), 3 / 16, abs_tol=1e-13, rel_tol=0):
                raise ValueError("This response slice requires the specified fixed-loading family")
            if float(case["G"]) >= 0 or not math.isfinite(float(case["G"])):
                raise ValueError("This stable-cosine allocation family requires finite negative G")
            indexed[key] = {"case": case, "source_path": str(path.relative_to(ROOT)), "source_index": index}
    selected = []
    selection = {}
    for branches in BRANCH_COUNTS:
        candidates = [item for key, item in indexed.items() if key[0] == branches]
        if not candidates:
            raise ValueError(f"No completed R={branches} data")
        modes = max(int(item["case"]["modes"]) for item in candidates)
        rows = sorted([item for item in candidates if item["case"]["modes"] == modes], key=lambda item: item["case"]["tau"])
        selection[str(branches)] = {
            "selected_modes": modes,
            "available_modes": sorted({int(item["case"]["modes"]) for item in candidates}),
            "tau": [float(item["case"]["tau"]) for item in rows],
            "rule": "highest supplied mode count for the entire branch family, never mixed by width",
        }
        selected.extend(rows)
    budgets = {float(item["case"]["G"]) for item in selected}
    if len(budgets) != 1:
        raise ValueError("The displayed hierarchy comparison requires a common static quartic budget")
    return selected, {"inputs": sources, "selection": selection, "static_G": next(iter(budgets))}


def coefficients(case: dict[str, Any], order: int) -> dict[str, Any]:
    harmonic = case["harmonic_moments"]
    m2, mp = float(harmonic["2"]), float(harmonic[str(order)])
    if not math.isfinite(m2) or not math.isfinite(mp) or min(m2, mp) <= MOMENT_FLOOR:
        return {"status": "UNRESOLVED_MOMENT", "reason": "harmonic moment is nonfinite or at/below the declared 1e-250 floor", "harmonic_M2": m2 if math.isfinite(m2) else None, "harmonic_Mp": mp if math.isfinite(mp) else None}
    prefactor = float(case["G"]) / 0.25**4
    branch = case["branch_moment_coefficients"]
    with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
        term_p = prefactor * np.asarray([r[str(order)] for r in branch], dtype=float) / mp
        term_2 = prefactor * (order / 2) * np.asarray([r["2"] for r in branch], dtype=float) / m2
        coefficient = term_p - term_2
    if not np.all(np.isfinite(coefficient)) or not np.all(np.isfinite(term_p)) or not np.all(np.isfinite(term_2)):
        return {"status": "UNRESOLVED_MOMENT", "reason": "nonfinite branchwise ratio or cancellation terms"}
    return {"status": "READY", "coefficient": coefficient, "term_p": term_p, "term_2": term_2, "harmonic_M2": m2, "harmonic_Mp": mp}


def analyze(selected_cases: list[dict[str, Any]], allocations: list[str]) -> dict[str, Any]:
    designs: dict[str, Any] = {}
    rows: list[dict[str, Any]] = []
    unresolved: list[dict[str, Any]] = []
    audit_findings: list[dict[str, Any]] = []
    for source in selected_cases:
        case = source["case"]
        branches = int(case["branches"])
        poles = np.asarray(case["bare_poles"], dtype=float)
        design = frequency_design(case["bare_poles"])
        if str(branches) in designs and designs[str(branches)] != design:
            raise ValueError("Boundary poles changed between widths of one family")
        designs[str(branches)] = design
        for allocation in allocations:
            weights = normalized_weights(case, allocation)
            for order in ORDERS:
                base = {"branches": branches, "modes": int(case["modes"]), "tau": float(case["tau"]), "G": float(case["G"]), "order": order, "allocation": allocation, "source_path": source["source_path"], "source_index": source["source_index"]}
                ready = coefficients(case, order)
                if ready["status"] != "READY":
                    unresolved.append({**base, **ready})
                    continue
                c = ready["coefficient"]
                actual = float(c @ weights)
                stored = case["allocations"][allocation]["log_standardized_harmonic_ratio_derivative"].get(str(order))
                scale_terms = float(np.abs(ready["term_p"]) @ weights + np.abs(ready["term_2"]) @ weights)
                consistency_tolerance = 256 * np.finfo(float).eps * max(scale_terms, abs(actual), 1e-300)
                if stored is None or not math.isfinite(float(stored)):
                    unresolved.append({**base, "status": "UNRESOLVED_REFERENCE", "reason": "stored allocated A1 is unresolved"})
                    continue
                consistency_error = abs(actual - float(stored))
                if consistency_error > consistency_tolerance:
                    raise ArithmeticError(f"Branch reconstruction disagrees with saved A1: {base}, {consistency_error}, {consistency_tolerance}")
                previous = None
                for stage in design["stages"]:
                    try:
                        interval = closure_interval(c, poles, stage["positive_frequencies"], weights)
                    except ArithmeticError as error:
                        unresolved.append({**base, "positive_frequency_count": stage["positive_frequency_count"], "status": "LP_UNRESOLVED", "reason": str(error)})
                        continue
                    A = calibration_matrix(poles, interval["frequencies"])
                    target = A @ weights
                    norm_c = float(np.sum(abs(c)))
                    # A numerical audit scale, not a rigorous objective error bound.
                    audit_tolerance = 5e-8 * max(norm_c, 1e-300)
                    flags = []
                    if interval["width"] < 0:
                        flags.append("negative_width_from_numerical_endpoint_order")
                    if not interval["lower"]["observable"] - audit_tolerance <= actual <= interval["upper"]["observable"] + audit_tolerance:
                        flags.append("true_allocation_outside_interval_beyond_audit_scale")
                    if previous is not None and interval["width"] > previous + audit_tolerance:
                        flags.append("nested_information_width_increased_beyond_audit_scale")
                    if stage["positive_frequency_count"] == 0:
                        static_error = max(abs(interval["lower"]["observable"] - float(c.min())), abs(interval["upper"]["observable"] - float(c.max())))
                        if static_error > audit_tolerance:
                            flags.append("static_simplex_control_disagreement")
                    else:
                        static_error = None
                    for endpoint in ("lower", "upper"):
                        witness = np.asarray(interval[endpoint]["weights"])
                        interval[endpoint]["normalization_residual"] = abs(float(witness.sum() - 1))
                        interval[endpoint]["minimum_weight"] = float(witness.min())
                        interval[endpoint]["recomputed_calibration_residual"] = float(np.max(abs(A @ witness - target)))
                        interval[endpoint]["objective_reconstruction_error"] = abs(float(c @ witness) - interval[endpoint]["observable"])
                    if stage["all_poles"] and interval["calibration_rank"] != branches:
                        flags.append("all_pole_sample_is_not_numerically_full_column_rank")
                    if interval["calibration_rank"] == branches and abs(interval["width"]) > audit_tolerance:
                        flags.append("full_rank_interval_exceeds_numerical_audit_scale")
                    if flags:
                        audit_findings.append({**base, "positive_frequency_count": stage["positive_frequency_count"], "flags": flags})
                    rows.append({
                        **base, **stage, "status": "COMPUTED" if not flags else "REVIEW_REQUIRED",
                        "coefficient": c.tolist(), "true_weights": weights.tolist(), "calibration_targets": target.tolist(),
                        "interval": interval, "coefficient_l1": norm_c,
                        "stored_A1": float(stored), "branch_reconstruction_error": consistency_error,
                        "branch_roundoff_diagnostic_scale": consistency_tolerance,
                        "numerical_audit_scale_not_error_bound": audit_tolerance,
                        "static_simplex_error": static_error, "audit_flags": flags,
                        "harmonic_M2": ready["harmonic_M2"], "harmonic_Mp": ready["harmonic_Mp"],
                    })
                    previous = interval["width"]
    return {"rows": rows, "unresolved": unresolved, "audit_findings": audit_findings, "frequency_designs": designs}


def display_rows(result: dict[str, Any], tau: float, allocation: str) -> list[dict[str, Any]]:
    return [r for r in result["rows"] if math.isclose(r["tau"], tau, rel_tol=0, abs_tol=1e-12) and r["allocation"] == allocation]


def make_figure(result: dict[str, Any], selection: dict[str, Any], tau: float, allocation: str, pdf: Path, png: Path) -> str:
    cache = local_path("tmp/matplotlib_stage2_closure")
    cache.mkdir(parents=True, exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(cache)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 9, "xtick.labelsize": 7, "ytick.labelsize": 7, "pdf.fonttype": 42, "ps.fonttype": 42, "axes.spines.top": False, "axes.spines.right": False, "text.usetex": False})
    shown = display_rows(result, tau, allocation)
    colors = {4: "#225ea8", 6: "#756bb1", 8: "#d95f0e"}
    markers = {4: "o", 6: "s", 8: "^"}
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 5.6))
    fig.subplots_adjust(left=0.10, right=0.985, bottom=0.17, top=0.82, wspace=0.58, hspace=0.45)
    fig.text(0.5, 0.98, "Pressure-prediction ranges from retained boundary response", ha="center", va="top", fontsize=10)
    allocation_label = "uniform allocation" if allocation == "uniform" else "allocation eta = 0.5"
    fig.text(0.5, 0.915, rf"Fixed averaging width $\tau={tau:g}$; " + allocation_label, ha="center", va="top", fontsize=9)
    for column, branches in enumerate(BRANCH_COUNTS):
        family = [r for r in shown if r["branches"] == branches]
        positive_widths = [r["interval"]["width"] for r in family if r["status"] == "COMPUTED" and r["interval"]["width"] > 0]
        exponent = max(-300, min(300, math.floor(math.log10(max(positive_widths))))) if positive_widths else 0
        scale = 10.0**exponent
        top, bottom = axes[:, column]
        stages = [s["positive_frequency_count"] for s in result["frequency_designs"][str(branches)]["stages"]]
        any_curve = False
        for order in ORDERS:
            rows = sorted([r for r in family if r["order"] == order], key=lambda r: r["positive_frequency_count"])
            lookup = {r["positive_frequency_count"]: r for r in rows}
            widths = [lookup[k]["interval"]["width"] if k in lookup and lookup[k]["status"] == "COMPUTED" else math.nan for k in stages]
            if any(math.isfinite(w) for w in widths):
                any_curve = True
            denominator = widths[0]
            fractions = [w / denominator if math.isfinite(denominator) and denominator > 0 else math.nan for w in widths]
            top.plot(stages, [w / scale for w in widths], color=colors[order], marker=markers[order], markersize=3.5, linewidth=1.1)
            bottom.plot(stages, fractions, color=colors[order], marker=markers[order], markersize=3.5, linewidth=1.1)
        modes = selection[str(branches)]["selected_modes"]
        top.set_title(f"({chr(97 + column)}) R = {branches}, M = {modes}", pad=5)
        top.set_ylabel("Interval width\n" + rf"$W_{{p,1}}$ ($10^{{{exponent}}}$)", labelpad=2)
        bottom.set_ylabel("Fraction of static-only\ninterval width", labelpad=2)
        bottom.set_xlabel("Positive calibration\nfrequencies K", labelpad=3)
        for ax in (top, bottom):
            ax.set_xticks(stages)
            ax.set_xlim(-0.35, stages[-1] + 0.35)
            ax.grid(axis="y", alpha=0.16, linewidth=0.5)
        top.set_ylim(bottom=0)
        bottom.set_ylim(-0.04, 1.07)
        if not any_curve:
            top.text(0.5, 0.5, "No resolved moments", transform=top.transAxes, ha="center", va="center", fontsize=8, bbox={"facecolor": "white", "edgecolor": "none"})
    handles = [Line2D([], [], color=colors[p], marker=markers[p], linewidth=1.1, markersize=4, label=rf"Moment order $p={p}$") for p in ORDERS]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.52, 0.015), ncol=3, frameon=False, fontsize=8)
    fig.savefig(pdf, format="pdf", metadata={"Title": "Finite-family boundary response information", "Author": "Andrei Tudor Pătrașcu"})
    fig.savefig(png, format="png", dpi=300)
    plt.close(fig)
    return matplotlib.__version__


def manuscript(result: dict[str, Any], selection: dict[str, Any], tau: float, allocation: str) -> str:
    shown = display_rows(result, tau, allocation)
    allocation_tex = r"uniform allocation $w_r=1/R$" if allocation == "uniform" else r"the mixed allocation $\eta=1/2$"
    lines = [
        "% Generated subsection content; root controls its placement in the manuscript.",
        r"We next quantify the pressure information left undetermined by a specified nonlinear boundary calibration. For the fixed static budget, write $u_r=G w_r/(1/4)^4$, with $w_r\geq0$ and $\sum_rw_r=1$. The first-order shape coefficient is $A_{p,1}=\sum_r c_{p,r}w_r$, where",
        r"\begin{equation}c_{p,r}=\frac{G}{(1/4)^4}\left[\frac{m_{p,1}^{(r)}}{M_p^{(0)}}-\frac p2\frac{m_{2,1}^{(r)}}{M_2^{(0)}}\right].\label{eq:stage2-information-coefficient}\end{equation}",
        r"Here $m_{p,1}^{(r)}$ is the derivative of the increment moment per unit branch coupling $u_r$, rather than the coefficient after a nonlinear allocation has already been selected. The harmonic model, geometry, pressure, and averaging width are fixed within each comparison.",
        r"A normalized four-field response sample at Euclidean frequency $\xi$ has the form",
        r"\begin{equation}\frac{\Gamma_4(\xi,-\xi,0,0)}{G}=\sum_r w_r\left(\frac{\Omega_r^2}{\Omega_r^2+\xi^2}\right)^2.\label{eq:stage2-information-response}\end{equation}",
        r"The zero-frequency row fixes the total budget. For additional frequencies let $A$ be the matrix of the displayed response factors, including that static row, and let $y=Aw^{\rm true}$ be the ideal response data of the specified allocation. The minimum and maximum of $\sum_rc_{p,r}w_r$ subject to $Aw=y$ and $w\geq0$ define the sharp finite-family prediction interval. We evaluate these extrema numerically and retain the endpoint allocations and constraint residuals. The range measures incomplete response information, not an error bar on a chosen reconstruction or a model of experimental noise.",
        r"The positive frequencies are chosen before considering any pressure width or moment order. We select the smallest and largest branch poles, then successively bisect the widest remaining logarithmic pole interval, using the lower index to resolve ties. The retained sets are nested. They contain one, two, four, and eight positive frequencies where available, followed by every distinct pole frequency; for six branches the last such set contains six frequencies. Frequencies use the same inverse-time units as the line and branch spectrum.",
        r"With only the static row, the interval is exactly $[\min_r c_{p,r},\max_r c_{p,r}]$. Each new response row can only restrict the allowed allocations. We compute an orthonormal nullspace basis $N$ from a singular-value decomposition and write $w=w^{\rm true}+Nz$, so the optimization imposes only $-Nz\leq w^{\rm true}$. This parameterization represents the same ideal-data allocation set. If $A$ has full column rank, its nullspace is zero and the interval is structurally the singleton $\{c_p\cdot w^{\rm true}\}$; its zero width is not obtained by clipping a computed linear-programming width. The record retains the rank threshold, singular values, nullspace residuals, endpoint allocations, and original-constraint residuals. For nonzero nullspace dimension, objective rescaling and primal and dual solver tolerances $10^{-10}$ are used. Each witness must satisfy the original normalized response equations, total-weight constraint, and nonnegativity to absolute tolerance $10^{-10}$. These are finite-dimensional numerical checks, not bounds on pressure-mode or finite-coupling errors.",
        "Figure~\\ref{fig:stage2-information} selects " + allocation_tex + rf" and $\tau={tau:g}$. The raw interval width $W_{{p,1}}$ is dimensionless per unit of the dimensionless coupling multiplier $\beta$; the lower panels divide it by its static-only value. Every branch count retains its own harmonic reference. Mode counts are " + ", ".join(f"$M={selection[str(r)]['selected_modes']}$ for $R={r}$" for r in BRANCH_COUNTS) + ". The common static branch loading is $3/16$ and the quartic budget is $G=" + tex_number(result["static_G"]) + "$.",
        r"\begin{figure*}[t]\includegraphics[width=\textwidth]{figures/stage2_closure_information.pdf}",
        r"\caption{Dependence of the first-order pressure-shape prediction range on retained four-field boundary data. The upper panels show the width of the allowed $A_{p,1}$ interval in the displayed dimensionless units; the lower panels show its fraction of the static-only interval. Colors identify $p=4,6,8$. The horizontal coordinate counts positive-frequency samples, with the zero-frequency budget constraint always included. Lines join nested calibration sets, rather than averaging-scale samples. Thus this figure measures response-information closure, not an intermittency exponent. Unresolved moments or flagged numerical intervals are omitted, without clipping or introducing a positive floor.}\label{fig:stage2-information}\end{figure*}",
        r"\begin{table*}[t]\caption{Selected eighth-moment shape intervals for the allocation and averaging width of Fig.~\ref{fig:stage2-information}. For each branch count the static-only, four-frequency, and all-pole sets are shown. Here $K$ counts the positive-frequency samples; the zero-frequency row is additional. Rank includes the zero-frequency row. The final column is the larger endpoint residual $\|Aw-y\|_\infty$; it is not a bound on the pressure-mode error.}\label{tab:stage2-information}",
        r"\begingroup\small\setlength{\tabcolsep}{4pt}\begin{ruledtabular}\begin{tabular}{ccccccc}",
        r"$R$ & $K$ & rank & lower $A_{8,1}$ & upper $A_{8,1}$ & interval width & witness residual\\",
    ]
    for branches in BRANCH_COUNTS:
        for count in (0, 4, branches):
            candidates = [r for r in shown if r["branches"] == branches and r["order"] == 8 and r["positive_frequency_count"] == count]
            if not candidates:
                missing = [r for r in result["unresolved"] if r["branches"] == branches and r["order"] == 8 and r["allocation"] == allocation and math.isclose(r["tau"], tau, rel_tol=0, abs_tol=1e-12) and (r.get("positive_frequency_count") == count or "positive_frequency_count" not in r)]
                label = "optimization unresolved" if any(r["status"] == "LP_UNRESOLVED" for r in missing) else "moment or reference unresolved" if missing else "not evaluated"
                lines.append(f"{branches} & {count}" + r" & \multicolumn{5}{c}{" + label + r"}\\")
                continue
            row = candidates[0]
            interval = row["interval"]
            if row["status"] != "COMPUTED":
                lines.append(f"{branches} & {count} & {interval['calibration_rank']}" + r" & \multicolumn{4}{c}{numerical interval requires review}\\")
                continue
            values = [interval["lower"]["observable"], interval["upper"]["observable"], interval["width"], max(interval[end]["recomputed_calibration_residual"] for end in ("lower", "upper"))]
            lines.append(f"{branches} & {count} & {interval['calibration_rank']} & " + " & ".join("$" + tex_number(x, 4) + "$" for x in values) + r"\\")
    lines.extend([
        r"\end{tabular}\end{ruledtabular}\endgroup\end{table*}",
        r"The intervals use completed per-branch first derivatives, not a fit to the pressure data. The saved analysis reconstructs the supplied allocation values from these branch coefficients and checks the static simplex range, nesting, and endpoint constraints. It carries unresolved small harmonic moments explicitly. The first-order comparison does not impose second-order two-point matching or control the finite-$\beta$ remainder. Numerical mode refinement and measurement uncertainty are also separate from the ideal response-information range.",
    ])
    if result["audit_findings"]:
        lines.append(f"The present analysis records {len(result['audit_findings'])} numerical audit findings; the corresponding intervals require review and are not presented as resolved bounds.")
    unresolved_lp = sum(row["status"] == "LP_UNRESOLVED" for row in result["unresolved"])
    if unresolved_lp:
        lines.append(f"The optimization did not resolve {unresolved_lp} calibration sets; those intervals are also omitted. These solver failures are distinct from exclusions due to unresolved harmonic moments.")
    return "\n\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", nargs="+", default=DEFAULT_DATA)
    parser.add_argument("--controls", default=DEFAULT_CONTROLS)
    parser.add_argument("--allocations", nargs="+", choices=["uniform", "eta_0.5"], default=["uniform"])
    parser.add_argument("--figure-allocation", choices=["uniform", "eta_0.5"], default="uniform")
    parser.add_argument("--figure-tau", type=float, default=0.8)
    args = parser.parse_args()
    if args.figure_allocation not in args.allocations:
        parser.error("The figure allocation must be included in --allocations")
    if not math.isfinite(args.figure_tau) or args.figure_tau <= 0:
        parser.error("A positive finite figure width is required")
    paths = [local_path(path, must_exist=True) for path in args.data]
    if len(set(paths)) != len(paths):
        parser.error("Input paths must be distinct")
    control_path = local_path(args.controls, must_exist=True)
    controls = json.loads(control_path.read_text())
    if controls.get("status") != "PASS":
        raise ValueError("The known closure-information controls must pass first")
    cases, metadata = load_cases(paths)
    for branches in BRANCH_COUNTS:
        if not any(math.isclose(t, args.figure_tau, rel_tol=0, abs_tol=1e-12) for t in metadata["selection"][str(branches)]["tau"]):
            raise ValueError(f"Preselected figure width missing for R={branches}")
    result = analyze(cases, list(dict.fromkeys(args.allocations)))
    result.update({
        "schema_version": 1, "status": "COMPLETED",
        "validation_status": "REVIEW_REQUIRED" if result["audit_findings"] or any(row["status"] == "LP_UNRESOLVED" for row in result["unresolved"]) else "NO_INTERVAL_AUDIT_FLAGS",
        "scope": "ideal response-information ranges of first-order increment-shape derivatives at finite line-mode regulators",
        "metadata": metadata,
        "static_G": metadata["static_G"],
        "selection_parameters": vars(args),
        "moment_floor": MOMENT_FLOOR,
        "known_control_source": {"path": str(control_path.relative_to(ROOT)), "sha256": sha256(control_path)},
    })
    code_paths = [Path(__file__).resolve(), ROOT / "research/agents/response_information_closure.py", ROOT / "research/stage2/build_higher_order_results.py"]
    code_hashes = {str(p.relative_to(ROOT)): sha256(p) for p in code_paths}
    fingerprint = hashlib.sha256(json.dumps({"inputs": metadata["inputs"], "allocations": args.allocations, "figure_tau": args.figure_tau, "figure_allocation": args.figure_allocation, "code": code_hashes, "controls": sha256(control_path)}, sort_keys=True).encode()).hexdigest()[:16]
    destinations = {key: local_path(path) for key, path in OUTPUTS.items()}
    destinations["analysis"] = local_path(f"results/stage2_2026-09-15/response_information_physical_{fingerprint}.json")
    for path in destinations.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    tex = manuscript(result, metadata["selection"], args.figure_tau, args.figure_allocation)
    with tempfile.TemporaryDirectory(prefix=".stage2-closure-", dir=local_path("paper")) as tmp:
        staged = {key: Path(tmp) / path.name for key, path in destinations.items()}
        version = make_figure(result, metadata["selection"], args.figure_tau, args.figure_allocation, staged["pdf"], staged["png"])
        staged["analysis"].write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
        staged["tex"].write_text(tex)
        import scipy
        provenance = {
            "status": "ARTIFACTS_GENERATED_REQUIRES_VISUAL_AND_SCIENTIFIC_REVIEW",
            "generated_utc": datetime.now(timezone.utc).isoformat(),
            "inputs": metadata["inputs"], "controls": result["known_control_source"],
            "code_sha256": code_hashes,
            "outputs": {key: {"path": str(destinations[key].relative_to(ROOT)), "sha256": sha256(staged[key]), "bytes": staged[key].stat().st_size} for key in ("analysis", "tex", "pdf", "png")},
            "runtime": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__, "matplotlib": version},
            "computed_intervals": len(result["rows"]), "unresolved_records": len(result["unresolved"]),
            "audit_findings": len(result["audit_findings"]),
            "frequency_selection_is_independent_of_pressure_data": True,
            "figure_width_preselected": args.figure_tau,
            "scope": result["scope"],
        }
        staged["provenance"].write_text(json.dumps(provenance, indent=2, allow_nan=False) + "\n")
        for key in ("analysis", "pdf", "png", "tex", "provenance"):
            staged[key].replace(destinations[key])
    print(json.dumps({"status": provenance["status"], "computed_intervals": len(result["rows"]), "unresolved_records": len(result["unresolved"]), "audit_findings": len(result["audit_findings"]), "outputs": {key: str(path.relative_to(ROOT)) for key, path in destinations.items()}}))


if __name__ == "__main__":
    main()
