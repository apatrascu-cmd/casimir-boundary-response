"""Next cosine order and ordered cumulants: explicit finite-regulator pilot.

The beta^2 coefficient includes two V4 insertions and the full sextic potential
expressed in normal order, with only the original first-order calibration.
The repeated-quartic coefficient is independently step-refined by symmetric
finite differences; no all-mode theorem is inferred from this pilot.
"""
from pathlib import Path
import sys,json,math,time,hashlib,argparse
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research')]
from nonlinear_pressure import continuum_pressure_modes,first_order_cumulants,exact_spectral_cumulants,harmonic_pressure
from static_family import family_couplings,branch_problem,independent_cosine

def vector(d,n):return np.array([d[str(k)] for k in range(1,n+1)])
def serial(a):return {str(i+1):float(x) for i,x in enumerate(a)}
def raw_moments(k):
    m=[1.]
    for n in range(1,len(k)+1):m.append(sum(math.comb(n-1,j-1)*k[j-1]*m[n-j] for j in range(1,n+1)))
    return m[1:]

def second_cosine_vertex(f,modes,u,even):
    W=np.zeros((len(even),len(even)))
    for KJ,ur,(b,var) in zip(modes.p.KJ,u,f.branch_data(modes)):
        if ur==0:continue
        for degree,coefficient in [(2,var*var/16),(4,var/48),(6,1/720)]:
            W+=ur*ur/KJ*coefficient*f.normal_power(b,degree)[even][:,even].toarray()
    return (W+W.T)/2

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--modes',type=int,default=3)
    ap.add_argument('--quanta',type=int,nargs='+',default=[12,14]);ap.add_argument('--tau',type=float,nargs='+',default=[.2,.4,.8]);ap.add_argument('--eta',type=float,nargs='+',default=[0,.5,1]);ap.add_argument('--G',type=float,default=-.01);ap.add_argument('--order',type=int,default=8);ap.add_argument('--increments',action='store_true');ap.add_argument('--beta',type=float,nargs='+',default=[.25,.125,.0625,.03125]);a=ap.parse_args()
    dest=(ROOT/a.output).resolve()
    if not dest.is_relative_to(ROOT):raise ValueError('Project-local output required')
    if any(b<=0 for b in a.beta):raise ValueError('Cosine beta values must be positive')
    if dest.exists():raise FileExistsError(dest)
    dest.parent.mkdir(parents=True,exist_ok=True);start=time.monotonic()
    result={'status':'RUNNING','scope':'finite modes and occupation; first-order matching only','parameters':vars(a),'cases':[],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    def save():
        result['elapsed_seconds']=time.monotonic()-start
        temp=dest.with_suffix('.tmp');temp.write_text(json.dumps(result,indent=2));temp.replace(dest)
    save();modes=continuum_pressure_modes(a.modes)
    result['omega']=modes.omega.tolist()
    for Q in a.quanta:
        f,even,E,P,vertices=branch_problem(modes,Q,max_dimension=5000);H0=np.diag(E)
        for eta in a.eta:
            u=family_couplings(modes.p,eta,a.G);V=sum(x*y for x,y in zip(u,vertices));W=second_cosine_vertex(f,modes,u,even)
            # Directly check the beta^2 Hamiltonian coefficient against the projected cosine.
            matrix_check=[]
            for beta in [.02,.01,.005]:
                exact=independent_cosine(f,modes,beta*u)[np.ix_(even,even)]
                matrix_check.append({'beta':beta,'coefficient_residual_norm':float(np.linalg.norm((exact-beta*V)/(beta*beta)-W))})
            cosines={beta:H0+independent_cosine(f,modes,beta*u)[np.ix_(even,even)] for beta in a.beta}
            for inc in ([False,True] if a.increments else [False]):
                for tau in a.tau:
                    first=first_order_cumulants(E,P,V,tau,a.order,modes.p.hbar,inc);baseline=vector(first['harmonic_cumulants'],a.order);c1=vector(first['delta_cumulants'],a.order)
                    direct0=vector(exact_spectral_cumulants(H0,P,tau,a.order,modes.p.hbar,inc),a.order)
                    analytic0=vector(harmonic_pressure(modes,tau,a.order,inc),a.order)
                    harmonic_error=float(np.max(abs(baseline-analytic0)/np.maximum(abs(analytic0),1.)))
                    if harmonic_error>2e-10:raise AssertionError(('harmonic cutoff',Q,tau,inc,harmonic_error))
                    c2_sextic=vector(first_order_cumulants(E,P,W,tau,a.order,modes.p.hbar,inc)['delta_cumulants'],a.order)
                    steps=[.1,.05,.025];second=[];first_checks=[]
                    for h in steps:
                        plus=vector(exact_spectral_cumulants(H0+h*V,P,tau,a.order,modes.p.hbar,inc),a.order)
                        minus=vector(exact_spectral_cumulants(H0-h*V,P,tau,a.order,modes.p.hbar,inc),a.order)
                        second.append((plus+minus-2*direct0)/(2*h*h));first_checks.append((plus-minus)/(2*h))
                    vv_coarse=(4*second[1]-second[0])/3;vv_fine=(4*second[2]-second[1])/3
                    c2=vv_fine+c2_sextic
                    tests=[]
                    for beta,H in cosines.items():
                        exact=vector(exact_spectral_cumulants(H,P,tau,a.order,modes.p.hbar,inc),a.order)
                        residual1=exact-baseline-beta*c1;residual2=residual1-beta*beta*c2
                        moments=np.array(raw_moments(exact))
                        if any(moments[n-1]<-1e-10 for n in range(2,a.order+1,2)):raise AssertionError('negative even spectral moment')
                        tests.append({'beta':beta,'exact_cumulants':serial(exact),'raw_moments':serial(moments),'residual_after_first_order':serial(residual1),'residual_after_second_order':serial(residual2)})
                    row={'quanta':Q,'dimension':len(E),'eta':eta,'u':u.tolist(),'tau':tau,'increment':inc,'harmonic_cumulants':serial(baseline),'first_order':serial(c1),'second_repeated_quartic':serial(vv_fine),'second_sextic_and_contractions':serial(c2_sextic),'second_total':serial(c2),'second_step_refinement_absolute':serial(abs(vv_fine-vv_coarse)),'second_steps':steps,'first_symmetric_derivative':serial(first_checks[-1]),'first_symmetric_error_absolute':serial(abs(first_checks[-1]-c1)),'harmonic_relative_error':harmonic_error,'hamiltonian_second_order_checks':matrix_check,'cosine_checks':tests}
                    result['cases'].append(row);save();print(json.dumps({k:row[k] for k in ['quanta','eta','tau','increment','dimension']}),flush=True)
    result['status']='COMPLETED';result['interpretation']='Coefficient and cutoff errors require analysis; completion is not an intermittency result.';save();print(json.dumps({'status':result['status'],'cases':len(result['cases']),'elapsed_seconds':result['elapsed_seconds']}),flush=True)
if __name__=='__main__':main()
