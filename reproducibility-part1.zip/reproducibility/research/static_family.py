"""Matched static quartic family; independent branch couplings and stable cosine."""
from pathlib import Path
import sys, math
import numpy as np
from scipy.sparse import csr_matrix
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from nonlinear_pressure import FockRegulator


def family_couplings(p,eta,G=-1e-4):
    if not 0<=eta<=1: raise ValueError('eta must be in [0,1]')
    h0=np.asarray(p.Kc)/(np.asarray(p.Kc)+np.asarray(p.Kg)+np.asarray(p.KJ))
    return G*np.array([eta,1-eta])/h0**4


def sparse_pressure(f,modes):
    """Project the normally ordered spatial pressure before dense conversion."""
    d=f.collective(modes.slope*np.sqrt(modes.p.hbar/(2*modes.omega)))
    z=f.collective(modes.endpoint*np.sqrt(modes.p.hbar*modes.omega/2))
    return (d.T@d+.5*(d.T@d.T+d@d))/modes.p.L0 + modes.p.C0*(z.T@z-.5*(z.T@z.T+z@z))


def branch_problem(modes,quanta=6,energy=None,max_dimension=10000):
    f=FockRegulator(modes.omega,quanta,energy,modes.p.hbar,max_dimension)
    even=np.flatnonzero(f.states.sum(axis=1)%2==0)
    P=sparse_pressure(f,modes)[even][:,even].toarray()
    vertices=[(f.normal_power(b,4)/24)[even][:,even].toarray() for b,_ in f.branch_data(modes)]
    return f,even,f.energies[even],P,vertices


def independent_cosine(f,modes,couplings):
    """Exact P cos(c_r q_r) P with branch c_r=sqrt(-u_r/KJ_r).

    The normal-ordered expansion terminates at degree 2Q under total occupation
    Q. Writing the residual in this basis avoids cancellation of harmonic terms.
    The O(c_r^2) tadpole calibration uses this regulator's vacuum covariance.
    """
    out=csr_matrix(f.identity.shape)
    for KJ,u,(b,var) in zip(modes.p.KJ,couplings,f.branch_data(modes)):
        if u>0: raise ValueError('Stable cosine control requires nonpositive quartic coupling')
        if u==0: continue
        c2=-u/KJ; s=c2*var
        # exp(-s/2)-1+s/2, safely evaluated when the residual is tiny.
        z=-s/2; residual=sum(z**j/math.factorial(j) for j in range(2,18))
        out+=(KJ/2*residual)*f.normal_power(b,2)
        coefficient=-KJ*np.exp(-s/2)*c2/24
        for k in range(2,f.max_quanta+1):
            if k>2: coefficient*=-c2/((2*k)*(2*k-1))
            out+=coefficient*f.normal_power(b,2*k)
    return ((out+out.T)/2).toarray()
