"""Generate two figures and a manuscript fragment from completed stage 3 data.

Prepared for a central guarded launch. This does not construct nonlinear
Hamiltonians. The harmonic reference is recomputed by the exact ordered
Riccati recursion in parameters(10,20), never from an adapted saved H0 basis.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import os
import re
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'research/stage3'),str(ROOT/'src')]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'tmp/stage3_matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from full_cosine_hierarchy import parameters,filter_gap
from distributed_line import quantum_quadratic_cumulants

BASE=ROOT/'results/stage3_2026-09-15'
TAU=51.2
INPUTS={
    'occupation':'ordered_cumulants_occupation_retry.json',
    'primitive':'ordered_cumulants_primitive40.json',
    'modes':'ordered_cumulants_modes28.json',
    'bath':'ordered_cumulants_bath48.json',
    'ordered_wick':'ordered_cumulants_wick.json',
    'wick':'wick_pilot.json','wick_bath':'wick_bath_refinement.json','wick_strong':'wick_strong.json',
    'remainders':'equal_phase_remainders.json',
    'first_order':'equal_phase_pilot.json',
    'instrument':'equal_phase_instrument_common.json',
    'spectra':'equal_phase_ordered_spectra.json'}


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def close(a,b):return math.isclose(float(a),float(b),rel_tol=2e-11,abs_tol=1e-13)


def one(rows,predicate,label):
    values=[r for r in rows if predicate(r)]
    if len(values)!=1:raise ValueError(label+' expected exactly one row; got '+str(len(values)))
    return values[0]


def ordered_case(data,Q,beta):
    result=one(data['cases'],lambda r:r['context']['Q']==Q and close(r['context']['beta'],beta),'ordered Q/beta')
    if result.get('status')!='COMPLETED':raise ValueError('Selected ordered case is incomplete')
    ctx=result['context']
    if ctx['R']!=10 or ctx['calibration_modes']!=24:raise ValueError('Unexpected physical/calibration family')
    return result


def window(case,observable,tau=TAU):
    result=one(case['windows'],lambda w:w['observable']==observable and close(w['tau'],tau),'ordered window')['actual']
    if not result['spectral_check']['passed']:raise ValueError('Selected spectral reconstruction failed')
    return result


def source_case(data,Q,beta,bath_quanta=4,primitive=None):
    case=one(data['cases'],lambda c:c['Q']==Q and c.get('bath_quanta',4)==bath_quanta
        and (primitive is None or c['primitive']==primitive)
        and any(close(r['beta'],beta) for r in c['cosine']),'Wick Q/beta/bath')
    if (case.get('status')!='COMPLETED' or case['R']!=10 or case['M']!=20
            or case['calibration_modes']!=24 or case['coupling_family']!='equal_reference_phase'):
        raise ValueError('Incomplete or wrong Wick family')
    rec=one(case['cosine'],lambda r:close(r['beta'],beta),'Wick beta')
    win=one(rec['windows'],lambda w:close(w['tau'],TAU),'Wick window')
    return case,rec,win


def raw_from_cumulants(kappa):
    m=[1.]
    for n in range(1,9):
        m.append(math.fsum(math.comb(n-1,j-1)*kappa[str(j)]*m[n-j] for j in range(1,n+1)))
    return {str(p):m[p] for p in range(1,9)}


def exact_harmonic(tau,increment):
    modes,poles,_=parameters(10,20)
    A,B=modes.matrices();omega=modes.omega
    difference=omega[:,None]-omega[None,:];summation=omega[:,None]+omega[None,:]
    if increment:fa,fb=filter_gap(difference,tau,2.),filter_gap(summation,tau,2.)
    else:fa,fb=np.exp(-.5*(tau*difference)**2),np.exp(-.5*(tau*summation)**2)
    k=quantum_quadratic_cumulants(A*fa,B*fb,8);m=raw_from_cumulants(k)
    return dict(cumulants=k,moments=m,
        standardized_cumulants={str(p):k[str(p)]/k['2']**(p/2) for p in range(2,9)},
        R=10,M=20,tau=tau,increment=increment,ratio=2. if increment else None,
        hbar=modes.p.hbar,poles=poles.tolist(),
        source='parameters(10,20) and exact quantum_quadratic_cumulants; no adapted H0')


def shape(mom,reference,p):
    return (math.log(mom[str(p)])-math.log(reference[str(p)])
            -p/2*(math.log(mom['2'])-math.log(reference['2'])))


def texnum(value,digits=4):
    if not math.isfinite(float(value)):raise ValueError('Nonfinite table entry')
    if value==0:return '$0$'
    mant,exponent=f'{float(value):.{digits-1}e}'.split('e')
    return '$'+mant+r'\!\times\!10^{'+str(int(exponent))+'}$'


def decimal(value,digits=6):return f'{float(value):.{digits}g}'


def fit_zero_intercept(beta,values,degree):
    beta=np.asarray(beta,float);values=np.asarray(values,float)
    if len(beta)<degree:raise ValueError('Insufficient points for polynomial degree')
    scale=float(max(beta));x=beta/scale
    design=np.column_stack([x**k for k in range(1,degree+1)])
    coefficient,_,rank,singular=np.linalg.lstsq(design,values,rcond=None)
    if rank!=degree:raise ArithmeticError('Polynomial fit lost column rank')
    physical=coefficient/np.array([scale**k for k in range(1,degree+1)])
    return dict(degree=degree,intercept_constraint=0.,free_linear_coefficient=float(physical[0]),
        coefficients=physical.tolist(),beta=beta.tolist(),values=values.tolist(),
        max_absolute_residual=float(max(abs(values-design@coefficient))),
        singular_values=singular.tolist(),degrees_of_freedom=len(beta)-degree,
        scope='local polynomial description in beta; no confidence intervals or divergence claim')


def save_figure(fig,stem):
    paths=[ROOT/'paper/figures'/(stem+'.pdf'),ROOT/'paper/figures'/(stem+'.png')]
    paths[0].parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(paths[0],bbox_inches='tight',metadata={'Creator':'stage3 saved-result generator','CreationDate':None,'ModDate':None})
    fig.savefig(paths[1],dpi=300,bbox_inches='tight')
    plt.close(fig)
    return paths


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--prefix',default='stage3',help='Derived output prefix beginning stage3')
    ap.add_argument('--replace',action='store_true',help='Replace only these derived stage3 artifacts')
    args=ap.parse_args()
    if not re.fullmatch(r'stage3[a-zA-Z0-9_]*',args.prefix):raise ValueError('Use a stage3 output prefix')
    mem=float(os.environ['PYSCF_MAX_MEMORY'])
    if not math.isfinite(mem) or mem<256:raise ValueError('At least 256 MB declared memory required for plotting')
    texpath=ROOT/'paper'/(args.prefix+'_results.tex')
    provpath=ROOT/'paper'/(args.prefix+'_results_provenance.json')
    figstems=[args.prefix+'_gaussian_comparators',args.prefix+'_cumulant_shapes']
    targets=[texpath,provpath]+[ROOT/'paper/figures'/(stem+ext) for stem in figstems for ext in ('.pdf','.png')]
    if not args.replace and any(p.exists() for p in targets):raise FileExistsError('Derived output exists; use --replace deliberately')
    started=time.monotonic();data={};input_provenance={}
    for key,name in INPUTS.items():
        path=BASE/name;value=json.loads(path.read_text())
        if value.get('status')!='COMPLETED':raise ValueError(name+' is not COMPLETED')
        data[key]=value;input_provenance[str(path.relative_to(ROOT))]=dict(sha256=sha(path),status=value['status'])
        if value.get('input_sha256'):
            upstream=(ROOT/value['input']).resolve()
            if not upstream.is_relative_to(ROOT) or sha(upstream)!=value['input_sha256']:
                raise ValueError('Upstream input differs from recorded hash: '+name)
    if data['instrument'].get('normalization')!='common_harmonic':raise ValueError('Detector resolution must remain common')
    main_cases={b:ordered_case(data['occupation'],14,b) for b in (1.,3.)}
    original={obs:exact_harmonic(TAU,obs=='increment') for obs in ('ordinary','increment')}
    actual={b:{obs:window(case,obs) for obs in original} for b,case in main_cases.items()}
    a1source=data['first_order']['cases'][0]['first_order_reference']
    a1={str(p):a1source['delta_moments'][str(p)]/a1source['harmonic_moments'][str(p)]
        -p/2*a1source['delta_moments']['2']/a1source['harmonic_moments']['2'] for p in (4,6,8)}
    if not close(a1['8'],.4799422391203576):raise ArithmeticError('Unexpected executed first-order reference')
    for p in (2,4,6,8):
        if not math.isclose(original['increment']['moments'][str(p)],a1source['harmonic_moments'][str(p)],rel_tol=3e-10):
            raise ArithmeticError('Fresh Riccati reference differs from executed harmonic reference')

    selections=[('wick_strong',12,.1,40),('wick',12,1.,32),
                ('wick_bath',12,3.,32),('wick_strong',12,10.,40)]
    comparison=[]
    for key,Q,beta,primitive in selections:
        case,rec,win=source_case(data[key],Q,beta,4,primitive)
        A0={str(p):shape(win['microscopic_moments'],original['increment']['moments'],p) for p in (4,6,8)}
        AG={str(p):shape(win['microscopic_moments'],win['wick']['moments'],p) for p in (4,6,8)}
        comparison.append(dict(beta=beta,Q=Q,primitive=primitive,bath_quanta=4,input=INPUTS[key],archive=rec['archive'],
            original_H0_log_shape=A0,retained_DZ_Wick_log_shape=AG,
            graph=rec['graph'],source_diagnostics=rec['source_diagnostics'],
            outside_tensor_covariance_scale_upper=rec['outside_tensor_covariance_scale_upper']))

    # Independent requested refinements: beta1 baseline uses a completed source
    # run; beta3 baseline uses completed occupation_retry. Do not read FAILED runs.
    baseline={1.:ordered_case(data['ordered_wick'],12,1.),3.:ordered_case(data['occupation'],12,3.)}
    refined=[]
    for key,label,value in [('modes',r'Modes $M:20\to28$',28),('primitive',r'Primitive levels $32\to40$',40),
                            ('bath',r'Quartic bath seeds $24\to48$',48),('occupation',r'Excitation cutoff $Q:12\to14$',14)]:
        for beta in (1.,3.):
            other=ordered_case(data[key],14 if key=='occupation' else 12,beta)
            row=dict(parameter=key,label=label,beta=beta,baseline_archive=baseline[beta]['archive'],
                     refined_archive=other['archive'],baseline_context=baseline[beta]['context'],
                     refined_context=other['context'],raw_moment_fractional_changes={})
            for obs in original:
                lo,hi=window(baseline[beta],obs),window(other,obs)
                delta={str(p):abs(hi['moments'][str(p)]/lo['moments'][str(p)]-1) for p in (2,4,6,8)}
                row['raw_moment_fractional_changes'][obs]=delta
                row['max_even_moment_change_'+obs]=max(delta.values())
                row['all_cumulant_absolute_changes_'+obs]={str(p):abs(hi['cumulants'][str(p)]-lo['cumulants'][str(p)]) for p in range(2,9)}
                if obs=='ordinary':row['ordinary_kappa8_fractional_change']=abs(hi['cumulants']['8']/lo['cumulants']['8']-1)
            refined.append(row)

    _,strong_refined,strong_window=source_case(data['wick_strong'],12,10.,4,48)
    strong_refinement=dict(beta=10.,primitive_from=40,primitive_to=48,
        reference_archive=comparison[-1]['archive'],refined_archive=strong_refined['archive'],
        original_shape_absolute_changes={str(p):abs(shape(strong_window['microscopic_moments'],original['increment']['moments'],p)
            -comparison[-1]['original_H0_log_shape'][str(p)]) for p in (4,6,8)},
        Wick_shape_absolute_changes={str(p):abs(shape(strong_window['microscopic_moments'],strong_window['wick']['moments'],p)
            -comparison[-1]['retained_DZ_Wick_log_shape'][str(p)]) for p in (4,6,8)})
    fits=[];remainder_points={}
    for case in data['remainders']['cases']:
        if case['status']!='COMPLETED':raise ValueError('Remainder case incomplete')
        points=[]
        for rec in case['cosine']:
            win=one(rec['windows'],lambda w:close(w['tau'],TAU),'remainder window')
            points.append((float(rec['beta']),shape(win['moments'],original['increment']['moments'],8)))
        points.sort();beta=np.array([v[0] for v in points]);values=np.array([v[1] for v in points])
        remainder_points[str(case['Q'])]=points
        fit=fit_zero_intercept(beta,values,2);fit.update(Q=case['Q'],name='quadratic',
            exact_linear_reference=a1['8'],linear_difference_from_reference=fit['free_linear_coefficient']-a1['8'])
        fits.append(fit)
        if len(points)>=4:
            for selected,degree,label in [(slice(None),3,'cubic'),(slice(0,3),2,'quadratic smaller interval')]:
                f=fit_zero_intercept(beta[selected],values[selected],degree)
                f.update(Q=case['Q'],name=label,exact_linear_reference=a1['8'],
                    linear_difference_from_reference=f['free_linear_coefficient']-a1['8']);fits.append(f)
            # Free-intercept control exposes a possible fixed-basis offset.
            scale=max(beta);x=beta/scale;design=np.column_stack([np.ones(len(x)),x,x*x])
            coeff,_,rank,_=np.linalg.lstsq(design,values,rcond=None)
            if rank!=3:raise ArithmeticError('Free-intercept fit rank failure')
            fits.append(dict(Q=case['Q'],name='quadratic free intercept',degree=2,
                intercept_constraint=None,intercept=float(coeff[0]),
                free_linear_coefficient=float(coeff[1]/scale),quadratic_coefficient=float(coeff[2]/scale**2),
                beta=beta.tolist(),values=values.tolist(),max_absolute_residual=float(max(abs(values-design@coeff))),
                exact_linear_reference=a1['8'],linear_difference_from_reference=float(coeff[1]/scale-a1['8'])))
    drift=[]
    for beta,value14 in remainder_points['14']:
        value12=one(remainder_points['12'],lambda point:close(point[0],beta),'matching remainder beta')[1]
        drift.append(dict(beta=beta,A8_Q12=value12,A8_Q14=value14,difference=value14-value12,
                          difference_divided_by_beta=(value14-value12)/beta))

    # Retain finite-CDF and ordered cross-scale data; do not replace their saved
    # adapted harmonic reference by an uncomputed exact Gaussian tail law.
    spectra=[]
    for case in data['spectra']['cases']:
        if case['Q']!=14:continue
        for rec in case['cosine']:
            if rec['beta'] not in (1.,3.):continue
            win=one(rec['finite']['widths'],lambda w:close(w['tau'],TAU),'spectral width')
            for p in (2,4,6,8):
                if not math.isclose(win['moments'][str(p)],actual[rec['beta']]['increment']['moments'][str(p)],rel_tol=3e-9):
                    raise ArithmeticError('Independent spectral diagnostic uses a different moment')
            spectra.append(dict(beta=rec['beta'],Q=14,widths=rec['finite']['widths'],
                cross_scale=rec['finite']['cross_scale'],slopes=rec['finite']['slopes'],
                reference_scope='finite source spectral laws only; no uncomputed exact harmonic CDF comparison'))
    spectral_beta1=one(spectra,lambda r:close(r['beta'],1.),'spectral beta1')
    spectral_width1=one(spectral_beta1['widths'],lambda w:close(w['tau'],TAU),'spectral tau')
    exceedance8=one(spectral_width1['exceedances'],lambda r:r['threshold']==8,'spectral threshold8')
    instrument=[]
    for case in data['instrument']['cases']:
        if case['Q']!=14:continue
        for rec in case['cosine']:
            for model,values in rec['models'].items():
                selected=one(values['checks'],lambda c:c['sigma']==1 and c['threshold']==8,'instrument setting')
                st=selected['statistics']
                row=one(st['rows'],lambda r:close(r['time'],TAU),'instrument lag')
                instrument.append(dict(beta=rec['beta'],model=model,pressure_scale=values['pressure_scale'],
                    sigma=1,threshold=8,lag=TAU,p1=row['p1'],p2=row['p2'],p11=row['p11'],g_hit=row['g_hit'],
                    second_marginal_disturbance=row['second_marginal_disturbance'],
                    deposited_energy_first=st['deposited_energy_first'],deposited_energy_total=row['deposited_energy_total']))

    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':10,
        'axes.titlesize':10,'legend.fontsize':8,'xtick.labelsize':9,'ytick.labelsize':8,
        'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.facecolor':'white'})
    colors={4:'#0072B2',6:'#D55E00',8:'#009E73'};markers={4:'o',6:'s',8:'^'}
    fig,axs=plt.subplots(1,2,figsize=(7.1,3.15),constrained_layout=True)
    for ax,key,title in zip(axs,['original_H0_log_shape','retained_DZ_Wick_log_shape'],
                            ['(a) Original harmonic reference','(b) Retained D/Z Wick reference']):
        for p in (4,6,8):ax.plot([r['beta'] for r in comparison],[r[key][str(p)] for r in comparison],
            marker=markers[p],color=colors[p],lw=1.3,ms=5,label=f'p = {p}')
        if key!='original_H0_log_shape':ax.axhline(0,color='.55',lw=.7)
        ax.set_xscale('log');ax.set_xticks([.1,1,3,10],['0.1','1','3','10'])
        ax.set_xlabel(r'Nonlinear multiplier $\beta$');ax.set_ylabel(r'Shape contrast $A_p$ (dimensionless)')
        if key=='original_H0_log_shape':
            if any(r[key][str(p)]<=0 for r in comparison for p in (4,6,8)):raise ValueError('Positive logarithmic comparator axis needs positive data')
            ax.set_yscale('log')
        ax.set_title(title);ax.grid(axis='y',alpha=.18);ax.legend(loc='best',frameon=False)
    figure_paths=save_figure(fig,figstems[0])
    fig,axs=plt.subplots(1,2,figsize=(7.1,3.15),constrained_layout=True);orders=np.arange(2,9)
    scales={}
    for ax,obs,title in zip(axs,['ordinary','increment'],['(a) Ordinary averaged pressure','(b) Pressure increment, b = 2']):
        series=[('Exact harmonic',original[obs]['standardized_cumulants'],'#333333','o','--'),
                (r'$\beta=1$, Q=14',actual[1.][obs]['standardized_cumulants'],'#0072B2','s','-'),
                (r'$\beta=3$, Q=14',actual[3.][obs]['standardized_cumulants'],'#D55E00','^','-')]
        values=[]
        for label,k,col,marker,style in series:
            y=[k[str(p)] for p in orders];values+=y;ax.plot(orders,y,label=label,color=col,marker=marker,ls=style,lw=1.3,ms=4)
        scales[obs]='log' if min(values)>0 else 'symlog'
        if scales[obs]=='log':ax.set_yscale('log')
        else:ax.set_yscale('symlog',linthresh=1.)
        ax.set_xticks(orders);ax.set_xlabel('Cumulant order n');ax.set_ylabel(r'$\kappa_n/\kappa_2^{n/2}$ (dimensionless)')
        ax.set_title(title);ax.grid(axis='y',alpha=.18);ax.legend(frameon=False,loc='upper left')
    figure_paths+=save_figure(fig,figstems[1])

    lines=[r'% Generated from completed records by research/stage3/build_stage3_results.py.',
        r'\section{Finite-strength pressure statistics}',r'\label{sec:s3-results}',
        r'We evaluate the equal-reference-phase family at $R=10$, $M=20$, and $\tau=51.2$, with the calibration fixed at $M_{\rm ref}=24$. '
        r'The full cosine is retained. The ordinary averaged pressure and the increment $X_\tau=O_\tau-O_{2\tau}$ are each centered in the actual ground state of their finite Hamiltonian. '
        r'This fixes a source constant without reconstructing an absolute physical mean. The results below distinguish finite-model statistics from the separate bounds on omitted states and source information.',
        r'\subsection{Cumulants and independent refinements}',
        r'Table~\ref{tab:s3-cumulants} reports every pressure cumulant from second through eighth order. '
        r'The harmonic columns are obtained from the exact ordered Gaussian recursion for the same twenty line modes; they are not evaluated in the nonlinear adapted basis. '
        r'Figure~\ref{fig:s3-cumulant-shapes} separates the magnitude of fluctuations from their standardized shape. '
        r'Increasing $\beta$ from one to three reduces the variance at this width while increasing several standardized higher cumulants. '
        r'High standardized cumulants are already present in the harmonic pressure and are not, on their own, evidence for a nonlinear intermittency mechanism.',
        r'\begin{table*}[t]\centering\small',
        r'\caption{Ordered cumulants at $\tau=51.2$. The nonlinear columns use $Q=14$ and 32 primitive levels. Values have units of pressure to power $n$ in the dimensionless model convention. These are finite-model values, not statistical estimates with inferred error bars.}\label{tab:s3-cumulants}',
        r'\begin{tabular}{c rrr rrr}\toprule',
        r'&\multicolumn{3}{c}{Ordinary averaged pressure}&\multicolumn{3}{c}{Increment, $b=2$}\\',
        r'$n$&Harmonic&$\beta=1$&$\beta=3$&Harmonic&$\beta=1$&$\beta=3$\\\midrule']
    for p in range(2,9):
        vals=[v['cumulants'][str(p)] for obs in ('ordinary','increment') for v in (original[obs],actual[1.][obs],actual[3.][obs])]
        lines.append(str(p)+' & '+' & '.join(texnum(v) for v in vals)+r' \\')
    lines += [r'\bottomrule\end{tabular}\end{table*}',
        r'\begin{figure*}[t]\centering\includegraphics[width=\textwidth]{figures/'+figstems[1]+r'.pdf}',
        r'\caption{Standardized cumulants for ordinary pressure and increments at $\tau=51.2$. Harmonic statistics use the exact twenty-mode Riccati reference; nonlinear statistics use $Q=14$. '
        r'The horizontal coordinate is cumulant order, not an averaging scale. Growth along this axis is not a measured multiscaling exponent.}\label{fig:s3-cumulant-shapes}\end{figure*}',
        r'Table~\ref{tab:s3-refinement} varies the mode count, primitive oscillator resolution, bath selection, and excitation cutoff independently. '
        r'Its entries are changes between specified calculations, not confidence intervals or certified truncation errors. '
        r'The $Q=12$, $\beta=1$ baseline comes from the completed full-parity source calculation; the $\beta=3$ baseline comes from the completed occupation comparison. '
        r'Both retain the same ground-state pressure observable. The mode comparison retains the physical calibration at $M_{\rm ref}=24$.',
        r'\begin{table*}[t]\centering\small',
        r'\caption{Fractional refinement changes at $\tau=51.2$. For each observable, $\delta M=\max_{p=2,4,6,8}|M_p^{\rm new}/M_p^{\rm base}-1|$. '
        r'The last column is $|\kappa_8^{\rm new}/\kappa_8^{\rm base}-1|$ for ordinary pressure. Bath counts refer to selected quartic seed configurations before downward closure, not the final bath dimension. Unlisted settings remain fixed within each comparison.}\label{tab:s3-refinement}',
        r'\begin{tabular}{lrrrr}\toprule Comparison&$\beta$&$\delta M$ ordinary&$\delta M$ increment&$\delta\kappa_8$ ordinary\\\midrule']
    for r in refined:
        lines.append(r['label']+' & '+decimal(r['beta'])+' & '+' & '.join(texnum(r[k],3) for k in ['max_even_moment_change_ordinary','max_even_moment_change_increment','ordinary_kappa8_fractional_change'])+r' \\')
    lines += [r'\bottomrule\end{tabular}\end{table*}',
        r'\subsection{What the retained two-point reference removes}',
        r'For each pressure increment define $A_p^{\rm ref}=\log[(M_p/M_2^{p/2})/(M_p^{\rm ref}/(M_2^{\rm ref})^{p/2})]$. '
        r'Figure~\ref{fig:s3-comparators} compares the original harmonic reference with the Wick pressure built from the retained interacting $D/Z$ transition spectrum. '
        r'These answer different questions: the first includes changes of the two-point response, whereas the second removes the Wick contribution of the selected interacting two-point data. '
        r'For $p=8$, the latter contrast changes from '+decimal(comparison[1]['retained_DZ_Wick_log_shape']['8'])+r' at $\beta=1$ to '+decimal(comparison[2]['retained_DZ_Wick_log_shape']['8'])+r' at $\beta=3$. '
        r'This statement concerns the retained spectrum. Missing odd transitions, source weight outside the retained tensor space, and approximate ground-state/source errors must be controlled before interpreting the difference as a complete connected-field measurement.',
        r'At $\beta=10$, $A_8$ relative to the original harmonic model reaches '+decimal(comparison[-1]['original_H0_log_shape']['8'])
        +r', whereas the retained-Wick contrast is '+decimal(comparison[-1]['retained_DZ_Wick_log_shape']['8'])+r'. '
        r'The magnitude of the latter is smaller than at $\beta=3$, although the original-reference contrast is much larger. '
        r'This comparison shows how strongly two-point retuning can affect the interpretation of the raw nonlinear contrast. '
        r'Raising the primitive resolution from 40 to 48 changes the retained-Wick $A_8$ at $\beta=10$ by '
        +texnum(strong_refinement['Wick_shape_absolute_changes']['8'],3)+r'. '
        r'The unfiltered upper bound on source covariance outside the retained tensor space remains '+decimal(comparison[-1]['outside_tensor_covariance_scale_upper'])
        +r' in the declared source normalization. Primitive agreement alone therefore does not bound the omitted Gaussian pressure moments.',
        r'\begin{figure*}[t]\centering\includegraphics[width=\textwidth]{figures/'+figstems[0]+r'.pdf}',
        r'\caption{Increment shape contrasts at $\tau=51.2$, $R=10$, $M=20$, and $Q=12$, with bath quanta fixed at four. The $\beta=0.1,10$ points use 40 primitive levels; $\beta=1,3$ use 32. '
        r'Lines connect computed couplings. The left vertical axis is logarithmic; the right is linear. '
        r'The right panel uses the retained $D/Z$ Wick comparator and carries its source-completeness limitations; no omitted-source uncertainty bars are inferred from these curves.}\label{fig:s3-comparators}\end{figure*}',
        r'\subsection{Small-coupling remainders and averaging-width dependence}',
        r'The independently executed first-order reference gives $\partial_\beta A_8|_{\beta=0}='+decimal(a1['8'],12)+r'$. '
        r'We fit local polynomials $A_8=a_1\beta+a_2\beta^2+\cdots$ with $a_1$ free; the zero intercept encodes the harmonic endpoint. '
        r'A separate fit permits a free intercept to expose a possible fixed-basis offset. Fits with two points and two free coefficients interpolate those points and supply no goodness-of-fit evidence.',
        r'\begin{table*}[t]\centering\small',
        r'\caption{Local coupling fits at $\tau=51.2$. The linear coefficient is estimated freely and compared with the independent first-order reference. Fit residuals are numerical discrepancies, not uncertainty estimates.}\label{tab:s3-remainders}',
        r'\begin{tabular}{clrrrr}\toprule $Q$&Fit&$\beta$ interval&$a_1$&$a_1-a_1^{\rm exact}$&Max. residual\\\midrule']
    for f in fits:
        lines.append(str(f['Q'])+' & '+f['name']+' & '+decimal(min(f['beta']))+'--'+decimal(max(f['beta']))+' & '+decimal(f['free_linear_coefficient'],9)+' & '+texnum(f['linear_difference_from_reference'],3)+' & '+texnum(f['max_absolute_residual'],3)+r' \\')
    lines += [r'\bottomrule\end{tabular}\end{table*}',
        r'At the shared small couplings, the changes in $A_8/\beta$ between $Q=12$ and $Q=14$ are '+', '.join(texnum(r['difference_divided_by_beta'],3) for r in drift)+r'. '
        r'These changes must be separated from higher powers of $\beta$; imposing the exact linear coefficient on an unresolved finite-basis curve would mix the two effects.',
        r'The neighboring widths use common finite bases. For $\beta=1$, the raw standardized-moment slope $d\log(M_8/M_2^4)/d\log\tau$ changes from '
        +decimal(spectral_beta1['slopes'][0]['shape_slopes']['8'])+' to '+decimal(spectral_beta1['slopes'][1]['shape_slopes']['8'])+r' across the two adjacent intervals. '
        r'The measured slopes vary across the current finite window. '
        r'These three-window data do not supply a common widening scaling interval. Deeper-resonance calculations are reported separately; neither observation establishes or rules out intermittency in a broader boundary family.',
        r'\subsection{Spectral tails, cross-scale ordering, and a declared instrument}',
        r'Diagonalization of the saved finite increment produces positive spectral weights and threshold exceedances. '
        r'For example, at $Q=14$, $\beta=1$, and $\tau=51.2$, the two-sided exceedance above eight times its own standard deviation is '
        +texnum(exceedance8['two_sided'],4)+r'. '
        r'This is a finite-operator spectral probability; the available moment checks do not certify its far-tail or continuum limit. '
        r'Ordered cross-scale products and their reverse orderings are retained as separate diagnostics, rather than combined into an assumed classical joint law.',
        r'The Gaussian Kraus instrument provides a distinct operational calculation. Its resolution and thresholds are fixed in common harmonic pressure units. '
        r'For resolution one and a two-sided threshold eight, the first probe deposits energies '
        +', '.join(texnum(one(instrument,lambda r:close(r['beta'],b) and r['model']=='cosine','instrument beta')['deposited_energy_first'],4) for b in (1.,3.))
        +r' at $\beta=1,3$, respectively. Heating and correlated threshold outcomes also occur in the saved harmonic comparator. '
        r'The sequential probabilities use the actual disturbed second marginal. They describe the declared finite measurement, not a local pressure detector or an undisturbed record of vacuum bursts.']
    lines += [r'\begin{table*}[t]\centering\small',
        r'\caption{Two-probe events for the declared instrument at $\tau=t=51.2$, $\sigma=1$ and $h=8$, in fixed original-harmonic pressure units. The harmonic rows use the same saved adapted basis as their nonlinear counterpart. $p_2$ includes the first measurement; $g=p_{11}/(p_1p_2)$ therefore uses the actual marginals. These are finite-instrument probabilities, not a measurement of spontaneous pressure bursts.}\label{tab:s3-instrument}',
        r'\begin{tabular}{clrrrr}\toprule $\beta$&Model&$p_1$&$p_2$&$p_{11}$&$g$\\\midrule']
    for row in instrument:
        label='Full cosine' if row['model']=='cosine' else 'Saved-basis harmonic'
        lines.append(decimal(row['beta'])+' & '+label+' & '+' & '.join(decimal(row[k],6) for k in ('p1','p2','p11','g_hit'))+r'\\')
    lines += [r'\bottomrule\end{tabular}\end{table*}']
    texpath.write_text('\n'.join(lines)+'\n')
    selected_archives={}
    for case in [*main_cases.values(),*baseline.values()]:
        selected_archives[case['archive']]=case.get('archive_sha256')
    for row in refined:
        for key in ('baseline_archive','refined_archive'):
            selected_archives.setdefault(row[key],None)
    for row in comparison:selected_archives.setdefault(row['archive'],None)
    selected_archives.setdefault(strong_refined['archive'],None)
    archive_provenance={}
    for name,recorded_hash in selected_archives.items():
        path=(ROOT/name).resolve()
        if not path.is_relative_to(ROOT):raise ValueError('Archive lies outside project')
        current_hash=sha(path)
        if recorded_hash is not None and current_hash!=recorded_hash:
            raise ValueError('Selected archive differs from executed ordered record: '+name)
        archive_provenance[str(path.relative_to(ROOT))]=dict(sha256=current_hash,
            recorded_sha256=recorded_hash,recorded_hash_verified=recorded_hash is not None)
    sourcefiles=[Path(__file__).resolve(),ROOT/'research/stage3/full_cosine_hierarchy.py',
        ROOT/'research/stage2/run_boundary_hierarchy.py',ROOT/'src/distributed_line.py',ROOT/'src/nonlinear_pressure.py']
    provenance=dict(status='COMPLETED',artifact_scope='completed saved finite calculations; final physical acceptance and omitted-state/source bounds remain separate',
        inputs=input_provenance,selected_archives=archive_provenance,
        source_sha256={str(p.relative_to(ROOT)):sha(p) for p in sourcefiles},
        selection=dict(R=10,M=20,tau=TAU,calibration_modes=24,main_Q=14,main_beta=[1.,3.],
            no_failed_or_partial_hierarchy_records_used=True),exact_harmonic=original,
        selected_cumulants={str(b):{obs:actual[b][obs]['cumulants'] for obs in original} for b in actual},
        gaussian_comparisons=comparison,strong_primitive_refinement=strong_refinement,independent_refinements=refined,
        first_order_reference=dict(source=INPUTS['first_order'],path='cases[0].first_order_reference',
            formula='delta_m[p]/m0[p] - p/2 delta_m[2]/m0[2]',A1=a1),
        remainder_fits=fits,occupation_drift=drift,finite_spectral_diagnostics=spectra,
        instrument_selection=instrument,figure_axis_scales=scales,
        output_sha256={str(p.relative_to(ROOT)):sha(p) for p in [texpath,*figure_paths]},
        elapsed_seconds=time.monotonic()-started,memory_mb=mem)
    provpath.write_text(json.dumps(provenance,indent=2,allow_nan=False))
    print(json.dumps(dict(status='COMPLETED',fragment=str(texpath.relative_to(ROOT)),figures=[str(p.relative_to(ROOT)) for p in figure_paths],provenance=str(provpath.relative_to(ROOT)))),flush=True)


if __name__=='__main__':main()
