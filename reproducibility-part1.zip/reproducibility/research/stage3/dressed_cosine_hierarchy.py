"""Self-consistent product orbitals plus full-cosine configuration interaction.

The Hartree product is a basis reference, not the final field approximation.
All projected cross-mode cosine and quadratic matrix elements are retained.
Local primitive, configuration, spectral-mode and width controls are separate.
"""
from pathlib import Path
import sys,os,json,time,math,hashlib,argparse
import numpy as np
from scipy.linalg import eigh
from scipy.special import eval_genlaguerre,gammaln
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'research/stage3'),str(ROOT/'src'),str(ROOT/'research')]
from full_cosine_hierarchy import AdaptiveFock,weights,parameters,projected_harmonic,harmonic_exact,shape_logs,spectral_moments,satellite_configuration

def primitive(N,t):
    n=np.arange(N);lo=np.minimum(n[:,None],n[None,:]);hi=np.maximum(n[:,None],n[None,:]);gap=hi-lo;z=t*t
    D=np.exp(-z/2+.5*(gammaln(lo+1)-gammaln(hi+1)))*(1j*t)**gap*eval_genlaguerre(lo,gap,z)
    # Exact finite Laguerre polynomial minus its constant, to preserve tiny phases.
    lm=np.zeros(N);term=np.ones(N)
    for k in range(1,N):
        term*=-(n-k+1)*z/(k*k);term[n<k]=0;lm+=term
    if z<1e-3:
        np.fill_diagonal(D,np.expm1(-z/2)*(1+lm)+lm)
    else:
        # At appreciable phase use the stable special function, not a large
        # alternating finite-polynomial sum. Subtracting one is safe here.
        np.fill_diagonal(D,np.exp(-z/2)*eval_genlaguerre(n,0,z)-1)
    return D # displacement minus identity

def quadratures(N):
    a=np.diag(np.sqrt(np.arange(1,N)),1);x=a+a.T;p=1j*(a.T-a)
    n=np.arange(N);x2=np.diag(2*n+1.)+np.diag(np.sqrt((n[:-2]+1)*(n[:-2]+2)),2)+np.diag(np.sqrt((n[:-2]+1)*(n[:-2]+2)),-2)
    p2=2*np.diag(2*n+1.)-x2
    return x,p,x2,p2

def parity_eigh(H):
    N=len(H);vectors=[];energies=[];parities=[]
    for parity in [0,1]:
        ix=np.arange(parity,N,2);E,U=eigh(H[np.ix_(ix,ix)],check_finite=False)
        B=np.zeros((N,len(ix)));B[ix]=U
        energies.extend(E);vectors.extend(B.T);parities.extend([parity]*len(E))
    order=np.argsort(energies);E=np.asarray(energies)[order];U=np.asarray(vectors)[order].T;par=np.asarray(parities)[order]
    if not np.array_equal(par,np.arange(N)%2):raise ArithmeticError('local parity sequence changed')
    # Fix phases for repeatability; statistical observables are phase independent.
    for j in range(N):
        k=np.argmax(abs(U[:,j]));U[:,j]*=1 if U[k,j]>=0 else -1
    return E-E[0],U

def mean_field(modes,u,beta,N,reference=None,tolerance=1e-14):
    M=len(modes.omega);R=len(u);kj=np.asarray(modes.p.KJ)
    c=modes.branch*np.sqrt(modes.p.hbar/(2*modes.omega))[None,:]
    v=np.sum(c*c,axis=1) if reference is None else np.asarray(reference)
    theta2=-beta*u/kj
    if np.any(theta2<=0):raise ValueError('this driver requires beta>0 and negative branch couplings')
    x,p,x2,p2=quadratures(N);zero=np.zeros((N,N));n=np.arange(N)
    displacements=[[primitive(N,math.sqrt(theta2[r])*c[r,j]) for j in range(M)] for r in range(R)]
    corr=np.array([[displacements[r][j][0,0].real for j in range(M)] for r in range(R)])
    history=[];Us=[];Es=[]
    for iteration in range(80):
        old=corr.copy();Us=[];Es=[]
        for j in range(M):
            H=np.diag(modes.p.hbar*modes.omega[j]*n)
            for r in range(R):
                dc=np.delete(corr[r],j)
                if np.any(dc<=-1):raise ArithmeticError('mean-field characteristic factor not positive')
                minus=np.expm1(np.log1p(dc).sum());prod=1+minus;t2=theta2[r]*c[r,j]**2
                crem=displacements[r][j].real+t2*x2/2
                H+=(kj[r]/2*(minus+theta2[r]*v[r]/2)*c[r,j]**2)*x2-(kj[r]/theta2[r])*prod*crem
            E,U=parity_eigh((H+H.T)/2);Us.append(U);Es.append(E)
            for r in range(R):corr[r,j]=float(U[:,0]@displacements[r][j].real@U[:,0])
        change=float(np.max(abs(corr-old)));history.append(change)
        if change<tolerance:break
    else:raise ArithmeticError('mean-field iteration did not converge')
    X=np.array([U.T@x@U for U in Us]);Y=np.array([U.T@p@U for U in Us]);X2=np.array([U.T@x2@U for U in Us]);Y2=np.array([U.T@p2@U for U in Us])
    D=[[Us[j].T@displacements[r][j]@Us[j] for j in range(M)] for r in range(R)]
    # Reconstruct local operators with final factors, retaining off-diagonal
    # stationarity residuals. Thus exact assembly does not rely on SCF tolerance.
    local_h=[];stationarity=[]
    for j,U in enumerate(Us):
        H=np.diag(modes.p.hbar*modes.omega[j]*n)
        for r in range(R):
            minus=np.expm1(np.log1p(np.delete(corr[r],j)).sum());prod=1+minus;t2=theta2[r]*c[r,j]**2
            crem=displacements[r][j].real+t2*x2/2
            H+=(kj[r]/2*(minus+theta2[r]*v[r]/2)*c[r,j]**2)*x2-(kj[r]/theta2[r])*prod*crem
        h=U.T@H@U;h-=h[0,0]*np.eye(N);local_h.append((h+h.T)/2)
        stationarity.append(float(np.linalg.norm(h-np.diag(Es[j]))))
    return dict(energies=np.asarray(Es),local_hamiltonians=np.asarray(local_h),local_stationarity_residual=max(stationarity),orbitals=Us,X=X,Y=Y,X2=X2,Y2=Y2,D=D,c=c,theta2=theta2,reference=v,history=history,ground_primitive_top_weight=max(float(np.sum(U[-4:,0]**2)) for U in Us))

def difference_structure(states):
    D=len(states);count=np.zeros((D,D),np.uint8);first=np.zeros((D,D),np.int16);second=first.copy()
    for j in range(states.shape[1]):
        mask=states[:,j,None]!=states[None,:,j]
        first[(count==0)&mask]=j;second[(count==1)&mask]=j;count+=mask
    r1,c1=np.nonzero(count==1);r2,c2=np.nonzero(count==2)
    return count,first,second,(r1,c1),(r2,c2)

def pair_matrix(states,structure,operator,coefficient):
    _,first,second,_,(rr,cc)=structure;j=first[rr,cc];k=second[rr,cc]
    values=coefficient[j,k]*operator[j,states[rr,j],states[cc,j]]*operator[k,states[rr,k],states[cc,k]]
    out=np.zeros((len(states),len(states)),complex);out[rr,cc]=values
    return out.real

def one_body(states,structure,operators):
    _,first,_,(rr,cc),_=structure;D=len(states)
    out=np.zeros((D,D),complex);j=first[rr,cc]
    out[rr,cc]=operators[j,states[rr,j],states[cc,j]]
    np.fill_diagonal(out,sum(operators[j,states[:,j],states[:,j]] for j in range(states.shape[1])))
    return out.real

def assemble(modes,states,local,memory_mb):
    dim=len(states);M=len(modes.omega);R=len(modes.p.KJ)
    if dim*dim*180>memory_mb*1024**2*.8:raise MemoryError('dressed dense workspace budget exceeded')
    structure=difference_structure(states)
    active=np.flatnonzero(np.max(states,axis=0)>0);frozen=np.flatnonzero(np.max(states,axis=0)==0)
    H=one_body(states,structure,local['local_hamiltonians'])
    for r in range(R):
        S0=np.ones((dim,dim),complex);S1=np.zeros_like(S0);S2=np.zeros_like(S0)
        for j in active:
            n=states[:,j];same=n[:,None]==n[None,:];mat=local['D'][r][j];dc=mat[0,0].real
            delta=mat[n[:,None],n[None,:]]-dc*same;ref=(1+dc)*same
            S2=S2*(ref+delta)+S1*delta;S1=S1*ref+S0*delta;S0*=ref
        S2*=np.prod([1+local['D'][r][j][0,0].real for j in frozen])
        C=pair_matrix(states,structure,local['X'],np.outer(local['c'][r],local['c'][r]))
        kj=modes.p.KJ[r];t2=local['theta2'][r];s=t2*local['reference'][r]
        H-=kj/t2*(S2.real+t2*C);H+=kj*s/2*C
    d=modes.slope*np.sqrt(modes.p.hbar/(2*modes.omega));z=modes.endpoint*np.sqrt(modes.p.hbar*modes.omega/2)
    onsite=d[:,None,None]**2/(2*modes.p.L0)*local['X2']+modes.p.C0*z[:,None,None]**2/2*local['Y2']
    P=one_body(states,structure,onsite)
    P+=pair_matrix(states,structure,local['X'],np.outer(d,d)/modes.p.L0)
    P+=pair_matrix(states,structure,local['Y'],modes.p.C0*np.outer(z,z))
    P-=P[0,0]*np.eye(dim)
    return (H+H.T)/2,(P+P.T)/2

def solve(modes,u,f,tau,beta,primitive_size=24,ratio=2.,reference=None,memory_mb=4096):
    even=np.flatnonzero(f.states.sum(axis=1)%2==0);states=f.states[even]
    if primitive_size<=states.max()+3:raise ValueError('primitive oscillator basis needs extra levels')
    local=mean_field(modes,u,beta,primitive_size,reference)
    H,P=assemble(modes,states,local,memory_mb)
    E,moments,ground=spectral_moments(H,P,tau,modes.p.hbar,ratio)
    return dict(moments=moments,gap=float(E[1]),configuration_reference_weight=float(ground[0]**2),mean_field_iterations=len(local['history']),mean_field_last_change=local['history'][-1],primitive_top_weight=local['ground_primitive_top_weight'],phase_variances=(local['theta2']*local['reference']).tolist()),(H,P,local)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--spec',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    dest=(ROOT/a.output).resolve();spec=json.loads((ROOT/a.spec).read_text());mem=int(os.environ['PYSCF_MAX_MEMORY'])
    if dest.exists() or not dest.is_relative_to(ROOT):raise ValueError('new project output required')
    start=time.monotonic();result={'status':'RUNNING','spec':spec,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':[]}
    def save():
        result['elapsed_seconds']=time.monotonic()-start;tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(result,indent=2));tmp.replace(dest)
    save()
    try:
        for case in spec['cases']:
            row=dict(case,status='BUILDING',cosine=[]);result['cases'].append(row);save();begin=time.monotonic()
            modes,poles,u=parameters(case['R'],case['M'],case.get('G',-1e-7),case.get('s',0.));tau=case['tau'];Q=case['Q']
            costs=weights(modes.omega,tau,case.get('soft',0.),case.get('hard',.25));sat=satellite_configuration(modes,u,costs,Q,case)
            try:f=AdaptiveFock(modes.omega,Q,costs,modes.p.hbar,spec.get('max_dimension',12000),sat)
            except ValueError as e:
                row.update(status='DIMENSION_EXCLUDED',reason=str(e));save();continue
            even,E,P,hm=projected_harmonic(f,modes,tau);taus=case.get('evaluation_taus',[tau]);ratio=case.get('ratio',2.)
            refs={str(t):{'projected':projected_harmonic(f,modes,t,ratio)[3],'full':harmonic_exact(modes,t,ratio)} for t in taus}
            reference=None
            if case.get('calibration_modes'):
                rm,_,_=parameters(case['R'],case['calibration_modes'],case.get('G',-1e-7),case.get('s',0.));reference=np.sum(rm.branch**2*rm.p.hbar/(2*rm.omega)[None,:],axis=1)
            row.update(even_dimension=len(even),dimension=f.dimension,satellite_info=f.satellite_info,costs=costs.tolist(),omega=modes.omega.tolist(),window_references=refs,fixed_calibration_variances=None if reference is None else reference.tolist());save()
            for beta in case['beta']:
                try:value,internal=solve(modes,u,f,taus,beta,case.get('primitive',24),ratio,reference,mem)
                except MemoryError as error:row.update(status='MEMORY_EXCLUDED',reason=str(error));save();break
                if case.get('harmonic_projection_check'):
                    H,P,local=internal;states=f.states[even]
                    h0=np.array([U.T@np.diag(modes.p.hbar*modes.omega[j]*np.arange(len(U)))@U for j,U in enumerate(local['orbitals'])])
                    H0=one_body(states,difference_structure(states),h0)
                    _,hmcheck,_=spectral_moments(H0,P,taus,modes.p.hbar,ratio)
                    value['same_basis_harmonic']=[{'tau':t,'moments':v,'relative_errors':{k:v[k]/refs[str(t)]['full'][k]-1 for k in v}} for t,v in zip(taus,hmcheck)]
                widths=[]
                for t,mom in zip(taus,value.pop('moments')):
                    widths.append({'tau':t,'moments':mom,'log_shape_against_projected_harmonic':shape_logs(mom,refs[str(t)]['projected']),'log_shape_against_full_harmonic':shape_logs(mom,refs[str(t)]['full'])})
                row['cosine'].append(dict(beta=beta,widths=widths,**value));save()
            if row['status']=='BUILDING':row['status']='COMPLETED'
            row['elapsed_seconds']=time.monotonic()-begin;save();print(json.dumps({k:row[k] for k in ['R','M','tau','Q','even_dimension','status','elapsed_seconds']}),flush=True)
        result['status']='COMPLETED';save()
    except BaseException as e:
        result.update(status='FAILED',failure={'type':type(e).__name__,'message':str(e)});save();raise
    print(json.dumps({'status':result['status'],'elapsed_seconds':result['elapsed_seconds']}),flush=True)
if __name__=='__main__':main()
