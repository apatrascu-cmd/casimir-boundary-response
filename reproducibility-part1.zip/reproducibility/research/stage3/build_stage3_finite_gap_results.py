"""Extract the executed fixed-gap diagnostic into a manuscript fragment.

Saved-data formatting and scalar audits only; no numerical-physics imports,
eigensolve, matrix operation, or job launch. The parent executes this generator.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import hashlib
import json
import math
import os

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_INPUT = 'results/stage3_2026-09-15/finite_gap_crossover_diagnostic.json'
TARGET = 'paper/stage3_finite_gap_results.tex'
PROVENANCE = 'paper/stage3_finite_gap_provenance.json'
HELPER = 'research/stage3/analyze_saved_common_widths_2026_09_15.py'
HELPER_SHA = 'bd8755753ece6786750691ad05306ac327135e3a11a7c81ca701bee565bad34b'
TAUS = (327.68, 368.64, 409.6)
ORDERS = (2, 4, 6, 8)
D = Decimal


def require(condition, message):
    if not condition:
        raise ValueError(message)


def local(name):
    path = (ROOT / name).resolve()
    require(path.is_relative_to(ROOT), 'Project-local paths required')
    return path


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def moments(row, key='moments'):
    return {int(k): D(v['decimal']) for k, v in row[key].items()}


def formal_log(m):
    """Independent formal logarithm of the exponential moment series."""
    z = [D(0)] + [m[n] / D(math.factorial(n)) for n in range(1, 9)]
    power = [D(1)] + [D(0)] * 8
    answer = [D(0)] * 9
    for k in range(1, 9):
        power = [sum((power[j] * z[n-j] for j in range(n+1)), D(0)) for n in range(9)]
        for n in range(1, 9):
            answer[n] += D((-1)**(k+1)) * power[n] / D(k)
    return {n: answer[n] * D(math.factorial(n)) for n in range(2, 9)}


def window(case, observable, tau):
    found = [w for w in case['windows'] if w['observable'] == observable and w['tau'] == tau]
    require(len(found) == 1, 'Expected exactly one saved window')
    return found[0]


def shape(w, p=8):
    m = moments(w['actual'])
    h = moments(w['declared_M_harmonic'])
    return (m[p]/h[p]).ln() - D(p)/2 * (m[2]/h[2]).ln()


def sensitivity_zero(model, observable):
    rows = [r for r in model['sensitivity_rows']
            if r['increment'] == (observable == 'increment')
            and r['source_threshold'] == 0. and isinstance(r['energy_model'], str)]
    require(len(rows) == 1, 'Missing zero-threshold sensitivity row')
    return rows[0]


def sci(x, precision=5):
    mantissa, exponent = f'{x:.{precision}e}'.split('e')
    return mantissa + r'\times10^{' + str(int(exponent)) + '}'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', default=DEFAULT_INPUT)
    parser.add_argument('--replace', action='store_true', help='Replace only this generator\'s derived artifacts')
    args = parser.parse_args()
    memory = float(os.environ['PYSCF_MAX_MEMORY'])
    require(math.isfinite(memory) and memory >= 64, 'Declare at least 64 MB for formatting')
    source, target, provenance = local(args.input), local(TARGET), local(PROVENANCE)
    if (target.exists() or provenance.exists()) and not args.replace:
        raise FileExistsError('Owned finite-gap artifacts already exist; use --replace explicitly')
    data = json.loads(source.read_text())
    require(data['status'] == 'COMPLETED_WITH_WARNINGS', 'Unexpected execution status')
    require(data['new_taus'] == list(TAUS) and data['hbar'] == 1. and data['ratio'] == 2., 'Unexpected widths or units')
    checks = data['new_rate_controls']
    require(checks['status'] == 'PASS' and len(checks['checks']) == 13
            and all(c['passed'] for c in checks['checks']), 'Rate controls do not match accepted execution')
    verified = {str(source.relative_to(ROOT)): sha(source)}
    def verify(name, expected):
        observed = sha(local(name))
        require(observed == expected, 'Provenance mismatch: ' + name)
        verified[name] = observed
    verify(HELPER, HELPER_SHA)
    verify(data['input'], data['input_sha256'])
    for mapping in (data['prior_source_sha256'], data['source_sha256']):
        for name, expected in mapping.items():
            verify(name, expected)
    prior = json.loads(local(data['input']).read_text())
    require(prior['status'] == 'COMPLETED_WITH_WARNINGS'
            and prior['new_arithmetic_controls']['status'] == 'PASS', 'Prior controlled analysis not accepted')
    for entry in prior['controls']:
        verify(entry['path'], entry['sha256'])
    cases = {c['label']: c for c in data['cases']}
    old_cases = {c['label']: c for c in prior['cases']}
    require(set(cases) == set(old_cases) == {'R10_Q14', 'R10_Q16'}, 'Expected Q14 and Q16 only')
    audit = dict(A_max_absolute_error=0., formal_log_max_scaled_error=0.,
                 path_log_max_absolute_error=0., matrix_calculations_performed=0)
    arithmetic, spectral, sensitivities, rows, upstream = [], [], {}, [], {}
    with localcontext() as ctx:
        ctx.prec = 80
        ctx.Emin, ctx.Emax = -999999999, 999999999
        for label, case in cases.items():
            old = old_cases[label]
            expected = dict(R=10, M=20, Q=14 if label == 'R10_Q14' else 16, tau=51.2,
                            primitive=32, low_count=5, bath_top=24, calibration_modes=24)
            require(case['status'] == 'COMPLETED' and case['context'] == expected
                    and old['context'] == expected and old['beta'] == 1., 'Physical scope changed')
            require(case['original_diagnostics'] == old['original_diagnostics'], 'Inherited diagnostics changed')
            require(case['original_diagnostics']['even_ground_certified_against_odd'], 'Parity ground uncertified')
            verify(case['archive'], case['archive_sha256'])
            require(case['archive_sha256'] == old['archive_sha256'], 'Archive changed between analyses')
            verify(old['input'], old['input_sha256'])
            physical = json.loads(local(old['input']).read_text())
            require(physical['status'] == 'COMPLETED', 'Upstream physical batch incomplete')
            upstream[old['input']] = physical.get('source_sha256', {})
            original_control = old['saved_ordinary_control']
            verify(original_control['input'], original_control['sha256'])
            require(original_control['max_scaled_error'] < 2e-8
                    and old['saved_width_control']['max_relative_even_error'] < 2e-8, 'Moderate-width replay failed')
            replay = case['prior_width_replay']
            require(replay['status'] == 'PASS' and replay['tau'] == 289.630937574, 'Long-width replay absent')
            require(all(r['moment_relative_error'] < 2e-9 and r['harmonic_relative_error'] < 2e-9
                        for r in replay['observables'].values()), 'Long-width replay outside gate')
            require(len(case['windows']) == 6, 'Incomplete width extension')
            for w in case['windows']:
                require(w['tau'] in TAUS and w['observable'] in ('ordinary', 'increment'), 'Unexpected window')
                for which in ('actual', 'declared_M_harmonic'):
                    a = w[which]
                    require(a['positive_moment_checks']['passed'], 'Necessary moment positivity failed')
                    m, k = moments(a), moments(a, 'cumulants')
                    require(m[1] == 0 and all(m[p] > 0 for p in ORDERS), 'Zero variance or missing centering')
                    reconstructed = formal_log(m)
                    for n in range(2, 9):
                        err = float(abs(reconstructed[n]-k[n]) / max(abs(k[n]), m[2].sqrt()**n))
                        audit['formal_log_max_scaled_error'] = max(audit['formal_log_max_scaled_error'], err)
                        require(err < 1e-60, 'Scalar cumulant mismatch')
                f = w['actual']['filter_arithmetic']
                require(f['actual_ground_diagonal'] == 0., 'Spurious ordinary ground floor')
                if w['observable'] == 'increment':
                    require(f['diagonal_exactly_zero'], 'Increment diagonal not zero')
                require(f['pressure_filter_product_underflow_entries'] == 0, 'New product underflow needs review')
                for n in (4, 6, 8):
                    err = abs(float(shape(w, n))-w['log_shape_A'][str(n)])
                    audit['A_max_absolute_error'] = max(audit['A_max_absolute_error'], err)
                    require(err < 1e-11, 'Stored shape does not match original H0 reference')
                m = moments(w['actual'])
                for p in ORDERS:
                    F = D.from_float(case['centered_pressure_bound']['centered_frobenius_upper'])
                    tau = D.from_float(w['tau'])
                    cutoff = D.from_float(case['original_diagnostics']['omitted_interacting_threshold_lower_bound'])
                    value = float(D(p)*F.ln()-2*(tau*cutoff)**2/D(p)-m[p].ln())
                    err = abs(value-w['conditional_omitted_path_bounds']['log_relative_even_moment_bound'][str(p)])
                    audit['path_log_max_absolute_error'] = max(audit['path_log_max_absolute_error'], err)
                    require(err < 1e-8, 'Conditional centered path bound mismatch')
                spectral.append(dict(case=label, tau=w['tau'], observable=w['observable'],
                                     **w['actual']['spectral_reconstruction']))
                arithmetic.append(dict(case=label, tau=w['tau'], observable=w['observable'],
                    filter=f, filter_deletion_log_relative_even_bounds=w['actual']['filter_deletion_log_relative_even_bounds'],
                    moment_status={n: v['binary64_status'] for n, v in w['actual']['moments'].items()},
                    positive_actual=w['actual']['positive_moment_checks'],
                    positive_reference=w['declared_M_harmonic']['positive_moment_checks']))
                require(all(v['binary64_status'] == 'representable' for group in ('moments', 'cumulants', 'standardized_cumulants')
                            for v in w['actual'][group].values() if v['sign']), 'New nonrepresentable statistic needs review')
                require(w['declared_M_harmonic']['modes'] == 20, 'Wrong harmonic reference mode count')
            beta, harmonic = case['beta_path_rates'], case['harmonic_rate_model']
            hb = harmonic['support_and_degeneracy_sensitivity']
            require(beta['ordinary_lowest_block']['condition'] and harmonic['ordinary_lowest_block']['condition'], 'Ordinary source-block criterion failed')
            require(all(r['result']['condition'] for model in (beta, hb)
                        for r in model['ordinary_lowest_block_sensitivity']), 'Ordinary block support not stable')
            require(harmonic['dimension'] == 14, 'Harmonic diagnostic region changed')
            margins = []
            for name, graph in harmonic['rates'].items():
                require(graph['retained_source_is_entrywise_nonnegative'], 'Harmonic no-cancellation condition changed')
                for p in ORDERS:
                    r = graph['rows'][str(p)]
                    require(r['finite_M_leading_rate_condition_satisfied_in_float_model'], 'Harmonic leading rate incomplete')
                    margins.append(r['omitted_energy_excursion_rate_margin'])
            tie_ratios = {}
            for model_name, model in (('beta', beta), ('harmonic', hb)):
                strict = model['baseline_strict_float_ties']['increment']
                tolerant = sensitivity_zero(model, 'increment')
                for p in ORDERS:
                    a, b = strict['rows'][str(p)], tolerant['rows'][str(p)]
                    require(abs(a['supported_rate']-b['supported_rate']) < 1e-14, 'Leading rate tie sensitivity changed')
                    ratio = D(b['grouped_leading_coefficient_candidate']['decimal'])/D(a['grouped_leading_coefficient_candidate']['decimal'])
                    expected_ratio = 2 if model_name == 'harmonic' and p == 6 else 4 if model_name == 'harmonic' and p == 8 else 1
                    require(abs(ratio-D(expected_ratio)) < D('1e-12'), 'Leading coefficient tie pattern changed')
                    tie_ratios[model_name+str(p)] = float(ratio)
            states = harmonic['states']
            require(states[1] == [2, 0]+[0]*18 and states[2] == [1, 1]+[0]*18
                    and states[4] == [0, 2]+[0]*18, 'Harmonic equal-cost path identification changed')
            ordinary_prediction = case['ordinary_A8_lowest_block_prediction']
            errors = [abs(float(shape(window(case, 'ordinary', tau)))-ordinary_prediction['constant']
                          -ordinary_prediction['tau_squared_slope']*tau*tau) for tau in TAUS]
            require(max(errors) < 1e-9, 'Ordinary source-block prediction no longer matches')
            last = window(case, 'increment', TAUS[-1])
            sensitivity_residual = {str(p): last['supported_group_prediction_check'][str(p)]['difference']
                                    +math.log(tie_ratios['harmonic'+str(p)]) for p in (6, 8)}
            sensitivities[label] = dict(ordinary_prediction=ordinary_prediction,
                ordinary_prediction_max_absolute_error=max(errors), harmonic_cutoff_min_rate_margin=min(margins),
                strict_to_tolerant_coefficient_ratios=tie_ratios,
                last_width_intercept_adjustment_residual=sensitivity_residual,
                beta_path_rates=beta, harmonic_rate_model=harmonic,
                supported_group_A_predictions=case['supported_group_A_predictions'],
                tau_squared_secants=case['tau_squared_secants'])
        for tau in TAUS:
            hi, lo = cases['R10_Q16'], cases['R10_Q14']
            o, x = window(hi, 'ordinary', tau), window(hi, 'increment', tau)
            delta = {name: float(moments(window(hi, name, tau)['actual'])[8]
                                /moments(window(lo, name, tau)['actual'])[8]-1) for name in ('ordinary', 'increment')}
            rows.append(dict(tau=tau, tau_Omega_min=x['tau_Omega_min'],
                A8_ordinary=float(shape(o)), A8_increment=float(shape(x)),
                M8_increment=window(hi, 'increment', tau)['actual']['moments']['8'],
                fractional_M8_Q14_to_Q16=delta,
                fractional_M2_Q14_to_Q16=float(moments(x['actual'])[2]/moments(window(lo, 'increment', tau)['actual'])[2]-1)))
        previous = window(old_cases['R10_Q16'], 'increment', 289.630937574)['log_shape_A']['8']
        require(previous < 0 and all(r['A8_increment'] > 0 and r['A8_ordinary'] < 0 for r in rows), 'Observed crossing pattern changed')
        require(all(r['tau_Omega_min'] > 1 for r in rows), 'Fixed-R infrared scope changed')
        require(all(not s['passed'] for s in spectral), 'Update text: direct spectral status changed')
        filter_max = max(v for c in cases.values() for w in c['windows']
                         for v in w['actual']['filter_deletion_log_relative_even_bounds'].values() if v is not None)
        path_max = max(v for c in cases.values() for w in c['windows']
                       for v in w['conditional_omitted_path_bounds']['log_relative_even_moment_bound'].values())
        require(filter_max < -400 and path_max < -6600, 'Update claimed deletion/path envelopes')
        replay_max = max(v['moment_relative_error'] for c in cases.values()
                         for v in c['prior_width_replay']['observables'].values())
        harmonic_max = max(w['declared_M_harmonic']['validated_binary64_Riccati_max_scaled_difference']
                           for c in cases.values() for w in c['windows'])
    high = sensitivities['R10_Q16']
    op = high['ordinary_prediction']
    last_secant = next(s for s in reversed(cases['R10_Q16']['tau_squared_secants']) if s['observable'] == 'ordinary')['A_slope']['8']
    lines = [r'% Generated from finite_gap_crossover_diagnostic.json; see stage3_finite_gap_provenance.json.',
        r'\subsection{Resolving the fixed-regulator gap crossover}',
        r'\label{sec:s3-finite-gap-results}',
        r'We extend the saved $R=10$, $\beta=1$ full-cosine calculation to three longer widths with $M=20$, $M_{\rm ref}=24$, 32 primitive levels, five active modes and the same bath selection. Let $O_\tau$ be the actual-ground-centered Gaussian average and $X_\tau=O_\tau-O_{2\tau}$. In this subsection $M_p(Y)=\langle Y^p\rangle$ and $A_8^{(0)}(Y)=\log[(M_8/M_2^4)/(M_8^{(0)}/(M_2^{(0)})^4)]$. The reference $(0)$ is the original distributed harmonic $H_0$ evaluated with ordered quadratic algebra at all 20 declared modes. It is not the retained interacting Wick comparator, so the contrast combines altered two-point response with higher information.',
        r'\begin{table}[tbp]\centering\small',
        r'\caption{Extended fixed-$R$ gap crossover. Contrasts use $Q=16$; $\delta_8^Y=M_8^{Q=16}(Y)/M_8^{Q=14}(Y)-1$ measures this occupation/selection refinement only. All rows use normalized vacuum-vector moments; direct spectral weights remain unresolved for both observables and both basis sizes.}\label{tab:s3-finite-gap-results}',
        r'\begin{tabular}{rrrrr}\toprule',
        r'$\tau$ & $A_8^{(0)}(O_\tau)$ & $A_8^{(0)}(X_\tau)$ & $10^6\delta_8^O$ & $10^6\delta_8^X$\\\midrule']
    for r in rows:
        lines.append(f'{r["tau"]:.2f} & {r["A8_ordinary"]:.6f} & {r["A8_increment"]:.6f} & '
                     f'{1e6*r["fractional_M8_Q14_to_Q16"]["ordinary"]:+.3f} & '
                     f'{1e6*r["fractional_M8_Q14_to_Q16"]["increment"]:+.3f}'+r'\\')
    lines += [r'\bottomrule\end{tabular}\end{table}',
        r'The widths have $\tau\Omega_{\min}=5.632,6.336,7.040$, outside the $R=10$ infrared interior. Together with $A_8^{(0)}(X_{289.631})='+f'{previous:.6f}'+r'$, they establish a return through zero in the finite-regulator increment contrast. The increase is a normalized-shape effect: its raw eighth moment decreases throughout this extension. Neither a scaling plateau nor a rare-tail law follows.',
        r'For the ordinary observable with a simple ground state, let $\Pi_\delta$ project onto the complete eigenspace at the smallest pressure-accessible excitation frequency $\delta$, and set $v=\Pi_\delta P_c|0\rangle$, and $D_\delta=\Pi_\delta P_c\Pi_\delta$ on the entire excited block. When $D_\delta v\ne0$, the leading returning paths give $M_{2k}\sim\|D_\delta^{k-1}v\|^2e^{-\delta^2\tau^2}$: the two ground edges supply the cost and the intermediate zero-gap block supplies the prefactor. This condition holds in both saved nonlinear matrices and the harmonic reference across the declared source-threshold and near-degeneracy sensitivity checks. For $Q=16$, the resulting conditional prediction is',
        r'\begin{equation}',
        r'A_8^{(0)}(O_\tau)\sim '+f'{op["constant"]:.11f}'+r'-'+sci(abs(op['tau_squared_slope']), 11)+r'\,\tau^2.',
        r'\label{eq:s3-finite-gap-ordinary-prediction}',
        r'\end{equation}',
        r'Its coefficient is $3(\delta_\beta^2-\delta_0^2)$, with $\delta_\beta='+f'{op["beta_delta"]:.14f}'+r'$ and $\delta_0='+f'{op["harmonic_delta"]:.14f}'+r'$. The new values agree with the full prefactor-and-rate prediction within $'+sci(high['ordinary_prediction_max_absolute_error'], 2)+r'$ in $A_8$; the final measured $\tau^2$ secant is $'+sci(last_secant, 11)+r'$. This agreement concerns the saved matrices and their stated source.',
        r'The increment annuls every zero-gap block, so higher-order paths traverse additional excited-state gaps. Its supported rates remain stable under the tested thresholds, but the leading coefficient is sensitive to numerical grouping of harmonic equal-cost paths. In the saved harmonic sensitivity rows, changing the relative tie tolerance from zero to $10^{-12}$ multiplies the sixth- and eighth-order candidate coefficients by two and four, respectively, without changing their rates; the nonlinear coefficients are unchanged. The states $|2,0\rangle$, $|1,1\rangle$ and $|0,2\rangle$ denote occupations of the two lowest harmonic normal modes, $\omega_0<\omega_1$, with all other modes in the vacuum. They have successive gaps $\omega_1-\omega_0$ and equal adjacent quadratic-source amplitudes. Their equal-cost half paths explain why coefficients must be grouped before squaring. Thus the strict-floating-tie increment intercept is not established as a unique physical asymptotic coefficient: the alternative grouping shifts the predicted $A_6^{(0)}$ and $A_8^{(0)}$ by $-\log2$ and $-\log4$. Actual finite-width values in the table use the all-mode harmonic reference and are unaffected by this path diagnostic.',
        r'The harmonic leading-rate check includes every even Fock state below $8\omega_{\min}$ and excludes omitted-energy paths by a positive rate margin at orders two through eight. This is a rate-completeness check in the declared floating model, not a finite-width amplitude truncation. The nonlinear eighth-order supported increment path includes a pressure entry of about $1.80\times10^{-9}$; it survives the tested source thresholds, but those thresholds and the transform-roundoff scale are sensitivity diagnostics rather than a certified physical source-error bound.',
        r'All 13 new rate, cancellation and rejection controls pass, and the earlier controlled arithmetic tests remain applicable. Replaying the prior long width agrees within $'+sci(replay_max, 2)+r'$ in raw moments. Necessary positive-moment checks pass through order eight; actual ground centering and increment zero diagonals are enforced. Nonzero reported statistics remain representable, and the explicit filter-deletion relative envelopes are below $e^{-400}$. All 12 new direct spectral reconstructions remain unresolved, so no direct probability distribution or cumulative distribution is inferred. Decimal scalar accumulation preserves small amplitudes without improving the binary64 eigenpairs or projected source.',
        r'The conditional relative even-moment omitted-path envelopes are below $e^{-6600}$, assuming an exact retained spectral subspace and a common exact ground. They exclude the original subspace, state, source and physical-regulator errors. Together with the small $Q=14\to16$ changes, these checks support the fixed-regulator crossover while leaving increasing-depth and continuum conclusions separate.']
    fragment = '\n'.join(lines) + '\n'
    report = dict(status='COMPLETED', scope='saved-data manuscript extraction; no physical/matrix calculation',
        input_status=data['status'], input_warnings=data['warnings'], verified_input_sha256=verified,
        executed_analysis_source_sha256=data['source_sha256'], inherited_source_sha256=data['prior_source_sha256'],
        historical_physical_source_sha256=upstream,
        generator=dict(path=str(Path(__file__).relative_to(ROOT)), sha256=sha(Path(__file__))),
        memory_allowance_mb=memory, scalar_audit=audit, selected_rows=rows,
        new_rate_controls=checks, inherited_arithmetic_controls=prior['new_arithmetic_controls'],
        prior_width_replays={k: c['prior_width_replay'] for k, c in cases.items()},
        maximum_prior_width_relative_error=replay_max, harmonic_Riccati_max_scaled_difference=harmonic_max,
        spectral_reconstruction=spectral, arithmetic_status=arithmetic,
        largest_log_relative_filter_deletion_bound=filter_max,
        largest_conditional_log_relative_even_path_bound=path_max,
        rate_and_tie_diagnostics=sensitivities,
        original_finite_tensor_diagnostics={k: c['original_diagnostics'] for k, c in cases.items()},
        saved_matrix_eigensolve_diagnostics={k: c['eigensolve'] for k, c in cases.items()},
        previous_increment_A8=dict(tau=289.630937574, value=previous),
        reference='original distributed harmonic H0, all M=20 modes; not retained interacting Wick comparator',
        limitations=['fixed R10 outside infrared interior; no common-interior convergence',
            'strict floating harmonic increment intercept not unique under saved tie sensitivity',
            'direct spectral weights and CDF unresolved', 'source-support threshold is not a physical source certificate',
            'conditional omitted paths exclude state/source/subspace and regulator errors',
            'no scaling plateau, rare-tail law, or continuum result'])
    mode = 'w' if args.replace else 'x'
    with target.open(mode) as stream:
        stream.write(fragment)
    report['output_sha256'] = {TARGET: sha(target)}
    with provenance.open(mode) as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print('COMPLETED finite-gap manuscript fragment and provenance', flush=True)


if __name__ == '__main__':
    main()
