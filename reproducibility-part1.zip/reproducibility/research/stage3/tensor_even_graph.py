"""Even-total-parity invariant graph for an unchanged low x bath tensor model.

Only bath-ground x active-even vectors are retained target columns. Excited-bath
rows include both active parities: odd x odd is essential virtual dressing.
The returned first excitation gap is EVEN, not the physical lowest gap. Ground
to odd field response and a full Gibbs trace need a separate odd calculation.

Prepared without numerical execution by the effective-boundary theory agent.
"""
import numpy as np
import os
from scipy.linalg import eigh
from tensor_cosine import compress_terms, operator_norm_bound


def state_parities(states):
    states = np.asarray(states)
    if states.ndim != 2 or not len(states):
        raise ValueError('states must be a nonempty matrix of modal occupations')
    if np.any(states < 0) or np.any(states != np.floor(states)):
        raise ValueError('modal occupations must be nonnegative integers')
    # mean_field.parity_eigh verifies that orbital index modulo two is parity.
    return np.asarray(states.sum(axis=1), dtype=np.int64) % 2


def block_parity_eigh(matrix, parities, parity_tolerance=None):
    """Diagonalize parity blocks separately, retaining exact eigenvector parity.

    Roundoff-sized cross-parity entries are measured, never silently promoted to
    a physical interaction. Final residuals below use the ORIGINAL full model.
    """
    matrix = np.asarray(matrix)
    if np.iscomplexobj(matrix) and np.any(matrix.imag != 0):
        raise ValueError('the tensor implementation expects real matrices')
    matrix = np.asarray(matrix.real, dtype=float)
    parities = np.asarray(parities, dtype=int)
    if matrix.shape != (len(parities), len(parities)):
        raise ValueError('parity labels do not match matrix shape')
    scale = max(1., operator_norm_bound(matrix))
    allowed = (128*np.finfo(float).eps*scale if parity_tolerance is None
               else float(parity_tolerance))
    asymmetry = float(np.linalg.norm(matrix-matrix.T))
    forbidden = parities[:, None] != parities[None, :]
    leakage = float(np.linalg.norm(matrix[forbidden]))
    if max(asymmetry, leakage) > allowed:
        raise ArithmeticError('factor Hamiltonian is not parity invariant to roundoff')
    energies, vectors, labels = [], [], []
    for parity in (0, 1):
        ix = np.flatnonzero(parities == parity)
        if not len(ix):
            continue
        e, u = eigh(matrix[np.ix_(ix, ix)], check_finite=False)
        embedded = np.zeros((len(matrix), len(ix)))
        embedded[ix] = u
        energies.extend(e)
        vectors.extend(embedded.T)
        labels.extend([parity]*len(e))
    # A stable energy sort never mixes degenerate opposite-parity vectors.
    order = np.argsort(energies, kind='stable')
    e = np.asarray(energies)[order]
    u = np.asarray(vectors)[order].T
    labels = np.asarray(labels, dtype=int)[order]
    return e, u, labels, dict(cross_parity_frobenius=leakage,
                             symmetry_frobenius=asymmetry,
                             allowed_absolute_roundoff=allowed)


def _pressure_bounds(model, low_parity, bath_parity, even_dimension):
    """Finite-tensor source norm bounds; no omitted-mode/basis certificate."""
    nl, nb = len(low_parity), len(bath_parity)
    factors = [(model['PL'], np.eye(nb)), (np.eye(nl), model['PB'])]
    factors += model['pterms']
    op_bound = sum(operator_norm_bound(a)*operator_norm_bound(b)
                   for a, b in factors)
    ordinary, signed = [], []
    sl = 1-2*low_parity
    sb = 1-2*bath_parity
    for a, b in factors:
        for c, d in factors:
            ordinary.append(float(np.sum(a*c)*np.sum(b*d)))
            # Tr(Pi_total P^T P), with Pi weighting input columns.
            signed.append(float(np.sum(a*c*sl[None, :])
                                * np.sum(b*d*sb[None, :])))
    full_sum = sum(ordinary)
    even_sum = .5*(full_sum+sum(signed))
    rounding = (64*np.finfo(float).eps
                * sum(abs(x) for x in ordinary+signed))
    # ||P Pi_even||_F bounds ||Pi_even P Pi_even||_F even in the
    # presence of tiny numerical parity leakage.
    gram_bound = np.sqrt(max(0., even_sum)+rounding)
    return dict(pressure_operator_norm_bound=float(op_bound),
                pressure_frobenius_bound=float(min(op_bound*np.sqrt(even_dimension),
                                                  gram_bound)),
                pressure_frobenius_from_tensor_gram=float(np.sqrt(max(0., even_sum))),
                pressure_full_tensor_frobenius=float(np.sqrt(max(0., full_sum))),
                pressure_tensor_gram_roundoff=float(rounding),
                pressure_gram_scope='finite tensor, even input columns')


def invariant_graph_even(model, tolerance=2e-14, max_iterations=80,
                         damping=1., compress=True, parity_tolerance=None):
    """Return even-sector Heff, Peff, and original-model diagnostics.

    The graph has shape (Nb-1, Nlow, Neven), with forbidden parity rows exactly
    zero. No low-state-dependent bath selection is made. Compression and the
    iteration affect the graph approximation; returned H/P are projections of
    the ORIGINAL supplied tensor operators, not the compressed Hamiltonian.
    """
    lp0 = state_parities(model['low_states'])
    bp0 = state_parities(model['bath_states'])
    raw_eb, ub, bp, hb_parity = block_parity_eigh(model['HB'], bp0, parity_tolerance)
    if len(raw_eb) < 2:
        raise ValueError('a nontrivial bath basis is required')
    if bp[0] != 0:
        raise ArithmeticError('the bath reference ground state is not even')
    eb = raw_eb-raw_eb[0]
    bath_terms = [(a, ub.T@b@ub) for a, b in model['hterms']]
    active = model['HL'].copy()
    for a, b in bath_terms:
        active += b[0, 0]*a
    raw_ea, ua, lp, active_parity = block_parity_eigh(active, lp0, parity_tolerance)
    if lp[0] != 0:
        raise ArithmeticError('the active reference ground state is not even')
    ea = raw_ea-raw_ea[0]
    even = np.flatnonzero(lp == 0)
    nl, nb, ne = len(ea), len(eb), len(even)
    if not len(even):
        raise ValueError('no active even states')
    original_terms = [(ua.T@a@ua, b) for a, b in bath_terms]
    centered_terms = [(a, b-b[0, 0]*np.eye(nb)) for a, b in original_terms]
    ts = centered_terms
    compression = None
    compression_bound = 0.
    if compress and ts:
        ts, compression = compress_terms(ts)
        compression = dict(compression)
        compression_bound = compression['discarded_frobenius_bound']
    # Centering is an exact algebraic property. QR can introduce a tiny 00
    # entry; resetting it is separately bounded, including the no-compress path.
    reset_bound = 0.
    reset_terms = []
    for a, b in ts:
        reset_bound += operator_norm_bound(a)*abs(float(b[0, 0]))
        b = b.copy()
        b[0, 0] = 0.
        reset_terms.append((a, b))
    ts = reset_terms
    compression_bound += reset_bound
    if compression is not None:
        compression['center_reset_norm_bound'] = float(reset_bound)
        compression['total_operator_error_bound'] = float(compression_bound)

    allowed_q = bp[1:, None] == lp[None, :]
    allowed_all = bp[:, None] == lp[None, :]
    den = eb[1:, None, None]+ea[None, :, None]-ea[even][None, None, :]
    bare_separation = float(np.min(den[allowed_q]))
    if bare_separation <= 0:
        raise ArithmeticError('bath gap overlaps retained active-even spectral window')
    den[~allowed_q] = 1.  # These entries have identically zero graph components.
    coupling = np.zeros((nb-1, nl, ne))
    for a, b in ts:
        coupling += b[1:, 0, None, None]*a[:, even]
    coupling[~allowed_q] = 0.
    omega = -coupling/den
    history = []

    def off_apply(w):
        y = np.zeros_like(w)
        for a, b in ts:
            t = np.matmul(a, w)
            y += (b[1:, 1:]@t.reshape(nb-1, -1)).reshape(w.shape)
        y[~allowed_q] = 0.
        return y

    def coupling_back(w):
        return np.einsum('bij,bik->jk', coupling, w, optimize=True)

    for _ in range(max_iterations):
        feedback = coupling_back(omega)
        residual = (coupling+den*omega+off_apply(omega)
                    - np.matmul(omega, feedback))
        residual[~allowed_q] = 0.
        size = float(np.linalg.norm(residual))
        history.append(size)
        if size < tolerance:
            break
        omega -= damping*residual/den
        omega[~allowed_q] = 0.
        if not np.isfinite(omega).all() or np.linalg.norm(omega) > 2:
            raise ArithmeticError('even graph iteration outside admitted neighborhood')
    else:
        raise ArithmeticError('even invariant graph failed to converge')

    metric = np.eye(ne)+np.einsum('bij,bik->jk', omega, omega, optimize=True)
    se, su = eigh(metric, check_finite=False)
    sinv = (su/np.sqrt(se))@su.T
    graph_spectral_norm = float(np.sqrt(max(0., se[-1]-1.)))
    if graph_spectral_norm >= 1.:
        raise ArithmeticError('graph is not in the low-cluster angular neighborhood')
    graph_norm = float(np.linalg.norm(omega))
    odd_odd_norm = float(np.linalg.norm(omega[(bp[1:, None] == 1)
                                              & (lp[None, :] == 1)]))
    w = np.zeros((nb, nl, ne))
    w[0, even, :] = sinv
    w[1:] = omega@sinv
    forbidden_graph = float(np.linalg.norm(w[~allowed_all]))
    del omega, coupling, den, residual, feedback

    # Project the ORIGINAL supplied H. Constant shifts merely keep residuals
    # accurate; retained eigenvalues have this common shift removed.
    hl = ua.T@model['HL']@ua-raw_ea[0]*np.eye(nl)
    hb = ub.T@model['HB']@ub-raw_eb[0]*np.eye(nb)
    hw = np.matmul(hl, w)+(hb@w.reshape(nb, -1)).reshape(w.shape)
    for a, b in original_terms:
        hw += (b@np.matmul(a, w).reshape(nb, -1)).reshape(w.shape)
    heff = np.einsum('bij,bik->jk', w, hw, optimize=True)
    heff = (heff+heff.T)/2
    hw -= np.matmul(w, heff)
    invariant_residual = float(np.linalg.norm(hw))
    del hw

    pl = ua.T@model['PL']@ua
    pb = ub.T@model['PB']@ub
    pw = np.matmul(pl, w)+(pb@w.reshape(nb, -1)).reshape(w.shape)
    for a, b in model['pterms']:
        pw += ((ub.T@b@ub)@np.matmul(ua.T@a@ua, w).reshape(nb, -1)).reshape(w.shape)
    pressure_parity_leakage = float(np.linalg.norm(pw[~allowed_all]))
    peff = np.einsum('bij,bik->jk', w, pw, optimize=True)
    peff = (peff+peff.T)/2
    pw -= np.matmul(w, peff)
    low_high_source = float(np.linalg.norm(pw))
    del pw

    # Weyl/min-max bounds on the ORIGINAL Hamiltonian, including errors from
    # compression and finite parity-block diagonalization. The Q threshold is
    # taken in EVEN TOTAL parity and includes the odd-bath x odd-active rows.
    interaction = sum(operator_norm_bound(a)*operator_norm_bound(b) for a, b in ts)
    base_error = (operator_norm_bound(ua.T@active@ua-np.diag(raw_ea))
                  + operator_norm_bound(hb-np.diag(eb)))
    q_free_min = float(np.min((eb[1:, None]+ea[None, :])[allowed_q]))
    d_lower = q_free_min-interaction-compression_bound-base_error
    a_upper = float(np.max(ea[even])+base_error)
    comparison = None
    even_comparison = None
    odd_comparison = None
    if d_lower <= a_upper:
        from tensor_comparison_bounds import TensorComparisonBound
        comparison = TensorComparisonBound(ea, eb, ts, lp, bp,
            external_error=compression_bound+base_error,
            memory_mb=float(os.environ['PYSCF_MAX_MEMORY']))
        even_comparison = comparison.lower_bound(0, excited_bath=True, target=a_upper)
        d_lower = max(d_lower, even_comparison['lower_bound'])
    aq_margin = d_lower-a_upper
    if aq_margin <= 0:
        raise ArithmeticError('even A/Q cluster separation is not certified')
    eig = eigh(heff, eigvals_only=True, check_finite=False)
    # The direct residual already includes compression error; adding its bound
    # again is deliberate conservatism and keeps the original solver contract.
    residual_bound = invariant_residual+compression_bound
    threshold = float(d_lower-eig[0]-residual_bound)
    cluster_margin = float(threshold-(eig[-1]-eig[0])-2*residual_bound)
    if cluster_margin <= 0:
        raise ArithmeticError('lowest retained even cluster is not certified')
    odd_mask = bp[:, None] != lp[None, :]
    odd_threshold = None
    if np.any(odd_mask):
        odd_free = float(np.min((eb[:, None]+ea[None, :])[odd_mask]))
        odd_threshold = float(odd_free-interaction-compression_bound-base_error
                              -eig[0]-residual_bound)
    odd_block_bound = None
    odd_active = np.flatnonzero(lp == 1)
    odd_q = bp[1:, None] != lp[None, :]
    if len(odd_active) and np.any(odd_q):
        a_odd = float(np.min(ea[odd_active])-base_error)
        d_odd = float(np.min((eb[1:, None]+ea[None, :])[odd_q])
                      -interaction-compression_bound-base_error)
        # Original offdiagonal factors, not the compressed interaction. The
        # operator triangle bound avoids another large graph-sized allocation.
        b_odd = float(sum(operator_norm_bound(a[:, odd_active])
                          *np.linalg.norm(b[1:, 0]) for a,b in original_terms)
                      +base_error)
        correction = (0. if b_odd == 0 else
                      2*b_odd*b_odd/(abs(d_odd-a_odd)
                                     +np.hypot(d_odd-a_odd,2*b_odd)))
        lower = min(a_odd,d_odd)-correction
        tighter = float(lower-eig[0]-residual_bound)
        odd_block_bound = dict(active_min=a_odd,excited_bath_min=d_odd,
                               coupling_norm_bound=b_odd,block_min=lower,
                               odd_excitation_lower_bound=tighter,
                               method='two by two Hermitian block min-max bound')
        odd_threshold = tighter if odd_threshold is None else max(odd_threshold,tighter)
    if odd_threshold is not None and odd_threshold <= 0:
        if comparison is None:
            from tensor_comparison_bounds import TensorComparisonBound
            comparison = TensorComparisonBound(ea, eb, ts, lp, bp,
                external_error=compression_bound+base_error,
                memory_mb=float(os.environ['PYSCF_MAX_MEMORY']))
        odd_comparison = comparison.lower_bound(1, excited_bath=False,
            target=float(eig[0]+residual_bound))
        odd_threshold = float(max(odd_threshold, odd_comparison['lower_bound']-eig[0]-residual_bound))
    even_dimension = int(np.count_nonzero(allowed_all))
    info = dict(even_Q_comparison_bound=even_comparison, odd_comparison_bound=odd_comparison, iterations=len(history), riccati_residual_history=history,
                invariant_residual_frobenius=invariant_residual,
                invariant_residual_scope='original full tensor Hamiltonian',
                original_hamiltonian_residual_bound=float(residual_bound),
                retained_cluster_certification_margin=cluster_margin,
                active_even_to_excited_bath_separation_margin=float(aq_margin),
                orthogonality_error=float(np.linalg.norm(
                    np.einsum('bij,bik->jk', w, w)-np.eye(ne))),
                bare_separation=bare_separation,
                interaction_norm_bound=float(interaction),
                base_diagonalization_error_bound=float(base_error),
                norm_bound_method='minimum Frobenius and induced 1/infinity bounds',
                omitted_interacting_threshold_lower_bound=threshold,
                omitted_threshold_scope='same even-total-parity finite tensor sector',
                odd_sector_threshold_lower_bound=odd_threshold,
                odd_sector_block_bound=odd_block_bound,
                even_ground_certified_against_odd=bool(odd_threshold is not None
                                                   and odd_threshold > 0),
                full_space_omitted_threshold_lower_bound=(threshold if odd_threshold is None
                                                          else min(threshold, odd_threshold)),
                free_excited_bath_even_threshold=q_free_min,
                minimum_bath_excitation=float(eb[1]),
                low_high_source_frobenius=low_high_source,
                graph_norm=graph_norm, graph_norm_kind='Frobenius',
                graph_spectral_norm=graph_spectral_norm,
                odd_odd_graph_frobenius=odd_odd_norm,
                forbidden_parity_graph_frobenius=forbidden_graph,
                pressure_forbidden_parity_source_frobenius=pressure_parity_leakage,
                compression=compression, compression_operator_error_bound=float(compression_bound),
                low_dimension=ne, low_factor_dimension=nl, bath_dimension=nb,
                full_even_tensor_dimension=even_dimension,
                active_odd_dimension=int(np.count_nonzero(lp)),
                bath_even_dimension=int(np.count_nonzero(bp == 0)),
                bath_odd_dimension=int(np.count_nonzero(bp)),
                retained_sector='even total parity',
                first_returned_gap_is='even excitation; not physical lowest excitation',
                graph_array_entries=int((nb-1)*nl*ne),
                previous_graph_array_entries=int((nb-1)*nl*nl),
                graph_storage_ratio=float(ne/nl),
                hamiltonian_common_shift=float(raw_ea[0]+raw_eb[0]),
                parity_block_diagnostics=dict(bath=hb_parity, active=active_parity))
    info.update(_pressure_bounds(model, lp0, bp0, even_dimension))
    return heff, peff, info
