"""Bounded saved-H/P common-width analysis. Prepared for central execution only.

No physical Hamiltonian, product basis, calibration or archive is changed.
Exact harmonic means exact ordered quadratic algebra at the declared M modes.
Normalized vacuum-vector recurrence avoids reconstructing tiny spectral weights.
Decimal scalars do not improve binary64 Hamiltonian eigenpairs/source entries.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import hashlib
import json
import math
import os
import sys
import time
import zipfile
import numpy as np
from scipy.linalg import eigh

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT/'research/stage3'), str(ROOT/'src'), str(ROOT/'research')]
from full_cosine_hierarchy import parameters
from distributed_line import quantum_quadratic_cumulants
from pressure_cumulant_error_bounds import (memory_limit_mb,
    centered_frobenius_upper, returning_path_moment_bounds)

TAUS = (144.8154687872, 204.8, 289.630937574)
BASE = 'results/stage3_2026-09-15/'
JOBS = [('R10_Q14', BASE+'equal_phase_occupation_retry.json', 1),
        ('R10_Q16', BASE+'equal_phase_Q16_selected.json', 0)]
R14 = ('R14_Q10', BASE+'equal_phase_R14_common_chunked.json', 0)
ORDINARY_RECORDS = {'R10_Q14': BASE+'ordered_cumulants_occupation_retry.json',
    'R10_Q16': BASE+'ordered_cumulants_equal_phase_Q16_selected.json'}
ORDER = 8
D = Decimal


def local(name):
    p = (ROOT/name).resolve()
    if not p.is_relative_to(ROOT): raise ValueError('Project-local paths required')
    return p


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''): h.update(b)
    return h.hexdigest()


def dec(x):
    if isinstance(x, Decimal): return x
    if isinstance(x, np.longdouble): return D(str(x))
    return D.from_float(float(x))


def value(x):
    x = dec(x)
    if not x.is_finite(): raise ArithmeticError('Nonfinite scalar')
    if x == 0:
        return dict(value=0., decimal='0', sign=0, log_abs=None,
                    binary64_status='zero_in_stated_finite_arithmetic')
    f = float(x)
    status = 'representable'
    if f == 0: f, status = None, 'underflow_nonzero'
    elif not math.isfinite(f): f, status = None, 'overflow_nonzero'
    return dict(value=f, decimal=str(x), sign=1 if x>0 else -1,
                log_abs=float(abs(x).ln()), binary64_status=status)


def cumulants(m):
    k = {0: D(0)}
    for n in range(1, ORDER+1):
        k[n] = m[n]-sum((D(math.comb(n-1,j-1))*k[j]*m[n-j]
                         for j in range(1,n)), D(0))
    return k


def raw(k):
    m = {0: D(1)}
    for n in range(1, ORDER+1):
        m[n] = sum((D(math.comb(n-1,j-1))*k[j]*m[n-j]
                    for j in range(1,n+1)), D(0))
    return m


def error(a, b):
    return max(float(abs(a[n]-b[n])/max(abs(b[n]),
        b[2].sqrt()**n, D('1e-10000'))) for n in range(2, ORDER+1))


def positive_checks(m):
    if any(m[n] <= 0 for n in (2,4,6,8)):
        raise ArithmeticError('Nonpositive even moment: unresolved, never interpreted as physical zero')
    # Necessary positivity tests for the spectral law of one self-adjoint X.
    hankel = np.array([[float(m[i+j]/(m[2*i]*m[2*j]).sqrt())
                       for j in range(5)] for i in range(5)])
    eig = eigh((hankel+hankel.T)/2, eigvals_only=True, check_finite=False)
    logconvex = [float(m[n]**2/(m[n-2]*m[n+2])) for n in (2,4,6)]
    odd_cs = [float(m[n]**2/(m[n-1]*m[n+1])) for n in (1,3,5,7)]
    passed = min(eig) >= -2e-9 and max(logconvex+odd_cs) <= 1+2e-9
    if not passed: raise ArithmeticError('Necessary positive moment inequalities failed')
    return dict(passed=True, even_moments_strictly_positive=True,
        normalized_Hankel_min_eigenvalue=float(min(eig)),
        even_log_convex_ratios=logconvex, odd_Cauchy_Schwarz_ratios=odd_cs,
        tolerance=2e-9, scope='necessary positivity checks; not a full error certificate')


def normalized_moments(X):
    """X^k|0> = amplitude*v, ||v||=1; store amplitude in Decimal."""
    scale = float(np.max(abs(X)))
    if scale <= 0: raise ArithmeticError('Zero observable in numerical representation')
    Y = X/scale
    v = np.zeros(len(X)); v[0] = 1.
    amplitude = D(1)
    m = {0:D(1), 1:D(0)}
    steps = []
    for j in range(4):
        w = Y@v
        if j:
            m[2*j+1] = amplitude**2*dec(scale)*dec(np.dot(v,w))
        maximum = float(np.max(abs(w)))
        if maximum == 0: raise ArithmeticError('Vacuum Krylov vector vanished: unresolved arithmetic')
        norm = maximum*float(np.sqrt(np.dot(w/maximum,w/maximum)))
        amplitude *= dec(scale)*dec(norm)
        v = w/norm
        m[2*j+2] = amplitude**2
        steps.append(dict(power=j+1, norm_before_rescaling=norm,
                          log_physical_vector_norm=float(amplitude.ln())))
    return m, dict(matrix_scale=scale, steps=steps,
        scalar_precision_digits=80, vector_arithmetic='binary64 with a fresh norm at each multiplication')


def filtered(Pc, E, tau, increment, ratio=2., hbar=1.):
    z = -.5*(tau*(E[:,None]-E[None,:])/hbar)**2
    # Explicitly bound this numerical deletion instead of silently underflowing.
    keep = z >= -700.
    f = np.zeros_like(z)
    f[keep] = np.exp(z[keep])
    if increment:
        f[keep] *= -np.expm1((ratio*ratio-1)*z[keep])
        np.fill_diagonal(f, 0.)
    with np.errstate(under="ignore"):
        X = Pc*f
    product_underflow = int(np.count_nonzero((Pc != 0) & (f != 0) & (X == 0)))
    X[0,0] = 0.  # Exact actual-ground centering; never leave a numerical floor.
    dropped = int(np.count_nonzero((~keep) & (Pc != 0)))
    delta = (D(len(Pc))*dec(np.max(abs(Pc)))*D(-700).exp()
             *D('1.00000000001')) if dropped else D(0)
    if product_underflow:
        delta += D(len(Pc))*dec(np.nextafter(0.,1.))
    return X, dict(dropped_nonzero_source_entries=dropped,
        pressure_filter_product_underflow_entries=product_underflow,
        dropped_ground_row_entries=int(np.count_nonzero((~keep[0]) & (Pc[0]!=0))),
        deletion_operator_norm_upper=value(delta), filter_exponent_floor=-700.,
        actual_ground_diagonal=float(X[0,0]),
        diagonal_exactly_zero=bool(np.all(np.diag(X)==0)) if increment else None), delta


def eigen_prepare(H,P):
    if np.iscomplexobj(H) or np.iscomplexobj(P):
        raise ValueError('This bounded driver supports the saved real symmetric archives only')
    for x in (H,P):
        if not np.all(np.isfinite(x)) or not np.allclose(x,x.T,rtol=1e-12,atol=1e-14):
            raise ValueError('Finite symmetric H/P required')
    anchor = float(H[0,0]); HH = (H+H.T)/2-anchor*np.eye(len(H))
    E,U = eigh(HH, check_finite=False, driver='evr')
    residual = float(np.linalg.norm(HH@U-U*E))
    orthogonality = float(np.linalg.norm(U.T@U-np.eye(len(U))))
    resolution = 64*np.finfo(float).eps*max(float(np.max(abs(E))),1e-300)
    if E[1]-E[0] <= resolution: raise ArithmeticError('Ground not numerically resolved')
    Pe = U.T@P@U; Pe = (Pe+Pe.T)/2
    c = float(Pe[0,0]); Pc = Pe-c*np.eye(len(Pe)); Pc[0,0] = 0.
    return E-E[0], Pc, c, dict(ground_energy=float(E[0]+anchor),
        first_returned_even_gap=float(E[1]-E[0]),
        eigensolve_residual_frobenius=residual, eigenvector_orthogonality_frobenius=orthogonality,
        diagnostic_gap_uncertainty_twice_residual=2*residual,
        resolution_scale=resolution,
        scope='binary64 eigenpairs of saved H; residual diagnostics are not a rigorous interval eigensolve')


def spectral_check(X,m):
    s = float(np.max(abs(X))); x,U = eigh(X/s,check_finite=False)
    probabilities = U[0]**2
    mm = {0:D(1)}
    for n in range(1,9):
        mm[n] = sum((dec(p)*(dec(z)*dec(s))**n
                      for p,z in zip(probabilities,x)),D(0))
    err = max(error(mm,m),error(cumulants(mm),cumulants(m)))
    return dict(passed=err<=1e-8, max_scaled_error=err,
        probability_sum=float(sum(probabilities)),
        status='RESOLVED' if err<=1e-8 else 'UNRESOLVED_SMALL_SPECTRAL_WEIGHTS',
        scope='independent binary64 smeared-matrix diagonalization; failure does not replace vacuum recurrence by zeros')


def summarize(m):
    k = cumulants(m); checks = positive_checks(m)
    return dict(moments={str(n):value(m[n]) for n in range(1,9)},
        even_moments={str(n):value(m[n]) for n in (2,4,6,8)},
        cumulants={str(n):value(k[n]) for n in range(2,9)},
        standardized_cumulants={str(n):value(k[n]/m[2].sqrt()**n) for n in range(2,9)},
        positive_moment_checks=checks)


def harmonic(modes,tau,inc,ratio):
    """Same ordered Riccati algebra, evaluated in platform longdouble + Decimal."""
    A,B = modes.matrices(); w=modes.omega
    def f(gap):
        z = -np.longdouble('.5')*(np.longdouble(tau)*np.asarray(gap,dtype=np.longdouble))**2
        with np.errstate(under='ignore'):
            r = np.exp(z)
            if inc: r *= -np.expm1(np.longdouble(ratio*ratio-1)*z)
        return r
    A = np.asarray(A,dtype=np.longdouble)*f(w[:,None]-w[None,:])
    B = np.asarray(B,dtype=np.longdouble)*f(w[:,None]+w[None,:])
    z=[np.zeros_like(B),B.copy()]; k={0:D(0),1:D(0),2:dec(np.sum(B*B)/2)}
    for n in range(1,7):
        v=A@z[n]+z[n]@A.T
        for j in range(1,n): v += z[j]@B@z[n-j]
        z.append((v+v.T)/(2*(n+1)))
        k[n+2]=D(math.factorial(n+1))*dec(np.sum(B*z[n+1].T))/2
    m=raw(k); answer=summarize(m)
    # Independently compare the existing validated binary64 implementation.
    kk={int(n):dec(v) for n,v in quantum_quadratic_cumulants(A,B,8).items()}
    err=error(kk,k)
    if err>2e-8: raise ArithmeticError('Harmonic arithmetic disagreement')
    answer.update(scope='exact ordered quadratic algebra at all declared M continuum-shooting modes; not M-infinity',
        modes=len(w), longdouble_mantissa_bits=int(np.finfo(np.longdouble).nmant),
        validated_binary64_Riccati_max_scaled_difference=err,
        underflow_policy='all even denominators must be positive; no zero substituted for an unresolved moment')
    return m,answer


def evaluate(Pc,E,tau,inc,ratio):
    X,filter_diag,delta=filtered(Pc,E,tau,inc,ratio)
    m,arithmetic=normalized_moments(X)
    result=summarize(m)
    norm=dec(np.linalg.norm(X))*D('1.00000000001')+delta
    trunc={str(n):value(D(n)*norm**(n-1)*delta) for n in range(2,9)}
    rel={str(n):float((D(n)*norm**(n-1)*delta/m[n]).ln())
         if delta and m[n]>0 else None for n in (2,4,6,8)}
    if any(v is not None and v>math.log(1e-10) for v in rel.values()):
        raise ArithmeticError('Filter deletion bound is not negligible; use higher precision filters')
    result.update(arithmetic=arithmetic,filter_arithmetic=filter_diag,
        filter_deletion_absolute_moment_bounds=trunc,
        filter_deletion_log_relative_even_bounds=rel,
        spectral_reconstruction=spectral_check(X,m))
    return m,result


def independent_controls():
    # Positive control with arbitrarily small ground coupling and O(1) excited block.
    # Decimal direct multiplication is independent of normalized norm recursion.
    checks=[]
    for epsilon in ('0.3','1e-120'):
        e=D(epsilon); exact=[[D(0),e],[e,D(1)]]
        v=[D(1),D(0)]; direct={0:D(1)}
        for n in range(1,9):
            v=[sum((exact[i][j]*v[j] for j in range(2)),D(0)) for i in range(2)]
            direct[n]=v[0]
        observed,_=normalized_moments(np.array([[0.,float(e)],[float(e),1.]]))
        err=error(observed,direct)
        if err>2e-12: raise ArithmeticError('Tiny-coupling positive control failed')
        positive_checks(observed)
        checks.append(dict(control='two_level_Decimal_direct_powers',ground_coupling=epsilon,error=err))
    # Every returning eight-factor quadratic path fits in 12 oscillator levels.
    from types import SimpleNamespace
    class Modes:
        omega=np.array([.7])
        def matrices(self): return np.array([[.9]]),np.array([[.3]])
    a=np.diag(np.sqrt(np.arange(1,12)),1)
    P=.9*(a.T@a)+.15*(a.T@a.T+a@a)
    for inc in (False,True):
        X,_,_=filtered(P,.7*np.arange(12),.8,inc)
        got,_=normalized_moments(X); expected,_=harmonic(Modes(),.8,inc,2.)
        err=error(got,expected)
        if err>2e-10: raise ArithmeticError('Independent complete quadratic paths failed')
        checks.append(dict(control='one_mode_complete_order8_Fock_vs_Riccati',increment=inc,error=err))
    return dict(status='PASS',checks=checks)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',required=True)
    ap.add_argument('--r10-only',action='store_true',help='Otherwise include R14 if its batch is COMPLETED at admission')
    args=ap.parse_args(); destination=local(args.output)
    if destination.suffix!='.json' or destination.exists(): raise FileExistsError('Use a new JSON output')
    mem=memory_limit_mb(); started=time.monotonic()
    files=[Path(__file__),ROOT/'research/stage3/full_cosine_hierarchy.py',
        ROOT/'research/stage3/ordered_matrix_cumulants.py',ROOT/'research/stage3/pressure_cumulant_error_bounds.py',
        ROOT/'src/distributed_line.py',ROOT/'src/nonlinear_pressure.py',ROOT/'research/static_family.py']
    control_files=[BASE+'ordered_matrix_cumulant_controls.json',BASE+'pressure_cumulant_error_bound_controls.json']
    controls=[]
    for name,module in zip(control_files,['research/stage3/ordered_matrix_cumulants.py',
                                          'research/stage3/pressure_cumulant_error_bounds.py']):
        p=local(name); c=json.loads(p.read_text())
        if c.get('status')!='PASS' or c.get('source_sha256',{}).get(module)!=sha(ROOT/module):
            raise ValueError('Required current-hash controls do not pass: '+name)
        controls.append(dict(path=name,sha256=sha(p)))
    out=dict(status='RUNNING',memory_mb=mem,taus=list(TAUS),ratio=2.,hbar=1.,
        completion_status_note='COMPLETED_WITH_WARNINGS is expected even on success because the R10 infrared-scope warning is permanent; numerical failure has status FAILED',
        source_sha256={str(p.relative_to(ROOT)):sha(p) for p in files},controls=controls,cases=[],
        scope='saved finite matrices at fixed absolute widths; regulator and approximate-subspace errors remain separate',
        warnings=['R10 tau*Omega_min=2.49--4.98: outside common infrared interior; no scaling exponents inferred'])
    destination.parent.mkdir(parents=True,exist_ok=True)
    # Exclusive claim prevents concurrent writers from reusing the output path.
    with destination.open('x') as f: json.dump(out,f,indent=2)
    def save():
        out['elapsed_seconds']=time.monotonic()-started
        tmp=destination.with_name(destination.name+'.writing')
        tmp.write_text(json.dumps(out,indent=2,allow_nan=False));tmp.replace(destination)
    try:
        with localcontext() as ctx:
            ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
            out['new_arithmetic_controls']=independent_controls();save()
            jobs=list(JOBS)
            if not args.r10_only:
                p=local(R14[1]); status=json.loads(p.read_text()).get('status') if p.exists() else 'MISSING'
                out['R14_admission_status']=status
                if status=='COMPLETED': jobs.append(R14)
                else: out['warnings'].append('R14 not admitted; batch '+status+' at one-time admission')
            for label,name,ci in jobs:
                p=local(name); source_hash=sha(p); data=json.loads(p.read_text())
                if data.get('status')!='COMPLETED': raise ValueError('Incomplete input '+name)
                case=data['cases'][ci]
                if case.get('status')!='COMPLETED': raise ValueError('Incomplete selected case')
                rec=next(r for r in case['cosine'] if r['beta']==1.)
                diag=rec['diagnostics']
                if not diag.get('even_ground_certified_against_odd'): raise ValueError('Physical ground not certified')
                archive=local(rec['effective_archive']); archive_hash=sha(archive)
                with zipfile.ZipFile(archive) as z:
                    if sum(x.file_size for x in z.infolist()) > .35*mem*1024**2:
                        raise MemoryError('Archive load exceeds allowance')
                with np.load(archive,allow_pickle=False) as arrays:
                    H,P=np.array(arrays['H']),np.array(arrays['P'])
                    omega=np.array(arrays['omega'])
                if 640*len(H)**2 > .6*mem*1024**2: raise MemoryError('Matrix workspace exceeds allowance')
                modes,poles,_=parameters(case['R'],case['M'],case.get('G',-1e-7),case.get('s',0.))
                if not np.allclose(modes.omega,omega,rtol=2e-12,atol=2e-14):
                    raise ArithmeticError('Regenerated harmonic frequencies differ from saved archive')
                E,Pc,c,eigen=eigen_prepare(H,P)
                full_d=diag['full_even_tensor_dimension']
                center=centered_frobenius_upper(diag['pressure_frobenius_bound'],c,full_d,memory_mb=mem)
                row=dict(label=label,input=name,input_sha256=source_hash,archive=str(archive.relative_to(ROOT)),
                    archive_sha256=archive_hash,context={k:case[k] for k in ['R','M','Q','tau','primitive','low_count','bath_top','calibration_modes'] if k in case},
                    beta=1.,hbar=1.,dimension=len(H),eigensolve=eigen,
                    removed_scalar_in_supplied_P=c,centering_scope='actual ground of supplied H; no calibrated mean inferred',
                    original_diagnostics=diag,centered_pressure_bound=center,windows=[],
                    reference_scope='all M distributed harmonic modes, never archived H0/P0',
                    harmonic_mode_data=dict(omega=modes.omega.tolist(),endpoint=modes.endpoint.tolist(),slope=modes.slope.tolist()))
                out['cases'].append(row);save()
                # Mandatory saved moderate-width calibration before accepting long R10 rows.
                control_tau=51.2 if case['R']==10 else case['tau']
                mm,check=evaluate(Pc,E,control_tau,True,2.)
                old=next(w for w in rec['windows'] if abs(w['tau']-control_tau)<1e-8)
                control_error=max(float(abs(mm[n]/dec(old['moments'][str(n)])-1)) for n in (2,4,6,8))
                if control_error>2e-8: raise ArithmeticError('Saved increment moment control failed')
                row['saved_width_control']=dict(tau=control_tau,increment=True,max_relative_even_error=control_error,
                    positive_checks=check['positive_moment_checks'])
                if label in ORDINARY_RECORDS:
                    op=local(ORDINARY_RECORDS[label]); od=json.loads(op.read_text())
                    if od.get('status')!='COMPLETED': raise ValueError('Incomplete saved ordered control')
                    rr=next(r for r in od['cases'] if r['archive_sha256']==archive_hash)
                    oo=next(w for w in rr['windows'] if w['observable']=='ordinary' and abs(w['tau']-51.2)<1e-8)
                    ordinary,_=evaluate(Pc,E,51.2,False,2.)
                    expected={int(n):dec(v) for n,v in oo['actual']['moments'].items()}
                    err=error(ordinary,expected)
                    if err>2e-8: raise ArithmeticError('Saved ordinary moment control failed')
                    row['saved_ordinary_control']=dict(input=ORDINARY_RECORDS[label],sha256=sha(op),tau=51.2,max_scaled_error=err)
                save()
                for tau in TAUS:
                    for inc in (False,True):
                        m,actual=evaluate(Pc,E,tau,inc,2.)
                        mh,harm=harmonic(modes,tau,inc,2.)
                        shape={str(n):float((m[n]/mh[n]).ln()-D(n)/2*(m[2]/mh[2]).ln()) for n in (4,6,8)}
                        paths=returning_path_moment_bounds(center['centered_frobenius_upper'],tau,
                            diag['omitted_interacting_threshold_lower_bound'],increment=inc,ratio=2.,
                            omitted_state_count=full_d-len(H),memory_mb=mem)
                        relative={str(n):float(D(str(paths['moments'][str(n)]['log_absolute_error_upper']))-m[n].ln()) for n in (2,4,6,8)}
                        paths.update(log_relative_even_moment_bound=relative,
                            application_status='CONDITIONAL: exact finite spectral subspace/common exact ground; archived Ritz and source errors excluded')
                        entry=dict(tau=tau,observable='increment' if inc else 'ordinary',actual=actual,
                            exact_declared_M_harmonic=harm,log_shape_A=shape,
                            conditional_omitted_path_bounds=paths,
                            tau_nominal_Omega_min=float(tau*min(poles)),tau_lowest_harmonic_omega=float(tau*omega[0]),
                            tau_first_even_gap=float(tau*E[1]),
                            roundoff_gap_filter_diagnostic=float(2*tau*tau*max(E)*eigen['eigensolve_residual_frobenius']))
                        row['windows'].append(entry)
                        if not actual['spectral_reconstruction']['passed']:
                            out['warnings'].append(label+' '+str(tau)+' '+entry['observable']+': binary64 spectral weights unresolved; normalized recurrence retained with explicit status')
                        save()
                if sha(archive)!=archive_hash or sha(p)!=source_hash: raise RuntimeError('Input changed during analysis')
                row['status']='COMPLETED';save()
            # Same-width changes only; intentionally no power-law fit.
            out['same_width_comparisons']=[]
            for left,right in [('R10_Q14','R10_Q16'),('R10_Q16','R14_Q10')]:
                if not all(any(r['label']==x for r in out['cases']) for x in (left,right)): continue
                lr=next(r for r in out['cases'] if r['label']==left)
                rr=next(r for r in out['cases'] if r['label']==right)
                for a,b in zip(lr['windows'],rr['windows']):
                    out['same_width_comparisons'].append(dict(left=left,right=right,tau=a['tau'],observable=a['observable'],
                        log_moment_ratio_right_over_left={str(n):b['actual']['even_moments'][str(n)]['log_abs']-a['actual']['even_moments'][str(n)]['log_abs'] for n in (2,4,6,8)},
                        delta_log_shape_A={str(n):b['log_shape_A'][str(n)]-a['log_shape_A'][str(n)] for n in (4,6,8)},
                        interpretation='occupation/spectral-selection comparison' if left=='R10_Q14' else 'infrared-cutoff sensitivity; R10 is outside common interior'))
            out['status']='COMPLETED_WITH_WARNINGS' if out['warnings'] else 'COMPLETED';save()
        print(out['status']+' saved-matrix common-width analysis',flush=True)
    except BaseException as exc:
        out.update(status='FAILED',error=repr(exc));save();raise


if __name__=='__main__': main()
