"""Extract a completed R14/R10 common-width analysis into a paper fragment.

Only saved JSON, hashes and scalar identities are read. No numerical-physics
imports, matrix operations, archive loading, or calculations are launched.
Outputs are deterministic and require --replace before they can be overwritten.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import hashlib
import json
import math
import os

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_INPUT = 'results/stage3_2026-09-15/common_width_depth_R14_R10.json'
TARGET = 'paper/stage3_common_depth_results.tex'
PROVENANCE = 'paper/stage3_common_depth_provenance.json'
ANALYZER = 'research/stage3/analyze_common_width_depth_2026_09_15.py'
ANALYZER_SHA = '2a84863c2974846f1900bd196b0654fec0b643332730a6e18b8ccb9a23626c82'
HELPER = 'research/stage3/analyze_saved_common_widths_2026_09_15.py'
HELPER_SHA = 'bd8755753ece6786750691ad05306ac327135e3a11a7c81ca701bee565bad34b'
TAUS = (144.8154687872, 204.8, 289.630937574)
EVEN = (2, 4, 6, 8)
D = Decimal


def require(condition, message):
    if not condition:
        raise ValueError(message)


def local(name):
    path = (ROOT/name).resolve()
    require(path.is_relative_to(ROOT), 'Project-local paths required')
    return path


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def close(a, b):
    return math.isclose(float(a), float(b), rel_tol=2e-12, abs_tol=2e-13)


def window(rows, observable, tau):
    found = [w for w in rows if w['observable'] == observable and close(w['tau'], tau)]
    require(len(found) == 1, 'Missing or ambiguous window')
    return found[0]


def series(row, key='moments'):
    return {int(n): D(v['decimal']) for n, v in row[key].items()}


def formal_log(m):
    z = [D(0)] + [m[n]/D(math.factorial(n)) for n in range(1, 9)]
    power, answer = [D(1)]+[D(0)]*8, [D(0)]*9
    for k in range(1, 9):
        power = [sum((power[j]*z[n-j] for j in range(n+1)), D(0)) for n in range(9)]
        for n in range(1, 9):
            answer[n] += D((-1)**(k+1))*power[n]/D(k)
    return {n: answer[n]*D(math.factorial(n)) for n in range(2, 9)}


def shape(w, harmonic_key, p):
    m, h = series(w['actual']), series(w[harmonic_key])
    return (m[p]/h[p]).ln() - D(p)/2*(m[2]/h[2]).ln()


def sci(value, digits=2):
    if value == 0:
        return '0'
    mantissa, exponent = f'{value:.{digits}e}'.split('e')
    return mantissa+r'\times10^{'+str(int(exponent))+'}'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', default=DEFAULT_INPUT)
    parser.add_argument('--replace', action='store_true', help='Replace only the two owned derived artifacts')
    args = parser.parse_args()
    memory = float(os.environ['PYSCF_MAX_MEMORY'])
    require(math.isfinite(memory) and memory >= 64, 'Declare at least 64 MB for JSON formatting')
    source, target, provenance = local(args.input), local(TARGET), local(PROVENANCE)
    if (target.exists() or provenance.exists()) and not args.replace:
        raise FileExistsError('Common-depth artifacts exist; use --replace explicitly')
    data = json.loads(source.read_text())
    require(data.get('status') in ('COMPLETED', 'COMPLETED_WITH_WARNINGS'), 'Completed depth analysis required')
    require(data['taus'] == list(TAUS) and data['hbar'] == 1. and data['ratio'] == 2., 'Unexpected windows or conventions')
    require(data['source_sha256'].get(ANALYZER) == ANALYZER_SHA, 'Analysis was not made by the frozen driver')
    require(data['source_sha256'].get(HELPER) == HELPER_SHA, 'Analysis arithmetic helper differs')
    verified = {str(source.relative_to(ROOT)): sha(source)}
    def verify(name, expected):
        actual = sha(local(name))
        require(actual == expected, 'Input/source hash mismatch: '+name)
        verified[name] = actual
    for mapping in (data['verified_inputs_sha256'], data['source_sha256']):
        for name, expected in mapping.items():
            verify(name, expected)
    for key in ('input', 'archive', 'comparator'):
        verify(data[key], data[key+'_sha256'])
    physical = json.loads(local(data['input']).read_text())
    require(physical['status'] == 'COMPLETED', 'Physical batch did not complete')
    original = physical['cases'][data['selected_case_index']]
    require(original == data['original_case'] and original['status'] == 'COMPLETED', 'Physical case changed')
    require({k: v for k, v in physical.items() if k != 'cases'} == data['original_physical_batch_metadata'], 'Physical metadata mismatch')
    expected_r14 = dict(R=14, M=24, Q=10, calibration_modes=24, primitive=32, low_count=5, bath_top=24)
    require(all(original.get(k) == v for k, v in expected_r14.items()), 'R14 regulator differs from declared panel')
    require(original['coupling_family'] == 'equal_reference_phase' and original['even_only'] is True,
            'Wrong R14 family or parity sector')
    require(close(original['tau'], 204.8) and close(original['hard'], .5) and close(original.get('soft', 0.), 0.),
            'R14 basis construction changed')
    recs = [r for r in original['cosine'] if close(r['beta'], 1.)]
    require(len(recs) == 1, 'Expected one beta=1 record')
    rec = recs[0]
    require(rec['diagnostics'] == data['original_diagnostics'], 'R14 diagnostics mismatch')
    require(local(rec['effective_archive']) == local(data['archive']), 'R14 archive mismatch')
    verify(rec['effective_archive'], rec['effective_archive_sha256'])
    require(rec['effective_archive_sha256'] == data['archive_sha256'], 'Physical/analysis archive hash differs')
    receipt_ref = physical.get('finalization_phase_receipt')
    if physical.get('spec', {}).get('format') == 'explicit-packed-finalization-physical-route-v1':
        require(isinstance(receipt_ref, dict), 'Explicit finalization result has no phase receipt')
    if receipt_ref is not None:
        require(original.get('finalization_phase_receipt') == receipt_ref, 'Case/batch receipt differs')
        verify(receipt_ref['path'], receipt_ref['sha256'])
        receipt = json.loads(local(receipt_ref['path']).read_text())
        require(receipt['format'] == 'selected-graph-finalization-phase-receipt-v1'
                and receipt['status'] == 'CACHE_PHASES_RECORDED_NOT_PHYSICAL_RESULT'
                and receipt['scientific_result_accepted'] is False, 'Wrong receipt scope')
        provenance_data = receipt['provenance']
        encoded = json.dumps(provenance_data, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
        require(hashlib.sha256(encoded).hexdigest() == receipt['provenance_sha256'], 'Receipt provenance changed')
        require(local(provenance_data['execution_result']) == local(data['input']), 'Receipt names another physical result')
        require(provenance_data['scientific_archives'].get(rec['effective_archive']) == rec['effective_archive_sha256'],
                'Receipt archive binding differs')
        require(provenance_data['solver_returned_after_all_original_gates'] is True
                and provenance_data['downstream_observables_completed'] is True
                and provenance_data['failure'] is None, 'Receipt does not record completed numerical phases')
        require(provenance_data['admission_inputs'] == physical['input_validation']
                and provenance_data['current_source_sha256'] == physical['source_sha256'],
                'Receipt and physical source/admission identity differ')
        for metadata in provenance_data['cache_metadata']['records'].values():
            raw = metadata['exact_utf8_json'].encode('utf-8')
            require(len(raw) == metadata['bytes'] and hashlib.sha256(raw).hexdigest() == metadata['sha256'],
                    'Embedded cache metadata bytes changed')
            json.loads(raw)
    require(data['original_diagnostics']['even_ground_certified_against_odd'], 'R14 parity ground uncertified')
    require('even' in data['retained_sector'].lower() and data['dimension'] > 1, 'Wrong saved spectrum')
    require(len(data['harmonic_mode_data']['omega']) == 24, 'R14 harmonic mode count mismatch')
    require(data['calibration_variances'] == original['reference_variances'] and data['couplings'] == original['couplings'],
            'Fixed physical calibration/coupling mismatch')
    require('original distributed harmonic H0' in data['reference_scope'], 'Wrong R14 reference scope')
    physical_sources = {}
    for name, info in data['original_physical_source_provenance'].items():
        require(info['executed_sha256'] == physical['source_sha256'][name], 'Historical execution source hash mismatch')
        path = local(info['current_path'])
        physical_sources[name] = dict(info, current_at_extraction_sha256=sha(path) if path.exists() else None)
    r10 = json.loads(local(data['comparator']).read_text())
    require(r10['status'] in ('COMPLETED', 'COMPLETED_WITH_WARNINGS'), 'R10 comparator incomplete')
    require(r10['taus'] == list(TAUS) and r10['hbar'] == 1. and r10['ratio'] == 2., 'R10 conventions changed')
    arithmetic_controls = data['inherited_executed_arithmetic_controls']
    require(arithmetic_controls == r10['new_arithmetic_controls'] and arithmetic_controls['status'] == 'PASS',
            'Inherited arithmetic controls absent or changed')
    require(len(arithmetic_controls['checks']) == 4 and all(c['error'] <= 2e-10 for c in arithmetic_controls['checks']),
            'Inherited arithmetic controls outside acceptance')
    control_records = []
    for control in data['controls']:
        verify(control['path'], control['sha256'])
        record = json.loads(local(control['path']).read_text())
        require(record['status'] == 'PASS', 'Independent control failed')
        control_records.append(dict(path=control['path'], sha256=control['sha256'], record=record))
    require({(c['path'], c['sha256']) for c in data['controls']} ==
            {(c['path'], c['sha256']) for c in r10['controls']}, 'Missing inherited control record')
    cases = {c['label']: c for c in r10['cases']}
    require(set(cases) == {'R10_Q14', 'R10_Q16'}, 'R10 basis comparison is incomplete')
    physical_r10_sources = {}
    for label, c in cases.items():
        expected = dict(R=10, M=20, Q=14 if label == 'R10_Q14' else 16, tau=51.2,
                        primitive=32, low_count=5, bath_top=24, calibration_modes=24)
        require(c['status'] == 'COMPLETED' and c['context'] == expected and c['beta'] == 1., 'R10 case scope mismatch')
        require(c['original_diagnostics']['even_ground_certified_against_odd'], 'R10 parity ground uncertified')
        for key in ('input', 'archive'):
            verify(c[key], c[key+'_sha256'])
        parent = json.loads(local(c['input']).read_text())
        require(parent['status'] == 'COMPLETED', 'Original R10 physical batch incomplete')
        physical_r10_sources[c['input']] = parent.get('source_sha256', {})
        control = c['saved_ordinary_control']
        verify(control['input'], control['sha256'])
        require(control['max_scaled_error'] <= 2e-8 and c['saved_width_control']['max_relative_even_error'] <= 2e-8,
                'R10 moderate-width control failed')
    require(data['saved_R10_Q14_to_Q16_refinements'] == r10['same_width_comparisons'], 'R10 refinements changed')
    require(data['R10_original_diagnostics'] == cases['R10_Q16']['original_diagnostics']
            and data['R10_eigensolve_diagnostics'] == cases['R10_Q16']['eigensolve'], 'R10 inherited diagnostics mismatch')
    require(len(data['windows']) == len(data['comparisons']) == 6, 'Incomplete R14 common-width panel')
    replay = data['original_R14_increment_replay']
    require(replay['status'] == 'PASS' and len(replay['windows']) == 3, 'Original R14 increment replay absent')
    audit = dict(max_formal_log_scaled_error=0., max_standardized_scaled_error=0.,
                 max_A_absolute_error=0., max_path_log_absolute_error=0., max_comparison_scaled_error=0.,
                 matrix_diagonalizations_performed=0)
    spectral, arithmetic, path_bounds, table_rows, refinement_rows = [], [], [], [], []
    with localcontext() as ctx:
        ctx.prec, ctx.Emin, ctx.Emax = 80, -999999999, 999999999
        def validate_window(label, w, harmonic_key, path_key, diag, centered, declared_modes):
            require(w['tau'] in TAUS and w['observable'] in ('ordinary', 'increment'), 'Unexpected window')
            for key in ('actual', harmonic_key):
                a = w[key]
                require(a['positive_moment_checks']['passed'], 'Positive-moment check failed')
                m, k = series(a), series(a, 'cumulants')
                require(m[1] == 0 and all(m[p] > 0 for p in EVEN), 'Uncentered or nonpositive variance/moment')
                reconstructed = formal_log(m)
                for n in range(2, 9):
                    scale = max(abs(k[n]), m[2].sqrt()**n)
                    err = float(abs(reconstructed[n]-k[n])/scale)
                    audit['max_formal_log_scaled_error'] = max(audit['max_formal_log_scaled_error'], err)
                    require(err < 1e-60, 'Cumulant identity mismatch')
                    standard = k[n]/m[2].sqrt()**n
                    err = float(abs(standard-D(a['standardized_cumulants'][str(n)]['decimal']))/max(abs(standard), D(1)))
                    audit['max_standardized_scaled_error'] = max(audit['max_standardized_scaled_error'], err)
                    require(err < 1e-60, 'Standardized cumulant mismatch')
            require(w[harmonic_key]['modes'] == declared_modes, 'Wrong all-M harmonic reference')
            f = w['actual']['filter_arithmetic']
            require(f['actual_ground_diagonal'] == 0., 'Spurious ground diagonal floor')
            if w['observable'] == 'increment':
                require(f['diagonal_exactly_zero'], 'Increment diagonal is not zero')
            for v in w['actual']['filter_deletion_log_relative_even_bounds'].values():
                require(v is None or v <= math.log(1e-10), 'Filter deletion failed the frozen helper gate')
            for n in (4, 6, 8):
                err = abs(float(shape(w, harmonic_key, n))-w['log_shape_A'][str(n)])
                audit['max_A_absolute_error'] = max(audit['max_A_absolute_error'], err)
                require(err < 1e-11, 'Shape contrast does not match declared reference')
            paths = w[path_key]
            m = series(w['actual'])
            for n in EVEN:
                row = paths['moments'][str(n)]
                observed = paths['log_relative_even_moment_bound'][str(n)]
                if row['exact_zero']:
                    require(observed is None, 'Exact zero path bound has a nonzero log value')
                else:
                    F = D.from_float(centered['centered_frobenius_upper'])
                    damp = D.from_float(w['tau'])*D.from_float(diag['omitted_interacting_threshold_lower_bound'])
                    expected = D(n)*F.ln()-2*damp*damp/D(n)-m[n].ln()
                    err = abs(float(expected)-observed)
                    audit['max_path_log_absolute_error'] = max(audit['max_path_log_absolute_error'], err)
                    require(err < 1e-8, 'Conditional centered path estimate mismatch')
            spectral.append(dict(case=label, tau=w['tau'], observable=w['observable'], **w['actual']['spectral_reconstruction']))
            arithmetic.append(dict(case=label, tau=w['tau'], observable=w['observable'],
                filter=f, arithmetic=w['actual']['arithmetic'],
                filter_deletion_log_relative_even_bounds=w['actual']['filter_deletion_log_relative_even_bounds'],
                actual_moment_status={n: v['binary64_status'] for n, v in w['actual']['moments'].items()},
                actual_positive_moment_checks=w['actual']['positive_moment_checks'],
                harmonic_positive_moment_checks=w[harmonic_key]['positive_moment_checks']))
            path_bounds.append(dict(case=label, tau=w['tau'], observable=w['observable'],
                                    conditional_log_relative_even_bounds=paths['log_relative_even_moment_bound']))
        for label, c in cases.items():
            require(len(c['windows']) == 6, 'Incomplete R10 window panel')
            for w in c['windows']:
                validate_window(label, w, 'exact_declared_M_harmonic', 'conditional_omitted_path_bounds',
                                c['original_diagnostics'], c['centered_pressure_bound'], 20)
        for w in data['windows']:
            validate_window('R14_Q10', w, 'declared_all_M_original_harmonic', 'conditional_centered_path_bounds',
                            data['original_diagnostics'], data['centered_pressure_bound'], 24)
            require(0 < w['tau_Omega_min'] < 1 < w['tau_Omega_max'], 'R14 no longer inside nominal resonance band')
            old = window(cases['R10_Q16']['windows'], w['observable'], w['tau'])
            require(old['tau_nominal_Omega_min'] > 1, 'R10 infrared scope changed')
            c = window(data['comparisons'], w['observable'], w['tau'])
            require(c['log_shape_A_R10'] == old['log_shape_A'] and c['log_shape_A_R14'] == w['log_shape_A'],
                    'Comparison shape record mismatch')
            require(c['R10_spectral_reconstruction'] == old['actual']['spectral_reconstruction']
                    and c['R14_spectral_reconstruction'] == w['actual']['spectral_reconstruction'], 'Comparison spectral status mismatch')
            for n in (4, 6, 8):
                require(abs(c['delta_log_shape_A_R14_minus_R10'][str(n)]
                            -(w['log_shape_A'][str(n)]-old['log_shape_A'][str(n)])) < 1e-11, 'Depth contrast mismatch')
            for key, source_key in (('raw_moments', 'moments'), ('cumulants', 'cumulants'),
                                    ('standardized_cumulants', 'standardized_cumulants')):
                a, b = series(w['actual'], source_key), series(old['actual'], source_key)
                for n in range(2, 9):
                    r = c[key][str(n)]
                    error = abs(D(r['difference_R14_minus_R10']['decimal'])-(a[n]-b[n]))/max(abs(a[n]), abs(b[n]), D('1e-10000'))
                    audit['max_comparison_scaled_error'] = max(audit['max_comparison_scaled_error'], float(error))
                    require(error < D('1e-60'), 'Depth scalar difference mismatch')
                    if b[n]:
                        require(r['ratio_status'] == 'defined', 'Nonzero denominator marked undefined')
                        ratio = a[n]/b[n]
                        require(abs(D(r['ratio_R14_over_R10']['decimal'])-ratio)/max(abs(ratio), D(1)) < D('1e-60'),
                                'Depth scalar ratio mismatch')
                    else:
                        require(r['ratio_R14_over_R10'] is None and r['ratio_status'] == 'undefined_zero_R10_denominator',
                                'Zero denominator assigned a ratio')
            if w['observable'] == 'increment':
                saved = next(v for v in rec['windows'] if close(v['tau'], w['tau']))
                rr = next(v for v in replay['windows'] if close(v['tau'], w['tau']))
                require(rr['max_relative_even_moment_error'] <= rr['tolerance'] <= 2e-8, 'Original R14 replay failed')
                original_harmonic = [v for k, v in original['harmonic'].items() if close(k, w['tau'])]
                require(len(original_harmonic) == 1, 'Missing original harmonic reference')
                hr = w['original_all_M_harmonic_increment_replay']
                require(hr['status'] == 'PASS' and hr['tolerance'] <= 2e-8, 'Original harmonic replay absent')
                for n in EVEN:
                    actual_error = float(abs(series(w['actual'])[n]/D.from_float(float(saved['moments'][str(n)]))-1))
                    harmonic_error = float(abs(series(w['declared_all_M_original_harmonic'])[n]
                                               /D.from_float(float(original_harmonic[0][str(n)]))-1))
                    require(actual_error <= 2e-8 and harmonic_error <= 2e-8, 'Original raw-moment replay mismatch')
                    require(abs(actual_error-rr['relative_even_moment_errors'][str(n)]) < 1e-12
                            and abs(harmonic_error-hr['relative_even_moment_errors'][str(n)]) < 1e-12, 'Replay error record mismatch')
        for tau in TAUS:
            row = dict(tau=tau)
            refinements = dict(tau=tau)
            for name in ('ordinary', 'increment'):
                hi = window(cases['R10_Q16']['windows'], name, tau)
                lo = window(cases['R10_Q14']['windows'], name, tau)
                new = window(data['windows'], name, tau)
                row[name] = dict(A8_R10=float(shape(hi, 'exact_declared_M_harmonic', 8)),
                    A8_R14=float(shape(new, 'declared_all_M_original_harmonic', 8)),
                    R10_spectral_reconstruction=hi['actual']['spectral_reconstruction'],
                    R14_spectral_reconstruction=new['actual']['spectral_reconstruction'])
                ratio = series(hi['actual'])[8]/series(lo['actual'])[8]
                saved = window(data['saved_R10_Q14_to_Q16_refinements'], name, tau)
                require(saved['left'] == 'R10_Q14' and saved['right'] == 'R10_Q16', 'Wrong refinement direction')
                require(abs(float(ratio.ln())-saved['log_moment_ratio_right_over_left']['8']) < 2e-12, 'R10 refinement mismatch')
                refinements[name] = dict(fractional_M8_Q14_to_Q16=float(ratio-1),
                    delta_A8_Q16_minus_Q14=hi['log_shape_A']['8']-lo['log_shape_A']['8'])
            row.update(tau_Omega_min_R10=hi['tau_nominal_Omega_min'], tau_Omega_min_R14=new['tau_Omega_min'])
            table_rows.append(row)
            refinement_rows.append(refinements)
    unresolved = {label: sum(not s['passed'] for s in spectral if s['case'] == label)
                  for label in ('R10_Q14', 'R10_Q16', 'R14_Q10')}
    nonrepresentable = [(a['case'], a['tau'], a['observable'], n, status) for a in arithmetic
                       for n, status in a['actual_moment_status'].items()
                       if status not in ('representable', 'zero_in_stated_finite_arithmetic')]
    max_replay = max(w['max_relative_even_moment_error'] for w in replay['windows'])
    max_harmonic_replay = max(v for w in data['windows'] if w['observable'] == 'increment'
                             for v in w['original_all_M_harmonic_increment_replay']['relative_even_moment_errors'].values())
    max_paths = {}
    for label in ('R10_Q16', 'R14_Q10'):
        values = [r['conditional_log_relative_even_bounds']['8'] for r in path_bounds
                  if r['case'] == label and r['conditional_log_relative_even_bounds']['8'] is not None]
        max_paths[label] = max(values) if values else None
    def cell(value, spectral_status):
        return f'{value:.6f}' + (r'$^{\dagger}$' if not spectral_status['passed'] else '')
    lines = [r'% Generated from completed saved-data analysis; see stage3_common_depth_provenance.json.',
        r'\subsection{A common-width comparison across resonance depths}',
        r'\label{sec:s3-common-depth-results}',
        r'We compare the $\beta=1$ equal-reference-phase full-cosine models at the same three absolute averaging widths. The $R=10$ result uses $M=20$, $Q=16$ and construction width $51.2$; the $R=14$ result uses $M=24$, $Q=10$ and construction width $204.8$. Both use $M_{\rm ref}=24$, 32 primitive levels, a five-mode active prefix in each model and the same bath-selection prescription. These are different physical depths and numerical regulators, so their difference measures sensitivity to this combined change.',
        r'Here $O_\tau$ is the actual-ground-centered Gaussian average and $X_\tau=O_\tau-O_{2\tau}$. With $M_p(Y)=\langle Y^p\rangle$, define $A_8^{(0)}(Y)=\log[(M_8/M_2^4)/(M_8^{(0)}/(M_2^{(0)})^4)]$. At each depth, $(0)$ means its own original distributed harmonic $H_0$, evaluated using ordered quadratic algebra for all declared $M$ modes. It is neither the archived dressed harmonic proxy nor the retained interacting Wick comparator. Consequently this contrast includes altered two-point response and does not isolate irreducible non-Gaussian field information.',
        r'\begin{table}[t]\centering\small',
        r'\caption{Common absolute widths at two resonance depths. Entries are $A_8^{(0)}$. A dagger means that direct spectral reconstruction is unresolved; the displayed moments come from the controlled normalized vacuum-vector recurrence.}\label{tab:s3-common-depth-results}',
        r'\begin{tabular}{rrrrr}\toprule',
        r'& \multicolumn{2}{c}{Ordinary $O_\tau$} & \multicolumn{2}{c}{Increment $X_\tau$}\\',
        r'$\tau$ & $R10, Q16$ & $R14, Q10$ & $R10, Q16$ & $R14, Q10$\\\midrule']
    for row in table_rows:
        cells = [f'{row["tau"]:.3f}']
        for name in ('ordinary', 'increment'):
            for r in ('R10', 'R14'):
                cells.append(cell(row[name]['A8_'+r], row[name][r+'_spectral_reconstruction']))
        lines.append(' & '.join(cells)+r'\\')
    lines += [r'\bottomrule\end{tabular}\end{table}',
        r'The same widths correspond to $\tau\Omega_{\min}='+','.join(f'{r["tau_Omega_min_R10"]:.3f}' for r in table_rows)+
        r'$ for $R=10$ and $'+','.join(f'{r["tau_Omega_min_R14"]:.3f}' for r in table_rows)+
        r'$ for $R=14$. Thus $R=10$ lies beyond its infrared cutoff while $R=14$ lies inside its nominal resonance band. This is a common-width cutoff/depth comparison, not common-interior convergence. The three rows establish neither an extended scaling plateau nor a rare-tail law.',
        r'The separately saved $R=10$ occupation/selection refinement gives $10^6[M_8^{Q=16}(X_\tau)/M_8^{Q=14}(X_\tau)-1]='+
        ','.join(f'{r["increment"]["fractional_M8_Q14_to_Q16"]*1e6:+.3f}' for r in refinement_rows)+
        r'$ at these widths. The largest corresponding absolute ordinary-moment change is $'+
        f'{max(abs(r["ordinary"]["fractional_M8_Q14_to_Q16"]) for r in refinement_rows)*1e6:.3f}'+
        r'$ parts per million. No matching $R=14$ occupation refinement is included in this panel; the $R=10$ changes are not error bars for $R=14$ or for the depth difference.',
        r'The analysis retains the original odd-sector ground certificate and pressure-source diagnostics, and replays all three original $R=14$ increment moments and all-mode harmonic references. The largest replay errors are $'+sci(max_replay)+r'$ and $'+sci(max_harmonic_replay)+
        r'$, respectively. The inherited independent arithmetic controls and necessary positive-moment checks through order eight pass. Actual ground centering is enforced, increment zero-gap entries are removed, and explicit filter-deletion bounds satisfy the frozen arithmetic gate. Scalar amplitudes and cumulants use 80-digit Decimal arithmetic, while vectors and eigenpairs remain binary64.']
    if unresolved['R14_Q10'] or unresolved['R10_Q16']:
        lines.append(f'Of the six ordinary/increment rows at each depth, direct spectral reconstruction is unresolved in {unresolved["R10_Q16"]} at $R=10$ and {unresolved["R14_Q10"]} at $R=14$. '
                     r'Those cases do not supply a direct spectral probability distribution or cumulative distribution, even though the vacuum recurrence passes its stated arithmetic checks.')
    else:
        lines.append(r'Direct spectral reconstruction passes its stated numerical consistency check at both depths. This finite-matrix check does not certify a physical rare-tail law or regulator removal.')
    if nonrepresentable:
        lines.append(r'Some nonzero moments require their saved Decimal or logarithmic representation; they are not replaced by physical zeros. Their individual representation statuses are retained in the provenance.')
    bound_text = []
    for label, display in (('R10_Q16', 'R=10'), ('R14_Q10', 'R=14')):
        value = max_paths[label]
        bound_text.append(('zero' if value is None else '$e^{'+f'{value:.2f}'+'}$')+' for $'+display+'$')
    lines.append(r'The largest conditional relative eighth-moment omitted-path envelopes are '+ ' and '.join(bound_text)+
                 r'. These estimates assume an exact retained spectral subspace and a common exact ground state. They exclude errors in the original invariant subspace, ground state, projected pressure source, primitive basis, bath selection and line-mode regulator; small path envelopes cannot substitute for those separate controls.')
    if any(v is not None and v >= 0 for v in max_paths.values()):
        lines.append(r'An envelope at or above one is inconclusive as a relative-accuracy certificate and is retained as such.')
    fragment = '\n'.join(lines)+'\n'
    report = dict(status='COMPLETED', scope='deterministic saved-data manuscript extraction; no numerical-physics execution',
        analysis_status=data['status'], analysis_warnings=data['warnings'], verified_inputs_sha256=verified,
        generator=dict(path=str(Path(__file__).relative_to(ROOT)), sha256=sha(Path(__file__))),
        memory_allowance_mb=memory, scalar_audit=audit, selected_rows=table_rows,
        separate_R10_Q14_to_Q16_sensitivity=refinement_rows, R14_occupation_refinement_in_this_panel=False,
        reference='each depth uses original distributed harmonic H0 with all declared M modes, not archived H0/P0 or interacting Wick',
        executed_analysis_sources=data['source_sha256'], independent_control_records=control_records,
        inherited_arithmetic_controls=arithmetic_controls, original_R14_increment_replay=replay,
        R14_original_harmonic_replays=[w['original_all_M_harmonic_increment_replay'] for w in data['windows'] if w['observable']=='increment'],
        maximum_original_R14_increment_replay_error=max_replay, maximum_original_harmonic_replay_error=max_harmonic_replay,
        arithmetic_status=arithmetic, spectral_reconstruction=spectral, nonrepresentable_raw_moments=nonrepresentable,
        conditional_path_bounds=path_bounds, largest_conditional_log_relative_M8_bounds=max_paths,
        original_R14_case=original, original_R14_diagnostics=data['original_diagnostics'],
        R14_saved_eigensolve=data['eigensolve'], R14_removed_source_scalar=data['removed_scalar_in_supplied_pressure'],
        R14_physical_source_history_and_current_hashes=physical_sources,
        R10_physical_source_history=physical_r10_sources,
        R10_original_diagnostics={label: c['original_diagnostics'] for label, c in cases.items()},
        R10_saved_eigensolves={label: c['eigensolve'] for label, c in cases.items()},
        limitations=['R10 outside infrared interior while R14 is inside nominal band; not common-interior convergence',
            'M, Q and construction width differ across depths', 'no R14 occupation refinement in this panel',
            'original harmonic reference includes two-point-response differences',
            'conditional path bounds exclude state/source/subspace and physical regulator errors',
            'spectral reconstruction status is separate from vacuum-moment arithmetic',
            'no extended plateau, physical rare-tail law, or continuum conclusion'])
    mode = 'w' if args.replace else 'x'
    with target.open(mode) as stream:
        stream.write(fragment)
    report['outputs'] = {TARGET: dict(path=TARGET, sha256=sha(target))}
    report['provenance_path'] = PROVENANCE
    with provenance.open(mode) as stream:
        json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(status='COMPLETED', outputs={TARGET: sha(target), PROVENANCE: sha(provenance)}), sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
