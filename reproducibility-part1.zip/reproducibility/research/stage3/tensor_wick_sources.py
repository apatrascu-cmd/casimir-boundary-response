"""Prepare-only full-parity sources and response-matched Wick increments.

The nonlinear pressure is projected as its original composite operator. It is
never rebuilt by squaring the retained D/Z matrices. Missing-weight norms are
relative to the computed graph; spectral interpretation requires graph/state
error controls. See docs/RESPONSE_MATCHED_WICK_2026-09-15.md.
"""
from pathlib import Path
import os, sys, math
import numpy as np
from scipy.linalg import eigh
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT/'research/stage3'), str(ROOT/'src')]
from tensor_cosine import compress_terms, operator_norm_bound, group_operator
from tensor_even_graph import state_parities, block_parity_eigh
from dressed_cosine_hierarchy import difference_structure, one_body, pair_matrix
from distributed_line import quantum_quadratic_cumulants
from full_cosine_hierarchy import filter_gap, even_raw_from_cumulants


def _memory_gate(estimated_bytes, memory_mb):
    limit = float(os.environ['PYSCF_MAX_MEMORY'] if memory_mb is None else memory_mb)
    if not np.isfinite(limit) or limit <= 0:
        raise ValueError('positive allocated memory is required')
    if estimated_bytes > .6*limit*1024**2:
        raise MemoryError('source/comparator estimated workspace exceeds allocation')
    return float(estimated_bytes/1024**2)


def _graph_with_embedding(model, tolerance, max_iterations, damping, compress, memory_mb):
    """Full target parity companion; no changes to the existing graph modules."""
    nl, nb = len(model['HL']), len(model['HB'])
    estimate = _memory_gate(12*8*nb*nl*nl, memory_mb)
    lp0, bp0 = state_parities(model['low_states']), state_parities(model['bath_states'])
    raw_eb, ub, bp, bdiag = block_parity_eigh(model['HB'], bp0)
    if nb < 2 or bp[0] != 0:
        raise ArithmeticError('nontrivial bath with an even ground is required')
    eb = raw_eb-raw_eb[0]
    bt = [(a, ub.T@b@ub) for a, b in model['hterms']]
    active = model['HL'].copy()
    for a, b in bt:
        active += b[0, 0]*a
    raw_ea, ua, lp, adiag = block_parity_eigh(active, lp0)
    if lp[0] != 0 or not np.any(lp == 1):
        raise ArithmeticError('active basis must have even ground and odd states')
    ea = raw_ea-raw_ea[0]
    original = [(ua.T@a@ua, b) for a, b in bt]
    centered = [(a, b-b[0, 0]*np.eye(nb)) for a, b in original]
    ts, comp = centered, None
    eta = 0.
    if compress and ts:
        ts, comp = compress_terms(ts)
        comp = dict(comp)
        eta = comp['discarded_frobenius_bound']
    reset = 0.
    terms = []
    for a, b in ts:
        reset += operator_norm_bound(a)*abs(float(b[0, 0]))
        b = b.copy(); b[0, 0] = 0.
        terms.append((a, b))
    ts = terms; eta += reset
    if comp is not None:
        comp.update(center_reset_norm_bound=float(reset), total_operator_error_bound=float(eta))
    allowed = ((bp[:, None, None] ^ lp[None, :, None]) == lp[None, None, :])
    aq = allowed[1:]
    den = eb[1:, None, None]+ea[None, :, None]-ea[None, None, :]
    separation = float(np.min(den[aq]))
    if separation <= 0:
        raise ArithmeticError('bath overlaps the full retained active window')
    den[~aq] = 1.
    coupling = np.zeros((nb-1, nl, nl))
    for a, b in ts:
        coupling += b[1:, 0, None, None]*a
    coupling[~aq] = 0.
    omega = -coupling/den
    history = []

    def off_apply(w):
        y = np.zeros_like(w)
        for a, b in ts:
            y += (b[1:, 1:]@np.matmul(a, w).reshape(nb-1, -1)).reshape(w.shape)
        y[~aq] = 0.
        return y

    for _ in range(max_iterations):
        feedback = np.einsum('bij,bik->jk', coupling, omega, optimize=True)
        residual = coupling+den*omega+off_apply(omega)-omega@feedback
        residual[~aq] = 0.
        value = float(np.linalg.norm(residual)); history.append(value)
        if value < tolerance:
            break
        omega -= damping*residual/den
        omega[~aq] = 0.
        if not np.isfinite(omega).all() or np.linalg.norm(omega) > 2:
            raise ArithmeticError('full-parity source graph left admitted neighborhood')
    else:
        raise ArithmeticError('full-parity source graph failed to converge')
    metric = np.eye(nl)+np.einsum('bij,bik->jk', omega, omega, optimize=True)
    se, su, _, _ = block_parity_eigh(metric, lp)
    sinv = (su/np.sqrt(se))@su.T
    graph_spectral_norm = float(np.sqrt(max(0., se[-1]-1.)))
    if graph_spectral_norm >= 1:
        raise ArithmeticError('source graph is outside the low-cluster angular neighborhood')
    graph_norm = float(np.linalg.norm(omega))
    w = np.empty((nb, nl, nl)); w[0] = sinv; w[1:] = omega@sinv
    forbidden = float(np.linalg.norm(w[~allowed]))
    del omega, den, coupling, residual, feedback, allowed, aq
    hl = ua.T@model['HL']@ua-raw_ea[0]*np.eye(nl)
    hb = ub.T@model['HB']@ub-raw_eb[0]*np.eye(nb)
    hw = np.matmul(hl, w)+(hb@w.reshape(nb, -1)).reshape(w.shape)
    for a, b in original:
        hw += (b@np.matmul(a, w).reshape(nb, -1)).reshape(w.shape)
    heff = np.einsum('bij,bik->jk', w, hw, optimize=True)
    heff = (heff+heff.T)/2
    hw -= w@heff
    invariant_residual = float(np.linalg.norm(hw)); del hw
    pl, pb = ua.T@model['PL']@ua, ub.T@model['PB']@ub
    pw = np.matmul(pl, w)+(pb@w.reshape(nb, -1)).reshape(w.shape)
    for a, b in model['pterms']:
        pw += ((ub.T@b@ub)@np.matmul(ua.T@a@ua, w).reshape(nb, -1)).reshape(w.shape)
    peff = np.einsum('bij,bik->jk', w, pw, optimize=True)
    peff = (peff+peff.T)/2
    pw -= w@peff
    pressure_source = float(np.linalg.norm(pw)); del pw
    interaction = sum(operator_norm_bound(a)*operator_norm_bound(b) for a, b in ts)
    base_error = (operator_norm_bound(ua.T@active@ua-np.diag(raw_ea))
                  + operator_norm_bound(hb-np.diag(eb)))
    d_lower = float(eb[1]-interaction-eta-base_error)
    aq_margin = float(d_lower-max(ea)-base_error)
    if aq_margin <= 0:
        raise ArithmeticError('full source-graph A/Q separation is not certified')
    e, gvec, ep, _ = block_parity_eigh(heff, lp)
    if ep[0] != 0:
        raise ArithmeticError('source comparator requires an even interacting ground')
    rbound = float(invariant_residual+eta)
    threshold = float(d_lower-e[0]-rbound)
    cluster = float(threshold-(e[-1]-e[0])-2*rbound)
    if cluster <= 0:
        raise ArithmeticError('full retained source cluster is not certified')
    odd_q = (bp[1:, None] ^ lp[None, :]) == 1
    odd_free = float(np.min((eb[1:, None]+ea[None, :])[odd_q]))
    odd_threshold = float(odd_free-interaction-eta-base_error-e[0]-rbound)
    odd_columns = np.flatnonzero(lp == 1)
    odd_a_min = float(np.min(ea[odd_columns])-base_error)
    odd_d_min = float(odd_free-interaction-eta-base_error)
    odd_b_bound = float(sum(operator_norm_bound(a[:, odd_columns])*np.linalg.norm(b[1:, 0])
                            for a, b in ts)+eta+base_error)
    denominator = abs(odd_d_min-odd_a_min)+np.hypot(odd_d_min-odd_a_min, 2*odd_b_bound)
    correction = 0. if odd_b_bound == 0 else 2*odd_b_bound**2/denominator
    odd_ground_bound = float(min(odd_a_min, odd_d_min)-correction-e[0]-rbound)
    pressure_bound = (operator_norm_bound(model['PL'])+operator_norm_bound(model['PB'])
                      +sum(operator_norm_bound(a)*operator_norm_bound(b)
                           for a, b in model['pterms']))*np.sqrt(nl*nb)
    info = dict(iterations=len(history), riccati_residual_history=history,
                invariant_residual_frobenius=invariant_residual,
                invariant_residual_scope='original uncompressed full tensor',
                original_hamiltonian_residual_bound=rbound,
                retained_cluster_certification_margin=cluster,
                active_to_excited_bath_separation_margin=aq_margin,
                bare_separation=separation, interaction_norm_bound=float(interaction),
                base_diagonalization_error_bound=float(base_error),
                omitted_interacting_threshold_lower_bound=threshold,
                omitted_odd_transition_energy_lower_bound=odd_threshold,
                odd_sector_ground_block_lower_bound=odd_ground_bound,
                odd_ground_block_components=dict(A_lower=odd_a_min, D_lower=odd_d_min,
                                                 coupling_norm_upper=odd_b_bound),
                low_high_source_frobenius=pressure_source,
                pressure_frobenius_bound=float(pressure_bound),
                orthogonality_error=float(np.linalg.norm(
                    np.einsum('bij,bik->jk', w, w)-np.eye(nl))),
                forbidden_parity_graph_frobenius=forbidden,
                graph_norm=graph_norm, graph_norm_kind='Frobenius',
                graph_spectral_norm=graph_spectral_norm, compression=comp,
                compression_operator_error_bound=float(eta),
                low_dimension=nl, bath_dimension=nb,
                active_even_dimension=int(np.count_nonzero(lp == 0)),
                active_odd_dimension=int(np.count_nonzero(lp == 1)),
                retained_sector='both total parities with exact parity columns',
                estimated_workspace_mb=estimate,
                parity_block_diagnostics=dict(bath=bdiag, active=adiag),
                hamiltonian_common_shift=float(raw_ea[0]+raw_eb[0]))
    return heff, peff, w, ua, ub, lp, e, gvec, ep, info


def linear_group_sources(model, modes):
    """Real D and imaginary part of Hermitian Z in the original tensor factors."""
    d = modes.slope*np.sqrt(modes.p.hbar/(2*modes.omega))
    z = modes.endpoint*np.sqrt(modes.p.hbar*modes.omega/2)
    low, bath, local = model['low_states'], model['bath_states'], model['local']
    return dict(D=(group_operator(low, local, [], d, 'X').real,
                   group_operator(bath, local, [], d, 'X').real),
                Z_imag=(group_operator(low, local, [], z, 'Y').imag,
                        group_operator(bath, local, [], z, 'Y').imag))



def squared_group_sources(model, modes):
    """Separately projected D^2/Z^2; never square the projected linear matrices.

    Modes frozen in both factors are assigned to the bath for their scalar
    variance. This partition does not change the full projected quadratic form.
    """
    low, bath, local = model['low_states'], model['bath_states'], model['local']
    in_low = np.max(low, axis=0) > 0
    if np.any(in_low & (np.max(bath, axis=0) > 0)):
        raise ValueError('low and bath modal supports must be disjoint')
    d = modes.slope*np.sqrt(modes.p.hbar/(2*modes.omega))
    z = modes.endpoint*np.sqrt(modes.p.hbar*modes.omega/2)
    result = {}
    for name, coefficient, field, square in [('D', d, 'X', 'X2'),
                                            ('Z_imag', z, 'Y', 'Y2')]:
        parts = []
        for states, mask in [(low, in_low), (bath, ~in_low)]:
            c = coefficient*mask
            structure = difference_structure(states)
            operator = one_body(states, structure, c[:, None, None]**2*local[square])
            operator += pair_matrix(states, structure, local[field], 2*np.outer(c, c))
            parts.append((operator+operator.T)/2)
        result[name] = tuple(parts)
    return result


def transitions_from_operators(H, D, Z_imag, parities, hbar=1.):
    """Same odd eigenstates for DD, ZZ AND DZ; preserve their energy indices."""
    if hbar <= 0 or not np.isfinite(hbar):
        raise ValueError('positive finite hbar required')
    H, D, Z_imag = (np.asarray(x, dtype=float) for x in (H, D, Z_imag))
    if not all(np.all(np.isfinite(x)) for x in (H, D, Z_imag)):
        raise ValueError('H and linear sources must be finite')
    if D.shape != H.shape or Z_imag.shape != H.shape:
        raise ValueError('source dimensions must match H')
    e, u, ep, _ = block_parity_eigh(H, parities)
    if ep[0] != 0:
        raise ArithmeticError('ground state must be even')
    scale = max(1., float(np.linalg.norm(D)), float(np.linalg.norm(Z_imag)))
    if max(np.linalg.norm(D-D.T), np.linalg.norm(Z_imag+Z_imag.T)) > 256*np.finfo(float).eps*scale:
        raise ArithmeticError('D must be real symmetric and Z/i real antisymmetric')
    parity = np.asarray(parities, dtype=int)
    same = parity[:, None] == parity[None, :]
    if max(np.linalg.norm(D[same]), np.linalg.norm(Z_imag[same])) > 256*np.finfo(float).eps*scale:
        raise ArithmeticError('linear D/Z sources must reverse total parity')
    dp, zp = u.T@D@u, u.T@Z_imag@u
    odd = np.flatnonzero(ep == 1)
    d, z = dp[0, odd], -zp[0, odd]
    omega = (e[odd]-e[0])/hbar
    if len(omega) and np.any(omega <= 0):
        raise ArithmeticError('nonpositive ground-to-odd frequency')
    return dict(omega=omega, d=d, z=z, odd_energy_indices=odd,
                retained_D_weight=float(d@d), retained_Z_weight=float(z@z),
                retained_DZ_coefficient=float(d@z), transition_count=len(omega),
                scope='ground-to-odd transitions of the supplied finite H,D,Z')


def solve_with_sources(model, modes, tolerance=2e-14, max_iterations=80,
                       damping=1., compress=True, memory_mb=None):
    """Full-parity graph plus independently projected pressure and linear sources."""
    H, P, w, ua, ub, par, e, vectors, epar, graph = _graph_with_embedding(
        model, tolerance, max_iterations, damping, compress, memory_mb)
    nb, nl, _ = w.shape
    ground = vectors[:, 0]
    output, diagnostics, omitted_ground = {}, {}, {}
    squared = squared_group_sources(model, modes)
    full_ground = np.tensordot(w, ground, axes=(2, 0))
    for name, (left, right) in linear_group_sources(model, modes).items():
        l, b = ua.T@left@ua, ub.T@right@ub
        action = np.matmul(l, w)+(b@w.reshape(nb, -1)).reshape(w.shape)
        projected = np.einsum('bij,bik->jk', w, action, optimize=True)
        symmetry = 1 if name == 'D' else -1
        symmetry_error = float(np.linalg.norm(projected-symmetry*projected.T))
        projected = (projected+symmetry*projected.T)/2
        full_ground_action = np.tensordot(action, ground, axes=(2, 0))
        full_weight = float(np.sum(full_ground_action**2))
        kept_weight = float(np.linalg.norm(projected@ground)**2)
        action -= w@projected
        source_frobenius = float(np.linalg.norm(action))
        ground_outside = np.tensordot(action, ground, axes=(2, 0))
        missing_weight = float(np.sum(ground_outside**2))
        omitted_ground[name] = ground_outside.ravel()
        source_bound = operator_norm_bound(left)+operator_norm_bound(right)
        kl, kb = squared[name]
        kl, kb = ua.T@kl@ua, ub.T@kb@ub
        cross = 2. if name == 'D' else -2.
        square_action = full_ground@kl.T+kb@full_ground+cross*b@(full_ground@l.T)
        composite_second = float(np.sum(full_ground*square_action))
        square_bound = float(operator_norm_bound(kl)+operator_norm_bound(kb)
                             +2*operator_norm_bound(l)*operator_norm_bound(b))
        outside_basis = composite_second-full_weight
        allowance = float(256*np.finfo(float).eps*max(nb, nl)
                          *max(abs(composite_second), full_weight, square_bound))
        if outside_basis < -allowance:
            raise ArithmeticError('projected squared-source sum rule has a material negative remainder')
        diagnostics[name] = dict(low_high_source_frobenius=source_frobenius,
                                  missing_ground_weight=missing_weight,
                                  full_ground_weight=full_weight,
                                  retained_ground_weight=kept_weight,
                                  sum_rule_absolute_discrepancy=float(full_weight-kept_weight-missing_weight),
                                  source_operator_norm_bound=float(source_bound),
                                  source_full_to_all_norm_bound=float(np.sqrt(max(0., square_bound))),
                                  independently_projected_second_moment=composite_second,
                                  outside_tensor_source_weight_raw=float(outside_basis),
                                  outside_tensor_weight_diagnostic_allowance=allowance,
                                  outside_tensor_source_weight_upper=float(max(0., outside_basis)+allowance),
                                  outside_tensor_weight_has_bath_energy_bound=False,
                                  projected_symmetry_residual=symmetry_error,
                                  missing_weight_scope='computed graph complement; exact spectral weight only for an invariant graph')
        output[name] = projected
        del action, full_ground_action
    diagnostics['missing_DZ_imaginary_coefficient'] = float(
        omitted_ground['D']@omitted_ground['Z_imag'])
    diagnostics['missing_DZ_absolute_bound'] = float(np.sqrt(
        diagnostics['D']['missing_ground_weight']*diagnostics['Z_imag']['missing_ground_weight']))
    transitions = transitions_from_operators(H, output['D'], output['Z_imag'], par, modes.p.hbar)
    diagnostics['retained_transition_D_sum_error'] = float(
        diagnostics['D']['retained_ground_weight']-transitions['retained_D_weight'])
    diagnostics['retained_transition_Z_sum_error'] = float(
        diagnostics['Z_imag']['retained_ground_weight']-transitions['retained_Z_weight'])
    return dict(H=H, P=P, D=output['D'], Z_imag=output['Z_imag'], parities=par,
                energies=e, energy_parities=epar, transitions=transitions,
                graph=graph, source_diagnostics=diagnostics)


def wick_pressure_increment(transitions, tau, C0=1., L0=1., ratio=2., order=8,
                            memory_mb=None):
    """Ordered Wick comparator; frequencies already include division by hbar."""
    if not np.isfinite(tau) or tau <= 0 or not np.isfinite(ratio) or ratio <= 1:
        raise ValueError('positive tau and averaging ratio >1 required')
    if C0 <= 0 or L0 <= 0 or order < 2 or order % 2:
        raise ValueError('positive line parameters and positive even order required')
    omega, d, z = (np.asarray(transitions[k], dtype=float) for k in ('omega', 'd', 'z'))
    if omega.shape != d.shape or omega.shape != z.shape or omega.ndim != 1:
        raise ValueError('transition arrays must be same-sized vectors')
    if not all(np.all(np.isfinite(v)) for v in (omega, d, z)) or np.any(omega <= 0):
        raise ValueError('finite coefficients and positive frequencies required')
    supplied_count = len(omega)
    nonzero = (d != 0) | (z != 0)
    omega, d, z = omega[nonzero], d[nonzero], z[nonzero]
    count = len(omega)
    estimate = _memory_gate(8*count*count*(order+20), memory_mb)
    if count == 0:
        cumulants = {str(p): 0. for p in range(1, order+1)}
    else:
        aq, az = np.outer(d, d)/L0, C0*np.outer(z, z)
        A, B = aq+az, aq-az
        A *= filter_gap(omega[:, None]-omega[None, :], tau, ratio)
        B *= filter_gap(omega[:, None]+omega[None, :], tau, ratio)
        cumulants = quantum_quadratic_cumulants(A, B, order)
    moments = even_raw_from_cumulants(cumulants, order)
    if not all(np.isfinite(v) for v in list(cumulants.values())+list(moments.values())):
        raise FloatingPointError('Wick comparator moments overflowed')
    return dict(tau=float(tau), ratio=float(ratio), order=int(order),
                transition_count=count, supplied_transition_count=supplied_count,
                exactly_zero_transitions_removed=supplied_count-count,
                cumulants=cumulants, moments=moments,
                covariance_pressure_scale=float(d@d/L0+C0*(z@z)),
                estimated_workspace_mb=estimate,
                scope='vacuum Gaussian pressure increment matched to supplied DD,ZZ,DZ transition spectrum')


def gaussian_omission_bounds(retained_scale, missing_scale, tau, threshold_energy,
                              order=8, hbar=1.):
    """Conditional absolute MOMENT bounds, reported logarithmically.

    S scales are sum d^2/L0+C0 sum z^2. Missing scale must be an upper bound;
    threshold must bound every omitted ground-to-odd transition. Add graph,
    state, factor and mode errors before treating this as a source certificate.
    """
    sr, sm = float(retained_scale), float(missing_scale)
    if min(sr, sm) < 0 or not np.isfinite(sr+sm) or tau < 0 or hbar <= 0:
        raise ValueError('nonnegative finite scales, width and positive hbar required')
    if threshold_energy is not None and threshold_energy <= 0:
        raise ValueError('positive omitted transition threshold required')
    rows = {}
    for p in range(2, order+1, 2):
        if sm == 0:
            rows[str(p)] = dict(exact_zero_if_missing_scale_is_exact=True,
                                log_absolute_bound=None, log_spectral_bound=None,
                                log_weight_bound=None)
            continue
        cp = 2*(p+2)
        total = cp*(sr+sm)
        difference = cp*(2*math.sqrt(sr*sm)+sm)
        log_weight = math.log(p)+math.log(difference)+(p-1)*math.log(total)
        log_spectral = (None if threshold_energy is None else
                        -2*(tau*threshold_energy/hbar)**2/p+p*math.log(total))
        bound = log_weight if log_spectral is None else min(log_weight, log_spectral)
        rows[str(p)] = dict(exact_zero_if_missing_scale_is_exact=False,
                            log_absolute_bound=float(bound),
                            log_spectral_bound=log_spectral,
                            log_weight_bound=float(log_weight))
    return dict(retained_scale=sr, missing_scale_upper_bound=sm,
                threshold_energy_lower_bound=threshold_energy, tau=float(tau),
                hbar=float(hbar), moments=rows,
                scope='conditional Gaussian transition-omission bound, not nonlinear pressure or graph error')
