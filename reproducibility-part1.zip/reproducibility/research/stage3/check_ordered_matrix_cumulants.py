"""Independent ordinary/increment cumulant controls; run centrally under guard.

Physical coordinate squares are projected independently of the truncated
coordinates. Scalar cumulants are also checked by an independent formal-log
series, in addition to pressure spectral reconstruction in the tested module.
"""
from pathlib import Path
import argparse
import hashlib
import itertools
import json
import math
import os
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'research/stage3')]
from distributed_line import Parameters, quantum_quadratic_cumulants
from nonlinear_pressure import PressureModes
from ordered_matrix_cumulants import OrderedPressure, memory_limit_mb


def independent_fock(modes, levels, memory_mb):
    M, N, hb = len(modes.omega), int(levels), modes.p.hbar
    dimension = N**M
    if 48*16*dimension**2 > .6*memory_mb*1024**2:
        raise MemoryError('Independent Fock workspace exceeds allowance')
    ident = np.eye(N)
    ann = np.diag(np.sqrt(np.arange(1,N)),1)
    diag = np.diag(2*np.arange(N)+1)
    off = np.diag(np.sqrt(np.arange(1,N-1)*np.arange(2,N)),2)
    off = off+off.T
    def embed(local, j):
        out = np.ones((1,1))
        for i in range(M):
            out = np.kron(out, local if i == j else ident)
        return out
    Q, Pi, Q2, Pi2 = [], [], [], []
    for j,w in enumerate(modes.omega):
        Q.append(embed(np.sqrt(hb/(2*w))*(ann+ann.T),j))
        Pi.append(embed(-1j*np.sqrt(hb*w/2)*(ann-ann.T),j))
        # Full projected squares retain the top diagonal 2(N-1)+1.
        Q2.append(embed(hb/(2*w)*(diag+off),j))
        Pi2.append(embed(hb*w/2*(diag-off),j))
    P = np.zeros((dimension,dimension),complex)
    for j in range(M):
        P += modes.slope[j]**2/(2*modes.p.L0)*Q2[j]
        P += modes.p.C0*modes.endpoint[j]**2/2*Pi2[j]
        for k in range(j):
            P += modes.slope[j]*modes.slope[k]/modes.p.L0*(Q[j]@Q[k])
            P += modes.p.C0*modes.endpoint[j]*modes.endpoint[k]*(Pi[j]@Pi[k])
    assert np.max(abs(P.imag)) < 1e-14
    states = np.asarray(list(itertools.product(range(N),repeat=M)))
    H = np.diag(hb*(states@modes.omega))
    # Check the deliberately different top-edge product explicitly.
    assert np.max(abs(Q2[-1]-Q[-1]@Q[-1])) > 0
    return H, P.real


def reference_cumulants(modes, tau, increment, ratio):
    A,B = modes.matrices()
    w = modes.omega
    def filt(gap):
        first = np.exp(-.5*(tau*gap)**2)
        return first-np.exp(-.5*(ratio*tau*gap)**2) if increment else first
    return quantum_quadratic_cumulants(A*filt(w[:,None]-w[None,:]),
                                      B*filt(w[:,None]+w[None,:]),8)


def error(observed, expected, variance):
    return max(abs(observed[str(n)]-expected[str(n)])/
               max(abs(expected[str(n)]),abs(variance)**(n/2),1e-280)
               for n in range(2,9))


def independent_log_series(moments):
    """k_n = n! [t^n] log(sum m_n t^n/n!), not the cumulant recurrence."""
    u = np.array([0.]+[moments[str(n)]/math.factorial(n) for n in range(1,9)])
    term = np.zeros(9);term[0] = 1.
    log_series = np.zeros(9)
    for k in range(1,9):
        term = np.convolve(term,u)[:9]
        log_series += (-1)**(k+1)*term/k
    return {str(n):float(math.factorial(n)*log_series[n]) for n in range(1,9)}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',required=True)
    args = ap.parse_args()
    destination = (ROOT/args.output).resolve()
    if not destination.is_relative_to(ROOT) or destination.suffix != '.json':
        raise ValueError('Use a new project-local JSON output')
    if destination.exists():
        raise FileExistsError(destination)
    mem = memory_limit_mb()
    started = time.monotonic()
    files = [Path(__file__), ROOT/'research/stage3/ordered_matrix_cumulants.py',
             ROOT/'src/distributed_line.py', ROOT/'src/nonlinear_pressure.py']
    out = dict(status='RUNNING', memory_mb=mem, cases=[],
        source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
        scope='independent finite-matrix ordering/centering and harmonic cumulant controls; no physical hierarchy result')
    destination.parent.mkdir(parents=True,exist_ok=True)
    def save():
        out['elapsed_seconds'] = time.monotonic()-started
        temporary = destination.with_suffix('.tmp')
        temporary.write_text(json.dumps(out,indent=2,allow_nan=False));temporary.replace(destination)
    save()
    try:
        pars = Parameters(C0=.9,L0=1.2,hbar=.73)
        for M in (1,2):
            modes = PressureModes(pars,np.array([1.1,1.8])[:M],
                np.array([.35,-.24])[:M],np.zeros((2,M)),
                np.array([.52,.31])[:M],'independent projected coordinate-square control')
            # In eight returning quadratic factors the highest occupation is
            # at most eight; N=10 and N=12 both contain every such vacuum path.
            lowH,lowP = independent_fock(modes,10,mem)
            highH,highP = independent_fock(modes,12,mem)
            low = OrderedPressure(lowH,lowP,hbar=pars.hbar,memory_mb=mem)
            high = OrderedPressure(highH,highP,hbar=pars.hbar,memory_mb=mem)
            for tau,(increment,ratio) in itertools.product(
                    (0.,.4,.9),((False,2.),(True,2.),(True,3.))):
                expected = reference_cumulants(modes,tau,increment,ratio)
                a = low.evaluate(tau,increment=increment,ratio=ratio)
                b = high.evaluate(tau,increment=increment,ratio=ratio)
                err = error(b['cumulants'],expected,expected['2'])
                refinement = error(a['cumulants'],b['cumulants'],expected['2'])
                assert err < 3e-9 and refinement < 3e-9,(M,tau,increment,ratio,err,refinement)
                assert a['spectral_check']['passed'] and b['spectral_check']['passed']
                assert all(b['even_moments'][str(n)] >= 0 for n in (2,4,6,8))
                if increment and tau==0:
                    assert all(v==0 for v in b['moments'].values())
                out['cases'].append(dict(check='harmonic_Riccati_and_occupation',
                    modes=M,tau=tau,increment=increment,ratio=ratio,
                    cumulants=b['cumulants'],expected=expected,
                    max_scaled_error=err,occupation_scaled_error=refinement,
                    spectral_check=b['spectral_check']))
                save()
            zero = high.evaluate(.4,increment=True,ratio=1.)
            assert all(v==0 for v in zero['cumulants'].values())

        # Noncommuting complex synthetic source, with a known energy basis.
        E = np.array([0.,.7,1.6,2.8])
        Pe = np.array([[.6,.4+.3j,-.2j,.12], [.4-.3j,-.3,.18,.07j],
                       [.2j,.18,.8,.22-.11j], [.12,-.07j,.22+.11j,1.1]])
        rng = np.random.default_rng(20260915)
        V,_ = np.linalg.qr(rng.normal(size=(4,4))+1j*rng.normal(size=(4,4)))
        H,P = V@np.diag(E)@V.conj().T,V@Pe@V.conj().T
        assert np.linalg.norm(H@P-P@H)>0.1
        actual = OrderedPressure(H,P,hbar=.73,memory_mb=mem)
        shifted = OrderedPressure(H+37*np.eye(4),P-13*np.eye(4),hbar=.73,memory_mb=mem)
        for tau,(increment,ratio) in itertools.product(
                (0.,.4,.9),((False,2.),(True,2.),(True,3.))):
            gap = (E[:,None]-E[None,:])/.73
            filt = np.exp(-.5*(tau*gap)**2)
            if increment:filt -= np.exp(-.5*(ratio*tau*gap)**2)
            X = (Pe-Pe[0,0]*np.eye(4))*filt
            raw = {str(n):float(np.linalg.matrix_power(X,n)[0,0].real) for n in range(1,9)}
            expected = independent_log_series(raw)
            got = actual.evaluate(tau,increment=increment,ratio=ratio,return_spectrum=True)
            shifted_result = shifted.evaluate(tau,increment=increment,ratio=ratio)
            err = error(got['cumulants'],expected,raw['2'])
            shift_err = error(shifted_result['cumulants'],expected,raw['2'])
            assert err<2e-9 and shift_err<2e-9,(tau,increment,ratio,err,shift_err)
            assert got['spectral_check']['passed']
            assert abs(got['removed_scalar_in_supplied_pressure']-.6)<2e-13
            assert abs(shifted_result['removed_scalar_in_supplied_pressure']+12.4)<2e-12
            out['cases'].append(dict(check='noncommuting_complex_direct_powers_formal_log_and_scalar_shifts',
                tau=tau,increment=increment,ratio=ratio,cumulants=got['cumulants'],
                expected=expected,max_scaled_error=err,shift_scaled_error=shift_err,
                spectral_check=got['spectral_check']))
            save()

        # Known Bernoulli spectral law: mean-centering must not change k2..8.
        q=.3
        U=np.array([[math.sqrt(1-q),math.sqrt(q)],[-math.sqrt(q),math.sqrt(1-q)]])
        Bernoulli = U@np.diag([0.,1.])@U.T
        bern = OrderedPressure(np.diag([0.,1.]),Bernoulli,memory_mb=mem).evaluate(0.)
        independent = independent_log_series({str(n):q for n in range(1,9)})
        assert error(bern['cumulants'],independent,q*(1-q))<2e-10
        out['cases'].append(dict(check='Bernoulli_uncentered_MGF',cumulants=bern['cumulants']))

        for label,Hbad,Pbad in [('nonhermitian',np.diag([0.,1.]),np.array([[0.,1.],[0.,0.]])),
                                ('degenerate_ground',np.eye(2),np.diag([0.,1.]))]:
            try:OrderedPressure(Hbad,Pbad,memory_mb=mem)
            except ValueError:pass
            else:raise AssertionError(label+' must be rejected')
        for kwargs in [dict(tau=-1.),dict(tau=.4,ratio=.5),dict(tau=.4,order=9)]:
            try:actual.evaluate(**kwargs)
            except ValueError:pass
            else:raise AssertionError('Invalid settings must be rejected')
        out['status']='PASS';save()
        print('PASS independent ordered pressure cumulant controls',flush=True)
    except BaseException as exc:
        out.update(status='FAIL',error=repr(exc));save();raise


if __name__=='__main__':main()
