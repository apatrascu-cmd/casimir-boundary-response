"""Ordered ground-state pressure cumulants for a supplied finite H and P.

This module takes powers of one Gaussian-averaged Hermitian operator. It does
not commute pressure operators at different times, impose time ordering, or
identify its spectral law with an arbitrary detector record. The supplied P
is centered in the actual ground state of the supplied H before averaging.
Its removed scalar is not a calibrated Casimir mean, especially if an input
archive has already discarded a pressure constant. Regulator/source errors
outside these finite matrices are not controlled here.
"""
from __future__ import annotations

import math
import os
import numpy as np
from scipy.linalg import eigh


def memory_limit_mb(memory_mb=None):
    value = float(os.environ['PYSCF_MAX_MEMORY'] if memory_mb is None else memory_mb)
    if not np.isfinite(value) or value <= 0:
        raise ValueError('A positive finite PYSCF_MAX_MEMORY allowance is required')
    return value


def cumulants_from_moments(moments, order=8):
    """Classical cumulant identity for the spectral law of ONE operator.

    m_n = sum_{j=1}^n binom(n-1,j-1) k_j m_{n-j}. Quantum ordering is
    fixed when forming m_n; this scalar identity does not change it.
    """
    values = [1.] + [float(moments[str(n)]) for n in range(1, order+1)]
    cumulants = [0.]
    for n in range(1, order+1):
        cumulants.append(math.fsum([values[n]] + [
            -math.comb(n-1, j-1)*cumulants[j]*values[n-j]
            for j in range(1, n)]))
    return {str(n): cumulants[n] for n in range(1, order+1)}


def _real(value, scale, label):
    if abs(float(np.imag(value))) > 2e-11*max(float(scale), 1e-300):
        raise ArithmeticError(label + ' has a significant imaginary component')
    return float(np.real(value))


def _moments_from_ground_vector(X, order):
    """Even norms and odd sandwiches; no high matrix powers are formed."""
    v = np.zeros(len(X), dtype=X.dtype)
    v[0] = 1.
    moments = {}
    for k in range(order//2+1):
        if k:
            moments[str(2*k)] = float(np.vdot(v, v).real)
        if 2*k+1 <= order:
            w = X@v
            moments[str(2*k+1)] = _real(np.vdot(v, w),
                np.linalg.norm(v)*np.linalg.norm(w), 'Odd moment')
            v = w
    return moments


def _comparison(observed, reference, variance, order):
    return {str(n): abs(observed[str(n)]-reference[str(n)]) /
            max(abs(reference[str(n)]), abs(variance)**(n/2), 1e-300)
            for n in range(2, order+1)}


class OrderedPressure:
    """Diagonalize H once, then evaluate several windows for the same source.

    A unique numerically resolved ground state is required. A parity-restricted
    archive must separately certify that its ground state is the physical
    ground state; this class cannot infer an absent parity sector.
    """

    def __init__(self, H, P, hbar=1., memory_mb=None):
        self.memory_mb = memory_limit_mb(memory_mb)
        if not np.isfinite(hbar) or hbar <= 0:
            raise ValueError('hbar must be finite and positive')
        self.hbar = float(hbar)
        H, P = np.asarray(H), np.asarray(P)
        if H.ndim != 2 or not H.size or H.shape[0] != H.shape[1] or P.shape != H.shape:
            raise ValueError('H and P must be nonempty same-size square matrices')
        if not np.all(np.isfinite(H)) or not np.all(np.isfinite(P)):
            raise ValueError('H and P must have finite entries')
        self.dimension = len(H)
        estimate = 40*16*self.dimension**2
        if estimate > .6*self.memory_mb*1024**2:
            raise MemoryError('Estimated ordered-cumulant workspace exceeds allowance')
        self.estimated_workspace_mb = estimate/1024**2
        for label, matrix in [('H', H), ('P', P)]:
            if not np.allclose(matrix, matrix.conj().T, rtol=1e-12, atol=1e-14):
                raise ValueError(label+' must be Hermitian')
        dtype = complex if np.iscomplexobj(H) or np.iscomplexobj(P) else float
        H = np.asarray((H+H.conj().T)/2, dtype=dtype)
        P = np.asarray((P+P.conj().T)/2, dtype=dtype)
        anchor = float(H[0, 0].real)
        H = H-anchor*np.eye(len(H))
        energies, vectors = eigh(H, check_finite=False)
        uncertainty_scale = max(float(np.max(abs(energies))), 1e-300)
        resolution = 64*np.finfo(float).eps*uncertainty_scale
        if len(H)>1 and energies[1]-energies[0] <= resolution:
            raise ValueError('Ground state is degenerate or not numerically resolved')
        self.ground_energy_in_supplied_H = float(energies[0]+anchor)
        self.energies = energies-energies[0]
        self.ground_resolution_scale = resolution
        Pe = vectors.conj().T@P@vectors
        Pe = (Pe+Pe.conj().T)/2
        self.removed_scalar = float(Pe[0, 0].real)
        self.Pc = Pe-self.removed_scalar*np.eye(len(Pe))
        # This is the exact stated centering convention, not an inferred mean.
        self.Pc[0, 0] = 0.

    def evaluate(self, tau, order=8, increment=False, ratio=2.,
                 spectral_check=True, return_spectrum=False,
                 consistency_tolerance=1e-8):
        if not isinstance(order, (int, np.integer)) or not 2 <= order <= 8:
            raise ValueError('order must be an integer from 2 through 8')
        if not np.isfinite(tau) or tau < 0:
            raise ValueError('tau must be finite and nonnegative')
        if not np.isfinite(ratio) or ratio < 1:
            raise ValueError('ratio must be finite and >=1')
        if not np.isfinite(consistency_tolerance) or consistency_tolerance <= 0:
            raise ValueError('consistency_tolerance must be finite and positive')
        gaps = (self.energies[:, None]-self.energies[None, :])/self.hbar
        if increment and (ratio == 1 or tau == 0):
            filt = np.zeros_like(gaps)
        else:
            with np.errstate(over='ignore', under='ignore'):
                z = -.5*(tau*gaps)**2
                filt = np.exp(z)
                if increment:
                    filt *= -np.expm1((ratio*ratio-1)*z)
        X = self.Pc*filt
        scale = float(np.max(abs(X)))
        Y = X/scale if scale else X.copy()
        unit_moments = _moments_from_ground_vector(Y, order)
        unit_cumulants = cumulants_from_moments(unit_moments, order)
        def physical(values):
            out = {k: float(v*scale**int(k)) for k,v in values.items()}
            if not all(np.isfinite(v) for v in out.values()):
                raise FloatingPointError('Pressure moments/cumulants overflowed')
            return out
        moments, cumulants = physical(unit_moments), physical(unit_cumulants)
        variance = unit_moments['2']
        standardized = ({str(n): float(unit_cumulants[str(n)]/variance**(n/2))
                         for n in range(2,order+1)} if variance > 0 else None)
        answer = dict(tau=float(tau), order=int(order),
            observable='increment' if increment else 'ordinary_gaussian_average',
            ratio=float(ratio) if increment else None, hbar=self.hbar,
            dimension=self.dimension, moments=moments,
            even_moments={str(n):moments[str(n)] for n in range(2,order+1,2)},
            cumulants=cumulants, standardized_cumulants=standardized,
            centered_mean_residual=moments['1'], matrix_scale=scale,
            removed_scalar_in_supplied_pressure=self.removed_scalar,
            ground_energy_in_supplied_H=self.ground_energy_in_supplied_H,
            excitation_energies=self.energies.tolist(),
            ground_resolution_scale=self.ground_resolution_scale,
            estimated_workspace_mb=self.estimated_workspace_mb,
            mean_scope='actual-ground-centered supplied P; no physically calibrated mean inferred',
            ordering='powers of one smeared Hermitian operator, with ordered products preserved',
            scope='finite supplied H/P; omitted states, source defects and regulator errors remain separate')
        if spectral_check or return_spectrum:
            x, states = eigh(Y, check_finite=False)
            probabilities = np.abs(states[0, :])**2
            reconstructed = {str(n): float(np.dot(probabilities, x**n))
                             for n in range(1,order+1)}
            reconstructed_cumulants = cumulants_from_moments(reconstructed, order)
            moment_errors = _comparison(reconstructed, unit_moments, variance, order)
            cumulant_errors = _comparison(reconstructed_cumulants, unit_cumulants, variance, order)
            probability_error = abs(float(probabilities.sum())-1)
            max_error = max([probability_error, *moment_errors.values(), *cumulant_errors.values()])
            answer['spectral_check'] = dict(
                passed=bool(max_error <= consistency_tolerance),
                tolerance=float(consistency_tolerance), max_scaled_error=max_error,
                probability_sum=float(probabilities.sum()),
                moment_scaled_errors=moment_errors, cumulant_scaled_errors=cumulant_errors,
                moments=physical(reconstructed), cumulants=physical(reconstructed_cumulants),
                scale_definition='max(abs(reference order-n value), variance^(n/2), 1e-300) in matrix-scaled units')
            if return_spectrum:
                answer['spectral_law'] = dict(eigenvalues=(x*scale).tolist(),
                    probabilities=probabilities.tolist(),
                    scope='positive spectral law of the centered finite observable')
        return answer


def ordered_matrix_cumulants(H, P, tau, order=8, increment=False, ratio=2.,
                             hbar=1., memory_mb=None, **kwargs):
    """Convenience wrapper; use OrderedPressure to reuse H across windows."""
    return OrderedPressure(H, P, hbar=hbar, memory_mb=memory_mb).evaluate(
        tau, order=order, increment=increment, ratio=ratio, **kwargs)
