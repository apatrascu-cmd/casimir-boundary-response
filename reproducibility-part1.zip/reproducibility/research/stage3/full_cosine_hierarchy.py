"""Full projected cosine and ordered spectral moments in adaptive Fock spaces.

All  M  selected normal-mode vacuum contractions are retained, even when a
particular mode has no excitation in the adaptive space. This is a projection,
not an exact integration of discarded virtual states. Its error is measured.
"""
from pathlib import Path
import sys,os,json,math,time,hashlib,argparse
import numpy as np
from scipy.sparse import csr_matrix,eye
from scipy.linalg import eigh
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research'),str(ROOT/'research/stage2')]
from nonlinear_pressure import FockRegulator,continuum_pressure_modes,harmonic_pressure
from static_family import sparse_pressure
from run_boundary_hierarchy import hierarchy

class AdaptiveFock(FockRegulator):
    def __init__(self,omega,budget=10,costs=None,hbar=1.,max_dimension=8000,satellite=None):
        self.omega=np.asarray(omega);self.hbar=hbar
        costs=np.ones(len(omega)) if costs is None else np.asarray(costs)
        if np.any(costs<1) or budget<1:raise ValueError('cost >=1 and budget >=1 required')
        self.max_quanta=int(math.floor(budget/min(costs)+1e-10));self.costs=costs
        states=[]
        def visit(prefix,j,left):
            if j==len(omega):states.append(tuple(prefix));return
            for n in range(int(math.floor((left+1e-10)/costs[j]))+1):
                visit(prefix+[n],j+1,left-n*costs[j])
                if len(states)>max_dimension:raise ValueError('adaptive dimension budget exceeded')
        visit([],0,float(budget))
        self.satellite_info={}
        if satellite:
            hard=np.flatnonzero(costs>satellite.get('threshold',budget/2))
            seeds=[v for v in states if np.dot(v,costs)<=satellite.get('low_budget',2)+1e-10 and not any(v[j] for j in hard)]
            selected=set(states);sq=satellite.get('quanta',4)
            for base in seeds:
                for j in hard:
                    for n in range(1,sq+1):
                        v=list(base);v[j]=n;selected.add(tuple(v))
                for j,k in satellite.get('pairs',[]):
                    for nj in range(1,sq):
                        for nk in range(1,sq-nj+1):
                            v=list(base);v[j]=nj;v[k]=nk;selected.add(tuple(v))
            if len(selected)>max_dimension:raise ValueError('satellite dimension budget exceeded')
            self.satellite_info={'hard_modes':hard.tolist(),'seed_count':len(seeds),'pairs':satellite.get('pairs',[]),'core_dimension':len(states)}
            states=list(selected);self.max_quanta=max(sum(v) for v in states)
        states.sort(key=lambda s:(sum(s),s))
        self.states=np.asarray(states,dtype=int);self.dimension=len(states)
        self.energies=self.states@(hbar*self.omega)
        index={s:i for i,s in enumerate(states)};self.ann=[]
        for j in range(len(omega)):
            rows=[];cols=[];values=[]
            for col,state in enumerate(states):
                if state[j]:
                    lower=list(state);lower[j]-=1
                    rows.append(index[tuple(lower)]);cols.append(col);values.append(np.sqrt(state[j]))
            self.ann.append(csr_matrix((values,(rows,cols)),shape=(self.dimension,self.dimension)))
        self.identity=eye(self.dimension,format='csr')

def weights(omega,tau,soft=.25,hard=.25,hard_cap=None):
    x=tau*np.asarray(omega)
    hard_cost=hard*x if hard_cap is None else np.minimum(hard*x,hard_cap)
    return np.maximum.reduce([np.ones_like(x),soft/x,hard_cost])

def satellite_configuration(modes,u,costs,Q,case):
    n=case.get('satellite_quanta',0)
    if not n:return None
    threshold=case.get('satellite_threshold',Q/2)
    hard=np.flatnonzero(costs>threshold)
    c=modes.branch*np.sqrt(modes.p.hbar/(2*modes.omega))[None,:]
    scores=[]
    for ai,j in enumerate(hard):
        for k in hard[ai+1:]:
            score=0.
            for nj in [1,2,3]:
                nk=4-nj
                amp=sum(u*c[:,j]**nj*c[:,k]**nk)/np.sqrt(math.factorial(nj)*math.factorial(nk))
                score+=(amp/(modes.p.hbar*(nj*modes.omega[j]+nk*modes.omega[k])))**2
            scores.append((score,int(j),int(k)))
    scores.sort(reverse=True)
    pairs=[[j,k] for _,j,k in scores[:case.get('satellite_pairs',0)]]
    return {'threshold':threshold,'low_budget':case.get('satellite_low_budget',2),'quanta':n,'pairs':pairs}

def even_raw_from_cumulants(k,order=8):
    m=[1.]
    for n in range(1,order+1):m.append(sum(math.comb(n-1,j-1)*float(k[str(j)])*m[n-j] for j in range(1,n+1)))
    return {str(n):m[n] for n in range(2,order+1,2)}

def filter_gap(gaps,tau,ratio=2.):
    z=-.5*(tau*gaps)**2
    return np.exp(z)*(-np.expm1((ratio*ratio-1)*z))

def even_moments(O,order=8):
    v=np.zeros(O.shape[0]);v[0]=1.;out={}
    for j in range(1,order//2+1):
        v=O@v;out[str(2*j)]=float(v@v)
    return out

def shape_logs(raw,reference):
    if any(x<=1e-280 or not np.isfinite(x) for x in list(raw.values())+list(reference.values())):return None
    return {str(p):float(np.log(raw[str(p)])-np.log(reference[str(p)])-p/2*(np.log(raw['2'])-np.log(reference['2']))) for p in [4,6,8]}

def projected_harmonic(f,modes,tau,ratio=2.):
    even=np.flatnonzero(f.states.sum(axis=1)%2==0)
    P=sparse_pressure(f,modes)[even][:,even].tocsr();E=f.energies[even]
    S=P.tocoo(copy=True);S.data*=filter_gap((E[S.row]-E[S.col])/modes.p.hbar,tau,ratio)
    return even,E,P,even_moments(S.tocsr())

def harmonic_exact(modes,tau,ratio=2.):
    if ratio==2:return even_raw_from_cumulants(harmonic_pressure(modes,tau,8,True))
    from distributed_line import quantum_quadratic_cumulants
    A,B=modes.matrices();w=modes.omega
    return even_raw_from_cumulants(quantum_quadratic_cumulants(A*filter_gap(w[:,None]-w[None,:],tau,ratio),B*filter_gap(w[:,None]+w[None,:],tau,ratio),8))

def exp_remainder(s):
    """exp(-s/2)-1+s/2, avoiding both cancellation and fixed Taylor error."""
    if abs(s)>.1:return float(np.expm1(-s/2)+s/2)
    z=-s/2;term=z*z/2;ans=term
    for k in range(3,100):
        term*=z/k;ans+=term
        if abs(term)<=abs(ans)*2e-17:return float(ans)
    raise ArithmeticError('exp remainder did not converge')

def normal_vertices(f,modes,even):
    """Reusable projected even normal powers. No coordinate top-edge products."""
    all_vertices=[]
    for b,var in f.branch_data(modes):
        powers=[f.identity]
        for j in range(1,f.max_quanta+1):powers.append((powers[-1]@b).tocsr())
        vertices={}
        for degree in range(2,2*f.max_quanta+1,2):
            mat=csr_matrix(f.identity.shape)
            for j in range(max(0,degree-f.max_quanta),min(f.max_quanta,degree)+1):
                mat+=math.comb(degree,j)*(powers[j].T@powers[degree-j])
            if mat.nnz:vertices[degree]=mat[even][:,even].tocsr()
        all_vertices.append((var,vertices))
    return all_vertices

def cosine_hamiltonian(E,vertices,KJ,couplings,beta):
    H=np.diag(E);phase=[]
    for kj,u,(var,v) in zip(KJ,couplings,vertices):
        if u>0 or beta<0:raise ValueError('physical cosine requires beta >=0 and u<=0')
        if u==0 or beta==0:phase.append(0.);continue
        theta2=-beta*u/kj;s=theta2*var;phase.append(s)
        H+=(kj/2*exp_remainder(s))*v[2].toarray()
        coefficient=-kj*np.exp(-s/2)*theta2/24
        for k in range(2,max(v)//2+1):
            if k>2:coefficient*=-theta2/((2*k)*(2*k-1))
            if 2*k in v:H+=coefficient*v[2*k].toarray()
    return (H+H.T)/2,np.asarray(phase)

def streamed_hamiltonians(f,modes,even,E,u,betas,memory_mb,calibration_variances=None):
    D=len(even)
    if (len(betas)+12)*D*D*8>memory_mb*1024**2*.60:
        raise MemoryError('dense matrix budget exceeded')
    Hs={beta:np.diag(E) for beta in betas};phases={beta:[] for beta in betas}
    V=np.zeros((D,D));W=V.copy();variances=[];peak_sparse=0
    for r,(kj,ur,(b,var)) in enumerate(zip(modes.p.KJ,u,f.branch_data(modes))):
        vref=var if calibration_variances is None else calibration_variances[r]
        variances.append(var);powers=[f.identity]
        for j in range(1,f.max_quanta+1):powers.append((powers[-1]@b).tocsr())
        storage=sum(v.data.nbytes+v.indices.nbytes+v.indptr.nbytes for v in powers)
        if storage>memory_mb*1024**2*.25:raise MemoryError('annihilator power budget exceeded')
        columns=[v[:,even].tocsr() for v in powers]
        coeff={}
        for beta in betas:
            t2=-beta*ur/kj;s=t2*var;phases[beta].append(s)
            coeff[beta]={2:kj/2*(exp_remainder(s)+t2*(vref-var)/2),4:-kj*np.exp(-s/2)*t2/24}
            for k in range(3,f.max_quanta+1):coeff[beta][2*k]=coeff[beta][2*k-2]*(-t2)/((2*k)*(2*k-1))
        for degree in range(2,2*f.max_quanta+1,2):
            mat=csr_matrix((D,D))
            for j in range(max(0,degree-f.max_quanta),min(f.max_quanta,degree)+1):
                mat+=math.comb(degree,j)*(columns[j].T@columns[degree-j])
            peak_sparse=max(peak_sparse,storage+sum(v.data.nbytes+v.indices.nbytes+v.indptr.nbytes for v in columns)+mat.data.nbytes+mat.indices.nbytes+mat.indptr.nbytes)
            if peak_sparse>memory_mb*1024**2*.4:raise MemoryError('streamed sparse matrix budget exceeded')
            dense=mat.toarray()
            if degree==2:V+=ur*(var-vref)*dense/4
            if degree==4:V+=ur*dense/24
            if degree in [2,4,6]:W+=ur*ur/kj*{2:var*var/16,4:var/48,6:1/720}[degree]*dense
            for beta in betas:Hs[beta]+=coeff[beta][degree]*dense
    return Hs,phases,V,W,variances,peak_sparse

def projected_first_order(E,P,V,tau,hbar=1.):
    from nonlinear_pressure import smear_frechet
    S,D=smear_frechet(E,P.toarray(),V,tau,hbar,True)
    v=np.zeros(len(E));v[0]=1.;tangent=np.zeros(len(E));tangent[1:]=-V[1:,0]/E[1:]
    hm={};dm={}
    for j in range(1,5):
        tangent=D@v+S@tangent;v=S@v
        hm[str(2*j)]=float(v@v);dm[str(2*j)]=float(2*v@tangent)
    A={str(p):dm[str(p)]/hm[str(p)]-p/2*dm['2']/hm['2'] for p in [4,6,8]}
    return dict(moments=hm,delta_moments=dm,log_shape_derivative=A)

def direct_cosine_hamiltonian(f,modes,even,E,couplings,beta):
    """Independent displacement/Laguerre formula; best away from tiny beta."""
    from scipy.special import eval_genlaguerre,gammaln
    states=f.states[even];D=len(even);H=np.diag(E);ident=np.eye(D)
    for kj,u,(b,var),coeff in zip(modes.p.KJ,couplings,f.branch_data(modes),modes.branch*np.sqrt(modes.p.hbar/(2*modes.omega))[None,:]):
        if u==0 or beta==0:continue
        t2=-beta*u/kj;t=math.sqrt(t2);C=np.ones((D,D),complex)
        for j,c in enumerate(coeff):
            n=states[:,j];lo=np.minimum(n[:,None],n[None,:]);hi=np.maximum(n[:,None],n[None,:]);d=hi-lo;x=t*c
            C*=np.exp(.5*(gammaln(lo+1)-gammaln(hi+1)))*(1j*x)**d*eval_genlaguerre(lo,d,x*x)
        C=C.real*np.exp(-t2*var/2)
        q2=f.normal_power(b,2)[even][:,even].toarray()+var*ident
        part=kj/t2*(ident-C)-kj*q2/2+kj*t2*var*q2/4
        part-=part[0,0]*ident
        H+=part
    return (H+H.T)/2

def spectral_moments(H,P,taus,hbar=1.,ratio=2.):
    E,U=eigh(H,check_finite=False,driver='evr');E-=E[0]
    P=np.asarray(U.T@(P@U));gaps=(E[:,None]-E[None,:])/hbar
    rows=[]
    for tau in taus:rows.append(even_moments(P*filter_gap(gaps,tau,ratio)))
    return E,rows,U[:,0]

def parameters(R,M,G=-1e-7,s=0.):
    p,poles=hierarchy(R,2.,8.8/2**(R-1));m=continuum_pressure_modes(M,p)
    w=poles**s;w/=sum(w);u=G*w/.25**4
    return m,poles,u

def source_hashes():
    paths=[Path(__file__),ROOT/'src/nonlinear_pressure.py',ROOT/'research/static_family.py']
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--spec',required=True);ap.add_argument('--output',required=True)
    a=ap.parse_args();dest=(ROOT/a.output).resolve();spec=json.loads((ROOT/a.spec).read_text())
    if dest.exists() or not dest.is_relative_to(ROOT):raise ValueError('new project-local output required')
    mem=int(os.environ['PYSCF_MAX_MEMORY']);maxD=min(spec.get('max_dimension',8000),int(np.sqrt(mem*1024**2/80))*2)
    begin=time.monotonic();result={'status':'RUNNING','spec':spec,'source_sha256':source_hashes(),'cases':[],'memory_budget_mb':mem}
    def save():
        result['elapsed_seconds']=time.monotonic()-begin;tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(result,indent=2));tmp.replace(dest)
    save()
    try:
        for case in spec['cases']:
            start=time.monotonic();R=case['R'];M=case['M'];tau=case['tau'];Q=case['Q'];soft=case.get('soft',.25);hard=case.get('hard',.25);ratio=case.get('ratio',2.)
            row=dict(case);row['status']='BUILDING';result['cases'].append(row);save()
            modes,poles,u=parameters(R,M,case.get('G',-1e-7),case.get('s',0.))
            costs=weights(modes.omega,tau,soft,hard,case.get('hard_cap'))
            try:f=AdaptiveFock(modes.omega,Q,costs,modes.p.hbar,maxD,satellite_configuration(modes,u,costs,Q,case))
            except ValueError as error:
                if 'dimension' not in str(error):raise
                row.update(status='DIMENSION_EXCLUDED',reason=str(error));save();continue
            even,E,P,harm=projected_harmonic(f,modes,tau,ratio);full=harmonic_exact(modes,tau,ratio)
            row.update(satellite_info=f.satellite_info,dimension=f.dimension,even_dimension=len(even),costs=costs.tolist(),occupations_max=f.states.max(axis=0).tolist(),omega=modes.omega.tolist(),bare_poles=poles.tolist(),u=u.tolist(),harmonic_moments=full,projected_harmonic_moments=harm,harmonic_relative_errors={k:(harm[k]/full[k]-1 if full[k]>1e-280 else None) for k in full},harmonic_shape_errors=shape_logs(harm,full))
            row['cosine']=[];save()
            if case.get('beta'):
                if len(even)<2:
                    row.update(status='EMPTY_EXCITATION_SECTOR');save();continue
                eval_taus=case.get('evaluation_taus',[tau])
                references={str(t):{'projected':projected_harmonic(f,modes,t,ratio)[3],'full':harmonic_exact(modes,t,ratio)} for t in eval_taus}
                row['window_references']=references;save()
                calibration=None
                if case.get('calibration_modes'):
                    refm,_,_=parameters(R,case['calibration_modes'],case.get('G',-1e-7),case.get('s',0.))
                    calibration=np.sum(refm.branch**2*refm.p.hbar/(2*refm.omega)[None,:],axis=1)
                    row['fixed_calibration_variances']=calibration.tolist()
                try:Hs,phases,V,W,variances,peak=streamed_hamiltonians(f,modes,even,E,u,case['beta'],mem,calibration)
                except MemoryError as error:
                    row.update(status='MEMORY_EXCLUDED',reason=str(error));save();continue
                row.update(vacuum_variances=variances,peak_streamed_sparse_bytes=peak)
                if case.get('first_order'):
                    row['projected_first_order']=projected_first_order(E,P,V,tau,modes.p.hbar);save()
                for beta in case['beta']:
                    H=Hs.pop(beta);phase=phases[beta]
                    En,ms,ground=spectral_moments(H,P,eval_taus,modes.p.hbar,ratio)
                    values=[]
                    for t,mom in zip(eval_taus,ms):
                        ref=references[str(t)]
                        values.append({'tau':t,'moments':mom,'log_shape_against_projected_harmonic':shape_logs(mom,ref['projected']),'log_shape_against_full_harmonic':shape_logs(mom,ref['full'])})
                    c={'beta':beta,'widths':values,'vacuum_phase_variances':phase,'gap':float(En[1]),'ground_top_shell_weight':float(sum(ground[(f.states[even]@costs)>Q-2]**2))}
                    if case.get('direct_check'):
                        Hdirect=direct_cosine_hamiltonian(f,modes,even,E,u,beta)
                        norm=float(np.linalg.norm(H-Hdirect))
                        c['independent_cosine_matrix_relative_error']=norm/max(1.,np.linalg.norm(H))
                        c['independent_cosine_residual_relative_error']=norm/max(1e-300,np.linalg.norm(H-np.diag(E)))
                    row['cosine'].append(c);save()
            row.update(status='COMPLETED',elapsed_seconds=time.monotonic()-start);save();print(json.dumps({k:row[k] for k in ['R','M','tau','Q','soft','hard','even_dimension','elapsed_seconds'] if k in row}),flush=True)
        result['status']='COMPLETED';save()
    except BaseException as e:
        result.update(status='FAILED',failure={'type':type(e).__name__,'message':str(e)});save();raise
    print(json.dumps({'status':result['status'],'elapsed_seconds':result['elapsed_seconds']}),flush=True)
if __name__=='__main__':main()
