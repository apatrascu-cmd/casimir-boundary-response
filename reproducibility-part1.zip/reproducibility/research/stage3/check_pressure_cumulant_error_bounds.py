"""Small exact finite-spectrum and algebraic cumulant-interval controls.

Prepared without execution. Use a new output path under the central guard.
"""
from pathlib import Path
import argparse
import hashlib
import itertools
import json
import math
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research/stage3'))
from pressure_cumulant_error_bounds import (memory_limit_mb,centered_frobenius_upper,
    returning_path_moment_bounds,cumulant_intervals,cumulants_with_path_error)


def exact_moments(E,P,tau,increment,ratio,hbar):
    Pc=P-P[0,0]*np.eye(len(P))
    gap=(E[:,None]-E[None,:])/hbar
    filt=np.exp(-.5*(tau*gap)**2)
    if increment:filt-=np.exp(-.5*(ratio*tau*gap)**2)
    X=Pc*filt
    answer={}
    for n in range(1,9):
        value=np.linalg.matrix_power(X,n)[0,0]
        assert abs(value.imag)<1e-12*max(1.,abs(value.real))
        answer[str(n)]=float(value.real)
    return answer


def independent_cumulants(moments):
    u=np.array([0.]+[moments[str(p)]/math.factorial(p) for p in range(1,9)])
    term=np.zeros(9);term[0]=1.;logarithm=np.zeros(9)
    for k in range(1,9):
        term=np.convolve(term,u)[:9]
        logarithm+=(-1)**(k+1)*term/k
    return {str(p):float(math.factorial(p)*logarithm[p]) for p in range(1,9)}


def assert_encloses(expected,intervals,tolerance_scale=1.):
    for p in range(1,9):
        row=intervals['cumulants'][str(p)];value=expected[str(p)]
        tolerance=3e-11*max(abs(value),tolerance_scale,1e-280)
        assert row['lower']-tolerance<=value<=row['upper']+tolerance,(p,value,row)


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True)
    args=ap.parse_args();dest=(ROOT/args.output).resolve();mem=memory_limit_mb()
    if not dest.is_relative_to(ROOT) or dest.suffix!='.json':raise ValueError('New project-local JSON required')
    if dest.exists():raise FileExistsError(dest)
    files=[Path(__file__),ROOT/'research/stage3/pressure_cumulant_error_bounds.py']
    started=time.monotonic()
    out=dict(status='RUNNING',memory_mb=mem,checks=[],
        source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
        scope='exact finite spectral restrictions and algebraic error propagation; no hierarchy certification')
    dest.parent.mkdir(parents=True,exist_ok=True)
    def save():
        out['elapsed_seconds']=time.monotonic()-started
        temp=dest.with_suffix('.tmp');temp.write_text(json.dumps(out,indent=2,allow_nan=False));temp.replace(dest)
    save()
    try:
        E=np.array([0.,.4,1.1,2.,3.2])
        P=np.array([[.4,.35+.11j,-.2j,.13,-.08],
                    [.35-.11j,-.17,.12,.03j,.06],
                    [.2j,.12,.29,-.1+.05j,.08j],
                    [.13,-.03j,-.1-.05j,.7,.19],
                    [-.08,.06,-.08j,.19,-.31]])
        assert np.max(abs(P-P.conj().T))<1e-15
        assert np.linalg.norm(np.diag(E)@P-P@np.diag(E))>.1
        Pc=P-P[0,0]*np.eye(len(P))
        exact_norm=float(np.linalg.norm(Pc))
        pf_upper=float(np.linalg.norm(P))*(1+1e-12)
        safe=centered_frobenius_upper(pf_upper,float(P[0,0].real),len(P),memory_mb=mem)
        assert safe['centered_frobenius_upper']>=exact_norm
        for keep,tau,hbar,(increment,ratio) in itertools.product(
                (1,2,4),(.1,.4,1.2,3.),(.6,1.7),((False,2.),(True,2.),(True,3.))):
            full=exact_moments(E,P,tau,increment,ratio,hbar)
            retained=exact_moments(E[:keep],P[:keep,:keep],tau,increment,ratio,hbar)
            paths=returning_path_moment_bounds(safe['centered_frobenius_upper'],tau,E[keep],
                hbar=hbar,increment=increment,ratio=ratio,omitted_state_count=len(E)-keep,memory_mb=mem)
            errors={p:row['absolute_error_upper'] for p,row in paths['moments'].items()}
            for p in range(1,9):
                difference=abs(full[str(p)]-retained[str(p)])
                assert difference<=errors[str(p)]+3e-12*max(abs(full[str(p)]),abs(retained[str(p)]),1e-280)
            propagated=cumulant_intervals(retained,errors,memory_mb=mem)
            exact_k=independent_cumulants(full)
            assert_encloses(exact_k,propagated,max(abs(v) for v in exact_k.values()))
            out['checks'].append(dict(check='noncommuting_exact_full_vs_retained',
                kept=keep,tau=tau,hbar=hbar,increment=increment,ratio=ratio,
                raw_errors={str(p):abs(full[str(p)]-retained[str(p)]) for p in range(2,9)},
                path_upper=errors,cumulant_intervals=propagated['cumulants']))
        save()

        # Scalar shifts change the bound's reference norm/mean consistently,
        # while centered ordinary and increment moments stay invariant.
        shifted=P+17*np.eye(len(P))
        shifted_safe=centered_frobenius_upper(float(np.linalg.norm(shifted))*(1+1e-12),
            float(shifted[0,0].real),len(P),memory_mb=mem)
        assert shifted_safe['centered_frobenius_upper']>=exact_norm
        for increment in (False,True):
            a=exact_moments(E,P,.4,increment,2.,.73)
            b=exact_moments(E+37,shifted,.4,increment,2.,.73)
            assert max(abs(a[k]-b[k]) for k in a)<2e-12
        out['checks'].append(dict(check='same_source_scalar_and_energy_shift',safe_norm=safe))

        # All corners of a deterministic raw-moment box, with an independent
        # formal-log calculation. These are algebraic controls, not assumed
        # physically realizable joint moment sequences.
        m={str(p):v for p,v in enumerate([0.,1.,.07,3.,.11,15.,.17,105.],1)}
        eps={str(p):v for p,v in enumerate([0.,.03,.04,.06,.08,.1,.12,.2],1)}
        interval=cumulant_intervals(m,eps,memory_mb=mem)
        for signs in itertools.product((-1,1),repeat=7):
            corner={'1':0.,**{str(p):m[str(p)]+signs[p-2]*eps[str(p)] for p in range(2,9)}}
            assert_encloses(independent_cumulants(corner),interval)
        out['checks'].append(dict(check='all_128_raw_interval_corners',intervals=interval['cumulants']))

        # Odd-moment uncertainty changes even cumulants too: k6 includes
        # -10 m3^2 when centered. Even raw moments alone do not settle it.
        gaussian={str(p):v for p,v in enumerate([0.,1.,0.,3.,0.,15.,0.,105.],1)}
        odd_error={str(p):(.02 if p==3 else 0.) for p in range(1,9)}
        odd_interval=cumulant_intervals(gaussian,odd_error,memory_mb=mem)
        changed=dict(gaussian);changed['3']=.02
        true_k=independent_cumulants(changed)
        assert abs(true_k['6']+.004)<1e-12
        assert_encloses(true_k,odd_interval)
        try:cumulant_intervals({k:v for k,v in gaussian.items() if int(k)%2==0},odd_error,memory_mb=mem)
        except ValueError:pass
        else:raise AssertionError('Even-only input must be rejected')
        out['checks'].append(dict(check='odd_error_changes_kappa6_and_even_only_rejected',
                                 changed_kappa6=true_k['6'],intervals=odd_interval['cumulants']))

        # Uncentered input is allowed only when declared; centering is never
        # inferred from an already shifted archive's scalar.
        q=.3;raw={str(p):q for p in range(1,9)};zeros={str(p):0. for p in range(1,9)}
        uncentered=cumulant_intervals(raw,zeros,centered=False,memory_mb=mem)
        assert_encloses(independent_cumulants(raw),uncentered)
        try:cumulant_intervals(raw,zeros,centered=True,memory_mb=mem)
        except ValueError:pass
        else:raise AssertionError('Exact centered input must have m1=0')

        for tau,inc,ratio,count in [(0.,True,2.,3),(.4,True,1.,3),(.4,False,2.,0)]:
            result=returning_path_moment_bounds(2.,tau,1.,increment=inc,ratio=ratio,
                omitted_state_count=count,memory_mb=mem)
            assert all(row['exact_zero'] for row in result['moments'].values())
        tiny=returning_path_moment_bounds(1.,100.,1.,memory_mb=mem)
        assert not tiny['moments']['2']['exact_zero']
        assert tiny['moments']['2']['absolute_error_upper']>0
        assert tiny['moments']['2']['log_absolute_error_upper']<-9000
        huge=returning_path_moment_bounds(1e200,0.,1.,memory_mb=mem)
        assert huge['moments']['2']['absolute_error_upper'] is None
        combined=cumulants_with_path_error(exact_moments(E[:2],P[:2,:2],.4,False,2.,1.),
            safe['centered_frobenius_upper'],.4,E[2],memory_mb=mem)
        assert_encloses(independent_cumulants(exact_moments(E,P,.4,False,2.,1.)),combined['cumulant_bounds'])
        out['checks'].append(dict(check='zero_limits_log_underflow_overflow_and_combined_helper'))
        out['status']='PASS';save();print('PASS centered-pressure path and cumulant error controls',flush=True)
    except BaseException as exc:
        out.update(status='FAIL',error=repr(exc));save();raise


if __name__=='__main__':main()
