"""Finite-gap path-rate diagnostic plus bounded saved-matrix width extension.

Prepared for central execution only. No existing solver/analysis/output is edited.
Supported shortest rates are diagnostics until exact source support, equal-cost
amplitudes, and eigenpairs are controlled. No uniform-R or rare-tail conclusion.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import hashlib
import json
import math
import os
import sys
import time
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'research/stage3'),str(ROOT/'src'),str(ROOT/'research')]
import analyze_saved_common_widths_2026_09_15 as controlled
from nonlinear_pressure import FockRegulator

INPUT='results/stage3_2026-09-15/saved_common_widths_R10.json'
HELPER='research/stage3/analyze_saved_common_widths_2026_09_15.py'
EXPECTED_HELPER='bd8755753ece6786750691ad05306ac327135e3a11a7c81ca701bee565bad34b'
NEW_TAUS=(327.68,368.64,409.6)
ORDERS=(2,4,6,8)
REL_THRESHOLDS=(0.,1e-14,1e-12,1e-10,1e-8,1e-6)
D=Decimal


def require(condition,message):
    if not condition:raise ValueError(message)


def local(name):
    p=(ROOT/name).resolve()
    require(p.is_relative_to(ROOT),'Project-local paths required')
    return p


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def pack(x):return controlled.value(x)


def snap_spectrum(E,tolerance):
    """A declared nearby spectral model; group clusters by total span, not chains."""
    order=np.argsort(E);snapped=np.array(E,copy=True);groups=[];start=0
    while start<len(E):
        stop=start+1
        while stop<len(E) and E[order[stop]]-E[order[start]]<=tolerance:stop+=1
        ids=order[start:stop]
        if len(ids)>1:
            snapped[ids]=float(np.mean(E[ids]));groups.append(ids.tolist())
        start=stop
    snapped-=snapped[0]
    return snapped,dict(tolerance=tolerance,nontrivial_groups=groups,
        maximum_frequency_displacement=float(np.max(abs(snapped-E))),
        scope='near-degeneracy sensitivity model; not an assertion of exact degeneracy')


def path_rates(E,P,increment,source_threshold=0.,relative_tie_tolerance=1e-12):
    """Leading supported half-path cost and grouped-amplitude diagnostic.

    For p=2k, the support minimum is twice the minimum k-step cost.
    Prefix coefficients are added for approximately tied minimal costs. A zero
    coefficient explicitly invalidates inference from that support minimum.
    Approximate tie grouping is not an exact symbolic cancellation algorithm.
    """
    n=len(E);gap=E[:,None]-E[None,:]
    support=abs(P)>source_threshold
    if increment:support &= gap!=0
    edge=np.where(support,.5*gap*gap,np.inf)
    tie=relative_tie_tolerance*max(float(np.max(.5*gap*gap)),np.finfo(float).tiny)
    costs=np.full(n,np.inf);costs[0]=0.
    amplitudes=np.zeros(n);amplitudes[0]=1.
    absolute=np.zeros(n);absolute[0]=1.
    paths=[None]*n;paths[0]=[0]
    rows={}
    for k in range(1,5):
        candidates=edge+costs[None,:]
        best=np.min(candidates,axis=1);reachable=np.isfinite(best)
        tied=np.zeros((n,n),dtype=bool)
        with np.errstate(invalid='ignore'):
            tied[reachable]=abs(candidates[reachable]-best[reachable,None])<=tie
        next_amp=np.sum(np.where(tied,P*amplitudes[None,:],0.),axis=1)
        next_abs=np.sum(np.where(tied,abs(P)*absolute[None,:],0.),axis=1)
        next_paths=[None]*n
        for j in np.flatnonzero(reachable):
            prev=int(np.argmin(candidates[j]));next_paths[j]=paths[prev]+[int(j)]
        costs,amplitudes,absolute,paths=best,next_amp,next_abs,next_paths
        minimum=float(np.min(costs))
        if not math.isfinite(minimum):raise ArithmeticError('No supported vacuum path')
        endpoints=np.flatnonzero(abs(costs-minimum)<=tie)
        coefficient=float(np.dot(amplitudes[endpoints],amplitudes[endpoints]))
        absolute_squared=float(np.dot(absolute[endpoints],absolute[endpoints]))
        cancellation_ratio=coefficient/absolute_squared if absolute_squared else 0.
        endpoint=int(endpoints[np.argmax(abs(amplitudes[endpoints]))])
        half=paths[endpoint];full=half+list(reversed(half[:-1]))
        rate=2*minimum
        rows[str(2*k)]=dict(supported_rate=rate,
            grouped_leading_coefficient_candidate=pack(coefficient),
            grouped_amplitude_squared_over_absolute_path_sum_squared=cancellation_ratio,
            leading_group_numerically_noncancelled=bool(coefficient>0 and cancellation_ratio>1e-20),
            minimum_half_path_endpoints=endpoints.tolist(),
            representative_returning_path=full,
            representative_energies=[float(E[j]) for j in full],
            representative_source_entries=[float(P[j,i]) for i,j in zip(full,full[1:])],
            absolute_cost_tie_tolerance=tie)
    return dict(increment=increment,source_threshold=source_threshold,
        relative_tie_tolerance=relative_tie_tolerance,rows=rows,
        supported_source_entries=int(np.count_nonzero(support)),
        retained_source_is_entrywise_nonnegative=bool(np.all(P[support]>=0)),
        scope='supported minimum is a rate lower bound for this declared support model; grouped coefficients use numerical cost ties, not a proof for physical eigenpairs')


def ordinary_lowest_block(E,P,source_threshold=0.,block_tolerance=0.):
    ground_ids=np.flatnonzero(E==E[0])
    if len(ground_ids)!=1:
        return dict(condition=False,reason='Simple-ground corollary inapplicable: degenerate ground block',
            ground_block_indices=ground_ids.tolist(),
            scope='The general grouped half-path theorem still applies to the chosen ground vector')
    P=np.where(abs(P)>source_threshold,P,0.)
    allowed=np.flatnonzero((E>0)&(P[:,0]!=0))
    if not len(allowed):return dict(condition=False,reason='No nonzero ground transition')
    delta=float(np.min(E[allowed]));ids=np.flatnonzero(abs(E-delta)<=block_tolerance)
    if not len(ids):ids=np.array([int(allowed[np.argmin(E[allowed])])])
    v=P[ids,0].copy();block=P[np.ix_(ids,ids)];q=v.copy();coefficients={}
    for p in ORDERS:
        coefficients[str(p)]=pack(float(np.dot(q,q)))
        q=block@q
    norm_v=float(np.linalg.norm(v));norm_dv=float(np.linalg.norm(block@v))
    condition=norm_v>0 and norm_dv>0
    return dict(condition=condition,delta=delta,block_indices=ids.tolist(),
        source_amplitudes=v.tolist(),excited_block=block.tolist(),
        norm_Dv=norm_dv,norm_v=norm_v,
        rates={str(p):delta*delta for p in ORDERS} if condition else None,
        coefficients=coefficients if condition else None,
        scope='ordinary corollary is exact for exact support/eigenspaces when D_delta v is nonzero; this floating check is diagnostic')


def sensitivity(E,P,eigen):
    scale=float(np.max(abs(P)))
    proxy=64*len(P)*np.finfo(float).eps*float(np.linalg.norm(P))
    thresholds=sorted(set([scale*r for r in REL_THRESHOLDS]+[proxy]))
    eps_gap=2*eigen.get('eigensolve_residual_frobenius',0.)
    gap_tols=sorted(set([0.,eps_gap,128*np.finfo(float).eps*max(float(max(E)),1e-300)]))
    rows=[];block_checks=[]
    for threshold in thresholds:
        block_checks.append(dict(source_threshold=threshold,energy_model='original spectrum',
            result=ordinary_lowest_block(E,P,threshold,0.)))
        for inc in (False,True):
            r=path_rates(E,P,inc,threshold,1e-12)
            r['source_relative_threshold']=threshold/scale
            r['energy_model']='original saved approximate spectrum'
            rows.append(r)
    # Near-degeneracy sensitivity, without multiplying the full threshold grid.
    for tol in gap_tols[1:]:
        snapped,description=snap_spectrum(E,tol)
        block_checks.append(dict(source_threshold=0.,energy_model=description,
            result=ordinary_lowest_block(snapped,P,0.,0.)))
        for inc in (False,True):
            r=path_rates(snapped,P,inc,0.,1e-12)
            r['energy_model']=description;rows.append(r)
    baseline={name:path_rates(E,P,inc,0.,0.) for name,inc in [('ordinary',False),('increment',True)]}
    return dict(baseline_strict_float_ties=baseline,sensitivity_rows=rows,
        ordinary_lowest_block_sensitivity=block_checks,
        source_entry_scale=scale,source_transform_roundoff_scale_proxy=proxy,
        roundoff_proxy_scope='64 N epsilon ||Pc||_F is a sensitivity scale, not a certified eigenvector/source error bound',
        ordinary_lowest_block=ordinary_lowest_block(E,P,0.,0.))


def harmonic_rate_model(modes):
    """Complete small energy region for rate diagnostics, not a moment denominator."""
    # The rate bound uses excitation frequencies. Here hbar=1 is enforced by
    # main, so this is also the numerical energy passed to FockRegulator.
    cutoff=8*float(min(modes.omega))
    f=FockRegulator(modes.omega,8,energy_cutoff=cutoff,hbar=1.,max_dimension=1500)
    A,B=modes.matrices();P=f.quadratic(A,B)
    ids=np.flatnonzero(f.states.sum(axis=1)%2==0)
    states=f.states[ids];E=f.energies[ids];P=P[np.ix_(ids,ids)]
    ordering=np.argsort(E);E=E[ordering];P=P[np.ix_(ordering,ordering)];states=states[ordering]
    P-=P[0,0]*np.eye(len(P));P[0,0]=0.
    result=dict(energy_cutoff=cutoff,excitation_frequency_cutoff=cutoff,hbar=1.,
        dimension=len(E),states=states.tolist(),energies=E.tolist(),
        omitted_path_rate_lower_bound={str(p):2*cutoff*cutoff/p for p in ORDERS},
        completeness='all even Fock states below 8 omega_min; no more than eight quanta can occur in an order-eight returning quadratic path',
        ordinary_lowest_block=ordinary_lowest_block(E,P),
        support_and_degeneracy_sensitivity=sensitivity(E,P,{'eigensolve_residual_frobenius':0.}),
        rates={name:path_rates(E,P,inc,0.,0.) for name,inc in [('ordinary',False),('increment',True)]},
        scope='small harmonic region used only for leading rates; finite-width moments still use all-M Riccati algebra')
    for name,r in result['rates'].items():
        for p,row in r['rows'].items():
            margin=result['omitted_path_rate_lower_bound'][p]-row['supported_rate']
            row['omitted_energy_excursion_rate_margin']=margin
            row['finite_M_leading_rate_condition_satisfied_in_float_model']=bool(margin>0 and
                r['retained_source_is_entrywise_nonnegative'] and row['leading_group_numerically_noncancelled'])
    return E,P,result


def prediction(beta_graph,harm_graph,p):
    p=str(p);b=beta_graph['rows'];h=harm_graph['rows']
    if beta_graph['relative_tie_tolerance']!=harm_graph['relative_tie_tolerance']:
        return dict(status='INCONCLUSIVE_TIE_POLICY_MISMATCH',
            beta_relative_tie_tolerance=beta_graph['relative_tie_tolerance'],
            harmonic_relative_tie_tolerance=harm_graph['relative_tie_tolerance'])
    incomplete=[n for n in sorted(set(['2',p]),key=int)
        if not h[n].get('finite_M_leading_rate_condition_satisfied_in_float_model',False)]
    if incomplete:
        return dict(status='INCONCLUSIVE_HARMONIC_RATE_CUTOFF',orders=incomplete,
            scope='The retained harmonic candidate has not excluded all omitted-energy paths for these orders')
    if not all(r['leading_group_numerically_noncancelled'] for r in (b[p],b['2'],h[p],h['2'])):
        return dict(status='INCONCLUSIVE_CANCELLATION')
    power=D(p)/2
    cb=D(b[p]['grouped_leading_coefficient_candidate']['decimal']);cb2=D(b['2']['grouped_leading_coefficient_candidate']['decimal'])
    ch=D(h[p]['grouped_leading_coefficient_candidate']['decimal']);ch2=D(h['2']['grouped_leading_coefficient_candidate']['decimal'])
    constant=(cb/ch).ln()-power*(cb2/ch2).ln()
    slope=float(power)*(b['2']['supported_rate']-h['2']['supported_rate'])-(b[p]['supported_rate']-h[p]['supported_rate'])
    return dict(status='DIAGNOSTIC_NUMERICAL_SUPPORT_PREDICTION',constant=float(constant),tau_squared_slope=slope,
        relative_tie_tolerance=beta_graph['relative_tie_tolerance'],
        scope='conditional leading supported groups with harmonic energy-cutoff gate satisfied in the float model; no claim that sampled widths have reached the asymptotic regime')


def controls():
    checks=[]
    E=np.array([0.,.7])
    for diagonal in (0.,.4):
        P=np.array([[0.,.3],[.3,diagonal]])
        for inc in (False,True):
            r=path_rates(E,P,inc)
            for p in ORDERS:
                expected=.7**2 if diagonal and not inc else p*.7**2/2
                require(abs(r['rows'][str(p)]['supported_rate']-expected)<1e-13,'Two-state rate control failed')
                require(r['rows'][str(p)]['leading_group_numerically_noncancelled'],'Unexpected two-state cancellation')
            checks.append(dict(control='two_state_analytic_rates',diagonal=diagonal,increment=inc,passed=True))
    E=np.array([0.,1.,1.,1.1]);P=np.array([[0.,1.,1.,0.],[1.,0.,0.,1.],[1.,0.,0.,-1.],[0.,1.,-1.,0.]])
    for inc in (False,True):
        r=path_rates(E,P,inc,0.,1e-12);q=r['rows']['4']
        require(abs(q['supported_rate']-1.01)<1e-13,'Counterexample support rate changed')
        require(not q['leading_group_numerically_noncancelled'],'Failed to detect cancellation')
        for tau in (1.,4.):
            X,_,_=controlled.filtered(P,E,tau,inc)
            m,_=controlled.normalized_moments(X)
            z=D.from_float(-tau*tau/2);f=z.exp()
            if inc:f-=(4*z).exp()
            expected=D(4)*f**4
            require(abs(m[4]/expected-1)<D('2e-12'),'Counterexample actual moment control failed')
        checks.append(dict(control='degenerate_four_state_shortest_rate_cancelled',increment=inc,
            supported_rate=1.01,actual_leading_M4_rate=2.,passed=True))
    # Rejection gates are tested without interpreting missing evidence as a rate.
    r=path_rates(np.array([0.,.7]),np.array([[0.,.3],[.3,.4]]),False,0.,0.)
    def harmonic_candidate():
        h=dict(r);h['rows']={n:dict(row) for n,row in r['rows'].items()}
        for row in h['rows'].values():
            row['finite_M_leading_rate_condition_satisfied_in_float_model']=True
        return h
    require(prediction(r,harmonic_candidate(),8)['status']=='DIAGNOSTIC_NUMERICAL_SUPPORT_PREDICTION',
        'Complete identical-reference prediction control failed')
    checks.append(dict(control='prediction_identical_reference_complete',passed=True))
    for n in ('2','8'):
        h=harmonic_candidate();h['rows'][n]['finite_M_leading_rate_condition_satisfied_in_float_model']=False
        result=prediction(r,h,8)
        require(result['status']=='INCONCLUSIVE_HARMONIC_RATE_CUTOFF' and n in result['orders'],
            'Missing harmonic order completeness was not rejected')
        checks.append(dict(control='prediction_missing_harmonic_completeness',order=int(n),passed=True))
    h=harmonic_candidate();h['relative_tie_tolerance']=1e-12
    require(prediction(r,h,8)['status']=='INCONCLUSIVE_TIE_POLICY_MISMATCH',
        'Mismatched cost-tie policy was not rejected')
    checks.append(dict(control='prediction_mismatched_tie_policy',passed=True))
    P=np.array([[0.,.3,.2],[.3,.4,0.],[.2,0.,.5]])
    snapped,description=snap_spectrum(np.array([0.,1e-12,1.]),2e-12)
    for E,label in ((np.array([0.,0.,1.]),'exact'),(snapped,'snapped')):
        result=ordinary_lowest_block(E,P)
        require(not result['condition'] and result['ground_block_indices']==[0,1],
            'Degenerate-ground ordinary corollary was not rejected')
        checks.append(dict(control='ordinary_corollary_ground_degeneracy_rejection',model=label,passed=True))
    E=np.array([0.,1.,1.]);P=np.array([[0.,1.,0.],[1.,0.,2.],[0.,2.,0.]])
    block=ordinary_lowest_block(E,P)
    require(block['condition'] and block['block_indices']==[1,2],
        'Whole degenerate excited block control failed')
    require(all(D(block['coefficients'][str(p)]['decimal'])==D(2)**(p-2) for p in ORDERS),
        'Whole degenerate excited block coefficients failed')
    checks.append(dict(control='ordinary_corollary_whole_excited_block',passed=True))
    return dict(status='PASS',checks=checks)


def replay(case,E,Pc,modes):
    tau=289.630937574;errs={}
    for name,inc in [('ordinary',False),('increment',True)]:
        old=next(w for w in case['windows'] if w['tau']==tau and w['observable']==name)
        m,a=controlled.evaluate(Pc,E,tau,inc,2.)
        h,hh=controlled.harmonic(modes,tau,inc,2.)
        err=max(float(abs(m[p]/D(old['actual']['moments'][str(p)]['decimal'])-1)) for p in ORDERS)
        he=max(float(abs(h[p]/D(old['exact_declared_M_harmonic']['moments'][str(p)]['decimal'])-1)) for p in ORDERS)
        require(err<2e-9 and he<2e-9,'Prior long-width replay failed')
        errs[name]=dict(moment_relative_error=err,harmonic_relative_error=he,
            spectral_reconstruction=a['spectral_reconstruction'])
    return dict(tau=tau,status='PASS',observables=errs)


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True)
    args=ap.parse_args();dest=local(args.output)
    if dest.suffix!='.json' or dest.exists():raise FileExistsError('Use a new JSON output')
    require(sha(local(HELPER))==EXPECTED_HELPER,'Frozen arithmetic helper changed')
    source=local(INPUT);data=json.loads(source.read_text())
    require(data['status']=='COMPLETED_WITH_WARNINGS' and data['new_arithmetic_controls']['status']=='PASS','Prior control record not accepted')
    require(data['hbar']==1. and data['ratio']==2.,'This bounded diagnostic fixes hbar=1,b=2')
    for name,expected in data['source_sha256'].items():
        require(sha(local(name))==expected,'Prior controlled source changed: '+name)
    mem=controlled.memory_limit_mb();started=time.monotonic()
    out=dict(status='RUNNING',input=INPUT,input_sha256=sha(source),memory_mb=mem,
        new_taus=list(NEW_TAUS),hbar=1.,ratio=2.,cases=[],
        source_sha256={str(p.relative_to(ROOT)):sha(p) for p in [Path(__file__),local(HELPER),local('src/nonlinear_pressure.py'),local('src/distributed_line.py'),local('research/stage3/full_cosine_hierarchy.py')]},
        warnings=['Fixed finite-matrix Gaussian-window diagnostic; not a uniform hierarchy theorem',
            'Minimum supported rate can be cancelled or controlled by uncertain tiny source entries',
            'Decimal moments do not certify original eigenpairs, projected source or physical truncation'],
        prior_source_sha256=data['source_sha256'])
    dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('x') as f:json.dump(out,f,indent=2)
    def save():
        out['elapsed_seconds']=time.monotonic()-started
        tmp=dest.with_name(dest.name+'.writing');tmp.write_text(json.dumps(out,indent=2,allow_nan=False));tmp.replace(dest)
    try:
        with localcontext() as ctx:
            ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
            out['new_rate_controls']=controls();save()
            for case in data['cases']:
                require(case['label'] in ('R10_Q14','R10_Q16') and case['status']=='COMPLETED','Unexpected input case')
                archive=local(case['archive']);require(sha(archive)==case['archive_sha256'],'Archive changed')
                require(sha(local(case['input']))==case['input_sha256'],'Physical input changed')
                with zipfile.ZipFile(archive) as z:
                    require(sum(i.file_size for i in z.infolist())<.35*mem*1024**2,'Archive memory allowance exceeded')
                with np.load(archive,allow_pickle=False) as arrays:H,P=np.array(arrays['H']),np.array(arrays['P'])
                require(640*len(H)**2<.6*mem*1024**2,'Dense workspace allowance exceeded')
                E,Pc,c,eigen=controlled.eigen_prepare(H,P)
                center=controlled.centered_frobenius_upper(case['original_diagnostics']['pressure_frobenius_bound'],c,
                    case['original_diagnostics']['full_even_tensor_dimension'],memory_mb=mem)
                modes,_,_=controlled.parameters(10,20)
                require(np.allclose(modes.omega,case['harmonic_mode_data']['omega'],rtol=2e-12,atol=2e-14),'Harmonic modes changed')
                row=dict(label=case['label'],context=case['context'],archive=case['archive'],archive_sha256=case['archive_sha256'],
                    original_diagnostics=case['original_diagnostics'],eigensolve=eigen,removed_source_scalar=c,
                    centered_pressure_bound=center,
                    prior_width_replay=replay(case,E,Pc,modes),windows=[])
                out['cases'].append(row);save()
                row['beta_path_rates']=sensitivity(E,Pc,eigen)
                he,hp,harmonic_model=harmonic_rate_model(modes)
                row['harmonic_rate_model']=harmonic_model
                predictions={}
                for name in ('ordinary','increment'):
                    b=row['beta_path_rates']['baseline_strict_float_ties'][name]
                    h=harmonic_model['rates'][name]
                    predictions[name]={str(p):prediction(b,h,p) for p in ORDERS}
                row['supported_group_A_predictions']=predictions
                bblock=row['beta_path_rates']['ordinary_lowest_block'];hblock=harmonic_model['ordinary_lowest_block']
                if bblock['condition'] and hblock['condition']:
                    block_constant=(D(bblock['coefficients']['8']['decimal'])/D(hblock['coefficients']['8']['decimal'])).ln()-4*(D(bblock['coefficients']['2']['decimal'])/D(hblock['coefficients']['2']['decimal'])).ln()
                    row['ordinary_A8_lowest_block_prediction']=dict(
                        constant=float(block_constant),
                        tau_squared_slope=3*(bblock['delta']**2-hblock['delta']**2),
                        beta_delta=bblock['delta'],harmonic_delta=hblock['delta'],
                        scope='conditional ordinary theorem; floating source-support/eigenspace checks are not a rigorous physical certificate')
                save()
                for tau in NEW_TAUS:
                    for name,inc in [('ordinary',False),('increment',True)]:
                        m,a=controlled.evaluate(Pc,E,tau,inc,2.)
                        h,ha=controlled.harmonic(modes,tau,inc,2.)
                        shape={str(p):float((m[p]/h[p]).ln()-D(p)/2*(m[2]/h[2]).ln()) for p in (4,6,8)}
                        paths=controlled.returning_path_moment_bounds(center['centered_frobenius_upper'],tau,
                            case['original_diagnostics']['omitted_interacting_threshold_lower_bound'],increment=inc,
                            omitted_state_count=case['original_diagnostics']['full_even_tensor_dimension']-len(H),memory_mb=mem)
                        paths['log_relative_even_moment_bound']={str(p):float(D(str(paths['moments'][str(p)]['log_absolute_error_upper']))-m[p].ln()) for p in ORDERS}
                        paths['scope_of_application']='Conditional exact finite restriction/common exact ground; archived eigenpair/source and regulator errors remain separate'
                        prediction_check={}
                        for p in (4,6,8):
                            pr=predictions[name][str(p)]
                            if pr['status'].startswith('DIAGNOSTIC'):
                                predicted=pr['constant']+pr['tau_squared_slope']*tau*tau
                                prediction_check[str(p)]=dict(predicted_A=predicted,observed_A=shape[str(p)],difference=shape[str(p)]-predicted)
                        row['windows'].append(dict(tau=tau,observable=name,actual=a,declared_M_harmonic=ha,
                            log_shape_A=shape,supported_group_prediction_check=prediction_check,
                            conditional_omitted_path_bounds=paths,tau_Omega_min=tau*8.8/512))
                        if not a['spectral_reconstruction']['passed']:
                            out['warnings'].append(case['label']+' '+str(tau)+' '+name+': direct spectral weights unresolved')
                        save()
                # Only local secants in tau²; no log-time exponent fit.
                row['tau_squared_secants']=[]
                for name in ('ordinary','increment'):
                    prior=[w for w in case['windows'] if w['observable']==name]
                    new=[w for w in row['windows'] if w['observable']==name]
                    combined=sorted(prior+new,key=lambda w:w['tau'])
                    for a,b in zip(combined,combined[1:]):
                        row['tau_squared_secants'].append(dict(observable=name,tau_left=a['tau'],tau_right=b['tau'],
                            A_slope={str(p):(b['log_shape_A'][str(p)]-a['log_shape_A'][str(p)])/(b['tau']**2-a['tau']**2) for p in (4,6,8)},
                            raw_moment_decay_rate={str(p):-(b['actual']['moments'][str(p)]['log_abs']-a['actual']['moments'][str(p)]['log_abs'])/(b['tau']**2-a['tau']**2) for p in ORDERS}))
                require(sha(archive)==case['archive_sha256'],'Archive changed during diagnostic')
                row['status']='COMPLETED';save()
            out['status']='COMPLETED_WITH_WARNINGS';save()
        print('COMPLETED_WITH_WARNINGS finite-gap crossover diagnostic',flush=True)
    except BaseException as exc:
        out.update(status='FAILED',error=repr(exc));save();raise


if __name__=='__main__':main()
