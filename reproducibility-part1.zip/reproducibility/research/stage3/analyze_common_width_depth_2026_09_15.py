"""Analyze a COMPLETED R14 common-width archive and compare saved R10 Q16.

New output only; no Hamiltonian/basis construction or physical parameter change.
The frozen normalized-vacuum arithmetic and its executed controls are reused.
All-M harmonic means ordered quadratic algebra for the declared finite mode
count, not an infinite-mode certificate or the archived dressed H0/P0 proxy.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import hashlib
import json
import math
import sys
import time
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'research/stage3'),str(ROOT/'src'),str(ROOT/'research')]
import analyze_saved_common_widths_2026_09_15 as controlled

HELPER='research/stage3/analyze_saved_common_widths_2026_09_15.py'
HELPER_SHA256='bd8755753ece6786750691ad05306ac327135e3a11a7c81ca701bee565bad34b'
R10_INPUT='results/stage3_2026-09-15/saved_common_widths_R10.json'
TAUS=(144.8154687872,204.8,289.630937574)
EVEN=(2,4,6,8)
D=Decimal


def require(condition,message):
    if not condition:raise ValueError(message)


def local(name):
    path=(ROOT/name).resolve()
    require(path.is_relative_to(ROOT),'Inputs and outputs must be project-local')
    return path


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def close(a,b):return math.isclose(float(a),float(b),rel_tol=2e-12,abs_tol=2e-13)


def window(rows,observable,tau):
    matches=[w for w in rows if w['observable']==observable and close(w['tau'],tau)]
    require(len(matches)==1,'Missing or ambiguous saved comparator window')
    return matches[0]


def recorded_sources(data):
    result={}
    for name,expected in data.get('source_sha256',{}).items():
        path=local(name if '/' in name else 'research/stage3/'+name)
        actual=sha(path) if path.exists() else None
        result[name]=dict(executed_sha256=expected,current_path=str(path.relative_to(ROOT)),
                          current_sha256=actual,matches_current=actual==expected)
    return result


def scalar_comparison(new,old):
    result={}
    for n in range(2,9):
        a=D(new[str(n)]['decimal']);b=D(old[str(n)]['decimal'])
        result[str(n)]=dict(difference_R14_minus_R10=controlled.value(a-b),
            ratio_R14_over_R10=controlled.value(a/b) if b else None,
            ratio_status='defined' if b else 'undefined_zero_R10_denominator')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',required=True,help='Completed R14 physical tensor JSON')
    parser.add_argument('--output',required=True,help='New project-local JSON')
    args=parser.parse_args()
    source=local(args.input);destination=local(args.output);r10_path=local(R10_INPUT)
    require(destination.suffix=='.json','Output must be JSON')
    if destination.exists():raise FileExistsError(destination)
    require(sha(local(HELPER))==HELPER_SHA256,'Frozen controlled arithmetic helper changed')
    source_sha=sha(source);physical=json.loads(source.read_text())
    require(physical.get('status')=='COMPLETED','Only COMPLETED physical batches are accepted')
    candidates=[]
    for index,c in enumerate(physical.get('cases',[])):
        if c.get('R')==14 and c.get('M')==24 and c.get('Q')==10 and c.get('calibration_modes')==24:
            candidates.append((index,c))
    require(len(candidates)==1,'Expected one R14/M24/ref24/Q10 case')
    case_index,case=candidates[0]
    require(case.get('status')=='COMPLETED','Selected R14 case is not completed')
    require(case.get('coupling_family')=='equal_reference_phase','Wrong physical coupling family')
    require(close(case['tau'],204.8) and close(case.get('ratio',2.),2.),'Unexpected construction width or increment ratio')
    require(case.get('low_count')==5 and case.get('primitive')==32 and case.get('bath_top')==24,
            'Unexpected active-prefix, primitive or bath regulator')
    require(close(case.get('hard',.25),.5) and close(case.get('soft',0.),0.),'Unexpected adaptive basis weights')
    require(case.get('even_only') is True,'Expected physical-ground-certified even archive')
    beta_rows=[r for r in case.get('cosine',[]) if close(r['beta'],1.)]
    require(len(beta_rows)==1,'Expected one completed beta1 record')
    rec=beta_rows[0];diag=rec['diagnostics']
    require(diag.get('even_ground_certified_against_odd') is True,'Absent physical odd-sector ground certificate')
    for key in ('full_even_tensor_dimension','omitted_interacting_threshold_lower_bound','pressure_frobenius_bound'):
        require(key in diag,'Missing required original diagnostic: '+key)
    for tau in TAUS:
        require(sum(close(w['tau'],tau) for w in rec['windows'])==1,'Missing original R14 increment window')
    archive=local(rec['effective_archive']);archive_sha=sha(archive)
    r10_sha=sha(r10_path);r10=json.loads(r10_path.read_text())
    require(r10.get('status') in ('COMPLETED','COMPLETED_WITH_WARNINGS'),'R10 comparator did not complete')
    require(r10.get('new_arithmetic_controls',{}).get('status')=='PASS','Executed new arithmetic controls not PASS')
    require(r10['hbar']==1. and r10['ratio']==2. and r10['taus']==list(TAUS),'R10 comparison convention changed')
    verified={str(source.relative_to(ROOT)):source_sha,str(archive.relative_to(ROOT)):archive_sha,R10_INPUT:r10_sha}
    for name,expected in r10['source_sha256'].items():
        actual=sha(local(name));require(actual==expected,'Controlled source hash changed: '+name);verified[name]=actual
    control_records=[]
    for c in r10['controls']:
        actual=sha(local(c['path']));require(actual==c['sha256'],'Executed control record changed')
        record=json.loads(local(c['path']).read_text());require(record['status']=='PASS','Executed independent controls failed')
        verified[c['path']]=actual;control_records.append(dict(path=c['path'],sha256=actual,source_sha256=record.get('source_sha256',{})))
    comparators=[c for c in r10['cases'] if c['label']=='R10_Q16']
    require(len(comparators)==1,'Missing/ambiguous R10 Q16 comparator');comparison=comparators[0]
    require(comparison['status']=='COMPLETED' and comparison['beta']==1.,'Invalid R10 beta1 comparator')
    require(comparison['context']['R']==10 and comparison['context']['M']==20 and
            comparison['context']['Q']==16 and comparison['context']['calibration_modes']==24,'R10 regulator changed')
    # Verify both archive/input pairs: Q14--Q16 refinement is retained as evidence,
    # without rerunning either R10 eigensolve or its long-window calculations.
    for c in r10['cases']:
        for path_key,hash_key in [('input','input_sha256'),('archive','archive_sha256')]:
            actual=sha(local(c[path_key]));require(actual==c[hash_key],'R10 provenance mismatch');verified[c[path_key]]=actual
        control=c.get('saved_ordinary_control')
        if control:
            actual=sha(local(control['input']));require(actual==control['sha256'],'R10 ordinary control changed')
            verified[control['input']]=actual
    mem=controlled.memory_limit_mb()
    with zipfile.ZipFile(archive) as z:
        require(sum(i.file_size for i in z.infolist())<.35*mem*1024**2,'Archive load exceeds memory allowance')
    started=time.monotonic()
    out=dict(status='RUNNING',input=str(source.relative_to(ROOT)),input_sha256=source_sha,
        selected_case_index=case_index,archive=str(archive.relative_to(ROOT)),archive_sha256=archive_sha,
        comparator=R10_INPUT,comparator_sha256=r10_sha,verified_inputs_sha256=verified,
        source_sha256={str(Path(__file__).relative_to(ROOT)):sha(Path(__file__)),**r10['source_sha256']},
        original_physical_source_provenance=recorded_sources(physical),
        original_physical_batch_metadata={k:v for k,v in physical.items() if k!='cases'},
        original_case=case,original_diagnostics=diag,controls=control_records,
        inherited_executed_arithmetic_controls=r10['new_arithmetic_controls'],
        memory_mb=mem,hbar=1.,ratio=2.,taus=list(TAUS),windows=[],comparisons=[],
        saved_R10_Q14_to_Q16_refinements=r10['same_width_comparisons'],
        R10_original_diagnostics=comparison['original_diagnostics'],
        R10_eigensolve_diagnostics=comparison['eigensolve'],
        warnings=['R10 is outside its infrared interior; R14 is inside the nominal resonance band. This is not common-interior convergence.',
            'All-M harmonic reference uses original distributed H0, not the archived dressed H0/P0 or interacting Wick comparator.',
            'Conditional path bounds exclude approximate subspace, ground-state, pressure-source and physical regulator errors.'],
        completion_status_note='COMPLETED_WITH_WARNINGS is expected on success because physical-scope warnings are permanent; arithmetic exceptions produce FAILED')
    destination.parent.mkdir(parents=True,exist_ok=True)
    with destination.open('x') as f:json.dump(out,f,indent=2,allow_nan=False)
    def save():
        out['elapsed_seconds']=time.monotonic()-started
        temporary=destination.with_name(destination.name+'.writing')
        temporary.write_text(json.dumps(out,indent=2,allow_nan=False));temporary.replace(destination)
    try:
        with localcontext() as ctx:
            ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
            with np.load(archive,allow_pickle=False) as arrays:
                H=np.array(arrays['H']);P=np.array(arrays['P']);omega=np.array(arrays['omega'])
                reference=np.array(arrays['reference']);couplings=np.array(arrays['couplings'])
                sector=str(arrays['retained_sector'].item())
            require(H.shape==P.shape and len(H)>1,'Invalid saved H/P dimensions')
            require(640*len(H)**2<.6*mem*1024**2,'Dense arithmetic workspace exceeds allowance')
            require('even' in sector.lower(),'Archive is not declared even sector')
            require(diag['full_even_tensor_dimension']>=len(H),'Full finite-sector dimension is inconsistent')
            require(np.allclose(reference,case['reference_variances'],rtol=2e-12,atol=2e-14),'Archive reference differs from physical case')
            require(np.allclose(couplings,case['couplings'],rtol=2e-12,atol=2e-14),'Archive couplings differ from physical case')
            modes,poles,_=controlled.parameters(14,24,case.get('G',-1e-7),case.get('s',0.))
            require(modes.p.hbar==1.,'Unexpected hbar')
            require(np.allclose(modes.omega,omega,rtol=2e-12,atol=2e-14),'Regenerated all-M frequencies differ from archive')
            calibration=np.sum(modes.branch**2/(2*modes.omega)[None,:],axis=1)
            require(np.allclose(reference,calibration,rtol=2e-11,atol=2e-14),'Fixed M_ref24 calibration mismatch')
            require(np.allclose(couplings,-np.array(modes.p.KJ)/reference,rtol=2e-11,atol=2e-14),'Equal-reference-phase coupling mismatch')
            E,Pc,c,eigen=controlled.eigen_prepare(H,P)
            centered=controlled.centered_frobenius_upper(diag['pressure_frobenius_bound'],c,
                diag['full_even_tensor_dimension'],memory_mb=mem)
            out.update(dimension=len(H),retained_sector=sector,eigensolve=eigen,
                retained_excitation_energies=E.tolist(),removed_scalar_in_supplied_pressure=c,
                mean_scope='actual-ground centering of supplied P; no calibrated Casimir mean inferred',
                centered_pressure_bound=centered,harmonic_mode_data=dict(omega=modes.omega.tolist(),
                    endpoint=modes.endpoint.tolist(),slope=modes.slope.tolist(),branch=modes.branch.tolist()),
                calibration_variances=reference.tolist(),couplings=couplings.tolist(),
                reference_scope='original distributed harmonic H0; ordered quadratic algebra at all M=24 modes, no infinite-mode claim')
            save()
            # Compute increment rows first and replay every original even moment.
            # Only accepted replays are used in the completed new window panel.
            increment_cache={};replays=[]
            for tau in TAUS:
                m,actual=controlled.evaluate(Pc,E,tau,True,2.)
                old=next(w for w in rec['windows'] if close(w['tau'],tau))
                errors={str(p):float(abs(m[p]/D.from_float(float(old['moments'][str(p)]))-1)) for p in EVEN}
                require(max(errors.values())<=2e-8,'R14 original increment replay failed at tau='+str(tau))
                increment_cache[tau]=(m,actual)
                replays.append(dict(tau=tau,relative_even_moment_errors=errors,
                    max_relative_even_moment_error=max(errors.values()),tolerance=2e-8,
                    positive_moment_checks=actual['positive_moment_checks'],spectral_reconstruction=actual['spectral_reconstruction']))
            out['original_R14_increment_replay']=dict(status='PASS',windows=replays);save()
            for tau in TAUS:
                for observable,inc in [('ordinary',False),('increment',True)]:
                    if inc:m,actual=increment_cache[tau]
                    else:m,actual=controlled.evaluate(Pc,E,tau,False,2.)
                    h,harmonic=controlled.harmonic(modes,tau,inc,2.)
                    harmonic_replay=None
                    if inc:
                        original_refs=[v for key,v in case['harmonic'].items() if close(key,tau)]
                        require(len(original_refs)==1,'Missing original all-M harmonic increment reference')
                        harmonic_errors={str(p):float(abs(h[p]/D.from_float(float(original_refs[0][str(p)]))-1)) for p in EVEN}
                        require(max(harmonic_errors.values())<=2e-8,'Original all-M harmonic increment replay failed')
                        harmonic_replay=dict(status='PASS',relative_even_moment_errors=harmonic_errors,tolerance=2e-8)
                    shape={str(p):float((m[p]/h[p]).ln()-D(p)/2*(m[2]/h[2]).ln()) for p in (4,6,8)}
                    paths=controlled.returning_path_moment_bounds(centered['centered_frobenius_upper'],tau,
                        diag['omitted_interacting_threshold_lower_bound'],increment=inc,ratio=2.,
                        omitted_state_count=diag['full_even_tensor_dimension']-len(H),memory_mb=mem)
                    relative={str(p):(float(D(str(paths['moments'][str(p)]['log_absolute_error_upper']))-m[p].ln())
                        if not paths['moments'][str(p)]['exact_zero'] else None) for p in EVEN}
                    paths.update(log_relative_even_moment_bound=relative,
                        application_status='CONDITIONAL: exact finite spectral restriction with common exact ground; archived eigenpair/source and regulator errors excluded')
                    infrared=float(tau*min(poles));ultraviolet=float(tau*max(poles))
                    require(0<infrared<1<ultraviolet,'R14 window is not inside the nominal resonance band')
                    row=dict(tau=tau,observable=observable,actual=actual,
                        declared_all_M_original_harmonic=harmonic,log_shape_A=shape,
                        original_all_M_harmonic_increment_replay=harmonic_replay,
                        conditional_centered_path_bounds=paths,tau_Omega_min=infrared,
                        tau_Omega_max=ultraviolet,tau_lowest_harmonic_frequency=float(tau*omega[0]),
                        tau_first_even_gap=float(tau*E[1]),
                        roundoff_gap_filter_diagnostic=float(2*tau*tau*max(E)*eigen['eigensolve_residual_frobenius']))
                    old=window(comparison['windows'],observable,tau)
                    require(old['tau_nominal_Omega_min']>1,'Expected R10 outside its infrared interior')
                    contrast=dict(tau=tau,observable=observable,R10_label='R10_Q16',R14_label='R14_Q10',
                        raw_moments=scalar_comparison(actual['moments'],old['actual']['moments']),
                        cumulants=scalar_comparison(actual['cumulants'],old['actual']['cumulants']),
                        standardized_cumulants=scalar_comparison(actual['standardized_cumulants'],old['actual']['standardized_cumulants']),
                        log_shape_A_R10=old['log_shape_A'],log_shape_A_R14=shape,
                        delta_log_shape_A_R14_minus_R10={str(p):shape[str(p)]-old['log_shape_A'][str(p)] for p in (4,6,8)},
                        tau_Omega_min_R10=old['tau_nominal_Omega_min'],tau_Omega_min_R14=infrared,
                        R10_spectral_reconstruction=old['actual']['spectral_reconstruction'],
                        R14_spectral_reconstruction=actual['spectral_reconstruction'],
                        interpretation='fixed-absolute-window cutoff/depth sensitivity; R10 and R14 do not share a common infrared interior',
                        reference_scope='each depth uses its own original all-M harmonic H0; the contrast includes two-point response changes')
                    out['windows'].append(row);out['comparisons'].append(contrast)
                    if not actual['spectral_reconstruction']['passed']:
                        out['warnings'].append('R14 '+str(tau)+' '+observable+': direct spectral reconstruction unresolved; normalized recurrence retained with its gates')
                    if not old['actual']['spectral_reconstruction']['passed']:
                        out['warnings'].append('R10 comparator '+str(tau)+' '+observable+': previously unresolved direct spectral reconstruction')
                    save()
            require(sha(source)==source_sha and sha(archive)==archive_sha and sha(r10_path)==r10_sha,'An input changed during analysis')
            out['status']='COMPLETED_WITH_WARNINGS';save()
        print('COMPLETED_WITH_WARNINGS R14/R10 saved-matrix common-width analysis',flush=True)
    except BaseException as exc:
        out.update(status='FAILED',error=repr(exc));save();raise


if __name__=='__main__':main()
