"""Conditional finite-spectrum pressure-path and cumulant error bounds.

The spectral projector and ground state in the path lemma are exact for ONE
finite H/P. Pc=P-<0|P|0>I is formed in that same source convention. Approximate
Ritz, ground-state, source, tensor-factor and mode errors are separate. Ordinary
Gaussian averages and increments both obey the stated returning-path bound.
"""
from __future__ import annotations

from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING
import math
import os
import numpy as np


def memory_limit_mb(memory_mb=None):
    value=float(os.environ['PYSCF_MAX_MEMORY'] if memory_mb is None else memory_mb)
    if not np.isfinite(value) or value<=0:
        raise ValueError('A positive finite PYSCF_MAX_MEMORY allowance is required')
    return value


def _finite_nonnegative(value,label):
    value=float(value)
    if not np.isfinite(value) or value<0:raise ValueError(label+' must be finite and nonnegative')
    return value


def _decimal(value):return Decimal.from_float(float(value))


def _float_upper(value):
    """Convert a positive Decimal upper bound upward into binary64."""
    result=float(value)
    if math.isinf(result):return None
    if Decimal.from_float(result)<value:result=float(np.nextafter(result,np.inf))
    return result


def centered_frobenius_upper(pressure_frobenius_upper,exact_ground_mean,
                             full_dimension,memory_mb=None):
    """||P-c I||_F <= PF + |c| sqrt(D), conditional on supplied PF and exact c.

    D is the COMPLETE finite-model dimension, not the retained Ritz dimension.
    c must refer to the same scalar convention as the source bounded by PF.
    """
    memory_limit_mb(memory_mb)
    pf=_finite_nonnegative(pressure_frobenius_upper,'pressure_frobenius_upper')
    c=float(exact_ground_mean)
    if not np.isfinite(c):raise ValueError('The declared exact ground mean must be finite')
    if not isinstance(full_dimension,(int,np.integer)) or full_dimension<1:
        raise ValueError('full_dimension must be a positive integer')
    with localcontext() as ctx:
        ctx.prec=80;ctx.rounding=ROUND_CEILING
        root=ctx.sqrt(Decimal(int(full_dimension))).next_plus()
        upper=_decimal(pf)+abs(_decimal(c))*root
        answer=_float_upper(upper)
    return dict(centered_frobenius_upper=answer,pressure_frobenius_upper=pf,
        exact_ground_mean_in_same_source=c,full_dimension=int(full_dimension),
        scope='conditional triangle bound for the same complete finite source and its exact ground mean')


def returning_path_moment_bounds(centered_pressure_frobenius_upper,tau,
        omitted_energy_lower_bound,order=8,hbar=1.,increment=False,ratio=2.,
        omitted_state_count=None,memory_mb=None):
    """Absolute errors in ALL centered raw moments, including odd orders.

    Every omitted E-E0 must be >= Lambda. Lambda=0 explicitly requests the
    unfiltered norm bound. If no states are omitted, supply count=0. For p>=2:
      |m_p-full - m_p-ret| <= ||Pc||_F^p exp[-2(tau Lambda/hbar)^2/p].
    The first centered moment agrees exactly. No population estimate is used.
    """
    memory_limit_mb(memory_mb)
    norm=_finite_nonnegative(centered_pressure_frobenius_upper,'centered norm upper bound')
    tau=_finite_nonnegative(tau,'tau');lam=_finite_nonnegative(omitted_energy_lower_bound,'Lambda')
    if not np.isfinite(hbar) or hbar<=0:raise ValueError('hbar must be finite and positive')
    if not np.isfinite(ratio) or ratio<1:raise ValueError('ratio must be finite and >=1')
    if not isinstance(order,(int,np.integer)) or not 2<=order<=8:
        raise ValueError('order must be an integer from 2 through 8')
    if omitted_state_count is not None and (not isinstance(omitted_state_count,(int,np.integer)) or omitted_state_count<0):
        raise ValueError('Omitted-state count, when supplied, must be a nonnegative integer')
    zero=norm==0 or omitted_state_count==0 or (increment and (tau==0 or ratio==1))
    rows={'1':dict(absolute_error_upper=0.,log_absolute_error_upper=None,exact_zero=True)}
    # Decimal arithmetic encloses damping conservatively. exp/sqrt are correctly
    # rounded nearest by Decimal; next_plus encloses their exact values above.
    with localcontext() as ctx:
        ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
        ctx.rounding=ROUND_FLOOR
        q=_decimal(tau)*_decimal(lam)/_decimal(hbar)
        q2=q*q
        ctx.rounding=ROUND_CEILING
        for p in range(2,order+1):
            if zero:
                rows[str(p)]=dict(absolute_error_upper=0.,log_absolute_error_upper=None,exact_zero=True)
                continue
            exponent=-Decimal(2)*q2/Decimal(p)
            exponential=ctx.exp(exponent).next_plus()
            upper=(_decimal(norm)**p)*exponential
            rows[str(p)]=dict(absolute_error_upper=_float_upper(upper),
                log_absolute_error_upper=float(ctx.ln(upper)),exact_zero=False)
    return dict(centered_pressure_frobenius_upper=norm,tau=tau,
        omitted_energy_lower_bound=lam,hbar=float(hbar),order=int(order),
        increment=bool(increment),ratio=float(ratio) if increment else None,
        omitted_state_count=omitted_state_count,moments=rows,
        scope='exact spectral restriction of one finite H/P with its common exact ground state',
        excluded_errors=['Ritz eigenvalue/eigenvector errors','ground-state error',
                         'source-projection error','tensor-factor truncation','primitive and line-mode truncation'],
        arithmetic='80-digit outward Decimal path upper bounds, then upward binary64 conversion')


def _down(value):return float(np.nextafter(float(value),-np.inf))
def _up(value):return float(np.nextafter(float(value),np.inf))


def _add(a,b):
    if a==(0.,0.):return b
    if b==(0.,0.):return a
    return _down(a[0]+b[0]),_up(a[1]+b[1])


def _multiply(a,b):
    if a==(0.,0.) or b==(0.,0.):return (0.,0.)
    if a==(1.,1.):return b
    if b==(1.,1.):return a
    products=[x*y for x in a for y in b]
    if not all(np.isfinite(products)):raise FloatingPointError('Cumulant interval multiplication overflowed')
    return _down(min(products)),_up(max(products))


def _subtract(a,b):return _add(a,(-b[1],-b[0]))


def cumulant_intervals(moments,absolute_moment_errors,order=8,centered=True,
                        positive_even_moments=True,memory_mb=None):
    """Propagate independent enclosing moment intervals through kappa2..8.

    Errors for EVERY raw moment 1..order are required; missing odd moments
    are rejected. Dependencies between moments are not assumed, making this
    conservative. Input error budgets may include independently proved graph,
    state, or source errors, but this routine does not establish those budgets.
    """
    memory_limit_mb(memory_mb)
    if not isinstance(order,(int,np.integer)) or not 2<=order<=8:
        raise ValueError('order must be an integer from 2 through 8')
    needed=[str(p) for p in range(1,order+1)]
    if any(k not in moments or k not in absolute_moment_errors for k in needed):
        raise ValueError('Moments and errors for every odd/even order 1..order are required')
    m=[1.];intervals=[(1.,1.)]
    for p in range(1,order+1):
        value=float(moments[str(p)])
        error=_finite_nonnegative(absolute_moment_errors[str(p)],'moment error '+str(p))
        if not np.isfinite(value):raise ValueError('Moments must be finite')
        if centered and p==1 and (value!=0 or error!=0):
            raise ValueError('Exact centering requires m1=0 and its error=0; otherwise use centered=False')
        band=(value,value) if error==0 else (_down(value-error),_up(value+error))
        if positive_even_moments and p%2==0:
            if band[1]<0:raise ValueError('An even spectral moment cannot have a wholly negative interval')
            band=(max(0.,band[0]),band[1])
        if not all(np.isfinite(band)):raise FloatingPointError('Moment interval overflowed')
        m.append(value);intervals.append(band)
    k=[0.];bands=[(0.,0.)];rows={}
    for n in range(1,order+1):
        nominal=math.fsum([m[n]]+[-math.comb(n-1,j-1)*k[j]*m[n-j] for j in range(1,n)])
        current=intervals[n]
        for j in range(1,n):
            coefficient=float(math.comb(n-1,j-1))
            term=_multiply((coefficient,coefficient),_multiply(bands[j],intervals[n-j]))
            current=_subtract(current,term)
        if not np.isfinite(nominal) or not all(np.isfinite(current)):
            raise FloatingPointError('Cumulant interval overflowed')
        k.append(nominal);bands.append(current)
        delta=max(abs(current[0]-nominal),abs(current[1]-nominal))
        rows[str(n)]=dict(nominal_cumulant=nominal,lower=current[0],upper=current[1],
                         absolute_error_upper=_up(delta) if delta else 0.)
    return dict(order=int(order),centered=bool(centered),
        raw_moment_intervals={str(p):list(intervals[p]) for p in range(1,order+1)},
        cumulants=rows,
        scope='conditional raw-moment intervals propagated through the spectral cumulant recurrence',
        arithmetic='outward binary64 addition/multiplication intervals; no independence or even-only inference')


def cumulants_with_path_error(retained_moments,centered_pressure_frobenius_upper,
        tau,omitted_energy_lower_bound,order=8,hbar=1.,increment=False,ratio=2.,
        omitted_state_count=None,memory_mb=None):
    """Combine ONLY the exact finite-model path error with cumulant intervals."""
    paths=returning_path_moment_bounds(centered_pressure_frobenius_upper,tau,
        omitted_energy_lower_bound,order,hbar,increment,ratio,omitted_state_count,memory_mb)
    if any(row['absolute_error_upper'] is None for row in paths['moments'].values()):
        raise OverflowError('A raw-moment upper bound exceeds binary64; rescale the pressure before interval propagation')
    propagated=cumulant_intervals(retained_moments,
        {p:row['absolute_error_upper'] for p,row in paths['moments'].items()},
        order=order,centered=True,memory_mb=memory_mb)
    return dict(path_bounds=paths,cumulant_bounds=propagated,
                scope='path omission only; no automatic certificate for approximate archived H/P')
