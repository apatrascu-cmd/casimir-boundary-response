"""Full-cosine low/bath tensor representation and invariant-graph solver.

Each bath configuration accompanies every active configuration. Tensor and
primitive cutoffs remain numerical approximations and are refined separately.
"""
from pathlib import Path
import sys, numpy as np
from scipy.linalg import eigh
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research/stage3'))
from dressed_cosine_hierarchy import mean_field,assemble,difference_structure,one_body

def group_operator(states,local,indices,coeff,kind):
    # First-degree operators have zero diagonal by parity, and connect one modal.
    structure=difference_structure(states);_,first,_,(rr,cc),_=structure
    j=first[rr,cc];O=np.zeros((len(states),len(states)),complex)
    O[rr,cc]=coeff[j]*local[kind][j,states[rr,j],states[cc,j]]
    return O

def characteristic(states,local,r,indices):
    n=len(states);S0=np.ones((n,n),complex);S1=np.zeros_like(S0);S2=np.zeros_like(S0)
    for j in indices:
        occ=states[:,j];same=occ[:,None]==occ[None,:];mat=local['D'][r][j];dc=mat[0,0].real
        delta=mat[occ[:,None],occ[None,:]]-dc*same;ref=(1+dc)*same
        S2=S2*(ref+delta)+S1*delta;S1=S1*ref+S0*delta;S0*=ref
    delta=S1+S2
    return delta.real,delta.imag

def tensor_model(modes,u,beta,low_states,bath_states,low_indices,primitive_size=24,reference=None,memory_mb=4096):
    M=len(modes.omega);low_indices=list(low_indices);bath_indices=[j for j in range(M) if j not in low_indices]
    local=mean_field(modes,u,beta,primitive_size,reference)
    HL,PL=assemble(modes,low_states,local,memory_mb);HB,PB=assemble(modes,bath_states,local,memory_mb)
    ht=[];pt=[]
    for r,kj in enumerate(modes.p.KJ):
        t2=local['theta2'][r];theta=np.sqrt(t2);v=local['reference'][r]
        CL,SL=characteristic(low_states,local,r,low_indices);CB,SB=characteristic(bath_states,local,r,bath_indices)
        qL=group_operator(low_states,local,low_indices,local['c'][r],'X').real
        qB=group_operator(bath_states,local,bath_indices,local['c'][r],'X').real
        rL=SL-theta*qL;rB=SB-theta*qB
        ht.extend([(CL,-kj/t2*CB),(rL,kj/t2*rB),(qL,kj/theta*rB),(rL,kj/theta*qB),(qL,kj*t2*v/2*qB)])
    d=modes.slope*np.sqrt(modes.p.hbar/(2*modes.omega));z=modes.endpoint*np.sqrt(modes.p.hbar*modes.omega/2)
    pt.append((group_operator(low_states,local,low_indices,d,'X').real,group_operator(bath_states,local,bath_indices,d,'X').real/modes.p.L0))
    pt.append((group_operator(low_states,local,low_indices,z,'Y').imag,-modes.p.C0*group_operator(bath_states,local,bath_indices,z,'Y').imag))
    return dict(HL=HL,HB=HB,PL=PL,PB=PB,hterms=ht,pterms=pt,local=local,low_states=low_states,bath_states=bath_states)

def full_tensor(model,pressure=False):
    L=model['PL'] if pressure else model['HL'];B=model['PB'] if pressure else model['HB'];terms=model['pterms'] if pressure else model['hterms']
    H=np.kron(np.eye(len(B)),L)+np.kron(B,np.eye(len(L)))
    for a,b in terms:H+=np.kron(b,a)
    return (H+H.T)/2

def operator_norm_bound(a):
    # Both bounds are certified upper bounds, and avoid repeated dense SVDs.
    return min(float(np.linalg.norm(a)),float(np.sqrt(np.max(np.sum(abs(a),axis=0))*np.max(np.sum(abs(a),axis=1)))))

def compress_terms(terms,tolerance=2e-15):
    # Orthogonal factorization only; residual norm is reported explicitly.
    nl=terms[0][0].shape[0];nb=terms[0][1].shape[0]
    A=np.stack([a.ravel() for a,b in terms],axis=1);B=np.stack([b.ravel() for a,b in terms],axis=1)
    qa,ra=np.linalg.qr(A,mode='reduced');qb,rb=np.linalg.qr(B,mode='reduced')
    u,s,v=np.linalg.svd(ra@rb.T,full_matrices=False);keep=s>tolerance*s[0]
    new=[((qa@u[:,j]).reshape(nl,nl)*np.sqrt(s[j]),(qb@v[j]).reshape(nb,nb)*np.sqrt(s[j])) for j in np.flatnonzero(keep)]
    return new,{'rank':len(new),'original_terms':len(terms),'discarded_frobenius_bound':float(np.sum(s[~keep])),'largest_singular_value':float(s[0])}

def invariant_graph(model,tolerance=2e-14,max_iterations=80,damping=1.,compress=True):
    Eb,UB=eigh(model['HB'],check_finite=False);Eb-=Eb[0]
    terms=[(a,UB.T@b@UB) for a,b in model['hterms']]
    A=model['HL'].copy()
    for a,b in terms:A+=b[0,0]*a
    Ea,UA=eigh(A,check_finite=False);Ea-=Ea[0]
    ts=[(UA.T@a@UA,b-b[0,0]*np.eye(len(b))) for a,b in terms]
    compression=None
    if compress:ts,compression=compress_terms(ts)
    nl=len(Ea);nb=len(Eb);den=Eb[1:,None,None]+Ea[None,:,None]-Ea[None,None,:]
    if den.min()<=0:raise ArithmeticError('bath gap overlaps retained low spectral window')
    B=np.zeros((nb-1,nl,nl))
    for a,b in ts:B+=b[1:,0,None,None]*a
    Om=-B/den;history=[]
    def off_apply(W):
        Y=np.zeros_like(W)
        for a,b in ts:
            T=np.matmul(a,W);Y+=(b[1:,1:]@T.reshape(nb-1,-1)).reshape(W.shape)
        return Y
    def coupling_back(W):return np.einsum('bij,bik->jk',B,W,optimize=True)
    for it in range(max_iterations):
        F=coupling_back(Om);res=B+den*Om+off_apply(Om)-np.matmul(Om,F)
        size=float(np.linalg.norm(res));history.append(size)
        if size<tolerance:break
        Om-=damping*res/den
        if not np.isfinite(Om).all() or np.linalg.norm(Om)>2:raise ArithmeticError('graph iteration outside admitted neighborhood')
    else:raise ArithmeticError('invariant graph failed to converge')
    S=np.eye(nl)+np.einsum('bij,bik->jk',Om,Om,optimize=True);se,su=eigh(S,check_finite=False);Sinv=(su/np.sqrt(se))@su.T
    graph_norm=float(np.linalg.norm(Om))
    W=np.empty((nb,nl,nl));W[0]=Sinv;W[1:]=Om@Sinv
    del Om,B,den,res,F
    # H in the transformed coordinates; ground scalar shifts cancel in gaps.
    HW=Ea[None,:,None]*W+Eb[:,None,None]*W
    for a,b in ts:HW+=(b@np.matmul(a,W).reshape(nb,-1)).reshape(W.shape)
    Heff=np.einsum('bij,bik->jk',W,HW,optimize=True);Heff=(Heff+Heff.T)/2
    HW-=np.matmul(W,Heff);invariant_residual=float(np.linalg.norm(HW));del HW
    # Exact transformed P matrix elements in the invariant low subspace.
    pl=UA.T@model['PL']@UA;pb=UB.T@model['PB']@UB
    PW=np.matmul(pl,W)+(pb@W.reshape(nb,-1)).reshape(W.shape)
    for a,b in model['pterms']:PW+=((UB.T@b@UB)@np.matmul(UA.T@a@UA,W).reshape(nb,-1)).reshape(W.shape)
    Peff=np.einsum('bij,bik->jk',W,PW,optimize=True);Peff=(Peff+Peff.T)/2
    PW-=np.matmul(W,Peff);low_high_source_norm=float(np.linalg.norm(PW));del PW
    # Weyl lower bound: first omitted eigenvalue >= Eb_min minus total cross operator norm.
    interaction_bound=sum(float(operator_norm_bound(a)*operator_norm_bound(b)) for a,b in ts)
    eig=eigh(Heff,eigvals_only=True,check_finite=False)
    compression_bound=0. if compression is None else compression['discarded_frobenius_bound']
    residual_bound=invariant_residual+compression_bound
    threshold=float(Eb[1]-interaction_bound-compression_bound-eig[0]-residual_bound)
    cluster_margin=float(threshold-(eig[-1]-eig[0])-2*residual_bound)
    if cluster_margin<=0:raise ArithmeticError('lowest retained cluster is not certified by the spectral separation bound')
    pressure_bound=float(operator_norm_bound(model['PL'])+operator_norm_bound(model['PB'])+sum(operator_norm_bound(a)*operator_norm_bound(b) for a,b in model['pterms']))
    # Frobenius is a safe entrywise-absolute operator-norm bound for path sums.
    pressure_frobenius_bound=pressure_bound*np.sqrt(nl*nb)
    pfactors=[(model['PL'],np.eye(nb)),(np.eye(nl),model['PB'])]+model['pterms']
    fterms=[float(np.sum(a*c)*np.sum(b*d)) for a,b in pfactors for c,d in pfactors]
    exact_frobenius=np.sqrt(max(0.,sum(fterms)))
    # Rounding allowance for the finite tensor Gram sum.
    gram_roundoff=64*np.finfo(float).eps*sum(abs(x) for x in fterms)
    pressure_frobenius_bound=min(pressure_frobenius_bound,float(np.sqrt(max(0.,sum(fterms))+gram_roundoff)))
    return Heff,Peff,{'iterations':len(history),'riccati_residual_history':history,'invariant_residual_frobenius':invariant_residual,'original_hamiltonian_residual_bound':residual_bound,'retained_cluster_certification_margin':cluster_margin,'orthogonality_error':float(np.linalg.norm(np.einsum('bij,bik->jk',W,W)-np.eye(nl))),'bare_separation':float(Eb[1]-np.ptp(Ea)),'interaction_norm_bound':interaction_bound,'norm_bound_method':'minimum Frobenius and induced 1/infinity bounds','omitted_interacting_threshold_lower_bound':threshold,'pressure_frobenius_bound':pressure_frobenius_bound,'pressure_frobenius_from_tensor_gram':float(exact_frobenius),'low_high_source_frobenius':low_high_source_norm,'graph_norm':graph_norm,'compression':compression,'low_dimension':nl,'bath_dimension':nb}
