"""Build one manuscript table from executed saved-matrix common-width data.

Pure saved-data audit/formatting: no matrix diagonalization or physical launch.
Prepared for central execution; output and provenance refuse replacement.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import hashlib
import json
import math
import os

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_INPUT = 'results/stage3_2026-09-15/saved_common_widths_R10.json'
TARGET = 'paper/stage3_common_width_results.tex'
PROVENANCE = 'paper/stage3_common_width_provenance.json'
D = Decimal
TAUS = (144.8154687872, 204.8, 289.630937574)


def local(name):
    p = (ROOT/name).resolve()
    if not p.is_relative_to(ROOT): raise ValueError('Project-local paths required')
    return p


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''): h.update(block)
    return h.hexdigest()


def require(condition, message):
    if not condition: raise ValueError(message)


def series(row, key='moments'):
    return {int(n):D(v['decimal']) for n,v in row[key].items()}


def formal_log(m):
    """Independent scalar formal-log check, not the executed cumulant recurrence."""
    u=[D(0)]+[m[n]/D(math.factorial(n)) for n in range(1,9)]
    power=[D(1)]+[D(0)]*8; result=[D(0)]*9
    for j in range(1,9):
        power=[sum((power[k]*u[n-k] for k in range(n+1)),D(0)) for n in range(9)]
        result=[v+D((-1)**(j+1))*power[n]/D(j) for n,v in enumerate(result)]
    return {n:D(math.factorial(n))*result[n] for n in range(2,9)}


def win(case, observable, tau):
    rows=[w for w in case['windows'] if w['observable']==observable and
          math.isclose(w['tau'],tau,rel_tol=1e-13,abs_tol=0)]
    require(len(rows)==1,'Expected one window')
    return rows[0]


def shape(w, n=8):
    m=series(w['actual']); h=series(w['exact_declared_M_harmonic'])
    return (m[n]/h[n]).ln()-D(n)/2*(m[2]/h[2]).ln()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',default=DEFAULT_INPUT)
    parser.add_argument('--replace',action='store_true',help='Explicitly regenerate owned derived artifacts')
    args=parser.parse_args()
    memory=float(os.environ['PYSCF_MAX_MEMORY'])
    require(math.isfinite(memory) and memory>=64,'Declare at least 64 MB for saved-data formatting')
    source=local(args.input); target=local(TARGET); provenance=local(PROVENANCE)
    if (target.exists() or provenance.exists()) and not args.replace: raise FileExistsError('Common-width manuscript artifacts already exist')
    data=json.loads(source.read_text())
    require(data.get('status') in ('COMPLETED','COMPLETED_WITH_WARNINGS'),'Analysis did not complete')
    require(data.get('new_arithmetic_controls',{}).get('status')=='PASS','New arithmetic controls not PASS')
    require(data['ratio']==2. and data['hbar']==1.,'Unexpected filter or units')
    require(data['taus']==list(TAUS),'Unexpected widths')
    inputs={str(source.relative_to(ROOT)):sha(source)}; archives={}; executed_sources={}
    def verify(name, expected):
        actual=sha(local(name));require(actual==expected,'Provenance hash mismatch: '+name)
        inputs[name]=actual
    for name, expected in data['source_sha256'].items(): verify(name,expected)
    for c in data['controls']: verify(c['path'],c['sha256'])
    cases={c['label']:c for c in data['cases']}
    require(set(cases)=={'R10_Q14','R10_Q16'},'This fragment requires the bounded R10-only result')
    audit={'formal_log_max_scaled_error':0.,'A_max_absolute_error':0.,
           'path_log_max_absolute_error':0.,'all_actual_even_moments_positive':True,
           'all_centered_ground_diagonals_zero':True,'all_increment_diagonals_zero':True,
           'matrix_diagonalizations_performed_by_this_generator':0}
    spectral=[]; underflow=[]; rows=[]
    with localcontext() as ctx:
        ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
        for label,case in cases.items():
            require(case['status']=='COMPLETED' and case['beta']==1.,'Incomplete/non-beta1 case')
            expected={'R':10,'M':20,'Q':14 if label=='R10_Q14' else 16,'tau':51.2,
                      'primitive':32,'low_count':5,'bath_top':24,'calibration_modes':24}
            require(case['context']==expected,'Unexpected physical or regulator parameters')
            require(case['original_diagnostics']['even_ground_certified_against_odd'],'Uncertified parity ground')
            verify(case['input'],case['input_sha256']);verify(case['archive'],case['archive_sha256'])
            archives[case['archive']]=case['archive_sha256']
            original=json.loads(local(case['input']).read_text())
            require(original['status']=='COMPLETED','Upstream physical batch incomplete')
            executed_sources[case['input']]=original.get('source_sha256',{})
            control=case['saved_ordinary_control'];verify(control['input'],control['sha256'])
            require(control['max_scaled_error']<=2e-8 and
                    case['saved_width_control']['max_relative_even_error']<=2e-8,'Saved moderate-width control failed')
            for w in case['windows']:
                require(w['tau'] in TAUS,'Unexpected saved width')
                actual=w['actual']; require(actual['positive_moment_checks']['passed'],'Positive moment check failed')
                f=actual['filter_arithmetic'];require(f['actual_ground_diagonal']==0.,'Residual ground diagonal')
                if w['observable']=='increment':require(f['diagonal_exactly_zero'],'Nonzero increment diagonal')
                for which in ('actual','exact_declared_M_harmonic'):
                    a=w[which];m=series(a); k=series(a,'cumulants')
                    require(m[1]==0 and all(m[n]>0 for n in (2,4,6,8)),'Nonpositive or uncentered raw moments')
                    reconstructed=formal_log(m)
                    for n in range(2,9):
                        err=float(abs(reconstructed[n]-k[n])/max(abs(k[n]),m[2].sqrt()**n))
                        audit['formal_log_max_scaled_error']=max(audit['formal_log_max_scaled_error'],err)
                        require(err<1e-60,'Scalar cumulant identity mismatch')
                for n in (4,6,8):
                    err=abs(float(shape(w,n))-w['log_shape_A'][str(n)])
                    audit['A_max_absolute_error']=max(audit['A_max_absolute_error'],err)
                    require(err<1e-11,'Shape does not match stored raw moments/reference')
                for n in (2,4,6,8):
                    norm=D.from_float(case['centered_pressure_bound']['centered_frobenius_upper'])
                    tau=D.from_float(w['tau']);lam=D.from_float(case['original_diagnostics']['omitted_interacting_threshold_lower_bound'])
                    expected_path=D(n)*norm.ln()-2*(tau*lam)**2/D(n)-series(actual)[n].ln()
                    err=abs(float(expected_path)-w['conditional_omitted_path_bounds']['log_relative_even_moment_bound'][str(n)])
                    audit['path_log_max_absolute_error']=max(audit['path_log_max_absolute_error'],err)
                    require(err<1e-8,'Conditional path log mismatch')
                spectral.append(dict(case=label,tau=w['tau'],observable=w['observable'],
                                     **actual['spectral_reconstruction']))
                underflow.append(dict(case=label,tau=w['tau'],observable=w['observable'],
                    moment_status={n:v['binary64_status'] for n,v in actual['moments'].items()},
                    filter=f,filter_deletion_log_relative_even_bounds=actual['filter_deletion_log_relative_even_bounds']))
        high=cases['R10_Q16'];low=cases['R10_Q14']
        for tau in TAUS:
            ordinary=win(high,'ordinary',tau);increment=win(high,'increment',tau);lo=win(low,'increment',tau)
            drift=series(increment['actual'])[8]/series(lo['actual'])[8]-1
            variance_difference=float(abs(series(ordinary['actual'])[2]/series(increment['actual'])[2]-1))
            require(variance_difference<1e-12,'Ordinary/increment variances no longer agree at displayed precision')
            record=next(c for c in data['same_width_comparisons'] if c['observable']=='increment' and c['tau']==tau)
            require(abs(float((1+drift).ln())-record['log_moment_ratio_right_over_left']['8'])<2e-12,'Refinement record mismatch')
            rows.append(dict(tau=tau,tau_Omega_min=increment['tau_nominal_Omega_min'],
                A8_ordinary=float(shape(ordinary)),A8_increment=float(shape(increment)),
                signed_fractional_increment_M8_Q14_to_Q16=float(drift),
                ordinary_increment_variance_fractional_difference=variance_difference,
                Q16_ordinary_spectral_check=ordinary['actual']['spectral_reconstruction'],
                Q16_increment_spectral_check=increment['actual']['spectral_reconstruction']))
        # Earlier positive value from the same physical input, not an inferred continuation.
        previous=json.loads(local(high['input']).read_text())['cases'][0]
        previous=next(r for r in previous['cosine'] if r['beta']==1.)
        previous=next(w for w in previous['windows'] if w['tau']==51.2)
        old_A8=previous['log_shape']['8']
        require(old_A8>0 and all(r['A8_increment']<0 for r in rows),'Expected finite-window sign pattern changed')
        require(rows[2]['A8_increment']>rows[1]['A8_increment'],'Expected observed return toward zero changed')
        max_control=max(c['error'] for c in data['new_arithmetic_controls']['checks'])
        max_saved=max(max(c['saved_ordinary_control']['max_scaled_error'],c['saved_width_control']['max_relative_even_error']) for c in cases.values())
        log_path_max=max(w['conditional_omitted_path_bounds']['log_relative_even_moment_bound']['8'] for c in cases.values() for w in c['windows'])
        max_filter=max(v for c in cases.values() for w in c['windows'] for v in w['actual']['filter_deletion_log_relative_even_bounds'].values() if v is not None)

    lines=[r'% Generated from saved_common_widths_R10.json; see stage3_common_width_provenance.json.',
        r'\subsection{Fixed-width probes beyond the finite infrared cutoff}',
        r'\label{sec:s3-common-width-results}',
        r'We re-evaluate the saved $R=10$, $\beta=1$ full-cosine matrices at three fixed absolute widths, keeping $M=20$, $M_{\rm ref}=24$, 32 primitive levels and the same five-mode active prefix. Here $O_\tau$ is the actual-ground-centered Gaussian average and $X_\tau=O_\tau-O_{2\tau}$. For either observable $Y$, the reported contrast is',
        r'\begin{equation}',
        r'A_8^{(0)}(Y)=\log\!\left[\frac{M_8(Y)/M_2(Y)^4}{M_8^{(0)}(Y)/(M_2^{(0)}(Y))^4}\right].',
        r'\label{eq:s3-common-width-contrast}',
        r'\end{equation}',
        r'The superscript $(0)$ denotes the original distributed harmonic $H_0$, using ordered quadratic algebra for all 20 declared modes. It does not denote the retained interacting Wick comparator. Thus $A_8^{(0)}$ combines altered two-point response with higher information; it does not isolate an irreducible non-Gaussian field contribution.',
        r'\begin{table}[t]\centering\small',
        r'\caption{Fixed-width $R=10$ results at $\beta=1$. The contrasts use $Q=16$; $\delta_8=M_8^{Q=16}(X_\tau)/M_8^{Q=14}(X_\tau)-1$ measures this occupation/selection refinement alone. A dagger marks widths where binary64 spectral reconstruction fails its stated consistency check for both $Q=16$ observables; the displayed moments use the normalized vacuum-vector recurrence.}\label{tab:s3-common-width}',
        r'\begin{tabular}{rrrr}\toprule',
        r'$\tau$ & $A_8^{(0)}(O_\tau)$ & $A_8^{(0)}(X_\tau)$ & $10^6\delta_8$\\\midrule']
    for r in rows:
        dagger=not r['Q16_ordinary_spectral_check']['passed'] and not r['Q16_increment_spectral_check']['passed']
        t=f'{r["tau"]:.3f}'+(r'$^{\dagger}$' if dagger else '')
        lines.append(t+f' & {r["A8_ordinary"]:.6f} & {r["A8_increment"]:.6f} & {1e6*r["signed_fractional_increment_M8_Q14_to_Q16"]:+.3f}'+r'\\')
    lines += [r'\bottomrule\end{tabular}\end{table}',
        r'These widths have $\tau\Omega_{\min}=2.489,3.520,4.978$, placing $R=10$ beyond its lowest-resonance scale. Together with $A_8^{(0)}(X_{51.2})='+f'{old_A8:.6f}'+r'$, the increment values show a sign change followed by a turn back toward zero; all three values in this panel remain negative. The longer-width extension in Sec.~\ref{sec:s3-finite-gap-results} resolves the subsequent crossing. The ordinary contrast continues to decrease. This observable-dependent finite-$R$ cutoff crossover supplies a baseline for a later same-width depth comparison; it supplies neither an interior scaling plateau nor a rare-tail result.',
        r'At these widths the ordinary and increment variances agree to displayed precision, while their higher moments differ strongly. Ordered returning paths permit this difference: the ordinary filter retains zero-energy-gap entries between intermediate excited states, whereas the difference filter annuls those entries even when the ground-to-excited variance filters have become nearly equal.',
        r'The recurrence preserves the order in powers of one smeared Hermitian operator, sets its actual ground diagonal to zero, normalizes each vacuum vector, and accumulates scalar amplitudes and cumulants with 80-digit Decimal arithmetic. Four small arithmetic controls pass, and the saved $\tau=51.2$ ordinary/increment checks agree within $7.3\times10^{-14}$ on their declared scales. Necessary positive-moment checks pass through order eight. At the two longer widths, the direct spectral weights, and hence a direct cumulative distribution from them, remain unresolved. Decimal accumulation does not improve the binary64 Hamiltonian eigenpairs or projected pressure entries.',
        r'The conditional relative eighth-moment omitted-path envelopes are smaller than $e^{-1171}$ for these rows. This statement assumes an exact finite spectral restriction with a common exact ground state; it excludes archived subspace, state, source, primitive, bath and line-mode errors. The small $Q=14\to16$ changes in Table~\ref{tab:s3-common-width} quantify only that refinement and do not complete those separate error controls.']
    fragment='\n'.join(lines)+'\n'
    provenance_data=dict(status='COMPLETED',scope='saved-data manuscript fragment; no physical or matrix computation',
        input_status=data['status'],input_warnings=data['warnings'],inputs_and_verified_sha256=inputs,
        archives=archives,executed_analysis_source_sha256=data['source_sha256'],
        reported_source_hashes=executed_sources,
        generator=dict(path=str(Path(__file__).relative_to(ROOT)),sha256=sha(Path(__file__))),memory_allowance_mb=memory,
        scalar_audit=audit,new_arithmetic_controls=data['new_arithmetic_controls'],
        maximum_new_control_error=max_control,maximum_saved_width_control_error=max_saved,
        largest_conditional_log_relative_M8_path_bound=log_path_max,
        largest_log_relative_filter_deletion_bound=max_filter,
        spectral_reconstruction=spectral,arithmetic_underflow_status=underflow,
        selected_rows=rows,previous_same_model_increment_A8=dict(tau=51.2,value=old_A8),
        original_finite_tensor_diagnostics={k:c['original_diagnostics'] for k,c in cases.items()},
        saved_matrix_eigensolve_diagnostics={k:c['eigensolve'] for k,c in cases.items()},
        reference='original distributed harmonic H0 with all M=20 declared modes; not retained interacting Wick',
        limitations=['R10 outside common infrared interior','no completed depth comparison in this fragment',
            'this three-width panel remains negative; subsequent crossing is documented in the longer-width extension','no plateau or rare-tail inference',
            'long-width direct spectral weights and CDF unresolved',
            'conditional path bound excludes state/source/subspace and regulator errors'])
    # Explicit replacement is restricted to these owned derived artifacts.
    mode='w' if args.replace else 'x'
    with target.open(mode) as stream: stream.write(fragment)
    provenance_data['outputs']={TARGET:sha(target)}
    with provenance.open(mode) as stream: json.dump(provenance_data,stream,indent=2,allow_nan=False)
    print('COMPLETED common-width manuscript fragment and provenance',flush=True)


if __name__=='__main__': main()
