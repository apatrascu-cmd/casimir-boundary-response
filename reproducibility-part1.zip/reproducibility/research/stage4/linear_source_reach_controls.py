"""Independent tiny padded-Fock controls for linear_source_reach; root-run only."""
from __future__ import annotations
import argparse,hashlib,json,math,os,platform,signal,sys,time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import linear_source_reach as core
ROOT=Path(__file__).resolve().parents[2]
CONTROL_NAMES=('harmonic_vacuum_complete_source','rotated_entangled_complete_padded_fock','missing_cross_configurations_and_contact','frozen_source_and_mixed_sign','input_memory_and_parity_rejections')


def identity():
    paths=[Path(__file__).resolve(),Path(core.__file__).resolve()]
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


def run_controls():
    N=6;NP=N+1;M=2
    a=np.diag(np.sqrt(np.arange(1,NP)),1);xf=a+a.T;yf=a.T-a
    x=xf[:N,:N];yi=yf[:N,:N];x2=(xf@xf)[:N,:N];y2=(-yf@yf)[:N,:N]
    def case(rotated=False,entangled=False,frozen=False,harmonic=False):
        orbitals=[]
        for j in range(M):
            U=np.eye(N)
            if rotated:
                for k,l,angle in [(0,2,.23+.1*j),(1,3,.37-.1*j),(2,4,-.12)]:
                    T=np.eye(N);T[np.ix_([k,l],[k,l])]=[[math.cos(angle),-math.sin(angle)],[math.sin(angle),math.cos(angle)]];U=U@T
            orbitals.append(U)
        low=np.array([[n,0] for n in ([0,1,2] if not entangled else [0,1,2,4])])
        bath=np.array([[0,n] for n in ([0] if frozen else [0,1,2])])
        psi=np.zeros((len(bath),len(low)))
        if harmonic:psi[0,0]=1.
        else:
            for b,bs in enumerate(bath):
                for l,ls in enumerate(low):
                    if (sum(bs)+sum(ls))%2==0:psi[b,l]=math.sin(.4+1.2*b+.7*l)
            psi/=np.linalg.norm(psi)
        local=dict(orbitals=np.array(orbitals),X=np.array([U.T@x@U for U in orbitals]),
            Y=1j*np.array([U.T@yi@U for U in orbitals]),X2=np.array([U.T@x2@U for U in orbitals]),Y2=np.array([U.T@y2@U for U in orbitals]))
        model=dict(low_states=low,bath_states=bath,local=local)
        modes=SimpleNamespace(omega=np.array([.3,1.1]),slope=np.array([.7,.2]),endpoint=np.array([.11,-.31]),p=SimpleNamespace(hbar=.7,L0=1.3,C0=.9))
        embed=np.zeros((NP**M,len(bath)*len(low)))
        for b,bs in enumerate(bath):
            for l,ls in enumerate(low):
                n=bs+ls;v=np.ones(1)
                for j in range(M):v=np.kron(v,np.pad(orbitals[j][:,n[j]],(0,1)))
                embed[:,b*len(low)+l]=v
        operators=[]
        for O in (xf,yf):
            for j in range(M):operators.append(np.kron(O,np.eye(NP)) if j==0 else np.kron(np.eye(NP),O))
        ambient=embed@psi.ravel();full=np.column_stack([O@ambient for O in operators]);projected=embed.T@full
        direct_full=full.T@full;direct_projected=projected.T@projected;outside=full-embed@projected
        direct_outside=outside.T@outside
        answer=core.source_reach(model,modes,psi,memory_mb=256,return_seeds=True)
        error=max(np.max(abs(answer['modal_complete_gram']-direct_full)),np.max(abs(answer['modal_projected_gram']-direct_projected)),np.max(abs(answer['modal_outside_gram']-direct_outside)))
        core.require(error<2e-12,'independent complete padded-Fock source comparison failed')
        dc=answer['coefficients'];coeff=np.zeros((4,2));coeff[:2,0]=dc[:,0];coeff[2:,1]=dc[:,1]
        core.require(np.max(abs(answer['projected_physical_seeds'].reshape(-1,2)-projected@coeff))<1e-12,'physical source seed sign or tensor layout differs')
        return model,modes,psi,answer,float(error)
    checks=[]
    model,modes,psi,ans,error=case(harmonic=True)
    core.require(np.max(abs(ans['modal_outside_gram']))<1e-14,'harmonic vacuum source should be complete in this basis')
    checks.append(dict(name=CONTROL_NAMES[0],passed=True,max_absolute_error=error))
    _,_,_,ans,error=case(rotated=True,entangled=True)
    checks.append(dict(name=CONTROL_NAMES[1],passed=True,max_absolute_error=error,scope='independent complete Fock projection with parity-preserving real orbitals and entangled even state'))
    _,_,_,ans,error=case(entangled=True)
    core.require(ans['diagnostics']['physical_outside_covariance_scale']>1e-4,'known missing source must be nonzero')
    checks.append(dict(name=CONTROL_NAMES[2],passed=True,max_absolute_error=error,known_nonzero_outside_scale=ans['diagnostics']['physical_outside_covariance_scale']))
    _,_,_,ans,error=case(rotated=True,frozen=True)
    core.require(ans['modal_outside_gram'][1,1]>0 and ans['modal_complete_gram'][1,3]>0,'frozen mode or mixed source contact lost')
    checks.append(dict(name=CONTROL_NAMES[3],passed=True,max_absolute_error=error,canonical_mixed_sign=float(ans['modal_complete_gram'][1,3])))
    rejected=[]
    tests=[('memory',lambda:core.source_reach(model,modes,psi,memory_mb=1)),('normalization',lambda:core.source_reach(model,modes,2*psi,memory_mb=256)),('complex_state',lambda:core.source_reach(model,modes,psi.astype(complex),memory_mb=256))]
    bad=psi.copy();bad[0,0]=0;bad[0,1]=1
    tests.append(('odd_state',lambda:core.source_reach(model,modes,bad,memory_mb=256)))
    for name,fn in tests:
        try:fn()
        except (ValueError,MemoryError):rejected.append(name)
    core.require(len(rejected)==len(tests),'an input refusal failed')
    checks.append(dict(name=CONTROL_NAMES[4],passed=True,rejected=rejected))
    return checks


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True);a=ap.parse_args()
    memory=float(os.environ['PYSCF_MAX_MEMORY']);core.require(memory>=256,'allocate at least 256 MB for tiny controls')
    dest=(ROOT/a.output).resolve();core.require(dest.is_relative_to(ROOT/'research/stage4') and dest.suffix=='.json' and dest.parent.is_dir(),'new stage4 JSON in existing directory required')
    source=identity();begin=time.monotonic();out=dict(status='RUNNING',format=core.FORMAT,source_sha256=source,
      runtime=dict(python=sys.version,numpy=np.__version__,platform=platform.platform(),machine=platform.machine(),declared_threads={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')}),checks=[])
    with dest.open('x') as f:json.dump(out,f)
    def save():
        out['elapsed_seconds']=time.monotonic()-begin;temp=dest.with_suffix('.writing');temp.write_text(json.dumps(out,indent=2,allow_nan=False));temp.replace(dest)
    def terminate(signum,frame):raise RuntimeError('admission interrupted controls')
    signal.signal(signal.SIGTERM,terminate)
    try:
        out['checks']=run_controls();core.require(tuple(r['name'] for r in out['checks'])==CONTROL_NAMES and all(r['passed'] for r in out['checks']),'exact five groups must pass');core.require(identity()==source,'control sources changed during execution');out['status']='PASS';save()
    except BaseException as exc:out.update(status='FAILED',error=repr(exc));save();raise
    print('PASS five linear-source reach control groups',flush=True)

if __name__=='__main__':main()
