"""Parity-preserving compression of coherent old-state bath source amplitudes.

Prepared for guarded execution. No ambient Hamiltonian is constructed. A
singular tail measures only the supplied old state's two canonical sources.
"""
from __future__ import annotations
import math
import numpy as np
from scipy.linalg import qr,svd
from scipy.sparse import coo_matrix
import source_directed_bath as frozen

FORMAT='stage4-source-compressed-bath-rank-v1'


def require(ok,message):
    if not ok:raise ValueError(message)


def norm(a):
    """Scaled Frobenius norm: no premature squaring of tiny entries."""
    a=np.asarray(a);scale=float(np.max(abs(a),initial=0.))
    return 0. if scale==0 else scale*math.sqrt(float(np.sum(abs(a/scale)**2)))


def source_generators(bath,orbitals,coefficients,source_modes,rows):
    """Sparse complete padded one-field maps, old bath -> supplied row inventory.

    The last local label is the bare primitive boundary state, orthogonal to
    every original dressed orbital. No amplitude threshold is applied.
    """
    bath=np.asarray(bath);rows=np.asarray(rows);coeff=np.asarray(coefficients)
    frozen.check_states(bath)
    require(rows.ndim==2 and rows.shape[1]==bath.shape[1] and rows.dtype.kind in 'iu','integer row inventory required')
    require(np.array_equal(rows[:len(bath)],bath),'old bath must be the exact row prefix')
    index={tuple(map(int,s)):i for i,s in enumerate(rows)}
    require(len(index)==len(rows),'duplicate source row labels')
    X,Yi,orth=frozen.padded_local_fields(orbitals);M,Np,_=X.shape
    require(coeff.shape==(M,2) and np.isfinite(coeff).all(),'source coefficients malformed')
    modes=tuple(source_modes);require(len(set(modes))==len(modes) and all(isinstance(j,(int,np.integer)) and 0<=j<M for j in modes),'integer source modes required')
    require(np.all(rows>=0) and np.max(rows)<Np,'padded source labels outside local basis')
    ii=[];jj=[];dd=[];zz=[]
    for b,state in enumerate(bath):
        for j in modes:
            for target in range(Np):
                d=float(coeff[j,0]*X[j,target,state[j]]);z=float(coeff[j,1]*Yi[j,target,state[j]])
                if d==0 and z==0:continue
                s=list(map(int,state));s[j]=target;s=tuple(s)
                require(s in index,'source inventory omits a nonzero coherent transition')
                ii.append(index[s]);jj.append(b);dd.append(d);zz.append(z)
    shape=(len(rows),len(bath));D=coo_matrix((dd,(ii,jj)),shape=shape).tocsr();Z=coo_matrix((zz,(ii,jj)),shape=shape).tocsr()
    D.sum_duplicates();Z.sum_duplicates()
    return dict(D=D,Z_imag=Z,rows=rows,bath=bath,diagnostics=dict(transition_count=len(ii),orbital_orthogonality_error=orth,primitive_size=Np-1,
      scope='complete one-field padded maps; no square of a projected source substitutes for a complete pressure contact'))


def reduce_ground(generators,low,psi,C0=1.,L0=1.):
    """Untruncated parity QR removes redundant active columns exactly in algebra."""
    bath=generators['bath'];rows=generators['rows'];p=np.asarray(psi);low=np.asarray(low)
    require(p.shape==(len(bath),len(low)) and p.dtype.kind=='f' and np.isfinite(p).all(),'real bath-by-active state required')
    require(abs(norm(p)-1)<1e-9,'saved ground must already be normalized')
    require(C0>0 and L0>0 and math.isfinite(C0+L0),'finite positive source units required')
    bp=np.sum(bath,axis=1)%2;lp=np.sum(low,axis=1)%2;rp=np.sum(rows,axis=1)%2
    require(norm(p[(bp[:,None]+lp[None,:])%2==1])<1e-13,'source QR requires an even saved ground')
    gram=np.zeros((len(rows),2,2));pieces={};factors={};checks=[];nb=len(bath)
    for old_parity in (0,1):
        ib=np.flatnonzero(bp==old_parity);il=np.flatnonzero(lp==old_parity)
        block=p[np.ix_(ib,il)]
        if min(block.shape)==0:V=np.zeros((len(il),0));R=np.zeros((0,len(ib)))
        else:V,R=qr(block.T,mode='economic',check_finite=False)
        qr_error=norm(block.T-V@R);orth=norm(V.T@V-np.eye(V.shape[1]))
        require(qr_error<1e-11 and orth<1e-11,'untruncated ground QR unresolved')
        # R.T has all min(n_active_parity,n_old_bath_parity) columns, including
        # numerical null directions: there is no Schmidt-value truncation.
        C=R.T;D=generators['D'][:,ib]@C;Z=generators['Z_imag'][:,ib]@C
        target_parity=1-old_parity;forbidden=rp!=target_parity
        require(norm(D[forbidden])+norm(Z[forbidden])<1e-12,'odd sources mix bath parities')
        # All row Grams, including retained and primitive boundary rows, replay
        # the independent original active-column calculation.
        gram[:,0,0]+=np.sum(D*D,axis=1);gram[:,1,1]+=np.sum(Z*Z,axis=1)
        cross=np.sum(D*Z,axis=1);gram[:,0,1]+=cross;gram[:,1,0]+=cross
        selected=np.flatnonzero((np.arange(len(rows))>=nb)&(rp==target_parity))
        pieces[target_parity]=dict(row_indices=selected,array=np.concatenate([D[selected]/math.sqrt(L0),math.sqrt(C0)*Z[selected]],axis=1),qr_columns=C.shape[1])
        factors[old_parity]=dict(old_bath_indices=ib,active_indices=il,V=V,R=R)
        checks.append(dict(old_bath_parity=old_parity,old_bath_count=len(ib),active_count=len(il),qr_columns=C.shape[1],reconstruction_frobenius=qr_error,orthogonality_frobenius=orth,discarded_forbidden_parity_source_norm=norm(D[forbidden])+norm(Z[forbidden])))
    deficit=math.fsum(norm(v['array'])**2 for v in pieces.values())
    require(deficit>0 and math.isfinite(deficit),'positive representable old-source deficit required')
    return dict(pieces=pieces,factors=factors,gram_by_row=gram,deficit=deficit,qr_checks=checks)


def decompose(panels):
    """Joint beta-normalized SVD, kept separately in each bath parity.

    Each beta has unit squared source norm before stacking. Consequently each
    beta's relative remaining norm is at most the joint singular-square tail.
    """
    require(len(panels)==2,'exact two-strength normalized source panel required')
    decompositions={}
    for parity in (0,1):
        parts=[p['pieces'][parity] for p in panels]
        require(np.array_equal(parts[0]['row_indices'],parts[1]['row_indices']),'common ordinal row inventory differs')
        widths=[p['array'].shape[1] for p in parts];edges=np.cumsum([0,*widths]);ranges=[(int(edges[i]),int(edges[i+1])) for i in range(2)]
        A=np.concatenate([parts[i]['array']/math.sqrt(panels[i]['deficit']) for i in range(2)],axis=1)
        if min(A.shape)==0:
            U=np.zeros((len(A),0));s=np.empty(0);Vh=np.zeros((0,A.shape[1]))
        else:U,s,Vh=svd(A,full_matrices=False,check_finite=False,lapack_driver='gesdd')
        orth=norm(U.T@U-np.eye(len(s)));right_orth=norm(Vh@Vh.T-np.eye(len(s)))
        residues=[0.,0.]
        for start in range(0,len(A),256):
            error=A[start:start+256]-(U[start:start+256]*s)@Vh
            for i,(a,b) in enumerate(ranges):residues[i]=math.hypot(residues[i],norm(error[:,a:b]))
        require(orth<1e-10 and right_orth<1e-10 and max(residues)<1e-10,'source SVD decomposition unresolved')
        # Source SVD reconstruction error supplies a numerical envelope on this
        # matrix, not a certified bound on generated amplitudes or physical H.
        weights=np.asarray([[float(np.sum(Vh[j,a:b]**2)) for a,b in ranges] for j in range(len(s))]).reshape(len(s),2)
        squared=s*s;underflow=int(np.count_nonzero((s!=0)&(squared==0)))
        cutoff=max(A.shape,default=1)*np.finfo(float).eps*float(s[0] if len(s) else 0.)
        numerical_rank=int(np.count_nonzero(s>cutoff))
        decompositions[parity]=dict(U=U,s=s,Vh=Vh,beta_column_ranges=ranges,beta_weights=weights,row_indices=parts[0]['row_indices'],
          orthogonality_frobenius=orth,right_orthogonality_frobenius=right_orth,svd_reconstruction_frobenius_by_beta=residues,
          numerical_rank_threshold=cutoff,numerical_rank=numerical_rank,positive_singular_square_underflow_count=underflow,input_shape=list(A.shape),
          scope='QR/SVD arithmetic diagnostics; threshold is a numerical resolution indicator, not a physical rank theorem')
    return decompositions


def rank_panel(decompositions,rank_grid,fractions,old_bath_count):
    order=sorted([(float(s),p,j) for p,d in decompositions.items() for j,s in enumerate(d['s'])],key=lambda x:(-x[0],x[1],x[2]))
    numerical_max=sum(d['numerical_rank'] for d in decompositions.values())
    def row(rank):
        require(0<=rank<=len(order),'rank outside thin decomposition')
        kept={p:sum(item[1]==p for item in order[:rank]) for p in (0,1)}
        tails=[0.,0.];uppers=[0.,0.];generator_estimates={}
        for p,d in decompositions.items():
            k=kept[p]
            if k:
                smallest=float(d['s'][k-1]);eta=math.hypot(*d['svd_reconstruction_frobenius_by_beta']);alpha=d['orthogonality_frobenius'];right=d['right_orthogonality_frobenius']
                estimate=None if smallest==0 else (math.sqrt(1+alpha)*float(d['s'][0])*right+eta*math.sqrt(1+right))/smallest
                generator_estimates[str(p)]=dict(smallest_kept_singular_value=smallest,inverse_singular_amplification=None if smallest==0 else 1/smallest,
                  generator_to_left_vector_reconstruction_upper_estimate=estimate)
            for beta in range(2):
                tail=math.fsum(float(d['s'][j])**2*float(d['beta_weights'][j,beta]) for j in range(k,len(d['s'])))
                tails[beta]+=tail
                # In exact arithmetic, ||(I-P_kept)U_tail|| <= sqrt(1+alpha),
                # where alpha bounds ||U*U-I||. Add the measured backward error.
                uppers[beta]+=(math.sqrt(1+d['orthogonality_frobenius'])*math.sqrt(tail)+d['svd_reconstruction_frobenius_by_beta'][beta])**2
        cut_near_tie=bool(0<rank<len(order) and abs(order[rank-1][0]-order[rank][0])<=max(d['numerical_rank_threshold'] for d in decompositions.values()))
        supported=all(kept[p]<=decompositions[p]['numerical_rank'] for p in (0,1))
        return dict(added_rank=rank,bath_dimension=int(old_bath_count)+rank,kept_by_bath_parity={str(p):kept[p] for p in kept},
          relative_discarded_singular_weight_by_beta=tails,relative_remaining_numerical_upper_estimate_by_beta=uppers,
          captured_singular_fraction_by_beta=[1-t for t in tails],captured_fraction_numerical_lower_estimate_by_beta=[1-u for u in uppers],
          within_reported_numerical_rank=supported,cut_intersects_numerically_tied_singular_cluster=cut_near_tie,generator_reconstruction_diagnostics=generator_estimates,
          scope='old-state padded bath source only; numerical envelopes exclude generation/QR/input-state/physical outside-source uncertainty')
    records=[row(k) for k in sorted(set([0,*[int(k) for k in rank_grid if 0<=k<=len(order)],len(order)]))]
    targets=[]
    for fraction in fractions:
        require(0<fraction<1,'capture target outside (0,1)')
        found=None
        for k in range(numerical_max+1):
            r=row(k)
            if r['within_reported_numerical_rank'] and max(r['relative_remaining_numerical_upper_estimate_by_beta'])<=1-fraction:
                # Keep an entire unresolved boundary cluster when possible.
                while r['cut_intersects_numerically_tied_singular_cluster'] and k<numerical_max:k+=1;r=row(k)
                if r['within_reported_numerical_rank']:found=r
                break
        targets.append(dict(fraction=fraction,status='TARGET_MET_FOR_SUPPLIED_SOURCE_MATRIX_WITH_NUMERICAL_DIAGNOSTICS' if found else 'TARGET_UNRESOLVED_WITHIN_NUMERICAL_RANK',choice=found))
    return dict(rank_grid=records,targets=targets,total_thin_columns=len(order),reported_numerical_rank=numerical_max,
      ordered_singular_labels=[dict(bath_parity=p,within_parity=j,value=s) for s,p,j in order],
      every_new_bath_vector_pairs_with_every_active_state=True,common_ordinal_labels_not_identical_physical_orbitals_across_beta=True)


def product_insertions(states,target_local,left_local,right_local):
    """Old-product-state contractions of K, L†K, KR, and L†KR.

    K is a tensor product; L/R are sums of single-mode local matrices. The
    4-channel recurrence sums all left/right insertion positions coherently,
    including insertions on the same mode. It never constructs ambient K.
    """
    states=np.asarray(states);n=len(states);dtype=np.result_type(*target_local,*left_local,*right_local,complex)
    f00=np.ones((n,n),dtype=dtype);f10=np.zeros_like(f00);f01=np.zeros_like(f00);f11=np.zeros_like(f00)
    require(len(target_local)==len(left_local)==len(right_local)==states.shape[1],'local contraction mode inventory differs')
    for j,(K,L,R) in enumerate(zip(target_local,left_local,right_local)):
        require(K.ndim==2 and K.shape[0]==K.shape[1] and L.shape==R.shape==K.shape,'local contraction dimensions differ')
        occ=states[:,j];ix=np.ix_(occ,occ)
        a=K[ix];b=(L.conj().T@K)[ix];c=(K@R)[ix];d=(L.conj().T@K@R)[ix]
        next11=f11*a+f10*c+f01*b+f00*d
        next10=f10*a+f00*b;next01=f01*a+f00*c;next00=f00*a
        f00,f10,f01,f11=next00,next10,next01,next11
    return dict(K00=f00,left=f10,right=f01,both=f11)


def removed_source_block(contractions,Bleft,Bright):
    c=contractions
    return c['both']-Bleft.conj().T@c['right']-c['left']@Bright+Bleft.conj().T@c['K00']@Bright
