"""Production full-cosine factors in exactly supplied frozen local orbitals.

No SCF iteration, arithmetic-backend substitution, or conditional bath space.
The complete old tensor is a restriction of each nested new tensor.
"""
from __future__ import annotations
import math,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'research/stage3'),str(ROOT/'src')]
import dressed_cosine_hierarchy as dressed
import tensor_cosine as original


def require(ok,message):
    if not ok:raise ValueError(message)


def local_from_orbitals(modes,u,beta,reference,orbitals):
    Us=[np.array(U,dtype=float,copy=True) for U in orbitals];M=len(modes.omega);R=len(u);N=Us[0].shape[0]
    require(len(Us)==M and all(U.shape==(N,N) for U in Us),'fixed orbital dimensions differ')
    require(max(np.linalg.norm(U.T@U-np.eye(N)) for U in Us)<1e-10,'fixed orbital metric unresolved')
    kj=np.asarray(modes.p.KJ);u=np.asarray(u);v=np.asarray(reference)
    require(v.shape==(R,) and np.all(v>0) and beta>0,'invalid fixed calibration')
    c=modes.branch*np.sqrt(modes.p.hbar/(2*modes.omega))[None,:];theta2=-beta*u/kj
    require(np.all(theta2>0),'positive beta and negative cosine branch coupling required')
    x,p,x2,p2=dressed.quadratures(N);n=np.arange(N)
    displacement=[[dressed.primitive(N,math.sqrt(theta2[r])*c[r,j]) for j in range(M)] for r in range(R)]
    corr=np.array([[float(Us[j][:,0]@displacement[r][j].real@Us[j][:,0]) for j in range(M)] for r in range(R)])
    X=np.asarray([U.T@x@U for U in Us]);Y=np.asarray([U.T@p@U for U in Us]);X2=np.asarray([U.T@x2@U for U in Us]);Y2=np.asarray([U.T@p2@U for U in Us])
    D=[[Us[j].T@displacement[r][j]@Us[j] for j in range(M)] for r in range(R)]
    hs=[]
    # Literal final-factor reconstruction in the frozen production mean_field.
    for j,U in enumerate(Us):
        H=np.diag(modes.p.hbar*modes.omega[j]*n)
        for r in range(R):
            dc=np.delete(corr[r],j);require(np.all(dc>-1),'nonpositive frozen characteristic factor')
            minus=np.expm1(np.log1p(dc).sum());prod=1+minus;t2=theta2[r]*c[r,j]**2
            crem=displacement[r][j].real+t2*x2/2
            H+=(kj[r]/2*(minus+theta2[r]*v[r]/2)*c[r,j]**2)*x2-(kj[r]/theta2[r])*prod*crem
        h=U.T@H@U;h-=h[0,0]*np.eye(N);hs.append((h+h.T)/2)
    return dict(local_hamiltonians=np.asarray(hs),orbitals=np.asarray(Us),X=X,Y=Y,X2=X2,Y2=Y2,D=D,c=c,theta2=theta2,reference=v,
      frozen_characteristic_factors=corr,origin='archived orbitals; literal frozen production primitive and final-factor algebra; no SCF solve')


def tensor_from_local(modes,low,bath,indices,local,memory_mb):
    # Literal tensor_model body following mean_field, with supplied local arrays.
    M=len(modes.omega);indices=list(indices);other=[j for j in range(M) if j not in indices]
    HL,PL=dressed.assemble(modes,low,local,memory_mb);HB,PB=dressed.assemble(modes,bath,local,memory_mb);ht=[];pt=[]
    for r,kj in enumerate(modes.p.KJ):
        t2=local['theta2'][r];theta=np.sqrt(t2);v=local['reference'][r]
        CL,SL=original.characteristic(low,local,r,indices);CB,SB=original.characteristic(bath,local,r,other)
        qL=original.group_operator(low,local,indices,local['c'][r],'X').real;qB=original.group_operator(bath,local,other,local['c'][r],'X').real
        rL=SL-theta*qL;rB=SB-theta*qB
        ht.extend([(CL,-kj/t2*CB),(rL,kj/t2*rB),(qL,kj/theta*rB),(rL,kj/theta*qB),(qL,kj*t2*v/2*qB)])
    d=modes.slope*np.sqrt(modes.p.hbar/(2*modes.omega));z=modes.endpoint*np.sqrt(modes.p.hbar*modes.omega/2)
    pt.append((original.group_operator(low,local,indices,d,'X').real,original.group_operator(bath,local,other,d,'X').real/modes.p.L0))
    pt.append((original.group_operator(low,local,indices,z,'Y').imag,-modes.p.C0*original.group_operator(bath,local,other,z,'Y').imag))
    return dict(HL=HL,HB=HB,PL=PL,PB=PB,hterms=ht,pterms=pt,local=local,low_states=low,bath_states=bath)


def tensor_action(model,psi,pressure=False):
    L=model['PL' if pressure else 'HL'];B=model['PB' if pressure else 'HB'];terms=model['pterms' if pressure else 'hterms']
    out=psi@L.T+B@psi
    for a,b in terms:out+=b@psi@a.T
    return out


def exact_common_blocks(old,new):
    nb=len(old['HB']);reports=[]
    require(np.array_equal(old['low_states'],new['low_states']) and np.array_equal(old['bath_states'],new['bath_states'][:nb]),'nested factor identity differs')
    for key in ('HL','PL','HB','PB'):
        a=old[key];b=new[key] if key.endswith('L') else new[key][:nb,:nb]
        require(np.array_equal(a,b),'common projected factor differs: '+key);reports.append(key)
    for key in ('hterms','pterms'):
        require(len(old[key])==len(new[key]),'factor count differs')
        for i,((a,b),(c,d)) in enumerate(zip(old[key],new[key])):
            require(np.array_equal(a,c) and np.array_equal(b,d[:nb,:nb]),'common cross factor differs: '+key+str(i));reports.append(key+str(i))
    return dict(passed=True,exact_factor_restrictions=reports,old_bath_dimension=nb,new_bath_dimension=len(new['HB']),every_bath_row_has_every_active_state=True,
      scope='exact array common blocks imply full original tensor restriction; original composite P/contact/scalar convention preserved')
