"""Root-run independent padded-Fock, contact, checkpoint and admission controls."""
from __future__ import annotations
import argparse,copy,itertools,json,math,os,signal,tempfile,time
from pathlib import Path
import numpy as np
from scipy.linalg import eigh
from scipy.sparse import csr_matrix
from scipy.special import eval_genlaguerre
import source_compressed_projection_run as run
from nonlinear_pressure import PressureModes
core=run.core


def kron(items):
    out=np.ones((1,1))
    for a in items:out=np.kron(out,a)
    return out


def embed_one(a,j,M,N):return kron([a if i==j else np.eye(N) for i in range(M)])


def displacement(N,t):
    out=np.empty((N,N),complex)
    for i in range(N):
        for j in range(N):
            lo=min(i,j);hi=max(i,j);gap=hi-lo
            out[i,j]=math.exp(-t*t/2+(math.lgamma(lo+1)-math.lgamma(hi+1))/2)*(1j*t)**gap*eval_genlaguerre(lo,gap,t*t)
    return out


def rejected(function):
    try:function()
    except (ValueError,ArithmeticError,MemoryError,FileExistsError,KeyError):return True
    raise AssertionError('counterfeit input accepted')


def controls(memory):
    rng=np.random.default_rng(728153);N=3;M=2;states=np.array([[0,0],[1,0],[0,1]]);E=np.eye(N**M)[:,[0,N,1]]
    src=rng.normal(size=(3,M,N,N));K=[displacement(N,.23+.07*j) for j in range(M)];KF=kron(K)
    fullsources=[sum((embed_one(a,j,M,N) for j,a in enumerate(f)),np.zeros_like(KF)) for f in src]
    blocks=core.contract(states,core.mpo('product',K),src);family=[np.eye(N**M),*fullsources];errors=[]
    for i,L in enumerate(family):
        for j,R in enumerate(family):errors.append(core.norm(blocks[i,j]-E.T@L.conj().T@KF@R@E))
    assert max(errors)<3e-12
    for kind in ('sum','pair','cos_ge1','cos_ge2'):
        ds=[a-np.eye(N) for a in K]
        if kind in ('sum','pair'):
            op=embed_one(K[0],0,M,N)+embed_one(K[1],1,M,N) if kind=='sum' else KF;locals_=K
        else:
            dc=[d[0,0].real for d in ds];delta=[d-dc[j]*np.eye(N) for j,d in enumerate(ds)]
            op=kron(delta)
            if kind=='cos_ge1':op+=(1+dc[1])*embed_one(delta[0],0,M,N)+(1+dc[0])*embed_one(delta[1],1,M,N)
            locals_=ds
        actual=core.contract(states,core.mpo(kind,locals_),src)
        for i,L in enumerate(family):
            for j,R in enumerate(family):errors.append(core.norm(actual[i,j]-E.T@L.conj().T@op@R@E))
    assert max(errors)<2e-11
    # A zero active factor cannot determine its bath partner's parity. This
    # known-true control is the exact algebraic separator for candidate v1.
    zero=np.zeros((2,2));odd_bath=np.array([[0.,-2.],[2.,0.]]);parity=np.array([0,1]);rules=core.cross_factor_rules(2)
    assert rules['hterms']==[(0,1),(1,1),(1,1),(1,1),(1,1)]*2 and rules['pterms']==[(1,1),(1,-1)]
    change,sign=rules['pterms'][1];za,zad=core.parity_gate(zero,parity,change,sign);zb,zbd=core.parity_gate(odd_bath,parity,change,sign)
    assert np.array_equal(za,zero) and np.array_equal(zb,odd_bath) and np.count_nonzero(np.kron(zb,za))==0
    assert rejected(lambda:core.parity_gate(odd_bath,parity,0,-1))
    result=[dict(name=run.CHECKS[0],passed=True,random_complex_full_Fock_insertion_max_error=max(errors),all_same_mode_insertions_included=True,
      zero_active_nonzero_bath_control=dict(known_parity=change,known_adjoint_sign=sign,active_norm=core.norm(za),bath_norm=core.norm(zb),tensor_term_exact_zero=True,incorrect_even_bath_assignment_rejected=True))]
    # Small physical geometry with separated active and bath frequencies. The
    # orbitals are fixed parity rotations, independently of the final solve.
    physics,_,u=run.parameters(2,3,G=-.001)
    modes=PressureModes(physics.p,np.array([.02,4.,6.]),np.array([0.,.2,.1]),np.array([[.003,.7,.35],[.0015,.3,.6]]),np.array([.2,.1,.3]),'independent compressed-bath full-Fock control')
    M=3;N=4;NP=N+1;low=np.array([[n,0,0] for n in range(3)]);bath=np.array([[0,0,0],[0,1,0],[0,0,1]])
    initial=set(map(tuple,bath));rows=np.asarray([*map(tuple,bath),*[s for s in itertools.product([0],range(NP),range(NP)) if s not in initial]])
    coefficients=np.column_stack([modes.slope*np.sqrt(modes.p.hbar/(2*modes.omega)),modes.endpoint*np.sqrt(modes.p.hbar*modes.omega/2)])
    orbitals=[];generators=[];localfields=[]
    for b in (1.,3.):
        Us=np.tile(np.eye(N),(M,1,1))
        for j in range(M):
            for ix,theta in [([0,2],.015*b+.002*j),([1,3],.008*b-.001*j)]:Us[j][np.ix_(ix,ix)]=[[math.cos(theta),-math.sin(theta)],[math.sin(theta),math.cos(theta)]]
        orbitals.append(Us);g=run.rank.core.source_generators(bath,Us,coefficients,[1,2],rows);generators.extend([g['D'],g['Z_imag']]);localfields.extend(core.local_fields(Us,coefficients,[1,2]))
    source=np.asarray(localfields);G=np.column_stack([g.toarray() for g in generators]);G[:len(bath)]=0.;rowpar=rows.sum(axis=1)%2
    C=np.zeros((4,len(bath),3));start=0;pnew=np.array([0,1,1])
    for parity,k in [(0,1),(1,2)]:
        ix=np.flatnonzero(rowpar==parity);uu,ss,vh=np.linalg.svd(G[ix],full_matrices=False);assert ss[k-1]>1e-8
        C[:,:,start:start+k]=(vh[:k].T/ss[:k]).reshape(4,len(bath),k);start+=k
    rep=core.reconstruction(generators,C,len(bath),pnew);T=np.column_stack([np.eye(len(rows))[:,:len(bath)],rep['W']]);assert core.norm(T.T@T-np.eye(T.shape[1]))<2e-12
    P=core.Projector(bath,source,rep);metric=P.target('test_metric',core.mpo('product',[np.eye(NP)]*M));assert core.norm(metric-np.eye(len(bath)+3))<2e-11
    result.append(dict(name=run.CHECKS[1],passed=True,sparse_source_metric_error=rep['metric_diagnostics']['final_orthogonality'],factor_metric_error=core.norm(metric-np.eye(6)),old_identity_prefix_exact=bool(np.array_equal(T[:3,:3],np.eye(3)))))
    # Independent complete bare-Fock Hamiltonian/pressure: no production
    # characteristic or assemble helper appears on this reference route.
    bare_a=np.diag(np.sqrt(np.arange(1,NP+1)),1);xx=bare_a+bare_a.T;yy=1j*(bare_a.T-bare_a)
    x=xx[:NP,:NP];yi=yy[:NP,:NP].imag;X2=(xx@xx)[:NP,:NP];Y2=(yy@yy)[:NP,:NP].real;XYi=(xx@yy).imag[:NP,:NP]
    reference=np.sum((modes.branch*np.sqrt(modes.p.hbar/(2*modes.omega))[None,:])**2,axis=1)*1.07
    herrors=[];perrors=[];gramerrors=[];newmodels=[];densepairs=[];physical_zero_factor_checks=[]
    for b,beta in enumerate((1.,3.)):
        small,large,padding=core.extended_local(modes,u,beta,reference,orbitals[b]);projector=core.Projector(bath,source,rep)
        model,old,info=core.assemble(modes,low,bath,[0],small,large,projector,memory)
        assert info['old_common_blocks_exact_after_replay'] and model['bath_parities'].tolist()==[0,1,1,0,1,1]
        za,zb=model['pterms'][1];assert np.count_nonzero(za)==0 and core.norm(zb)>1e-6
        contract=next(x for x in info['common_block_replay'] if x['factor']=='pterms1')
        assert contract['declared_parity_change']==1 and contract['declared_adjoint_sign']==-1
        physical_zero_factor_checks.append(dict(beta=beta,active_norm=core.norm(za),bath_norm=core.norm(zb),declared_parity_change=1,declared_adjoint_sign=-1))
        Hraw=sum((modes.p.hbar*modes.omega[j]*embed_one(np.diag(np.arange(NP)),j,M,NP) for j in range(M)),np.zeros((NP**M,NP**M)))
        for r,kj in enumerate(modes.p.KJ):
            c=modes.branch[r]*np.sqrt(modes.p.hbar/(2*modes.omega));t2=-beta*u[r]/kj
            q2=sum((c[j]**2*embed_one(X2,j,M,NP) for j in range(M)),np.zeros_like(Hraw))
            for j in range(M):
                for k in range(j):q2+=2*c[j]*c[k]*embed_one(x,j,M,NP)@embed_one(x,k,M,NP)
            cosine=kron([displacement(NP,math.sqrt(t2)*c[j]) for j in range(M)]).real
            Hraw+=-kj/t2*(cosine-np.eye(NP**M)+t2*q2/2)+kj*t2*reference[r]*q2/4
        d,z=coefficients[:,0],coefficients[:,1]
        DF=sum((d[j]*embed_one(x,j,M,NP) for j in range(M)),np.zeros_like(Hraw));ZF=sum((z[j]*embed_one(yi,j,M,NP) for j in range(M)),np.zeros_like(Hraw))
        DD=sum((d[j]**2*embed_one(X2,j,M,NP) for j in range(M)),np.zeros_like(Hraw));ZZ=sum((z[j]**2*embed_one(Y2,j,M,NP) for j in range(M)),np.zeros_like(Hraw));DZ=sum((d[j]*z[j]*embed_one(XYi,j,M,NP) for j in range(M)),np.zeros_like(Hraw))
        for j in range(M):
            for k in range(M):
                if j!=k:
                    DD+=d[j]*d[k]*embed_one(x,j,M,NP)@embed_one(x,k,M,NP);ZZ-=z[j]*z[k]*embed_one(yi,j,M,NP)@embed_one(yi,k,M,NP);DZ+=d[j]*z[k]*embed_one(x,j,M,NP)@embed_one(yi,k,M,NP)
        Praw=DD/(2*modes.p.L0)+modes.p.C0*ZZ/2
        Us=large['orbitals'];bathmap=np.column_stack([np.kron(Us[1][:,s[1]],Us[2][:,s[2]]) for s in rows]);bathmap=bathmap@T
        fullmap=np.column_stack([np.kron(Us[0][:,n],bathmap[:,j]) for j in range(len(T.T)) for n in range(len(low))])
        HH=fullmap.T@Hraw@fullmap;PP=fullmap.T@Praw@fullmap;HH-=HH[0,0]*np.eye(len(HH));PP-=PP[0,0]*np.eye(len(PP))
        assembledH=core.frozen.original.full_tensor(model);assembledP=core.frozen.original.full_tensor(model,True)
        he=core.norm(HH-assembledH);pe=core.norm(PP-assembledP);assert he<5e-9 and pe<2e-10
        herrors.append(he);perrors.append(pe);newmodels.append(model);densepairs.append((HH,PP))
        p=rng.normal(size=(6,3));p[(model['bath_parities'][:,None]^model['low_parities'][None,:])!=0]=0.;p/=np.linalg.norm(p)
        sg=core.source_gram(model,p);v=fullmap@p.ravel();direct=np.array([[v@DD@v,v@DZ@v],[v@DZ@v,v@ZZ@v]])
        dproj=fullmap.T@DF@v;zproj=fullmap.T@ZF@v;directproj=np.array([[dproj@dproj,dproj@zproj],[dproj@zproj,zproj@zproj]])
        ge=max(core.norm(sg['complete']-direct),core.norm(sg['projected']-directproj));assert ge<3e-10;gramerrors.append(ge)
        assert np.linalg.norm(DD-DF@DF)>1 and np.linalg.norm(ZZ+ZF@ZF)>1
    result.append(dict(name=run.CHECKS[2],passed=True,independent_complete_bare_Fock_H_errors=herrors,independent_composite_pressure_errors=perrors,constant_shift_fixed_by_same_original_product_vacuum=True,full_cosine_beta=[1.,3.],physical_zero_active_nonzero_bath_checks=physical_zero_factor_checks))
    result.append(dict(name=run.CHECKS[3],passed=True,complete_physical_Gram_errors=gramerrors,primitive_contact_separator_positive=True,no_projected_field_square_substitution=True))
    # Use the same small physical full-cosine factors for direct/full graph,
    # checkpoint resume and pressure-moment comparisons. The new bath basis has
    # explicit parity, with no fake occupation rows passed to the solver.
    model=newmodels[0];Hfull,Pfull=densepairs[0];options=dict(tolerance=2e-14,max_iterations=80,damping=1.,compress=True,memory_mb=memory)
    with tempfile.TemporaryDirectory(dir=run.ROOT/'research/stage4',prefix='compressed-control-') as td:
        parent=Path(td);identity=dict(test='small-independent-physical',runtime=run.runtime())
        with run.storage.Cache(parent/'one',identity) as cache:one=run.graph.solve(model,cache=cache,**options)
        with run.storage.Cache(parent/'resume',identity) as cache:stage=run.graph.solve(model,cache=cache,phase='iterate',max_updates=1,**options)
        assert stage['status'] in ('ITERATION_CHECKPOINT_NOT_PHYSICAL_RESULT','CONVERGED_ITERATION_NOT_PHYSICAL_RESULT')
        with run.storage.Cache(parent/'resume',identity) as cache:converged=run.graph.solve(model,cache=cache,phase='iterate',**options)
        assert converged['status']=='CONVERGED_ITERATION_NOT_PHYSICAL_RESULT'
        with run.storage.Cache(parent/'resume',identity) as cache:resumed=run.graph.solve(model,cache=cache,phase='finalize',**options)
        with run.storage.Cache(parent/'resume',identity) as cache:cached=run.graph.solve(model,cache=cache,phase='finalize',**options)
        for index in (0,1,2):assert np.array_equal(one[index],resumed[index]) and np.array_equal(resumed[index],cached[index])
        H,P,w,ua,ub,par,e,vectors,ep,diag=resumed;run.previous.graph_gate(diag,len(model['HB']),e,ep,low_dimension=3)
        ee,vv=eigh(Hfull);err=float(np.max(abs(ee[:3]-(e+diag['hamiltonian_common_shift']))));assert err<2e-10
        embedding=np.kron(ub,ua)@w.reshape(-1,3);directP=embedding.T@Pfull@embedding;pe=core.norm(P-directP);assert pe<2e-10
        # Gauge-invariant even moments in the direct low eigenspace.
        E2,V2=eigh(H);pc=V2.T@P@V2;pd=vv[:,:3].T@Pfull@vv[:,:3];pc-=pc[0,0]*np.eye(3);pd-=pd[0,0]*np.eye(3)
        momenterrors=[]
        for order in (2,4,6,8):
            a=float(np.linalg.matrix_power(pc,order)[0,0]);b=float(np.linalg.matrix_power(pd,order)[0,0]);momenterrors.append(abs(a-b)/max(1.,abs(b)))
        assert max(momenterrors)<2e-8
        result.append(dict(name=run.CHECKS[4],passed=True,bitwise_iteration_resume=True,bitwise_cached_finalization=True,independent_low_spectrum_error=err,uncompressed_pressure_projection_error=pe,equal_time_even_moment_errors=momenterrors,all_original_ground_cluster_odd_gates=True))
        refusals=[]
        def bad_identity():
            with run.storage.Cache(parent/'resume',dict(identity,other=True)):pass
        assert rejected(bad_identity);refusals.append('cache_identity')
        with run.storage.Cache(parent/'corrupt',identity) as cache:cache.save_array('test',np.eye(3));cachefile=cache.directory/cache.record['arrays']['test']['file']
        with cachefile.open('ab') as f:f.write(b'bad')
        assert rejected(lambda:run.storage.Cache(parent/'corrupt',identity));refusals.append('committed_array_corruption')
        with run.storage.Cache(parent/'badmeta',identity) as cache:cache.save_array('scalar_phase',np.eye(2),metadata=dict(residual=1e-12));mp=cache.manifest
        mr=json.loads(mp.read_text());mr['metadata']['scalar_phase']['residual']=0.;mp.write_text(json.dumps(mr))
        assert rejected(lambda:run.storage.Cache(parent/'badmeta',identity));refusals.append('committed_scalar_metadata_corruption')
        assert rejected(lambda:core.source_gram(model,np.ones((6,3),complex)));refusals.append('complex_source_state')
        assert rejected(lambda:run.memory_plan(1024,'all'));refusals.append('insufficient_memory')
        bad=dict(model);bad['bath_parities']=np.zeros(5,dtype=int)
        with run.storage.Cache(parent/'badparity',identity) as cache:assert rejected(lambda:run.graph.solve(bad,cache=cache,**options))
        refusals.append('incomplete_parity_inventory')
        altered=copy.deepcopy(diag);altered['odd_sector_ground_block_lower_bound']=0.
        assert rejected(lambda:run.previous.graph_gate(altered,6,e,ep,low_dimension=3));refusals.append('failed_odd_ground_bound')
        with run.storage.Cache(parent/'partial',identity) as cache:assert rejected(lambda:run.graph.solve(model,cache=cache,phase='finalize',**options))
        refusals.append('finalize_without_converged_iteration')
        result.append(dict(name=run.CHECKS[5],passed=True,rejected=refusals,partial_cache_not_a_result=True))
    return result


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--spec',default='research/stage4/source_compressed_projection_spec.json');ap.add_argument('--output',required=True);a=ap.parse_args()
    memory=float(os.environ['PYSCF_MAX_MEMORY']);run.require(math.isfinite(memory) and memory>=1024,'1024MB declared small-control memory required');sp,*_=run.load_spec(a.spec)
    dest=run.path(a.output);run.require(dest.is_relative_to(run.ROOT/'research/stage4') and dest.suffix=='.json' and dest.parent.is_dir(),'exclusive stage4 controls output required')
    out=dict(format=run.FORMAT+'-controls',status='RUNNING',spec_sha256=run.sha(sp),source_sha256=run.sources(),runtime=run.runtime(),checks=[]);start=time.monotonic()
    with dest.open('x') as f:json.dump(out,f)
    def persist():out['elapsed_seconds']=time.monotonic()-start;run.save(dest,out)
    def terminate(signum,frame):raise RuntimeError('projection controls resource admission interrupted')
    signal.signal(signal.SIGTERM,terminate)
    try:
        out['checks']=controls(memory);run.require(tuple(x['name'] for x in out['checks'])==run.CHECKS and all(x['passed'] for x in out['checks']),'complete six-control inventory required')
        run.require(run.sources()==out['source_sha256'] and run.sha(sp)==out['spec_sha256'],'projection controls source/spec changed');out['status']='PASS';persist()
    except BaseException as exc:out.update(status='FAILED',error=repr(exc));persist();raise
    print('PASS six compressed-bath projection groups',flush=True)

if __name__=='__main__':main()
