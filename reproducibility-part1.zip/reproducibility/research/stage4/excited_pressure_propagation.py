"""Vacuum-accessible excited pressure paths in saved finite models; no solver rebuild.

Even q_(2j) are positive normalized-vector norms. This is a mechanism diagnostic,
not a physical source error bound or an asymptotic exponent fit.
"""
from pathlib import Path
from decimal import Decimal as D,localcontext
import argparse,hashlib,json,math,os,platform,signal,sys,time,uuid,zipfile
import numpy as np
import scipy
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'research/stage3'),str(ROOT/'src'),str(ROOT/'research')]
import analyze_saved_common_widths_2026_09_15 as ar
import quantum_multiscaling_positive_control as positive
FORMAT='stage4-excited-pressure-propagation-v1'
CHECKS=('signed_Hermitian_block_identities','known_gapless_positive_control',
        'zero_block_and_increment_filter','degenerate_rotation_invariance',
        'tiny_source_positive_norm_arithmetic','source_input_and_inventory_refusals')


def require(ok,message):
    if not ok:raise ValueError(message)


def path(name):
    p=(ROOT/name).resolve();require(p.is_relative_to(ROOT),'project-local path required');return p


def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def pin(binding):
    p=path(binding['path']);require(sha(p)==binding['sha256'],'input changed: '+str(p));return p


def source_hashes():
    paths={Path(__file__).resolve(),Path(__file__).with_name('excited_pressure_propagation_controls.py')}
    for module in list(sys.modules.values()):
        f=getattr(module,'__file__',None)
        if f:
            p=Path(f).resolve()
            if p.is_relative_to(ROOT) and p.suffix=='.py' and p.relative_to(ROOT).parts[0] in ('src','research'):paths.add(p)
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}


def runtime():
    return dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),
        declared_threads={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS')})


def save(p,value):
    tmp=p.with_name(p.name+'.writing-'+uuid.uuid4().hex)
    with tmp.open('x') as f:json.dump(value,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)


def claim(p,value):
    require(p.is_relative_to(ROOT/'research/stage4') and p.suffix=='.json','new stage4 JSON required')
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(value,f,allow_nan=False)


def control_gate(control,source,spec_hash):
    require(control.get('status')=='PASS' and control.get('format')=='stage4-excited-pressure-controls-v1','completed new controls required')
    require(tuple(c.get('name') for c in control.get('checks',[]))==CHECKS and all(c.get('passed') is True for c in control['checks']),'all six named controls required')
    require(control['source_sha256']==source and control['spec_sha256']==spec_hash and control['runtime']==runtime(),'control source/spec/runtime mismatch')


def spec_gate(spec):
    require(spec['format']==FORMAT and spec['beta']==1. and spec['hbar']==1. and spec['ratio']==2.,'fixed physical scope changed')
    require([j['label'] for j in spec['jobs']]==['R10_Q14','R10_Q16','R14_current','R18_native'],'job inventory changed')
    require(spec['scaled_gap_bands']==[.1,.5,1.,2.] and spec['scaled_energy_cuts']==[2.,4.,8.],'diagnostic band inventory changed')
    for name,h in spec['frozen_sources'].items():require(sha(path(name))==h,'frozen helper changed')
    for binding in spec['evidence'].values():pin(binding)
    old=json.loads(pin(spec['evidence']['positive_control']).read_text())
    require(old['status']=='COMPLETED_MATHEMATICAL_POSITIVE_CONTROL' and len(old['controls'])==4 and all(c['passed'] for c in old['controls']),'known positive control incomplete')
    require(old['source_sha256']==sha(Path(positive.__file__)),'positive control source mismatch')
    ac=json.loads(pin(spec['evidence']['arithmetic_control']).read_text());require(ac['new_arithmetic_controls']['status']=='PASS','frozen arithmetic controls incomplete')
    for name,h in ac['source_sha256'].items():require(sha(path(name))==h,'controlled arithmetic source mismatch')
    for job in spec['jobs']:
        pin(job['parent']);pin(job['archive']);require(len(job['taus'])>=3 and all(t>0 and math.isfinite(t) for t in job['taus']),'positive widths required')


def normalized_action(B,v):
    y=B@v;maximum=float(np.max(abs(y))) if len(y) else 0.
    if maximum==0:return np.zeros_like(v),D(0)
    z=y/maximum;n=float(np.linalg.norm(z))
    require(math.isfinite(n) and n>0,'nonfinite propagation norm')
    return z/n,D.from_float(maximum)*D.from_float(n)


def propagation(g,B):
    """No q_even subtraction or signed full-path accumulation."""
    require(B.shape==(len(g),len(g)) and np.isfinite(g).all() and np.isfinite(B).all(),'invalid block shapes/entries')
    maximum=float(np.max(abs(g))) if len(g) else 0.
    if maximum==0:return {k:D(0) for k in range(7)},dict(status='ZERO_VACUUM_COUPLING')
    z=g/maximum;n=float(np.linalg.norm(z));gnorm=D.from_float(maximum)*D.from_float(n)
    v0=z/n;vectors=[v0];norms=[D(1)]
    for _ in range(3):
        v,scale=normalized_action(B,vectors[-1]);vectors.append(v);norms.append(norms[-1]*scale)
    s=gnorm*gnorm;q={0:s}
    for j in range(1,4):q[2*j]=s*norms[j]**2
    for j in range(3):
        # Odd quantities needed only in the signed algebraic identity.
        inner=np.vdot(vectors[j].astype(np.clongdouble),vectors[j+1].astype(np.clongdouble))
        require(abs(inner.imag)<1e-12,'Hermitian odd moment gained imaginary part')
        q[2*j+1]=s*norms[j]*norms[j+1]*D(str(inner.real))
    return q,dict(status='POSITIVE_EVEN_NORM_RECURRENCE',initial_norm=ar.value(gnorm),
        successive_B_norm_factors=[ar.value(x) for x in norms[1:]],
        scope='binary64 matrix/vector actions plus normalized vectors and Decimal scalar products; no spectral/source accuracy improvement')


def identities(q):
    s=q[0]
    return {2:s,4:s*s+q[2],6:s**3+2*s*q[2]+q[1]**2+q[4],
        8:s**4+3*s*s*q[2]+q[2]**2+3*s*q[1]**2+2*q[1]*q[3]+2*s*q[4]+q[6]}


def q_report(q,info):
    s=q[0];ratios={}
    if s>0:
        ratios={str(p):ar.value(q[p-2]/s**(p//2)) for p in (4,6,8)}
    return dict(q={str(k):ar.value(v) for k,v in q.items()},propagation_ratios=ratios,arithmetic=info)


def diagnose(X):
    require(not np.iscomplexobj(X),'whole-moment helper admits saved real symmetric X only; complex q algebra is checked independently')
    require(np.linalg.norm(X-X.conj().T)<1e-12*max(np.linalg.norm(X),1e-300) and X[0,0]==0.,'centered Hermitian X required')
    q,qi=propagation(X[1:,0],X[1:,1:]);m,mi=ar.normalized_moments(X);summary=ar.summarize(m);pred=identities(q)
    err={str(p):float(abs(pred[p]-m[p])/m[p]) for p in (2,4,6,8)}
    require(max(err.values())<2e-8,'independent block/whole-moment identity disagreement')
    s=q[0];ranges={4:(s*s+q[2],s*s+q[2]),6:(s**3+q[4],D('2.5')*(s**3+q[4])),8:(D(2)/3*(s**4+q[6]),D(13)*(s**4+q[6]))}
    bounds={str(p):dict(lower_over_M=ar.value(lo/m[p]),upper_over_M=ar.value(hi/m[p])) for p,(lo,hi) in ranges.items()}
    require(all(lo<=m[p]*(1+D('2e-8')) and hi>=m[p]*(1-D('2e-8')) for p,(lo,hi) in ranges.items()),'universal block moment bound failed')
    answer=q_report(q,qi);answer.update(actual=summary,whole_vector_arithmetic=mi,identity_relative_errors=err,bound_checks=bounds,
        log_standardized_even_moments={str(p):float(m[p].ln()-D(p//2)*m[2].ln()) for p in (4,6,8)})
    return m,q,answer


def deletion_q_bounds(g,B,q,delta):
    # Conditional ONLY on the helper's deleted-entry operator envelope delta.
    # n*max|B_ij| and sqrt(n)*max|g_i| avoid an un-enclosed norm reduction.
    n=len(g);inflation=D(1)+D('1e-65')
    N=D(n)*ar.dec(float(np.max(abs(B))) if B.size else 0.)+delta
    G=D(n).sqrt()*inflation*ar.dec(float(np.max(abs(g))) if n else 0.)+delta
    records={}
    for j in range(4):
        eps=D(0) if delta==0 else (delta if j==0 else delta*N**j+D(j)*delta*N**(j-1)*G)
        envelope=(2*q[2*j].sqrt()*inflation*eps+eps*eps)*inflation
        logrel=float((envelope/q[2*j]).ln()) if envelope and q[2*j]>0 else None
        good=delta==0 or (q[2*j]>0 and (envelope==0 or logrel<math.log(1e-8)))
        records[str(2*j)]=dict(absolute_deleted_entry_envelope=ar.value(envelope),log_relative_deleted_entry_envelope=logrel,
            small_relative_to_q=good,status='DELETION_ENVELOPE_SMALL' if good else 'UNRESOLVED_UNDER_FILTER_DELETION')
    return dict(quantities=records,scope='telescoping deleted-entry perturbation only, conditional on supplied delta; retained filter/matrix/vector/eigenpair errors and physical source errors excluded')


def filtered_diagnostic(Pc,E,tau,increment,spec,eigen_error):
    X,fd,delta=ar.filtered(Pc,E,tau,increment,2.);m,q,answer=diagnose(X)
    norm=ar.dec(np.linalg.norm(X))*D('1.00000000001')+delta
    rel={str(p):float((D(p)*norm**(p-1)*delta/m[p]).ln()) if delta else None for p in (2,4,6,8)}
    require(all(v is None or v<math.log(1e-10) for v in rel.values()),'filter deletion is not negligible for raw moments')
    answer.update(tau=tau,observable='increment' if increment else 'ordinary',filter_arithmetic=fd,filter_deletion_log_relative_even_bounds=rel,
        q_filter_deletion_diagnostic=deletion_q_bounds(X[1:,0],X[1:,1:],q,delta),
        spectral_reconstruction=ar.spectral_check(X,m),energy_gap_uncertainty_estimate=eigen_error)
    g=X[1:,0];B=X[1:,1:];energy=E[1:];gap=energy[:,None]-energy[None,:]
    variants=[]
    for label,width in [('exact_zero_transfer',0.),('binary64_uncertainty_band',eigen_error)]+[('scaled_gap_'+str(eta),eta/tau) for eta in spec['scaled_gap_bands']]:
        mask=abs(gap)<=width;modified=B.copy();modified[mask]=0.
        qq,ii=propagation(g,modified)
        # Action change includes interference; q is not monotone under ablation.
        record=q_report(qq,ii);record.update(label=label,energy_width=width,removed_entries=int(mask.sum()),
            removed_B_frobenius=float(np.linalg.norm(B[mask])),
            q_even_ratio_to_full={str(p):ar.value(qq[p]/q[p]) if q[p]>0 else None for p in (2,4,6)},
            scope='fixed actual g, altered excited block; diagnostic ablation, not the physical increment or a source error bound')
        variants.append(record)
    answer['excited_transfer_ablations']=variants
    cuts=[]
    for cut in spec['scaled_energy_cuts']:
        keep=energy<=cut/tau;qq,ii=propagation(g[keep],B[np.ix_(keep,keep)])
        rr=q_report(qq,ii);rr.update(tau_energy_cut=cut,states=int(sum(keep)),variance_fraction=ar.value(qq[0]/q[0]),
            q_even_ratio_to_full={str(p):ar.value(qq[p]/q[p]) if q[p]>0 else None for p in (2,4,6)},
            states_within_cut_uncertainty=int(sum(abs(energy-cut/tau)<=eigen_error)),
            scope='joint restriction of vacuum excitation and excited propagation; measured finite-matrix sensitivity, not an omitted-source enclosure')
        cuts.append(rr)
    answer['excited_energy_cuts']=cuts
    return answer


def slopes(windows):
    answer=[]
    for obs in ('ordinary','increment'):
        rows=sorted((w for w in windows if w['observable']==obs),key=lambda w:w['tau'])
        for a,b in zip(rows,rows[1:]):
            dt=math.log(b['tau']/a['tau']);row=dict(observable=obs,widths=[a['tau'],b['tau']],signed_raw_moment_slopes={},signed_q_slopes={},signed_standardized_slopes={})
            for p in (2,4,6,8):row['signed_raw_moment_slopes'][str(p)]=(b['actual']['moments'][str(p)]['log_abs']-a['actual']['moments'][str(p)]['log_abs'])/dt
            for k in (0,2,4,6):
                aa=a['q'][str(k)]['log_abs'];bb=b['q'][str(k)]['log_abs']
                resolved=a['q_filter_deletion_diagnostic']['quantities'][str(k)]['small_relative_to_q'] and b['q_filter_deletion_diagnostic']['quantities'][str(k)]['small_relative_to_q']
                row['signed_q_slopes'][str(k)]=(bb-aa)/dt if aa is not None and bb is not None and resolved else None
            for p in (4,6,8):row['signed_standardized_slopes'][str(p)]=(b['log_standardized_even_moments'][str(p)]-a['log_standardized_even_moments'][str(p)])/dt
            row['scope']='finite-grid signed slopes only; no existence of limiting exponents or power-law verdict inferred';answer.append(row)
    return answer


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--spec',default='research/stage4/excited_pressure_propagation_spec.json');ap.add_argument('--controls',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    sp=path(a.spec);spec=json.loads(sp.read_text());spec_gate(spec);source=source_hashes();cp=path(a.controls);control=json.loads(cp.read_text());control_gate(control,source,sha(sp))
    memory=float(os.environ['PYSCF_MAX_MEMORY']);require(math.isfinite(memory) and memory>=512,'at least512MB declared memory required')
    out=dict(format=FORMAT,status='RUNNING_NOT_A_RESULT',spec=spec,spec_sha256=sha(sp),source_sha256=source,runtime=runtime(),memory_mb=memory,controls=dict(path=str(cp.relative_to(ROOT)),sha256=sha(cp)),cases=[],comparisons=[],
        scope='saved complete supplied pressure in finite retained vacuum sectors; not a full-source error certificate, common-interior limit or measured temporal burst model')
    dest=path(a.output);claim(dest,out);begin=time.monotonic()
    def finish():out['elapsed_seconds']=time.monotonic()-begin;save(dest,out)
    def interrupted(sig,frame):raise RuntimeError('resource guard interrupted diagnostic')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        with localcontext() as ctx:
            ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
            for job in spec['jobs']:
                parent=json.loads(pin(job['parent']).read_text());require(parent['status']=='COMPLETED','physical parent incomplete');case=parent['cases'][job['case_index']]
                require(case['status']=='COMPLETED' and all(case.get(k)==v for k,v in job['physical'].items()),'physical case changed')
                rows=[r for r in case['cosine'] if r['beta']==1.];require(len(rows)==1,'unique beta1 row required');row=rows[0];dg=row['diagnostics']
                require(row['effective_archive']==job['archive']['path'],'parent/archive path mismatch')
                if row.get('effective_archive_sha256') is not None:require(row['effective_archive_sha256']==job['archive']['sha256'],'parent archive digest mismatch')
                require(dg['even_ground_certified_against_odd'] is True and dg['retained_cluster_certification_margin']>0,'original ground/cluster gates absent')
                aa=pin(job['archive'])
                with zipfile.ZipFile(aa) as z:require(sum(v.file_size for v in z.infolist())<.3*memory*1024**2,'archive exceeds admitted inventory')
                with np.load(aa,allow_pickle=False) as z:
                    require({'H','P','omega','couplings','reference','retained_sector'}<=set(z.files),'required archive provenance arrays missing')
                    H=z['H'].copy();P=z['P'].copy();omega=z['omega'].copy()
                    require('even' in str(z['retained_sector'].item()),'archive is not the declared even sector')
                    require(np.array_equal(omega,np.asarray(case['omega'])) and np.array_equal(z['couplings'],np.asarray(case['couplings'])),'archive frequency/coupling identity mismatch')
                    ref=case.get('reference_variances',case.get('fixed_calibration_variances'))
                    require(ref is not None and np.array_equal(z['reference'],np.asarray(ref)),'archive fixed reference mismatch')
                require(96*len(H)**2+256*1024**2<.7*memory*1024**2,'matrix workspace exceeds70% budget')
                require(len(omega)==case['M'] and H.shape==P.shape and np.isfinite(H).all() and np.isfinite(P).all(),'archive matrix schema failed')
                E,Pc,mean,ed=ar.eigen_prepare(H,P);uncertainty=2*ed['eigensolve_residual_frobenius']+64*np.finfo(float).eps*max(float(np.linalg.norm(H)),1e-300)
                replay=[]
                for old in row['windows']:
                    X,_,_=ar.filtered(Pc,E,old['tau'],True,2.);mm,_=ar.normalized_moments(X)
                    errors={str(p):float(abs(mm[p]/ar.dec(old['moments'][str(p)])-1)) for p in (2,4,6,8)}
                    require(max(errors.values())<2e-8,'original saved moment replay failed');replay.append(dict(tau=old['tau'],relative_errors=errors))
                result=dict(label=job['label'],physical=job['physical'],window_scope=job['window_scope'],retained_dimension=len(E),parent_binding=job['parent'],archive_binding=job['archive'],
                    original_historical_source_sha256=parent['source_sha256'],original_diagnostics=dg,eigensolve=ed,actual_ground_mean_removed=mean,
                    saved_increment_replay=replay,windows=[],
                    uncertainty_scope='eigensolve residual and binary64 norm allowance are diagnostics, not interval eigenvalue/source enclosures; deleted-entry q envelopes exclude retained-entry/filter arithmetic and source errors')
                for tau in job['taus']:
                    for inc in (False,True):
                        value=filtered_diagnostic(Pc,E,tau,inc,spec,uncertainty);value['tau_first_retained_even_gap']=tau*E[1];result['windows'].append(value)
                result['intervals']=slopes(result['windows']);out['cases'].append(result);finish()
            left,right=out['cases'][:2]
            for a0,b0 in zip(left['windows'],right['windows']):
                require((a0['tau'],a0['observable'])==(b0['tau'],b0['observable']),'Q sensitivity window mismatch')
                out['comparisons'].append(dict(labels=[left['label'],right['label']],tau=a0['tau'],observable=a0['observable'],
                    q_relative_changes={str(k):ar.value(D(b0['q'][str(k)]['decimal'])/D(a0['q'][str(k)]['decimal'])-1) if a0['q'][str(k)]['sign'] else None for k in (0,2,4,6)},
                    log_J_changes={str(p):b0['propagation_ratios'][str(p)]['log_abs']-a0['propagation_ratios'][str(p)]['log_abs'] if a0['propagation_ratios'][str(p)]['log_abs'] is not None and b0['propagation_ratios'][str(p)]['log_abs'] is not None else None for p in (4,6,8)},scope='combined occupation/selection sensitivity; not an error radius'))
        spec_gate(spec);require(source_hashes()==source and sha(sp)==out['spec_sha256'] and sha(cp)==out['controls']['sha256'],'source/control/spec changed during diagnostic')
        out['warnings']=['No common-interior convergence or asymptotic exponent verdict from these saved models.','Original source/graph/occupation/bath/mode errors remain separate; deleted-entry q envelopes exclude retained-entry/filter/vector/eigenpair errors, and unresolved q slopes are suppressed.','Near-degenerate bands and energy cuts are sensitivity tests, not exact spectral projectors of an independently certified Hamiltonian.']
        if any(not w['spectral_reconstruction']['passed'] for c in out['cases'] for w in c['windows']):out['warnings'].append('Some direct spectral reconstruction is unresolved; controlled norm recurrence retained and no CDF completeness claimed.')
        out['status']='COMPLETED_WITH_WARNINGS';finish()
    except BaseException as exc:out.update(status='FAILED',error=repr(exc));finish();raise


if __name__=='__main__':main()
