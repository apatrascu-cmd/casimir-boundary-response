"""Small identity-bound atomic cache for new compressed-bath runs only."""
from __future__ import annotations
import hashlib,json,os,uuid
from pathlib import Path
import numpy as np


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


def save_json(path,value):
    temp=path.with_name(path.name+'.writing-'+uuid.uuid4().hex)
    with temp.open('x') as f:f.write(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
    os.replace(temp,path)


class Cache:
    """Single-writer cache. A committed manifest points only to complete files.

    Superseded iteration arrays are removed only after an atomic new manifest.
    A crash before the manifest leaves an unreferenced file, never reusable data.
    """
    def __init__(self,directory,identity):
        self.directory=Path(directory);self.identity=identity;self.reused=[]
        self.directory.mkdir(parents=False,exist_ok=True)
        self.lock=self.directory/'LOCK';self.lockfd=os.open(self.lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        os.write(self.lockfd,str(os.getpid()).encode());os.fsync(self.lockfd)
        try:
            self.manifest=self.directory/'manifest.json'
            if self.manifest.exists():
                self.record=json.loads(self.manifest.read_text())
                require(self.record.get('format')=='stage4-compressed-bath-cache-v1' and self.record['identity']==identity,'compressed cache identity/runtime/source differs')
                self.validate_all()
            else:
                require(set(p.name for p in self.directory.iterdir())=={'LOCK'},'uninitialized nonempty cache directory')
                self.record=dict(format='stage4-compressed-bath-cache-v1',identity=identity,arrays={},metadata={});save_json(self.manifest,self.record)
        except BaseException:self.close();raise
    def close(self):
        if getattr(self,'lockfd',None) is not None:os.close(self.lockfd);self.lockfd=None;self.lock.unlink()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def validate_all(self):
        for key,item in self.record['arrays'].items():
            require(hashlib.sha256(canonical(self.record['metadata'].get(key)).encode()).hexdigest()==item['metadata_sha256'],'committed cache metadata corrupt: '+key)
            p=self.directory/item['file'];require(p.parent==self.directory and p.suffix=='.npy','unsafe cache array path')
            require(p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],'committed compressed cache array corrupt: '+key)
    def load_array(self,key):
        if key not in self.record['arrays']:return None
        item=self.record['arrays'][key];p=self.directory/item['file'];require(sha(p)==item['sha256'],'cached array changed')
        require(hashlib.sha256(canonical(self.record['metadata'].get(key)).encode()).hexdigest()==item['metadata_sha256'],'cached metadata changed')
        a=np.load(p,allow_pickle=False);require(list(a.shape)==item['shape'] and str(a.dtype)==item['dtype'],'cached array header differs')
        self.reused.append(key);return a
    def save_array(self,key,array,replace=False,metadata=None):
        require(key and all(c.isalnum() or c in '_-' for c in key),'unsafe cache key')
        require(replace or key not in self.record['arrays'],'immutable factor already cached')
        a=np.asarray(array);require(a.dtype.kind in 'fciub' and np.isfinite(a).all(),'finite numerical cache array required')
        old=self.record['arrays'].get(key);p=self.directory/(key+'-'+uuid.uuid4().hex+'.npy')
        with p.open('xb') as f:np.save(f,a,allow_pickle=False);f.flush();os.fsync(f.fileno())
        self.record['arrays'][key]=dict(file=p.name,sha256=sha(p),bytes=p.stat().st_size,shape=list(a.shape),dtype=str(a.dtype))
        if metadata is not None:self.record['metadata'][key]=metadata
        self.record['arrays'][key]['metadata_sha256']=hashlib.sha256(canonical(self.record['metadata'].get(key)).encode()).hexdigest()
        save_json(self.manifest,self.record)
        if old is not None:(self.directory/old['file']).unlink()
    def metadata(self,key):return self.record['metadata'].get(key)
    def receipt(self):
        self.validate_all();return dict(path=str(self.directory),manifest_sha256=sha(self.manifest),identity=self.identity,
          committed_array_sha256={k:v['sha256'] for k,v in self.record['arrays'].items()},reused=list(self.reused),
          scope='cache phases only; neither cache existence nor converged iteration alone is a physical completion result')
