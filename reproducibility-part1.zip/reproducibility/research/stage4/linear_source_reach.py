"""Prepare-only mode-resolved source reach for a real, even tensor ground state.

This is an algebraic source diagnostic, not an energy-placement or closure
certificate. Complete quadratic contacts and projected linear products are
kept separate. No Hamiltonian solve or physical run is performed here.
"""
from __future__ import annotations
import math, os
import numpy as np

FORMAT='stage4-linear-source-reach-v1'


def require(ok,message):
    if not ok:raise ValueError(message)


def _structure(states):
    n=len(states);count=np.zeros((n,n),np.uint8)
    first=np.zeros((n,n),np.int16);second=first.copy()
    for j in range(states.shape[1]):
        changed=states[:,j,None]!=states[None,:,j]
        first[(count==0)&changed]=j;second[(count==1)&changed]=j
        count+=changed
    return count,first,second


def _group_matrices(states,local,kind,structure):
    count,first,_=structure;rr,cc=np.nonzero(count==1)
    out=np.zeros((states.shape[1],len(states),len(states)))
    jj=first[rr,cc]
    out[jj,rr,cc]=local[kind][jj,states[rr,jj],states[cc,jj]]
    return out


def _group_complete_covariance(states,local,rho,structure):
    """XX and YY on a factor; local parity makes linear diagonals zero.

    The two-mode entry is assembled directly from its two different local
    factors, not by multiplying finite configuration-space linear matrices.
    """
    M=states.shape[1];answer={k:np.zeros((M,M)) for k in ('X','Yi')}
    count,first,second=structure;rr,cc=np.nonzero(count==1);jj=first[rr,cc]
    for kind,square in [('X','X2'),('Yi','Y2')]:
        same=np.array([np.dot(np.diag(rho),local[square][j,states[:,j],states[:,j]]) for j in range(M)])
        values=rho[cc,rr]*local[square][jj,states[rr,jj],states[cc,jj]]
        np.add.at(same,jj,values)
        np.fill_diagonal(answer[kind],same)
    rr,cc=np.nonzero(count==2);jj,kk=first[rr,cc],second[rr,cc]
    for kind,sign in [('X',1.),('Yi',-1.)]:
        values=(sign*rho[cc,rr]*local[kind][jj,states[rr,jj],states[cc,jj]]
                *local[kind][kk,states[rr,kk],states[cc,kk]])
        np.add.at(answer[kind],(jj,kk),values)
        np.add.at(answer[kind],(kk,jj),values)
    return answer


def source_reach(model,modes,psi,memory_mb=None,return_seeds=False):
    """Return full-contact/projected/outside source Grams, without PSD repair.

    psi has original factor coordinates (bath,low), *not* graph-rotated
    coordinates. Modal order is [X_0,...,X_(M-1), Yi_0,...,Yi_(M-1)], where
    Yi=Im[Y]=a^dagger-a and a source seed is Yi psi. These real seed overlaps
    have the correct sign for z_j=-<g|Im Z|j> in tensor_wick_sources.
    """
    low=np.asarray(model['low_states']);bath=np.asarray(model['bath_states'])
    p=np.asarray(psi)
    require(p.dtype.kind=='f' and p.shape==(len(bath),len(low)) and np.isfinite(p).all(),'finite real original-coordinate ground matrix required')
    require(low.ndim==bath.ndim==2 and low.shape[1]==bath.shape[1],'invalid factor states')
    M=low.shape[1];nl=len(low);nb=len(bath)
    memory=float(os.environ['PYSCF_MAX_MEMORY'] if memory_mb is None else memory_mb)
    estimate=64*1024**2+8*(6*M*(nl*nl+nb*nb)+4*M*nl*nb+12*(nl*nl+nb*nb))
    require(math.isfinite(memory) and memory>0 and estimate<.6*memory*10**6,'source-reach workspace exceeds declared memory')
    require(np.all(low>=0) and np.all(bath>=0),'negative modal occupations')
    active_low=np.max(low,axis=0)>0;active_bath=np.max(bath,axis=0)>0
    require(not np.any(active_low&active_bath),'factor modal supports overlap')
    # A mode frozen in both factors is assigned to the bath for its contacts.
    group_low=active_low;group_bath=~group_low
    norm=float(np.sum(p*p));require(abs(norm-1)<1e-9,'ground is not normalized; no silent normalization')
    forbidden=((bath.sum(axis=1)%2)[:,None]^(low.sum(axis=1)%2)[None,:])!=0
    parity_error=float(np.linalg.norm(p[forbidden]));require(parity_error<1e-11,'ground has unresolved odd contamination')
    pack=model['local'];local={k:np.asarray(pack[k]).real for k in ('X','X2','Y2')};local['Yi']=np.asarray(pack['Y']).imag
    require(max(float(np.linalg.norm(np.asarray(pack[k]).imag)) for k in ('X','X2','Y2'))<1e-11 and float(np.linalg.norm(np.asarray(pack['Y']).real))<1e-11,'local real/imaginary convention differs')
    N=local['X'].shape[-1]
    require(all(a.shape==(M,N,N) and np.isfinite(a).all() for a in local.values()),'local quadrature schema differs')
    require(max(int(low.max()),int(bath.max()))<N,'factor occupation outside primitive orbitals')
    require('orbitals' in pack,'orthogonal real primitive orbitals required for canonical mixed contact')
    U=np.asarray(pack['orbitals']);require(U.dtype.kind=='f' and U.shape==(M,N,N),'real square primitive orbitals required')
    orbital_error=float(max(np.linalg.norm(u.T@u-np.eye(N)) for u in U));require(orbital_error<1e-10,'primitive orbitals not numerically orthogonal')
    local_scale=max(1.,max(float(np.linalg.norm(a)) for a in local.values()))
    local_error=max(float(np.linalg.norm(local['X']-local['X'].transpose(0,2,1))),float(np.linalg.norm(local['Yi']+local['Yi'].transpose(0,2,1))),float(np.linalg.norm(np.diagonal(local['X'],axis1=1,axis2=2))),float(np.linalg.norm(np.diagonal(local['Yi'],axis1=1,axis2=2))))
    require(local_error<256*np.finfo(float).eps*local_scale,'local real/parity conventions unresolved')
    # Independently bind the complete-contact convention to the supplied U.
    ladder=np.diag(np.sqrt(np.arange(1,N+1)),1);xc=ladder+ladder.T;yc=ladder.T-ladder
    primitive={'X':xc[:N,:N],'Yi':yc[:N,:N],'X2':(xc@xc)[:N,:N],'Y2':(-yc@yc)[:N,:N]}
    contact_error=max(float(np.linalg.norm(local[k]-np.asarray([u.T@v@u for u in U]))) for k,v in primitive.items())
    require(contact_error<512*np.finfo(float).eps*local_scale,'local arrays do not match complete canonical contacts in the supplied orbitals')
    structures=[_structure(low),_structure(bath)]
    matrices={kind:(_group_matrices(low,local,kind,structures[0]),_group_matrices(bath,local,kind,structures[1])) for kind in ('X','Yi')}
    actions=[]
    for kind in ('X','Yi'):
        ls,bs=matrices[kind]
        actions.extend((p@ls[j].T+bs[j]@p).ravel() for j in range(M))
    actions=np.asarray(actions);projected=actions@actions.T
    rhoL=p.T@p;rhoB=p@p.T
    fullL=_group_complete_covariance(low,local,rhoL,structures[0]);fullB=_group_complete_covariance(bath,local,rhoB,structures[1])
    complete=projected.copy()
    for offset,kind in [(0,'X'),(M,'Yi')]:
        for mask,data in [(group_low,fullL),(group_bath,fullB)]:
            ids=np.flatnonzero(mask);complete[np.ix_(ids+offset,ids+offset)]=data[kind][np.ix_(ids,ids)]
    # For a real state in the complete canonical oscillator Hilbert space,
    # <X_j psi,Yi_k psi>=delta_jk. For j!=k the product is antisymmetric;
    # for j=k its symmetric part is I. This is not the finite-X/Y commutator.
    complete[:M,M:]=np.eye(M)*norm;complete[M:,:M]=np.eye(M)*norm
    outside=complete-projected
    omega=np.asarray(modes.omega,dtype=float);slope=np.asarray(modes.slope,dtype=float);endpoint=np.asarray(modes.endpoint,dtype=float)
    require(all(v.shape==(M,) and np.isfinite(v).all() for v in (omega,slope,endpoint)) and np.all(omega>0),'invalid physical modal source coefficients')
    require(all(math.isfinite(v) and v>0 for v in (modes.p.hbar,modes.p.C0,modes.p.L0)),'positive finite physical normalizations required')
    d=slope*np.sqrt(modes.p.hbar/(2*omega))
    z=endpoint*np.sqrt(modes.p.hbar*omega/2)
    coeff=np.zeros((2*M,2));coeff[:M,0]=d;coeff[M:,1]=z
    physical={key:coeff.T@g@coeff for key,g in [('complete',complete),('projected',projected),('outside',outside)]}
    eig=np.linalg.eigvalsh((outside+outside.T)/2)
    weighted=np.concatenate([d/math.sqrt(modes.p.L0),z*math.sqrt(modes.p.C0)])
    weighted_gram=weighted[:,None]*outside*weighted[None,:]
    result=dict(format=FORMAT,modal_complete_gram=complete,modal_projected_gram=projected,modal_outside_gram=outside,
        weighted_modal_outside_gram=weighted_gram,physical_grams=physical,
        coefficients=np.column_stack([d,z]),
        diagnostics=dict(ground_norm=norm,ground_forbidden_parity_norm=parity_error,orbital_orthogonality_error=orbital_error,
          local_symmetry_or_diagonal_error=local_error,complete_canonical_contact_replay_error=contact_error,outside_asymmetry_frobenius=float(np.linalg.norm(outside-outside.T)),
          outside_symmetric_part_eigenvalues=eig,negative_eigenvalue_count=int(np.count_nonzero(eig<0)),
          physical_outside_covariance_scale=float(physical['outside'][0,0]/modes.p.L0+modes.p.C0*physical['outside'][1,1]),
          mixed_complete_contact=float(physical['complete'][0,1]),canonical_mixed_expected=float(d@z)*norm,
          low_mode_indices=np.flatnonzero(group_low),bath_or_frozen_mode_indices=np.flatnonzero(group_bath),
          estimated_bytes=estimate,memory_mb=memory),
        scope='complete canonical quadratic contacts of the supplied real primitive-supported state minus source action projected into this tensor; no energy placement, graph correction, mode limit or probability certificate')
    if return_seeds:result['projected_physical_seeds']=(actions.T@coeff).reshape(nb,nl,2)
    return result
