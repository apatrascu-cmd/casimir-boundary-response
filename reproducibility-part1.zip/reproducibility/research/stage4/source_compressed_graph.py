"""New explicit-parity checkpoint adapter copied from frozen full-parity solver.

Iteration arithmetic, compression, original H/P actions and scientific gates
are unchanged. Only parity input and identity-bound phase persistence differ.
No result is complete until all final gates have run.
"""
from __future__ import annotations
import hashlib
import numpy as np
from tensor_wick_sources import _memory_gate
from tensor_cosine import compress_terms,operator_norm_bound
from tensor_even_graph import block_parity_eigh
from source_compressed_projection import require

def solve(model, tolerance, max_iterations, damping, compress, memory_mb, cache, phase="all", max_updates=None):
    """Same original uncompressed final gates, with explicit parity/checkpoints.

    phase=iterate stops after a committed convergence checkpoint. finalize
    requires that checkpoint and freshly rechecks the Riccati residual first.
    """
    require(phase in ("all","iterate","finalize"),"invalid graph phase")
    require(max_updates is None or isinstance(max_updates,int) and max_updates>0,"positive update cap required")
    nl, nb = len(model['HL']), len(model['HB'])
    estimate = _memory_gate(12*8*nb*nl*nl, memory_mb)
    lp0, bp0 = np.asarray(model['low_parities']), np.asarray(model['bath_parities'])
    require(lp0.shape==(nl,) and bp0.shape==(nb,) and np.isin(lp0,[0,1]).all() and np.isin(bp0,[0,1]).all(), 'explicit complete parity inventory required')
    raw_eb, ub, bp, bdiag = block_parity_eigh(model['HB'], bp0)
    if nb < 2 or bp[0] != 0:
        raise ArithmeticError('nontrivial bath with an even ground is required')
    eb = raw_eb-raw_eb[0]
    bt = [(a, ub.T@b@ub) for a, b in model['hterms']]
    active = model['HL'].copy()
    for a, b in bt:
        active += b[0, 0]*a
    raw_ea, ua, lp, adiag = block_parity_eigh(active, lp0)
    if lp[0] != 0 or not np.any(lp == 1):
        raise ArithmeticError('active basis must have even ground and odd states')
    ea = raw_ea-raw_ea[0]
    original = [(ua.T@a@ua, b) for a, b in bt]
    centered = [(a, b-b[0, 0]*np.eye(nb)) for a, b in original]
    ts, comp = centered, None
    eta = 0.
    if compress and ts:
        ts, comp = compress_terms(ts)
        comp = dict(comp)
        eta = comp['discarded_frobenius_bound']
    reset = 0.
    terms = []
    for a, b in ts:
        reset += operator_norm_bound(a)*abs(float(b[0, 0]))
        b = b.copy(); b[0, 0] = 0.
        terms.append((a, b))
    ts = terms; eta += reset
    if comp is not None:
        comp.update(center_reset_norm_bound=float(reset), total_operator_error_bound=float(eta))
    allowed = ((bp[:, None, None] ^ lp[None, :, None]) == lp[None, None, :])
    aq = allowed[1:]
    den = eb[1:, None, None]+ea[None, :, None]-ea[None, None, :]
    separation = float(np.min(den[aq]))
    if separation <= 0:
        raise ArithmeticError('bath overlaps the full retained active window')
    den[~aq] = 1.
    coupling = np.zeros((nb-1, nl, nl))
    for a, b in ts:
        coupling += b[1:, 0, None, None]*a
    coupling[~aq] = 0.
    omega = -coupling/den
    history = []
    checkpoint = cache.load_array('graph_omega')
    meta = cache.metadata('graph_omega')
    if checkpoint is not None:
        require(checkpoint.shape==omega.shape and checkpoint.dtype==omega.dtype,'graph checkpoint shape/dtype differs')
        require(meta['tolerance']==tolerance and meta['damping']==damping and meta['max_iterations']==max_iterations and meta['compress']==compress,'graph checkpoint iteration settings differ')
        require(np.array_equal(checkpoint[~aq],np.zeros_like(checkpoint[~aq])),'checkpoint forbidden parity is nonzero')
        require(float(np.linalg.norm(checkpoint))<=2,'checkpoint graph outside admitted neighborhood')
        omega=checkpoint;history=list(meta['history'])
    if phase=='finalize':require(meta is not None and meta['converged'] is True,'finalization requires committed converged iteration')
    def commit(converged):
        cache.save_array('graph_omega',omega,replace=True,metadata=dict(history=history,converged=converged,tolerance=tolerance,damping=damping,max_iterations=max_iterations,compress=compress))
    updates=0

    def off_apply(w):
        y = np.zeros_like(w)
        for a, b in ts:
            y += (b[1:, 1:]@np.matmul(a, w).reshape(nb-1, -1)).reshape(w.shape)
        y[~aq] = 0.
        return y

    for _ in range(1 if meta is not None and meta["converged"] else max_iterations-len(history)):
        feedback = np.einsum('bij,bik->jk', coupling, omega, optimize=True)
        residual = coupling+den*omega+off_apply(omega)-omega@feedback
        residual[~aq] = 0.
        value = float(np.linalg.norm(residual)); history.append(value)
        if value < tolerance:
            commit(True)
            if phase=='iterate':return dict(status='CONVERGED_ITERATION_NOT_PHYSICAL_RESULT',riccati_residual_history=history,cache=cache.receipt())
            break
        require(phase!='finalize','converged checkpoint fails fresh residual recheck')
        omega -= damping*residual/den
        omega[~aq] = 0.
        if not np.isfinite(omega).all() or np.linalg.norm(omega) > 2:
            raise ArithmeticError('full-parity source graph left admitted neighborhood')
        commit(False);updates+=1
        if max_updates is not None and updates>=max_updates:
            return dict(status='ITERATION_CHECKPOINT_NOT_PHYSICAL_RESULT',riccati_residual_history=history,cache=cache.receipt())
    else:
        raise ArithmeticError('full-parity source graph failed to converge')
    # Residual/convergence is committed before the distinct metric and
    # embedding stages. Resumption may reuse either complete stage separately.
    omega_binding=cache.record['arrays']['graph_omega']['sha256']
    basis_binding=hashlib.sha256(np.ascontiguousarray(ua).tobytes()+np.ascontiguousarray(ub).tobytes()).hexdigest()
    sinv=cache.load_array('graph_sinv')
    if sinv is None:
        metric = np.eye(nl)+np.einsum('bij,bik->jk', omega, omega, optimize=True)
        se, su, _, _ = block_parity_eigh(metric, lp)
        sinv = (su/np.sqrt(se))@su.T
        graph_spectral_norm = float(np.sqrt(max(0., se[-1]-1.)))
        if graph_spectral_norm >= 1:
            raise ArithmeticError('source graph is outside the low-cluster angular neighborhood')
        graph_norm = float(np.linalg.norm(omega))
        cache.save_array('graph_sinv',sinv,metadata=dict(omega_binding=omega_binding,basis_binding=basis_binding,graph_spectral_norm=graph_spectral_norm,graph_norm=graph_norm))
    else:
        smeta=cache.metadata('graph_sinv')
        require(smeta['omega_binding']==omega_binding and smeta['basis_binding']==basis_binding,'metric phase graph/coordinate identity differs')
        graph_spectral_norm=float(smeta['graph_spectral_norm']);graph_norm=float(smeta['graph_norm'])
        require(np.isfinite(sinv).all() and np.isfinite(graph_spectral_norm) and 0<=graph_spectral_norm<1 and 0<=graph_norm<=2,'cached metric/angular gate unresolved')
    w=cache.load_array('graph_embedding')
    if w is None:
        w = np.empty((nb, nl, nl)); w[0] = sinv; w[1:] = omega@sinv
        forbidden = float(np.linalg.norm(w[~allowed]))
        orthogonality_error=float(np.linalg.norm(np.einsum('bij,bik->jk',w,w)-np.eye(nl)))
        require(forbidden==0 and orthogonality_error<2e-9,'normalized graph parity/metric unresolved')
        cache.save_array('graph_embedding',w,metadata=dict(omega_binding=omega_binding,basis_binding=basis_binding,sinv_binding=cache.record['arrays']['graph_sinv']['sha256'],forbidden=forbidden,orthogonality_error=orthogonality_error))
    else:
        wmeta=cache.metadata('graph_embedding')
        require(wmeta['omega_binding']==omega_binding and wmeta['basis_binding']==basis_binding and wmeta['sinv_binding']==cache.record['arrays']['graph_sinv']['sha256'],'embedding phase graph/metric identity differs')
        require(w.shape==(nb,nl,nl) and np.isfinite(w).all(),'cached normalized embedding shape/values invalid')
        forbidden=float(wmeta['forbidden']);orthogonality_error=float(wmeta['orthogonality_error'])
        require(forbidden==0 and 0<=orthogonality_error<2e-9,'cached embedding parity/orthogonality gate unresolved')
    del omega, den, coupling, residual, feedback, allowed, aq
    hl = ua.T@model['HL']@ua-raw_ea[0]*np.eye(nl)
    hb = ub.T@model['HB']@ub-raw_eb[0]*np.eye(nb)
    coordinate_binding=hashlib.sha256(np.ascontiguousarray(ua).tobytes()+np.ascontiguousarray(ub).tobytes()+np.ascontiguousarray(sinv).tobytes()).hexdigest()
    omega_binding=cache.record['arrays']['graph_omega']['sha256']
    cached_h=cache.load_array('final_heff')
    if cached_h is None:
        hw = np.matmul(hl, w)+(hb@w.reshape(nb, -1)).reshape(w.shape)
        for a, b in original:
            hw += (b@np.matmul(a, w).reshape(nb, -1)).reshape(w.shape)
        heff = np.einsum('bij,bik->jk', w, hw, optimize=True)
        heff = (heff+heff.T)/2
        hw -= w@heff
        invariant_residual = float(np.linalg.norm(hw)); del hw
        cache.save_array('final_heff',heff,metadata=dict(invariant_residual_frobenius=invariant_residual,coordinate_binding=coordinate_binding,omega_binding=omega_binding))
    else:
        require(cache.metadata('final_heff')['coordinate_binding']==coordinate_binding and cache.metadata('final_heff')['omega_binding']==omega_binding,'cached H graph/coordinate identity differs')
        heff=cached_h;invariant_residual=float(cache.metadata('final_heff')['invariant_residual_frobenius'])
    cached_p=cache.load_array('final_peff')
    if cached_p is None:
        pl, pb = ua.T@model['PL']@ua, ub.T@model['PB']@ub
        pw = np.matmul(pl, w)+(pb@w.reshape(nb, -1)).reshape(w.shape)
        for a, b in model['pterms']:
            pw += ((ub.T@b@ub)@np.matmul(ua.T@a@ua, w).reshape(nb, -1)).reshape(w.shape)
        peff = np.einsum('bij,bik->jk', w, pw, optimize=True)
        peff = (peff+peff.T)/2
        pw -= w@peff
        pressure_source = float(np.linalg.norm(pw)); del pw
        cache.save_array('final_peff',peff,metadata=dict(low_high_source_frobenius=pressure_source,coordinate_binding=coordinate_binding,omega_binding=omega_binding))
    else:
        require(cache.metadata('final_peff')['coordinate_binding']==coordinate_binding and cache.metadata('final_peff')['omega_binding']==omega_binding,'cached P graph/coordinate identity differs')
        peff=cached_p;pressure_source=float(cache.metadata('final_peff')['low_high_source_frobenius'])
    require(np.isfinite(heff).all() and np.isfinite(peff).all() and np.isfinite(invariant_residual) and invariant_residual>=0 and np.isfinite(pressure_source) and pressure_source>=0,'final cached array/residual invalid')
    interaction = sum(operator_norm_bound(a)*operator_norm_bound(b) for a, b in ts)
    base_error = (operator_norm_bound(ua.T@active@ua-np.diag(raw_ea))
                  + operator_norm_bound(hb-np.diag(eb)))
    d_lower = float(eb[1]-interaction-eta-base_error)
    aq_margin = float(d_lower-max(ea)-base_error)
    if aq_margin <= 0:
        raise ArithmeticError('full source-graph A/Q separation is not certified')
    e, gvec, ep, _ = block_parity_eigh(heff, lp)
    if ep[0] != 0:
        raise ArithmeticError('source comparator requires an even interacting ground')
    rbound = float(invariant_residual+eta)
    threshold = float(d_lower-e[0]-rbound)
    cluster = float(threshold-(e[-1]-e[0])-2*rbound)
    if cluster <= 0:
        raise ArithmeticError('full retained source cluster is not certified')
    odd_q = (bp[1:, None] ^ lp[None, :]) == 1
    odd_free = float(np.min((eb[1:, None]+ea[None, :])[odd_q]))
    odd_threshold = float(odd_free-interaction-eta-base_error-e[0]-rbound)
    odd_columns = np.flatnonzero(lp == 1)
    odd_a_min = float(np.min(ea[odd_columns])-base_error)
    odd_d_min = float(odd_free-interaction-eta-base_error)
    odd_b_bound = float(sum(operator_norm_bound(a[:, odd_columns])*np.linalg.norm(b[1:, 0])
                            for a, b in ts)+eta+base_error)
    denominator = abs(odd_d_min-odd_a_min)+np.hypot(odd_d_min-odd_a_min, 2*odd_b_bound)
    correction = 0. if odd_b_bound == 0 else 2*odd_b_bound**2/denominator
    odd_ground_bound = float(min(odd_a_min, odd_d_min)-correction-e[0]-rbound)
    pressure_bound = (operator_norm_bound(model['PL'])+operator_norm_bound(model['PB'])
                      +sum(operator_norm_bound(a)*operator_norm_bound(b)
                           for a, b in model['pterms']))*np.sqrt(nl*nb)
    info = dict(iterations=len(history), riccati_residual_history=history,
                invariant_residual_frobenius=invariant_residual,
                invariant_residual_scope='original uncompressed full tensor',
                original_hamiltonian_residual_bound=rbound,
                retained_cluster_certification_margin=cluster,
                active_to_excited_bath_separation_margin=aq_margin,
                bare_separation=separation, interaction_norm_bound=float(interaction),
                base_diagonalization_error_bound=float(base_error),
                omitted_interacting_threshold_lower_bound=threshold,
                omitted_odd_transition_energy_lower_bound=odd_threshold,
                odd_sector_ground_block_lower_bound=odd_ground_bound,
                odd_ground_block_components=dict(A_lower=odd_a_min, D_lower=odd_d_min,
                                                 coupling_norm_upper=odd_b_bound),
                low_high_source_frobenius=pressure_source,
                pressure_frobenius_bound=float(pressure_bound),
                orthogonality_error=orthogonality_error,
                forbidden_parity_graph_frobenius=forbidden,
                graph_norm=graph_norm, graph_norm_kind='Frobenius',
                graph_spectral_norm=graph_spectral_norm, compression=comp,
                compression_operator_error_bound=float(eta),
                low_dimension=nl, bath_dimension=nb,
                active_even_dimension=int(np.count_nonzero(lp == 0)),
                active_odd_dimension=int(np.count_nonzero(lp == 1)),
                retained_sector='both total parities with exact parity columns',
                estimated_workspace_mb=estimate,
                parity_block_diagnostics=dict(bath=bdiag, active=adiag),
                hamiltonian_common_shift=float(raw_ea[0]+raw_eb[0]))
    info.update(checkpoint_cache=cache.receipt(),explicit_bath_parity=True,
      finalization_scope='original uncompressed tensor H/P actions; source residual measured before discarding full action; all original cluster/odd-ground gates rerun on return')
    return heff, peff, w, ua, ub, lp, e, gvec, ep, info

