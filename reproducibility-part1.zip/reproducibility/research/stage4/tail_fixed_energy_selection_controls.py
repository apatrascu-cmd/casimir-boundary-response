"""Independent controls for common energy-projector tail comparisons; unexecuted."""
import argparse,copy,json,os,signal,time
from decimal import localcontext
import numpy as np
from scipy.linalg import eigh
import tail_fixed_energy_selection as run

def law(E,P,ceiling=None,tau=0.,inc=False,h=1.5):
    E,P,_=run.energy_slice(E,P,ceiling,10.,0.)
    z=-.5*(tau*(E[:,None]-E[None,:]))**2;f=np.exp(z)
    if inc:f*=-np.expm1(3*z)
    X=P*f;v,U=eigh(X);weights=U[0]**2
    return float(np.sum(weights[abs(v)>h])),{n:float(weights@(v**n)) for n in (2,4,6,8)},X

def controls(memory):
    E=np.array([0.,1.,2.]);P=np.array([[0.,1.,0.],[1.,0.,2.],[0.,2.,0.]])
    full,m,_=law(E,P);cut,mc,_=law(E,P,1.5)
    run.require(abs(full-.2)<2e-14 and cut==0. and all(abs(mc[n]-1)<2e-13 for n in mc),'known selection tail separator failed')
    run.require(all(abs(m[n]-5**(n//2-1))<2e-11 for n in m),'known three-atom moments failed')
    yield run.CHECKS[0],dict(full_tail=full,restricted_tail=cut,nonvacuous_change=True)
    rng=np.random.default_rng(812);A=rng.normal(size=(5,5));P=(A+A.T)/2;H=np.diag([0.,.3,.7,1.2,1.9]);rows=[];shift_reference={}
    for shift in (0.,13.):
        E,Pc,mean,diag=run.tail.controlled.eigen_prepare(H,P+shift*np.eye(5))
        for inc in (False,True):
            _,_,full=law(E,Pc,None,.4,inc);_,_,small=law(E,Pc,.9,.4,inc)
            error=float(np.max(abs(small-full[:3,:3])));run.require(error<1e-13 and small[0,0]==0,'projection/filter/true centering failed')
            if inc:run.require(np.count_nonzero(np.diag(small))==0,'increment zero-gap entries survived')
            if shift==0.:shift_reference[inc]=full.copy()
            else:run.require(np.max(abs(full-shift_reference[inc]))<2e-13,'actual-ground scalar-shift invariance failed')
            rows.append(dict(shift=shift,increment=inc,commutation_error=error))
    yield run.CHECKS[1],rows
    E=np.array([0.,.4,.4,1.3]);P=np.array([[0.,1.,.3,.2],[1.,.2,-.4,.1],[.3,-.4,.5,.2],[.2,.1,.2,.9]])
    O=np.eye(4);theta=.61;O[1:3,1:3]=[[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]]
    p,m,_=law(E,P,.8,.3,True,.8);q,n,_=law(E,O.T@P@O,.8,.3,True,.8)
    error=max(abs(m[k]-n[k]) for k in m);run.require(abs(p-q)<2e-12 and error<2e-12,'degenerate summed law is not invariant')
    yield run.CHECKS[2],dict(probability_difference=abs(p-q),moment_error=error,scope='whole degenerate energy block retained; no individual eigenvector matching')
    rejected=[]
    def reject(label,fn):
        try:fn()
        except (ValueError,ArithmeticError,MemoryError):rejected.append(label)
        else:raise AssertionError('invalid case accepted: '+label)
    reject('cut_at_degeneracy',lambda:run.energy_slice(E,P,.4,2.,0.));reject('above_available_cluster',lambda:run.energy_slice(E,P,1.5,2.,0.));reject('above_parent_omitted_floor',lambda:run.energy_slice(E,P,.8,.7,0.));reject('only_ground',lambda:run.energy_slice(E,P,.1,2.,0.));reject('memory',lambda:run.admission(512))
    jobs=[dict(Q=q,beta=1.,label=str(q),archive=str(q),archive_sha256=str(q),input=str(q),input_sha256=str(q)) for q in (14,16)]
    run.validate_jobs(jobs);reject('reordered_jobs',lambda:run.validate_jobs(jobs[::-1]));reject('duplicate_jobs',lambda:run.validate_jobs([jobs[0],jobs[0]]));reject('wrong_beta',lambda:run.validate_jobs([jobs[0],dict(jobs[1],beta=3.)]))
    de=run.decompose(.1,.12,.09,.1);run.require(abs(de['identity_error'])<1e-15,'independent telescoping decomposition failed')
    # Independently defined three-atom laws can have identical hard tails
    # at threshold8 while their positive even moments differ materially.
    # A probability-only H-driver comparison must not accept the latter.
    def atomic_law(side_weight):
        x=np.array([-1.,0.,1.]);weights=np.array([side_weight,1-2*side_weight,side_weight])
        values={str(n):dict(decimal=str(float(weights@(x**n)))) for n in (2,4,6,8)}
        return dict(sigma0=1.,recurrence=dict(even_moments=values),tail_panel=[dict(threshold_sigma0=8.,hard=dict(two_sided=dict(value=float(np.sum(weights[abs(x)>8.])))),smooth=[])])
    config=dict(thresholds_sigma0=[8.],noise_sigma0=[],probability_absolute_tolerance=2e-11,relative_probability_floor=1e-10,probability_relative_tolerance=1e-5,moment_tolerance=2e-8)
    atom=atomic_law(.25);near=atomic_law(.25000000025);different=atomic_law(.3)
    same=run.compare_h_moments(atom,atom,config);small=run.compare_h_moments(atom,near,config)
    probability_only=run.compare_laws(atom,different,config)
    reject('equal_tails_but_wrong_H_moments',lambda:run.compare_h_moments(atom,different,config))
    wrongunits=copy.deepcopy(atom);wrongunits['sigma0']=2.
    reject('H_driver_units_changed',lambda:run.compare_h_moments(atom,wrongunits,config))
    badzero=copy.deepcopy(atom);badzero['recurrence']['even_moments']['2']['decimal']='0'
    reject('zero_H_driver_moment',lambda:run.compare_h_moments(atom,badzero,config))
    run.require(same['maximum_symmetric_relative_difference']==0 and small['maximum_symmetric_relative_difference']>0 and all(r['absolute']==0 for r in probability_only),'H-driver moment control is vacuous')
    yield run.CHECKS[3],dict(rejected=rejected,decomposition=de,H_driver_moment_controls=dict(identical=same,small_allowed_difference=small,equal_probability_comparison=probability_only,positive_separator='same hard tail; materially different even moments rejected'))
    # One harmonic oscillator, complete projected q² contact minus vacuum mean.
    # Q8 saturates vacuum-returning pressure paths through order8.
    from nonlinear_pressure import FockRegulator,PressureModes
    from distributed_line import Parameters
    p=Parameters();m=PressureModes(p,np.array([.7]),np.array([.2]),np.array([[.3]]),np.array([.5]),'known one-mode harmonic control')
    f=FockRegulator(m.omega,8);A,B=m.matrices();P=f.quadratic(A,B);E=f.energies
    rows=[]
    for inc in (False,True):
        with localcontext() as ctx:ctx.prec=80;hm,_=run.tail.controlled.harmonic(m,.35,inc,2.)
        _,mom,X=law(E,P,None,.35,inc)
        error=max(abs(mom[n]/float(hm[n])-1) for n in mom);run.require(error<2e-11,'harmonic all-occupation moment control failed')
        # Native selector is exactly the identity, including its pressure matrix.
        ee,pp,selection=run.energy_slice(E,P,None,10.,0.);run.require(np.array_equal(ee,E) and np.array_equal(pp,P),'full selection changed supplied matrix')
        rows.append(dict(increment=inc,maximum_relative_moment_error=error,identity_selection_exact=True))
    yield run.CHECKS[4],rows

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--spec',default='research/stage4/tail_fixed_energy_selection_spec.json');ap.add_argument('--output',required=True);a=ap.parse_args()
    sp,s,old,ospec=run.load_spec(a.spec);mem=run.tail.memory_limit();run.admission(mem);rt=run.runtime()
    run.require(all(v=='1' for k,v in rt['declared_environment'].items() if k!='PYSCF_MAX_MEMORY'),'five one-thread declarations required')
    out=dict(format=run.FORMAT+'-controls',status='RUNNING',source_sha256=run.sources(s),spec_sha256=run.sha(sp),runtime=rt,memory_mb=mem,checks=[]);dest=run.tail.claim_output(a.output,out);start=time.monotonic()
    def save():out['elapsed_seconds']=time.monotonic()-start;run.tail.save_output(dest,out)
    def stop(sig,frame):raise RuntimeError('selection controls interrupted')
    signal.signal(signal.SIGTERM,stop)
    try:
        for name,details in controls(mem):out['checks'].append(dict(name=name,passed=True,details=details));save()
        run.require(tuple(r['name'] for r in out['checks'])==run.CHECKS,'incomplete controls');run.load_spec(a.spec)
        run.require(run.sources(s)==out['source_sha256'] and run.sha(sp)==out['spec_sha256'] and run.runtime()==rt,'control identity changed');out['status']='PASS';save()
    except BaseException as e:out.update(status='FAILED',error=repr(e));save();raise
    print('PASS five fixed-energy tail control groups',flush=True)

if __name__=='__main__':main()
