"""Fresh full-cosine/source solve for a pinned, genuinely nested bath extension."""
from __future__ import annotations
import argparse,json,math,os,signal,sys,time
from pathlib import Path
from decimal import Decimal as D,localcontext
import numpy as np
import scipy
import source_directed_bath as selection_core
import source_directed_bath_select as select
import source_directed_bath_model as build
import linear_source_reach as reach_core
import linear_source_reach_physical as previous
import tensor_wick_sources as fields
from dressed_cosine_hierarchy import parameters
from tensor_even_graph import block_parity_eigh
import analyze_saved_common_widths_2026_09_15 as arithmetic
ROOT=Path(__file__).resolve().parents[2]
FORMAT='stage4-nested-source-directed-bath-physical-v1'
CHECKS=('frozen_orbitals_match_original_full_cosine','nested_common_tensor_pressure_contacts','old_original_ground_shift_and_source_actions','independent_complete_small_graph_and_sources','selection_and_physical_gate_refusals')


def require(ok,message):
    if not ok:raise ValueError(message)

path,sha,save,jsonable=select.path,select.sha,select.save,select.jsonable


def sources():
    files={Path(__file__).resolve(),Path(__file__).with_name('source_directed_bath_model_controls.py')}
    for module in list(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            p=Path(filename).resolve()
            if p.is_relative_to(ROOT) and p.suffix=='.py' and p.relative_to(ROOT).parts[0] in ('research','src'):files.add(p)
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}


def runtime():
    r=select.runtime();r['scipy']=scipy.__version__;return r


def load_selection(binding,cap,fraction):
    p=path(binding['path']);require(sha(p)==binding['sha256'],'selection record changed');record=json.loads(p.read_text())
    require(record['status']=='COMPLETED_SELECTION_NOT_ENLARGED_PHYSICAL_RESULT','complete row selection required')
    require(record['source_sha256']==select.source_identity(),'executed selection sources changed')
    cp=record['controls'];require(sha(path(cp['path']))==cp['sha256'],'selection control record changed');select.control_gate(path(cp['path']))
    ar=record['archive'];require(sha(path(ar['path']))==ar['sha256'],'selection archive changed')
    matches=[r for r in record['selections'] if r['max_bath_count']==cap and r['fraction']==fraction];require(len(matches)==1,'unique declared selection required')
    chosen=matches[0]
    require(chosen['status']=='TARGET_CAPTURED_FOR_SUPPLIED_OLD_STATES','requested source fraction was not captured in BOTH old states')
    require(chosen['new_count']>128,'selection did not extend bath')
    with np.load(path(ar['path']),allow_pickle=False) as z:bath=z[chosen['array_key']].copy();low=z['active_states'].copy();base=z['original_bath_states'].copy()
    require(np.array_equal(base,bath[:128]) and len(bath)==chosen['new_count'],'selected common bath prefix differs');selection_core.check_states(bath)
    return record,chosen,bath,low


def make_spec(selection,cap,fraction,dest):
    binding=dict(path=str(selection.relative_to(ROOT)),sha256=sha(selection));record,chosen,bath,low=load_selection(binding,cap,fraction)
    spec=dict(format=FORMAT,selection=binding,cap=cap,fraction=fraction,selected_array_key=chosen['array_key'],selected_bath_dimension=len(bath),beta=[1.,3.],
      graph=dict(tolerance=2e-14,max_iterations=80,damping=1.,compress=True),taus=[36.2038671968,51.2,72.4077343935],ratio=2.,
      original_ground_residual_max=1e-10,old_source_replay_scaled_tolerance=2e-10,complete_pressure_mean_replay_absolute_tolerance=2e-9,
      source_identity=sources(),scope='fixed original local orbitals at each beta; shared source-directed bath labels and every active row; fresh nonlinear graph/source evaluation')
    require(dest.is_relative_to(ROOT/'research/stage4') and dest.suffix=='.json','new project stage4 specification required')
    with dest.open('x') as f:json.dump(spec,f,indent=2,sort_keys=True);f.write('\n')
    return spec


def load_spec(name):
    sp=path(name);s=json.loads(sp.read_text());require(s['format']==FORMAT and s['beta']==[1.,3.],'physical spec differs')
    require(s['source_identity']==sources(),'physical specification source identity changed')
    require(s['graph']==dict(tolerance=2e-14,max_iterations=80,damping=1.,compress=True),'graph settings differ')
    require(s['taus']==[36.2038671968,51.2,72.4077343935] and s['ratio']==2.,'width literals differ')
    require(s['original_ground_residual_max']==1e-10 and s['old_source_replay_scaled_tolerance']==2e-10 and s['complete_pressure_mean_replay_absolute_tolerance']==2e-9,'baseline gate tolerances changed')
    r,c,b,l=load_selection(s['selection'],s['cap'],s['fraction']);require(c['array_key']==s['selected_array_key'] and len(b)==s['selected_bath_dimension'],'selected basis identity differs')
    return sp,s,r,c,b,l


def controls_gate(p,spec_sha):
    r=json.loads(p.read_text());require(r['status']=='PASS' and r['format']==FORMAT+'-controls','completed enlarged-model controls required')
    require(tuple(c['name'] for c in r['checks'])==CHECKS and all(c['passed'] is True for c in r['checks']),'exact five enlarged-model groups required')
    require(r['source_sha256']==sources() and r['runtime']==runtime() and r['spec_sha256']==spec_sha,'enlarged model controls/source/runtime/spec differ')
    return r


def memory_plan(memory,nb):
    require(math.isfinite(memory) and memory>0,'positive declared memory required');nl=421
    estimate=12*8*nb*nl*nl+8*128*(nl*nl+nb*nb)+384*1024**2
    require(estimate<.6*memory*10**6,'actual selected bath exceeds physical memory allowance; no automatic basis reduction')
    return dict(memory_mb=memory,estimated_bytes=estimate,active_dimension=nl,bath_dimension=nb,full_tensor_dimension=nl*nb)


def graph_gate(diag,nb,e,par,low_dimension=421):
    for k in ('retained_cluster_certification_margin','active_to_excited_bath_separation_margin','omitted_interacting_threshold_lower_bound','omitted_odd_transition_energy_lower_bound','odd_sector_ground_block_lower_bound'):
        require(math.isfinite(diag[k]) and diag[k]>0,'new original graph/odd gate failed: '+k)
    require(diag['original_hamiltonian_residual_bound']<1e-10 and diag['forbidden_parity_graph_frobenius']==0,'new graph residual/parity unresolved')
    require(diag['low_dimension']==low_dimension and diag['bath_dimension']==nb and diag['active_odd_dimension']==low_dimension//2,'new graph targets differ')
    require(int(par[0])==0 and e[1]>e[0],'new retained ground is not simple/even')


def projected_fields(w,ua,ub,model,modes):
    result={};errors={}
    for name,(left,right) in fields.linear_group_sources(model,modes).items():result[name],errors[name]=previous.projected_source(w,ua,ub,left,right,1 if name=='D' else -1)
    return result,errors


def evaluate(H,P,modes,taus,transitions=None,memory=8192):
    E,Pc,mean,ed=arithmetic.eigen_prepare(H,P);rows=[]
    with localcontext() as ctx:
        ctx.prec=80
        for tau in taus:
            for inc in (False,True):
                moments,actual=arithmetic.evaluate(Pc,E,tau,inc,2.);hm,reference=arithmetic.harmonic(modes,tau,inc,2.)
                shape={str(n):arithmetic.value((moments[n]/hm[n]).ln()-D(n)/2*(moments[2]/hm[2]).ln()) for n in (4,6,8)}
                row=dict(tau=tau,observable='increment' if inc else 'ordinary',actual=actual,original_harmonic=reference,A_vs_original=shape)
                if inc and transitions is not None:
                    wick=fields.wick_pressure_increment(transitions,tau,modes.p.C0,modes.p.L0,2.,memory_mb=memory)
                    row['retained_Wick']=wick;row['A_vs_retained_Wick']={str(n):float((moments[n]/D.from_float(wick['moments'][str(n)])).ln()-D(n)/2*(moments[2]/D.from_float(wick['moments']['2'])).ln()) for n in (4,6,8)}
                rows.append(row)
    return dict(eigen_diagnostics=ed,ground_mean=mean,windows=rows,
      scope='actual-ground-centered ordinary/increment moments/cumulants through8; increment-only existing interacting D/Z Wick comparator; finite retained spectral/source scope')


def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True)
    mk=sub.add_parser('make-spec');mk.add_argument('--selection',required=True);mk.add_argument('--cap',type=int,required=True);mk.add_argument('--fraction',type=float,required=True);mk.add_argument('--output',required=True)
    run=sub.add_parser('run');run.add_argument('--spec',required=True);run.add_argument('--controls',required=True);run.add_argument('--beta',type=float,choices=[1.,3.],required=True);run.add_argument('--output',required=True)
    a=ap.parse_args()
    if a.command=='make-spec':make_spec(path(a.selection),a.cap,a.fraction,path(a.output));return
    sp,spec,selection,chosen,new_bath,low=load_spec(a.spec);cp=path(a.controls);controls_gate(cp,sha(sp));source=sources();memory=float(os.environ['PYSCF_MAX_MEMORY']);plan=memory_plan(memory,len(new_bath))
    job=next(j for j in selection['spec']['jobs'] if j['beta']==a.beta);profile,data=select.profile_inputs(job,memory)
    require(np.array_equal(data['low_states'],low),'selected active factor differs')
    with np.load(path(job['archive']['path']),allow_pickle=False) as z:
        oldH=z['H'].copy();oldP=z['P'].copy();oldpar=z['retained_parities'].copy()
        old_transitions={key:z['transition_'+key].copy() for key in ('omega','d','z')}
    modes,_,_=parameters(10,20);require(np.array_equal(modes.omega,data['omega']),'fixed physical modal frequencies differ')
    dest=path(a.output);archive=dest.with_suffix('.npz');require(dest.is_relative_to(ROOT/'research/stage4') and dest.suffix=='.json' and dest.parent.is_dir() and not archive.exists(),'exclusive new stage4 output required')
    begin=time.monotonic();out=dict(format=FORMAT,status='RUNNING_NOT_A_RESULT',spec=spec,spec_sha256=sha(sp),source_sha256=source,runtime=runtime(),memory_plan=plan,
      controls=dict(path=str(cp.relative_to(ROOT)),sha256=sha(cp)),beta=a.beta,input_profile=job,selection_evidence=chosen,
      warnings=['Captured fraction refers to the old saved state, not the enlarged nonlinear ground.','Bath reference frequencies do not certify interacting source energies.','The original composite pressure is retained; no squares of projected linear sources replace it.'])
    with dest.open('x') as f:json.dump(jsonable(out),f)
    def persist():out['elapsed_seconds']=time.monotonic()-begin;save(dest,out)
    def terminate(signum,frame):raise RuntimeError('resource admission interrupted nested bath solve')
    signal.signal(signal.SIGTERM,terminate)
    try:
        t=time.monotonic();local=build.local_from_orbitals(modes,data['couplings'],a.beta,data['reference'],data['orbitals'])
        require(np.array_equal(local['orbitals'],data['orbitals']),'frozen orbitals changed')
        old=build.tensor_from_local(modes,low,data['bath_states'],range(5),local,memory);new=build.tensor_from_local(modes,low,new_bath,range(5),local,memory)
        common=build.exact_common_blocks(old,new);psi=data['ground_original_tensor'];ee,vv,ep,_=block_parity_eigh(oldH,oldpar)
        expected_E=float(ee[0]+profile['graph']['hamiltonian_common_shift']);residual=float(np.linalg.norm(build.tensor_action(old,psi)-expected_E*psi))
        require(residual<spec['original_ground_residual_max'],'archived ground does not replay original frozen H action')
        pressure_mean=float(np.sum(psi*build.tensor_action(old,psi,True)));expected_mean=float(vv[:,0]@oldP@vv[:,0]);require(abs(pressure_mean-expected_mean)<spec['complete_pressure_mean_replay_absolute_tolerance'],'original complete pressure scalar/contact mean differs')
        old_reach=reach_core.source_reach(old,modes,psi,memory_mb=memory)
        gram_error=float(np.max(abs(old_reach['modal_outside_gram']-data['modal_outside_gram'])));require(gram_error<spec['old_source_replay_scaled_tolerance'],'old source covariance does not replay frozen archived ground')
        out['baseline']=dict(original_ground_energy=expected_E,original_H_ground_residual=residual,pressure_mean=pressure_mean,archived_pressure_mean=expected_mean,modal_source_Gram_max_error=gram_error,
          common_blocks=common,old_state_source=old_reach['diagnostics'],build_seconds=time.monotonic()-t,scope='original factor recipe, full tensor restriction, source/contact and ground-action replay; no second old graph solve')
        baseline=evaluate(oldH,oldP,modes,spec['taus'],old_transitions,memory);out['baseline_evaluation']=baseline;persist();del old,old_reach
        t=time.monotonic();H,P,w,ua,ub,par,e,gvec,epar,diag=fields._graph_with_embedding(new,memory_mb=memory,**spec['graph']);graph_gate(diag,len(new_bath),e,epar)
        out['graph']=diag;out['graph_seconds']=time.monotonic()-t;persist()
        ground=previous.original_coordinates(w,ua,ub,gvec[:,0]);proj,serrors=projected_fields(w,ua,ub,new,modes);tr=fields.transitions_from_operators(H,proj['D'],proj['Z_imag'],par,modes.p.hbar)
        out['evaluation']=evaluate(H,P,modes,spec['taus'],tr,memory);out['source_projection_symmetry']=serrors
        profile_new=reach_core.source_reach(new,modes,ground,memory_mb=memory,return_seeds=True)
        out['new_source_diagnostics']=profile_new['diagnostics'];out['new_physical_source_Grams']=profile_new['physical_grams'];out['old_physical_source_Grams']=profile['physical_grams']
        sr=tr['retained_D_weight']/modes.p.L0+modes.p.C0*tr['retained_Z_weight']
        sm=float(profile_new['physical_grams']['projected'][0,0]/modes.p.L0+modes.p.C0*profile_new['physical_grams']['projected'][1,1]-sr)
        out['within_tensor_source_scales']=dict(retained=sr,missing_raw=sm,scope='computed approximate graph, no PSD clipping or exact spectral promotion')
        out['changes']=[]
        for old_window,new_window in zip(baseline['windows'],out['evaluation']['windows']):
            with localcontext() as ctx:
                ctx.prec=80
                def number(v):return D(v['decimal'])
                out['changes'].append(dict(tau=new_window['tau'],observable=new_window['observable'],relative_even_moment_change={str(n):float(number(new_window['actual']['moments'][str(n)])/number(old_window['actual']['moments'][str(n)])-1) for n in (2,4,6,8)},
                  A_vs_original_change={str(n):float(number(new_window['A_vs_original'][str(n)])-number(old_window['A_vs_original'][str(n)])) for n in (4,6,8)},
                  A_vs_retained_Wick_change=({str(n):new_window['A_vs_retained_Wick'][str(n)]-old_window['A_vs_retained_Wick'][str(n)] for n in (4,6,8)} if new_window['observable']=='increment' else None)))
        arrays={k:profile_new[k] for k in ('modal_complete_gram','modal_projected_gram','modal_outside_gram','weighted_modal_outside_gram','coefficients','projected_physical_seeds')}
        arrays.update(ground_original_tensor=ground,orbitals=data['orbitals'],H=H,P=P,D=proj['D'],Z_imag=proj['Z_imag'],retained_parities=par,transition_omega=tr['omega'],transition_d=tr['d'],transition_z=tr['z'],omega=modes.omega,low_states=low,bath_states=new_bath,reference=data['reference'],couplings=data['couplings'])
        with archive.open('xb') as f:np.savez_compressed(f,**arrays);f.flush();os.fsync(f.fileno())
        out['archive']=dict(path=str(archive.relative_to(ROOT)),sha256=sha(archive),bytes=archive.stat().st_size,arrays={k:dict(shape=list(v.shape),dtype=str(v.dtype)) for k,v in arrays.items()})
        require(sources()==source and sha(sp)==out['spec_sha256'] and sha(cp)==out['controls']['sha256'],'physical source/spec/control changed');load_spec(a.spec)
        out['status']='COMPLETED_NESTED_FINITE_TENSOR_WITH_SOURCE_LIMITATIONS';persist()
    except BaseException as exc:out.update(status='FAILED',error=repr(exc));persist();raise
    print('COMPLETED_NESTED_FINITE_TENSOR_WITH_SOURCE_LIMITATIONS beta='+str(a.beta),flush=True)

if __name__=='__main__':main()
