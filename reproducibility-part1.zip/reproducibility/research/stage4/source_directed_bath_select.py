"""Consume beta1/3 source archives and prepare common nested bath candidates.

This selects from exact one-source action on each OLD supplied ground. No new
nonlinear ground/graph is solved, and no source excitation energy is inferred.
"""
from __future__ import annotations
import argparse,hashlib,json,math,os,platform,signal,sys,time,uuid,zipfile
from pathlib import Path
import numpy as np
import source_directed_bath as core
ROOT=Path(__file__).resolve().parents[2]
FORMAT='stage4-common-source-directed-bath-selection-v1'
CONTROL_NAMES=('complete_padded_coherent_row_actions','interference_and_primitive_contact_separator','downward_closed_common_beta_selection','harmonic_source_complete_zero','budget_zero_threshold_and_input_refusals')


def require(ok,message):
    if not ok:raise ValueError(message)


def path(name):
    p=(ROOT/name).resolve();require(p.is_relative_to(ROOT),'project-local path required');return p


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def source_identity():
    names=['source_directed_bath.py','source_directed_bath_controls.py','source_directed_bath_select.py']
    return {str((Path(__file__).parent/n).relative_to(ROOT)):sha(Path(__file__).parent/n) for n in names}


def runtime():
    return dict(python=sys.version,numpy=np.__version__,platform=platform.platform(),machine=platform.machine(),declared_threads={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')})


def jsonable(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,dict):return {str(k):jsonable(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [jsonable(x) for x in v]
    return v


def save(p,value):
    tmp=p.with_name(p.name+'.writing-'+uuid.uuid4().hex)
    with tmp.open('x') as f:json.dump(jsonable(value),f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)


def validate_job_inventory(spec):
    """The advertised two-strength panel must name two distinct exact inputs."""
    jobs=spec.get('jobs')
    require(isinstance(jobs,list) and len(jobs)==2 and all(isinstance(j,dict) for j in jobs),'exact two-job beta1/beta3 inventory required')
    require([j.get('beta') for j in jobs]==[1.,3.],'ordered job beta inventory must be exactly [1,3]')
    for kind in ('profile','archive'):
        bindings=[j.get(kind) for j in jobs]
        require(all(isinstance(b,dict) and isinstance(b.get('path'),str) and isinstance(b.get('sha256'),str) for b in bindings),'malformed job '+kind+' identity')
        require(len({str(path(b['path'])) for b in bindings})==2,'distinct '+kind+' paths required across strengths')
        require(len({b['sha256'] for b in bindings})==2,'distinct '+kind+' hashes required across strengths')


def load_spec(name):
    sp=path(name);s=json.loads(sp.read_text());require(s['format']==FORMAT,'wrong selection specification')
    require(s['beta']==[1.,3.] and s['source_modes']==list(range(5,20)),'common physical source panel changed')
    require(s['fractions']==[.9,.99,.999] and s['max_bath_counts']==[192,256,320,384],'declared capture/dimension refinement changed')
    require(s['raw_gram_replay_absolute_tolerance']==2e-10,'source cancellation replay tolerance changed')
    validate_job_inventory(s)
    for j in s['jobs']:
        for kind in ('profile','archive'):
            b=j[kind];require(sha(path(b['path']))==b['sha256'],'pinned profile input changed: '+kind)
    return sp,s


def control_gate(p):
    r=json.loads(p.read_text());require(r['status']=='PASS' and r['format']==core.FORMAT+'-controls','completed coherent source controls required')
    require(tuple(x['name'] for x in r['checks'])==CONTROL_NAMES and all(x['passed'] is True for x in r['checks']),'exact five coherent-source groups required')
    require(r['source_sha256']==source_identity() and r['runtime']==runtime(),'coherent source/control/consumer/runtime binding differs')
    return r


def expected_physical_gram(modal,coeff,modes):
    M=len(coeff);a=np.zeros((2*M,2));a[np.asarray(modes),0]=coeff[np.asarray(modes),0];a[M+np.asarray(modes),1]=coeff[np.asarray(modes),1]
    return a.T@modal@a


def profile_inputs(job,memory):
    record=json.loads(path(job['profile']['path']).read_text());require(record['status']=='COMPLETED_SOURCE_REACH_NOT_ENERGY_CERTIFICATE' and record['beta']==job['beta'],'source profile incomplete or wrong beta')
    require(record['archive']['path']==job['archive']['path'] and record['archive']['sha256']==job['archive']['sha256'],'profile/archive binding differs')
    for name,digest in record['source_sha256'].items():require(sha(path(name))==digest,'profile source changed: '+name)
    for kind in ('controls','core_controls'):
        b=record[kind];require(sha(path(b['path']))==b['sha256'],'profile executed controls changed');r=json.loads(path(b['path']).read_text());require(r['status']=='PASS','profile control not completed')
    meta=record['physical_metadata'];require(all(meta[k]==v for k,v in dict(R=10,M=20,Q=12,primitive=32,low_count=5,bath_dimension=128,calibration_modes=24,coupling_family='equal_reference_phase').items()),'profile physical tensor differs')
    with zipfile.ZipFile(path(job['archive']['path'])) as z:require(sum(v.file_size for v in z.infolist())<.05*memory*10**6,'profile archive exceeds small-data allowance')
    needed=['orbitals','ground_original_tensor','coefficients','modal_outside_gram','omega','low_states','bath_states','reference','couplings']
    with np.load(path(job['archive']['path']),allow_pickle=False) as z:data={k:z[k].copy() for k in needed}
    require(data['ground_original_tensor'].shape==(128,421) and data['orbitals'].shape==(20,32,32) and data['modal_outside_gram'].shape==(40,40),'profile array dimensions differ')
    require(data['bath_states'].shape==(128,20) and data['low_states'].shape==(421,20),'profile state shapes differ')
    core.check_states(data['low_states']);core.check_states(data['bath_states'])
    require(np.all(data['low_states'][:,5:]==0) and np.all(data['bath_states'][:,:5]==0),'factor supports changed')
    return record,data


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--spec',default='research/stage4/source_directed_bath_select_spec.json');ap.add_argument('--controls',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    sp,spec=load_spec(a.spec);cp=path(a.controls);control_gate(cp);control_sha=sha(cp);source=source_identity();memory=float(os.environ['PYSCF_MAX_MEMORY']);require(math.isfinite(memory) and memory>=2048,'2048MB minimum coherent physical selection')
    dest=path(a.output);require(dest.is_relative_to(ROOT/'research/stage4') and dest.parent.is_dir() and dest.suffix=='.json','new stage4 JSON required');archive=dest.with_suffix('.npz');require(not archive.exists(),'companion selection archive exists')
    start=time.monotonic();out=dict(format=FORMAT,status='RUNNING_NOT_A_RESULT',spec=spec,spec_sha256=sha(sp),source_sha256=source,runtime=runtime(),memory_mb=memory,controls=dict(path=str(cp.relative_to(ROOT)),sha256=control_sha),panels=[],selections=[],scope='selection from saved beta1/3 ground source action; no enlarged nonlinear solve or interacting-energy certificate')
    with dest.open('x') as f:json.dump(out,f)
    def persist():out['elapsed_seconds']=time.monotonic()-start;save(dest,out)
    def terminate(signum,frame):raise RuntimeError('admission interrupted coherent source selection')
    signal.signal(signal.SIGTERM,terminate)
    try:
        panels=[];stored=[];arrays={};C0=L0=1.
        require(spec['C0']==C0 and spec['L0']==L0,'physical pressure normalization changed')
        for i,job in enumerate(spec['jobs']):
            record,data=profile_inputs(job,memory)
            if stored:
                for k in ('low_states','bath_states','omega','reference','couplings'):require(np.array_equal(data[k],stored[0][k]),'strengths do not share fixed source calibration/basis: '+k)
            # Count shared arrays more than once deliberately: admission covers
            # every retained previous panel without relying on alias inference.
            resident=sum(v.nbytes for container in [data,*stored,*panels,arrays] for v in container.values() if isinstance(v,np.ndarray))
            begin=time.monotonic();reach=core.coherent_reach(data['bath_states'],data['ground_original_tensor'],data['orbitals'],data['coefficients'],spec['source_modes'],C0,L0,memory_mb=memory,resident_bytes=resident,return_retained_amplitudes=False)
            expected=expected_physical_gram(data['modal_outside_gram'],data['coefficients'],spec['source_modes'])
            error=reach['total_missing_gram']-expected;require(np.max(abs(error))<spec['raw_gram_replay_absolute_tolerance'],'direct absent-row/primitive source Gram does not replay saved coherent bath deficit')
            active=expected_physical_gram(data['modal_outside_gram'],data['coefficients'],list(range(5)))
            scale=lambda g:float(g[0,0]/L0+C0*g[1,1])
            groups={}
            for state,weight in zip(reach['missing_configuration_states'],reach['missing_configuration_weights']):
                key=(int(np.count_nonzero(state)),int(np.sum(state)));groups[key]=groups.get(key,0.)+float(weight)
            order=np.argsort(-reach['missing_configuration_weights'],kind='stable')[:30]
            summary=dict(beta=job['beta'],input_binding=job,profile_source_sha256=record['source_sha256'],diagnostics=reach['diagnostics'],seconds=time.monotonic()-begin,
              saved_raw_coherent_bath_gram=expected,direct_complete_missing_bath_gram=reach['total_missing_gram'],raw_gram_replay_error=error,
              configuration_missing_gram=reach['configuration_missing_gram'],primitive_boundary_gram=reach['primitive_boundary_gram'],active_factor_raw_gram=active,
              configuration_deficit=scale(reach['configuration_missing_gram']),primitive_boundary_deficit=scale(reach['primitive_boundary_gram']),active_factor_raw_deficit=scale(active),
              deficits_by_support_and_total_occupation=[dict(occupied_modes=k[0],total_occupation=k[1],weight=v) for k,v in sorted(groups.items())],
              largest_missing_rows=[dict(state=reach['missing_configuration_states'][j],weight=float(reach['missing_configuration_weights'][j])) for j in order],
              scope='active deficit retained from raw Gram; primitive boundary resolved by padded canonical source action; all cross-mode interference retained')
            out['panels'].append(summary);panels.append(reach);stored.append(data)
            prefix='beta'+str(int(job['beta']))+'_'
            for k in ('states','gram_by_row','weight_by_row','configuration_missing_mask','primitive_boundary_mask','missing_configuration_states','missing_configuration_grams','missing_configuration_weights'):
                arrays[prefix+k]=reach[k]
            persist()
        for cap in spec['max_bath_counts']:
            for fraction in spec['fractions']:
                choice=core.common_nested_selection(stored[0]['bath_states'],panels,fraction,cap)
                key='bath_cap'+str(cap)+'_fraction'+str(fraction).replace('.','p');arrays[key]=choice['bath_states']
                report={k:v for k,v in choice.items() if k not in ('bath_states','added_states')};report['array_key']=key;report['added_states']=choice['added_states']
                report['unaddressed_old_state_source_deficits']=[dict(beta=spec['jobs'][i]['beta'],remaining_configuration=choice['residual_configuration_deficit'][i],primitive_boundary=out['panels'][i]['primitive_boundary_deficit'],active_factor_raw=out['panels'][i]['active_factor_raw_deficit']) for i in range(2)]
                report['full_tensor_dimensions']=dict(active=421,bath=choice['new_count'],full=421*choice['new_count'],requires_every_active_row=True)
                report['full_parity_graph_array_estimate_bytes']=12*8*choice['new_count']*421**2
                out['selections'].append(report);persist()
        arrays.update(original_bath_states=stored[0]['bath_states'],active_states=stored[0]['low_states'],omega=stored[0]['omega'],reference=stored[0]['reference'],couplings=stored[0]['couplings'])
        with archive.open('xb') as f:np.savez_compressed(f,**arrays);f.flush();os.fsync(f.fileno())
        out['archive']=dict(path=str(archive.relative_to(ROOT)),sha256=sha(archive),bytes=archive.stat().st_size,arrays={k:dict(shape=list(v.shape),dtype=str(v.dtype)) for k,v in arrays.items()})
        require(source_identity()==source and sha(sp)==out['spec_sha256'] and sha(cp)==control_sha,'selector source/spec/control changed');load_spec(a.spec);control_gate(cp)
        out['warnings']=['Captured weights refer to each saved old ground. Fresh enlarged ground and original composite pressure/source gates are still required.','A cap-limited target is not reported as captured. Configurations are selected by source weight, not an interacting energy guess.','The enlarged bath must accompany every active state; no conditional hard-vacuum dressing is permitted.','Primitive-contact and active-factor residuals are separate; increasing bath configurations does not remove them.']
        if any(p['diagnostics']['positive_amplitude_square_underflow_count'] for p in out['panels']):
            out['warnings'].append('Some nonzero binary64 amplitudes squared to zero. Captured fractions use representable row weights; they are not numerical enclosures of smaller source weights.')
        out['warnings'].append('Every candidate contains the original bath; candidates at different caps need not be nested. Check set inclusion or form an explicit union before physical comparisons.')
        out['status']='COMPLETED_SELECTION_NOT_ENLARGED_PHYSICAL_RESULT';persist()
    except BaseException as exc:out.update(status='FAILED',error=repr(exc));persist();raise
    print('COMPLETED_SELECTION_NOT_ENLARGED_PHYSICAL_RESULT',flush=True)

if __name__=='__main__':main()
