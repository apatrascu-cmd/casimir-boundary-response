"""Pinned bath133 full-cosine preflight/build/checkpoint/finalization driver.

Only root launches. Each output is exclusive; a checkpoint is never a physical
result. Frozen production sources, rank evidence and original archives stay put.
"""
from __future__ import annotations
import argparse,json,math,os,signal,sys,time,zipfile
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix
import source_compressed_projection as core
import source_compressed_graph as graph
import source_compressed_cache as storage
import source_compressed_bath_rank as rank
import source_directed_bath_run as previous
import source_directed_bath_select as selector
import linear_source_reach as old_reach
import tensor_wick_sources as fields
from dressed_cosine_hierarchy import parameters
from tensor_even_graph import block_parity_eigh
ROOT=Path(__file__).resolve().parents[2]
FORMAT='stage4-source-compressed-bath-physical-v1'
CHECKS=('independent_complete_fock_mpo_insertions','source_generator_metric_and_common_blocks','independent_full_cosine_H_and_composite_P','complete_physical_source_Gram_contacts','explicit_parity_graph_and_resumed_finalization','cache_and_admission_refusals')
require=core.require
path,sha,jsonable,save=selector.path,selector.sha,selector.jsonable,selector.save
runtime=previous.runtime


def sources():
    files={Path(__file__).resolve(),Path(__file__).with_name('source_compressed_projection_controls.py')}
    for module in list(sys.modules.values()):
        name=getattr(module,'__file__',None)
        if name:
            p=Path(name).resolve()
            if p.is_relative_to(ROOT) and p.suffix=='.py' and p.relative_to(ROOT).parts[0] in ('research','src'):files.add(p)
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}


def binding(b):
    p=path(b['path']);require(sha(p)==b['sha256'],'input hash changed: '+b['path']);return p


def load_spec(name):
    p=path(name);s=json.loads(p.read_text())
    require(s['format']==FORMAT and s['beta']==[1.,3.] and s['added_by_parity']==[1,4],'declared rank-five physical panel differs')
    require(s['physical']==dict(R=10,M=20,reference_modes=24,Q=12,old_bath=128,new_bath=133,active=421,primitive=32,padded_primitive=33,active_indices=list(range(5))),'physical/calibration/primitive inventory differs')
    require(s['graph']==dict(tolerance=2e-14,max_iterations=80,damping=1.,compress=True),'frozen full-parity graph settings differ')
    require(s['taus']==[36.2038671968,51.2,72.4077343935] and s['ratio']==2.,'fixed observable windows differ')
    rp=binding(s['rank']);r=json.loads(rp.read_text());require(r['status']=='COMPLETED_RANK_DIAGNOSTIC_NOT_PHYSICAL_COMPLETION','completed source rank required')
    require(r['archive']==s['rank_archive'],'rank archive provenance differs');binding(s['rank_archive']);require(r['controls']==s['rank_controls'],'rank control binding differs')
    cp=binding(s['rank_controls']);c=json.loads(cp.read_text())
    require(c['status']=='PASS' and tuple(x['name'] for x in c['checks'])==rank.CHECKS and all(x['passed'] is True for x in c['checks']),'exact executed rank controls required')
    require(c['source_sha256']==r['source_sha256']==rank.sources(),'rank source/control current identities differ')
    # Historical rank runtime is preserved; this new builder has its own fresh
    # runtime-matched controls and does not rewrite or import an old graph cache.
    _,rs,selection=rank.load_spec(s['rank_spec_path']);require(rs==r['spec'] and sha(path(s['rank_spec_path']))==r['spec_sha256'],'rank spec changed')
    target=next(x for x in r['rank_analysis']['targets'] if x['fraction']==.999)['choice']
    require(target['added_rank']==5 and target['kept_by_bath_parity']=={'0':1,'1':4} and target['within_reported_numerical_rank'] and not target['cut_intersects_numerically_tied_singular_cluster'],'accepted rank-five choice changed')
    require([j['beta'] for j in r['spec']['jobs']]==[1.,3.],'ordered distinct physical profile inventory differs')
    return p,s,r,selection,target


def control_gate(p,spec_sha):
    r=json.loads(p.read_text());require(r['format']==FORMAT+'-controls' and r['status']=='PASS','completed projection controls required')
    require(tuple(c['name'] for c in r['checks'])==CHECKS and all(c['passed'] is True for c in r['checks']),'exact six independent projection controls required')
    require(r['source_sha256']==sources() and r['spec_sha256']==spec_sha and r['runtime']==runtime(),'projection control/source/spec/runtime differs')
    return r


def memory_plan(memory,phase):
    require(math.isfinite(memory) and memory>0,'positive PYSCF_MAX_MEMORY required')
    contraction=768*1024**2+5*25*4*128*128*16
    graph_bytes=12*8*133*421*421+8*128*(421*421+133*133)+512*1024**2
    estimate=contraction if phase=='preflight' else max(contraction,graph_bytes)
    require(estimate<.6*memory*1e6,'compressed projection/graph memory admission failed')
    return dict(memory_mb=memory,estimated_bytes=estimate,recommended_mb=4096 if phase=='preflight' else 8192,
      active_dimension=421,bath_dimension=133,full_dimension=55993,ambient_H_created=False,cache_disk_recommendation_mb=1536)


def load_representation(spec,record,memory):
    archive=binding(spec['rank_archive'])
    with zipfile.ZipFile(archive) as z:require(sum(v.file_size for v in z.infolist())<.2*memory*1e6,'rank input exceeds declared resident allowance')
    data=[];profiles=[]
    for job in record['spec']['jobs']:
        r,d=selector.profile_inputs(job,memory);profiles.append(r);data.append(d)
    for key in ('bath_states','low_states','omega','reference','couplings'):
        require(np.array_equal(data[0][key],data[1][key]),'physical common ordinal/calibration mismatch: '+key)
    with np.load(archive,allow_pickle=False) as z:
        rows=z['row_states'];old=z['old_bath_states'];low=z['active_states'];require(np.array_equal(old,data[0]['bath_states']) and np.array_equal(low,data[0]['low_states']),'rank coordinate inventory differs')
        require(old.shape==(128,20) and low.shape==(421,20) and rows.shape==(28442,20),'rank physical shapes differ')
        generators=[];C=np.zeros((4,128,5));newpar=np.r_[np.zeros(1,int),np.ones(4,int)];U=np.zeros((len(rows),5));offset=0
        for beta in (1,3):
            for name in ('D','Z_imag'):
                p='beta'+str(beta)+'_'+name+'_csr_';generators.append(csr_matrix((z[p+'data'],z[p+'indices'],z[p+'indptr']),shape=(len(rows),128)))
        for parity,k in enumerate(spec['added_by_parity']):
            prefix='svd_bathparity'+str(parity)+'_';inds=z[prefix+'row_indices'];sv=z[prefix+'s'][:k];vh=z[prefix+'Vh'][:k];U[inds,offset:offset+k]=z[prefix+'U'][:,:k]
            require(np.all(sv>.05),'retained source inverse singular amplification changed')
            for b,beta in enumerate((1,3)):
                oldp=1-parity;pre='beta'+str(beta)+'_qr_oldparity'+str(oldp)+'_';ib=z[pre+'old_bath_indices'];R=z[pre+'R'];width=R.shape[0]
                start,stop=record['decompositions'][str(parity)]['beta_column_ranges'][b];require(stop-start==2*width,'QR/SVD column map differs')
                scale=math.sqrt(record['panels'][b]['complete_padded_source_deficit'])
                for source in (0,1):C[2*b+source,ib,offset:offset+k]=R.T@(vh[:,start+source*width:start+(source+1)*width].T/sv)/scale
            offset+=k
    # Both physical source units are exactly one in the pinned rank spec.
    require(record['spec']['C0']==record['spec']['L0']==1.,'source normalization not implemented for altered units')
    regeneration=[];source_local=[]
    for b,d in enumerate(data):
        gen=rank.core.source_generators(old,d['orbitals'],d['coefficients'],list(range(5,20)),rows)
        for i,name in enumerate(('D','Z_imag')):
            delta=gen[name]-generators[2*b+i];err=core.norm(delta.data);require(err==0.,'saved source generator does not replay current frozen physical arrays');regeneration.append(err)
        source_local.extend(core.local_fields(d['orbitals'],d['coefficients'],list(range(5,20))))
    rep=core.reconstruction(generators,C,128,newpar);raw=sum((g@c for g,c in zip(generators,C)),np.zeros_like(U));raw[:128]=0.
    replay=core.norm(raw-U);require(replay<2e-9,'right-singular generator reconstruction fails stored left vectors')
    rowpar=rows.sum(axis=1)%2;require(core.norm(rep['W'][rowpar[:,None]!=newpar[None,:]])==0.,'new bath columns mix parity')
    tails=[]
    for b,d in enumerate(data):
        # QR removes only redundant active columns; no Schmidt truncation.
        piece=rank.core.reduce_ground(dict(D=generators[2*b],Z_imag=generators[2*b+1],rows=rows,bath=old),low,d['ground_original_tensor'])
        kept=0.
        for parity,panel in piece['pieces'].items():
            ix=np.flatnonzero(newpar==parity);W=rep['W'][panel['row_indices']][:,ix];kept+=core.norm(W.T@panel['array'])**2
        rem=1-kept/piece['deficit'];expect=next(x for x in record['rank_analysis']['targets'] if x['fraction']==.999)['choice']['relative_discarded_singular_weight_by_beta'][b]
        require(abs(rem-expect)<2e-10,'polar retained span changes declared source tail');tails.append(dict(beta=float((1,3)[b]),relative_remaining=rem,saved_singular_tail=expect))
    diagnostics=dict(generator_regeneration_errors=regeneration,stored_left_vector_reconstruction_frobenius=replay,metric=rep['metric_diagnostics'],old_state_tail_replay=tails,
      no_new_ground_capture_claim=True,common_ordinal_labels_not_identical_physical_subspaces=True)
    return rep,np.asarray(source_local),rows,data,profiles,diagnostics


def evaluation_gate(evaluation,taus):
    evaluation['eigen_diagnostics']['first_returned_gap_scope']='minimum positive gap of the supplied both-parity H; the frozen helper field first_returned_even_gap does not assert parity here'
    rows=evaluation['windows'];require([(x['tau'],x['observable']) for x in rows]==[(t,name) for t in taus for name in ('ordinary','increment')],'complete ordinary/increment window inventory required')
    unresolved=[]
    for row in rows:
        actual=row['actual'];require(actual['positive_moment_checks']['passed'] is True,'physical positive-moment checks failed')
        require(set(actual['moments'])==set(map(str,range(1,9))) and set(actual['cumulants'])==set(map(str,range(2,9))),'raw moment/cumulant inventory incomplete')
        if not actual['spectral_reconstruction']['passed']:unresolved.append(dict(tau=row['tau'],observable=row['observable'],status=actual['spectral_reconstruction']['status']))
    return dict(positive_checks_passed=True,unresolved_spectral_rows=unresolved,
      scope='vacuum norm recurrence retained if separately reported spectral weights are unresolved; no CDF certification')


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--spec',default='research/stage4/source_compressed_projection_spec.json');ap.add_argument('--controls',required=True)
    ap.add_argument('--beta',type=float,choices=[1.,3.],required=True);ap.add_argument('--phase',choices=['preflight','build','iterate','finalize','all'],required=True)
    ap.add_argument('--max-updates',type=int);ap.add_argument('--cache',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    sp,spec,r,selection,target=load_spec(a.spec);cp=path(a.controls);control_gate(cp,sha(sp));memory=float(os.environ['PYSCF_MAX_MEMORY']);plan=memory_plan(memory,a.phase);source=sources()
    dest=path(a.output);require(dest.is_relative_to(ROOT/'research/stage4') and dest.suffix=='.json' and dest.parent.is_dir(),'exclusive new stage4 JSON required')
    archive=dest.with_suffix('.npz');require(not archive.exists(),'physical output archive already exists')
    cachepath=path(a.cache);require(cachepath.is_relative_to(ROOT/'research/stage4') and cachepath.parent.is_dir(),'new stage4 cache required')
    identity=dict(format=FORMAT,spec_sha256=sha(sp),source_sha256=source,runtime=runtime(),beta=a.beta,rank=spec['rank'],rank_archive=spec['rank_archive'],controls=dict(path=str(cp.relative_to(ROOT)),sha256=sha(cp)))
    out=dict(format=FORMAT,status='RUNNING_NOT_A_RESULT',spec=spec,spec_sha256=sha(sp),source_sha256=source,runtime=runtime(),beta=a.beta,phase=a.phase,controls=identity['controls'],memory_plan=plan,rank_choice=target,
      warnings=['Old-source singular-tail capture is not the enlarged ground source norm or a physical completeness certificate.',
        'All five new bath vectors accompany every one of the421 active states; active-factor and all-mode/source limitations remain.',
        'Common beta columns have identical ordinal coefficients but beta-specific frozen orbitals; this is not one identical physical subspace across strengths.',
        'Complete cosine and complete primitive quadratic contacts are projected directly; no squares of retained linear sources substitute for pressure.',
        'Every quoted arithmetic norm is a measured binary64 diagnostic, not an interval enclosure.'])
    with dest.open('x') as f:json.dump(out,f)
    start=time.monotonic()
    def persist():out['elapsed_seconds']=time.monotonic()-start;save(dest,out)
    def end_gate():
        require(sources()==source and sha(sp)==out['spec_sha256'] and sha(cp)==out['controls']['sha256'],'projection source/spec/control changed during phase')
        load_spec(a.spec);control_gate(cp,sha(sp))
    def terminate(signum,frame):raise RuntimeError('compressed-bath resource admission interrupted')
    signal.signal(signal.SIGTERM,terminate)
    try:
        with storage.Cache(cachepath,identity) as cache:
            rep,src,rows,data,profiles,replay=load_representation(spec,r,memory);out['source_basis_replay']=replay
            b=[1.,3.].index(a.beta);d=data[b];profile=profiles[b];job=r['spec']['jobs'][b]
            modes,_,_=parameters(10,20);require(np.array_equal(modes.omega,d['omega']),'physical harmonic frequencies changed')
            small,large,padding=core.extended_local(modes,d['couplings'],a.beta,d['reference'],d['orbitals']);out['padding']=padding
            projector=core.Projector(d['bath_states'],src,rep,cache)
            if a.phase=='preflight':
                out['preflight']=core.assemble(modes,d['low_states'],d['bath_states'],range(5),small,large,projector,memory,preflight=True)
                out['cache']=cache.receipt();out['status']='COMPLETED_TIMING_PREFLIGHT_NOT_PHYSICAL_RESULT';end_gate();persist();print(out['status'],flush=True);return
            model,old,info=core.assemble(modes,d['low_states'],d['bath_states'],range(5),small,large,projector,memory);out['projection']=info
            with np.load(path(job['archive']['path']),allow_pickle=False) as z:oldH=z['H'];oldP=z['P'];oldpar=z['retained_parities'];oldtr={k:z['transition_'+k] for k in ('omega','d','z')}
            ee,vv,ep,_=block_parity_eigh(oldH,oldpar);psi=d['ground_original_tensor'];E0=ee[0]+profile['graph']['hamiltonian_common_shift']
            res=core.norm(core.frozen.tensor_action(old,psi)-E0*psi);mean=float(np.sum(psi*core.frozen.tensor_action(old,psi,True)));mean0=float(vv[:,0]@oldP@vv[:,0])
            require(res<1e-10 and abs(mean-mean0)<2e-9,'original full H/P old-ground replay failed')
            oldsource=old_reach.source_reach(old,modes,psi,memory_mb=memory);gramerror=float(np.max(abs(oldsource['modal_outside_gram']-d['modal_outside_gram'])));require(gramerror<2e-10,'original full modal source replay failed')
            embedded=np.zeros((133,421));embedded[:128]=psi;new_oldsource=core.source_gram(model,embedded)
            require(core.norm(new_oldsource['complete']-profile['physical_grams']['complete'])<2e-8,'complete old-ground contacts changed under bath extension')
            out['baseline']=dict(original_H_ground_residual=res,pressure_mean_error=abs(mean-mean0),original_modal_source_Gram_max_error=gramerror,old_ground_in_new_bath_source=new_oldsource,
              original_physical_grams=profile['physical_grams'],scope='same saved old state; old common blocks exact, new bath source capture recomputed with complete contacts')
            out['baseline_evaluation']=previous.evaluate(oldH,oldP,modes,spec['taus'],oldtr,memory);out['baseline_arithmetic_gate']=evaluation_gate(out['baseline_evaluation'],spec['taus']);del old,oldsource
            if a.phase=='build':out['cache']=cache.receipt();out['status']='COMPLETED_PROJECTION_NOT_PHYSICAL_RESULT';end_gate();persist();print(out['status'],flush=True);return
            answer=graph.solve(model,memory_mb=memory,cache=cache,phase=a.phase if a.phase in ('iterate','finalize') else 'all',max_updates=a.max_updates,**spec['graph'])
            if isinstance(answer,dict):out['iteration']=answer;out['cache']=cache.receipt();out['status']=answer['status'];end_gate();persist();print(out['status'],flush=True);return
            H,P,w,ua,ub,par,e,vectors,epar,diag=answer;previous.graph_gate(diag,133,e,epar);out['graph']=diag
            ground=previous.previous.original_coordinates(w,ua,ub,vectors[:,0]);proj={};sym={}
            for name,(left,right) in model['linear_sources'].items():proj[name],sym[name]=previous.previous.projected_source(w,ua,ub,left,right,1 if name=='D' else -1)
            tr=fields.transitions_from_operators(H,proj['D'],proj['Z_imag'],par,modes.p.hbar)
            out['source_projection_symmetry']=sym;out['new_physical_source_grams']=core.source_gram(model,ground);out['evaluation']=previous.evaluate(H,P,modes,spec['taus'],tr,memory)
            out['arithmetic_gate']=evaluation_gate(out['evaluation'],spec['taus'])
            if out['arithmetic_gate']['unresolved_spectral_rows']:out['warnings'].append('Some direct spectral-weight reconstructions are unresolved; their positive norm-recurrence moments and explicit failure records are retained, without a direct CDF claim.')
            retained=tr['retained_D_weight']/modes.p.L0+modes.p.C0*tr['retained_Z_weight'];pg=out['new_physical_source_grams']['projected'];tensor=float(pg[0,0]/modes.p.L0+modes.p.C0*pg[1,1]);missing=tensor-retained
            require(missing>=-2e-9*max(1.,tensor),'retained odd sources exceed tensor source weight beyond arithmetic tolerance')
            out['within_tensor_source_scales']=dict(retained=retained,tensor_projected=tensor,missing_raw=missing,scope='raw retained odd versus tensor source weights; complete outside Gram is not assigned interacting energies or clipped to positivity')
            out['changes']=[]
            from decimal import Decimal,localcontext
            with localcontext() as ctx:
                ctx.prec=80
                for before,after in zip(out['baseline_evaluation']['windows'],out['evaluation']['windows']):
                    val=lambda x:Decimal(x['decimal'])
                    out['changes'].append(dict(tau=after['tau'],observable=after['observable'],relative_even_moment_change={str(p):float(val(after['actual']['moments'][str(p)])/val(before['actual']['moments'][str(p)])-1) for p in (2,4,6,8)},A_vs_original_change={str(p):float(val(after['A_vs_original'][str(p)])-val(before['A_vs_original'][str(p)])) for p in (4,6,8)}))
            arrays=dict(H=H,P=P,D=proj['D'],Z_imag=proj['Z_imag'],retained_parities=par,ground_compressed_tensor=ground,bath_parities=model['bath_parities'],low_states=d['low_states'],old_bath_states=d['bath_states'],source_rows=rows,source_vector_coefficients=rep['C'],source_old_correction=rep['T'],source_bath_vectors=rep['W'],new_bath_parities=rep['parities'],orbitals=d['orbitals'],omega=d['omega'],reference=d['reference'],couplings=d['couplings'],transition_omega=tr['omega'],transition_d=tr['d'],transition_z=tr['z'])
            with archive.open('xb') as f:np.savez_compressed(f,**arrays);f.flush();os.fsync(f.fileno())
            out['archive']=dict(path=str(archive.relative_to(ROOT)),sha256=sha(archive),bytes=archive.stat().st_size,arrays={k:dict(shape=list(v.shape),dtype=str(v.dtype)) for k,v in arrays.items()})
            out['cache']=cache.receipt();out['input_profile']=job
            require(sources()==source and sha(sp)==out['spec_sha256'],'projection source/spec changed during run');load_spec(a.spec);control_gate(cp,sha(sp))
            out['status']='COMPLETED_COMPRESSED_FINITE_TENSOR_WITH_SOURCE_LIMITATIONS';persist()
    except BaseException as exc:out.update(status='FAILED',error=repr(exc));persist();raise
    print(out['status'],flush=True)

if __name__=='__main__':main()
