"""Extract the independently audited stage4 tail result into two new artifacts.

Standard-library saved-data checks and formatting only. No pressure matrix is
loaded or diagonalized. Existing manuscript and packaged ZIP files are untouched.
"""
from pathlib import Path
from decimal import Decimal,localcontext
import argparse
import hashlib
import json
import math
import os

ROOT=Path(__file__).resolve().parents[2]
INPUT='research/stage4/results/saved_tail_refinement_Q14_Q16.json'
INPUT_SHA='5b3e2a2a06cdfff41b8ae84a29940a1a93c2d68c07d3c07d150307510fdae1f2'
CONTROL='research/stage4/results/tail_refinement_controls.json'
CONTROL_SHA='93283fa7a8268707f19e81912bdbf315f468193883d9073ea0dbb2d67874f5d5'
SPEC='research/stage4/saved_tail_refinement_spec.json'
SPEC_SHA='67a3b63b12b97ffd65ddaedbdd1a6021907724d433f8858f69dbad330fead9a1'
AUDIT='research/stage4/TAIL_EXECUTED_INDEPENDENT_AUDIT_2026-09-15.md'
AUDIT_SHA='c1a87f16cf6f4fca343661a8923f8af0eb90008fbfb1419d02911fc4b91af0cf'
TARGET='paper/stage4_tail_results.tex'
PROVENANCE='paper/stage4_tail_provenance.json'
D=Decimal


def require(condition,message):
    if not condition:raise ValueError(message)


def local(name):
    p=(ROOT/name).resolve();require(p.is_relative_to(ROOT),'Project-local path required');return p


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda:stream.read(1048576),b''):h.update(b)
    return h.hexdigest()


def one(rows,predicate,label):
    found=[x for x in rows if predicate(x)];require(len(found)==1,'Expected one '+label);return found[0]


def formal_log(m):
    z=[D(0)]+[m[n]/D(math.factorial(n)) for n in range(1,9)]
    power=[D(1)]+[D(0)]*8;answer=[D(0)]*9
    for k in range(1,9):
        power=[sum((power[j]*z[n-j] for j in range(n+1)),D(0)) for n in range(9)]
        for n in range(1,9):answer[n]+=D((-1)**(k+1))*power[n]/D(k)
    return {n:answer[n]*D(math.factorial(n)) for n in range(2,9)}


def number(value,places=7):
    answer=f'{value:.{places}g}'
    if 'e' in answer:
        mantissa,exponent=answer.split('e');return mantissa+r'\times10^{'+str(int(exponent))+'}'
    return answer
def percent(value,places=5):return f'{100*value:+.{places}f}'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replace',action='store_true',help='Regenerate only these two owned derived artifacts')
    args=parser.parse_args();memory=float(os.environ['PYSCF_MAX_MEMORY'])
    require(math.isfinite(memory) and memory>=64,'Declare at least 64 MiB for saved-data formatting')
    target,provenance=local(TARGET),local(PROVENANCE)
    if not args.replace and (target.exists() or provenance.exists()):raise FileExistsError('Tail artifacts already exist; explicit --replace required')
    verified={}
    def verify(name,digest):
        require(sha(local(name))==digest,'Identity mismatch: '+name);verified[name]=digest
    for name,digest in [(INPUT,INPUT_SHA),(CONTROL,CONTROL_SHA),(SPEC,SPEC_SHA),(AUDIT,AUDIT_SHA)]:verify(name,digest)
    data=json.loads(local(INPUT).read_text());control=json.loads(local(CONTROL).read_text());spec=json.loads(local(SPEC).read_text())
    require(data['status']=='COMPLETED_WITH_WARNINGS' and data['format']=='stage4-saved-tail-refinement-v1','Audited completed tail result required')
    require(data['spec']==spec and data['spec_path']==SPEC and data['spec_sha256']==SPEC_SHA,'Embedded specification mismatch')
    require(control['status']=='PASS' and control['test_suite']=='stage4-saved-tail-controls-v1','Accepted tail controls required')
    require(len(control['checks'])==17 and all(c['passed'] is True for c in control['checks']),'Seventeen successful controls required')
    require(control['spec_sha256']==SPEC_SHA and data['controls']==dict(path=CONTROL,sha256=CONTROL_SHA,checks=17,status='PASS'),'Control binding mismatch')
    for name,digest in control['source_sha256'].items():verify(name,digest)
    for name,digest in data['source_sha256'].items():
        require(control['source_sha256'].get(name)==digest,'Result source not covered by controls: '+name);verify(name,digest)
    require(control['tested_entrypoint_sha256']==data['source_sha256']['research/stage4/analyze_saved_tail_refinement.py'],'Tested entrypoint mismatch')
    for name,digest in spec['frozen_analysis_sources'].items():verify(name,digest)
    for key in ('python','numpy','scipy','platform','machine'):require(data['runtime'][key]==control['runtime'][key],'Execution/control runtime mismatch')
    require(spec['tau']==51.2 and spec['ratio']==2. and spec['hbar']==1.,'Unexpected window convention')
    require(spec['analysis']['thresholds_sigma0']==[2.,4.,6.,8.,10.,12.] and spec['analysis']['noise_sigma0']==[.1,.25,.5,1.],'Unexpected tail grid')
    expected_physical=dict(R=10,M=20,calibration_modes=24,coupling_family='equal_reference_phase',tau=51.2,hard=.5,soft=0.,low_count=5,bath_top=24,primitive=32,even_only=True)
    require(spec['physical_parameters']==expected_physical,'Unexpected physical calibration')
    require(len(data['cases'])==4 and {(c['Q'],c['beta']) for c in data['cases']}=={(q,b) for q in (14,16) for b in (1.,3.)},'Expected four cases')
    require(len(data['comparisons'])==2,'Expected both beta comparisons')
    references=data['reference_units'];require(set(references)=={'ordinary','increment'},'Both harmonic units required')
    for obs,r in references.items():
        require(r['sigma0']>0 and r['moments']['modes']==20,'Original all-M harmonic reference required')
        require(abs(r['sigma0']**2/r['variance']['value']-1)<2e-15,'Harmonic sigma does not match variance')
        require(abs(r['independent_pair_creation_variance']/r['variance']['value']-1)<2e-12,'Independent reference variance mismatch')
    laws={};origins={};audit=dict(formal_log_max_scaled_error=0.,hard_probability_replay_max_error=0.,comparison_transcription_max_error=0.,
        maximum_spectral_moment_error=0.,maximum_original_increment_replay_error=0.,maximum_tail_eigensolver_absolute_difference=0.,
        maximum_tail_eigensolver_relative_difference=0.,minimum_requested_probability=1.,maximum_numerical_edge_mass=0.,tail_comparisons=0,
        source_filter_deletions=0,overlap_underflows=0,pressure_matrix_operations=0)
    with localcontext() as ctx:
        ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
        for case in data['cases']:
            job=one(spec['jobs'],lambda x:x['label']==case['label'],'pinned job')
            for k,h in [('input','input_sha256'),('archive','archive_sha256')]:
                require(case[k]==job[k] and case[h]==job[h],'Case input/hash mismatch');verify(case[k],case[h])
            parent=json.loads(local(case['input']).read_text());original=parent['cases'][job['case_index']]
            require(parent['status']==original['status']=='COMPLETED' and original['Q']==case['Q'],'Incomplete or mismatched physical parent')
            for k,v in expected_physical.items():require(original.get(k,0. if k=='soft' else None)==v,'Physical field mismatch: '+k)
            require(original.get('selected_spectrum',False)==(case['Q']==16),'Unexpected selection route')
            if case['Q']==16:require(original['target_bath_fraction']==.88,'Unexpected selected energy window')
            record=one(original['cosine'],lambda r:r['beta']==case['beta'],'parent beta')
            require(record['effective_archive']==case['archive'] and record['diagnostics']==case['original_diagnostics'],'Original archive/diagnostics mismatch')
            require(case['historical_physical_source_sha256']==parent['source_sha256'],'Historical physical source map altered')
            # The strictly hashed parent contains the historical map; do not compare old code versions with live source.
            origins[case['input']]=dict(parent_sha256=case['input_sha256'],historical_source_map_sha256=hashlib.sha256(json.dumps(parent['source_sha256'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),
                identity_scope='original source map contained in the hash-bound COMPLETED parent; no current-code substitution')
            require(case['original_diagnostics']['even_ground_certified_against_odd'] is True,'Original physical ground not certified')
            require(len(case['observables'])==2,'Both observables required')
            for law in case['observables']:
                obs=law['observable'];require(obs in references and law['sigma0']==references[obs]['sigma0'],'Common harmonic units changed')
                laws[case['Q'],case['beta'],obs]=law
                a=law['recurrence'];require(a['positive_moment_checks']['passed'] and a['spectral_reconstruction']['passed'],'Moment/spectral arithmetic unresolved')
                f=a['filter_arithmetic'];require(f['actual_ground_diagonal']==0. and f['dropped_nonzero_source_entries']==f['pressure_filter_product_underflow_entries']==0,'Centering or filter loss')
                if obs=='increment':require(f['diagonal_exactly_zero'] is True,'Increment diagonal not zero')
                m={int(n):D(v['decimal']) for n,v in a['moments'].items()};k={int(n):D(v['decimal']) for n,v in a['cumulants'].items()}
                require(m[1]==0 and all(m[n]>0 for n in (2,4,6,8)),'Centered positive even moments required')
                for n,value in formal_log(m).items():
                    error=float(abs(value-k[n])/max(abs(k[n]),m[2]**(D(n)/2)));audit['formal_log_max_scaled_error']=max(audit['formal_log_max_scaled_error'],error)
                    require(error<1e-60,'Scalar cumulant identity failed')
                audit['maximum_spectral_moment_error']=max(audit['maximum_spectral_moment_error'],max(law['independent_moment_scaled_errors'].values()))
                require(max(law['independent_moment_scaled_errors'].values())<=2e-8,'Independent pressure spectrum moment mismatch')
                if obs=='increment':
                    old=one(record['windows'],lambda w:w['tau']==51.2,'original tau')
                    for n in (2,4,6,8):
                        err=abs(a['even_moments'][str(n)]['value']/old['moments'][str(n)]-1)
                        require(err<=2e-8 and abs(err-law['original_increment_moment_relative_errors'][str(n)])<1e-15,'Original moment replay mismatch')
                        audit['maximum_original_increment_replay_error']=max(audit['maximum_original_increment_replay_error'],err)
                spectrum=law['spectrum'];x,p=spectrum['values_sigma0'],spectrum['weights']
                require(len(x)==len(p)==case['dimension'] and all(v>=0 for v in p) and abs(math.fsum(p)-1)<2e-11,'Spectral law normalization/positivity failed')
                require(spectrum['renormalized'] is False and spectrum['squared_overlap_underflow_count']==0,'Unexpected weight normalization/underflow')
                require(len(law['tail_panel'])==6 and len(law['eigensolver_tail_sensitivity'])==30,'Incomplete requested probability grid')
                for row in law['tail_panel']:
                    h=row['threshold_sigma0'];hard=math.fsum(v for z,v in zip(x,p) if abs(z)>h)
                    error=abs(hard-row['hard']['two_sided']['value']);audit['hard_probability_replay_max_error']=max(audit['hard_probability_replay_max_error'],error)
                    require(error<2e-15,'Hard-tail replay from saved spectrum failed')
                    audit['maximum_numerical_edge_mass']=max(audit['maximum_numerical_edge_mass'],row['hard']['numerical_edge_cluster_weight'])
                    for e in [row['hard'],*row['smooth']]:
                        v=e['two_sided']['value'];require(v is not None and v>=1e-10,'Audited relative-probability resolution changed')
                        audit['minimum_requested_probability']=min(audit['minimum_requested_probability'],v)
                for e in law['eigensolver_tail_sensitivity']:
                    require(e['status']=='RESOLVED_ABSOLUTE_AND_RELATIVE','Unresolved aggregate tail comparison')
                    require(e['absolute_difference']<=2e-11 and e['relative_difference']<=1e-5,'Tail eigensolver discrepancy exceeds accepted gate')
                    audit['maximum_tail_eigensolver_absolute_difference']=max(audit['maximum_tail_eigensolver_absolute_difference'],e['absolute_difference'])
                    audit['maximum_tail_eigensolver_relative_difference']=max(audit['maximum_tail_eigensolver_relative_difference'],e['relative_difference']);audit['tail_comparisons']+=1
    require(len(laws)==8 and audit['tail_comparisons']==240 and audit['maximum_numerical_edge_mass']==0.,'Audited case/edge scope changed')
    def effect(law,h,noise):
        row=one(law['tail_panel'],lambda r:r['threshold_sigma0']==h,'threshold')
        return row['hard'] if noise==0 else one(row['smooth'],lambda r:r['noise_sigma0']==noise,'readout width')
    table=[];grid=[];moment_drift={}
    for beta in (1.,3.):
        comp=one(data['comparisons'],lambda r:r['beta']==beta,'comparison beta')
        for obs in ('ordinary','increment'):
            a,b=laws[14,beta,obs],laws[16,beta,obs]
            co=one(comp['observables'],lambda r:r['observable']==obs,'comparison observable')
            moment_drift[str(beta)+'_'+obs]={str(n):b['recurrence']['even_moments'][str(n)]['value']/a['recurrence']['even_moments'][str(n)]['value']-1 for n in (2,4,6,8)}
            for h in spec['analysis']['thresholds_sigma0']:
                cr=one(co['tails'],lambda r:r['threshold_sigma0']==h,'comparison threshold')
                for noise in (0.,.1,.25,.5,1.):
                    ea,eb=effect(a,h,noise),effect(b,h,noise)
                    ca=cr['hard'] if noise==0 else one(cr['smooth'],lambda r:r['noise_sigma0']==noise,'comparison readout')
                    require(ca['Q14']==ea['two_sided'] and ca['Q16']==eb['two_sided'],'Comparison probabilities not bound to cases')
                    pa,pb=ea['two_sided']['value'],eb['two_sided']['value'];delta=pb-pa;relative=pb/pa-1
                    require(delta==ca['signed_change_Q16_minus_Q14'] and relative==ca['relative_change'],'Comparison drift transcription mismatch')
                    entry=dict(beta=beta,observable=obs,threshold_sigma0=h,readout_sigma0=noise,Q14=pa,Q16=pb,absolute_change=delta,relative_change=relative)
                    grid.append(entry)
                    if h==8. and noise in (0.,1.):table.append(entry)
    hardest=max((r for r in grid if r['readout_sigma0']==0.),key=lambda r:abs(r['relative_change']))
    largest=max(grid,key=lambda r:abs(r['absolute_change']))
    beta3hard=max((r for r in grid if r['beta']==3. and r['readout_sigma0']==0.),key=lambda r:abs(r['relative_change']))
    require((hardest['beta'],hardest['observable'],hardest['threshold_sigma0'])==(1.,'increment',12.),'Full-grid worst relative location changed')
    require((beta3hard['observable'],beta3hard['threshold_sigma0'])==('increment',10.),'Beta-three worst hard-tail location changed')
    require((largest['beta'],largest['observable'],largest['threshold_sigma0'],largest['readout_sigma0'])==(1.,'increment',2.,.5),'Full-grid worst absolute location changed')
    lines=[r'% Generated from the audited stage4 tail result; see stage4_tail_provenance.json.',
        '% Input: '+INPUT+' SHA256 '+INPUT_SHA,
        '% Controls: '+CONTROL+' SHA256 '+CONTROL_SHA,
        r'\subsection{Finite-model tail sensitivity beyond moment agreement}',r'\label{sec:s4-tail-results}',
        r'We compare saved full-cosine pressure matrices at $R=10$, $M=20$, $M_{\rm ref}=24$, $\tau=51.2$ and $\beta=1,3$. '
        r'The $Q=14\to16$ comparison changes both occupation and retained spectral selection; the latter uses a bath-threshold fraction $0.88$ at $Q=16$. '
        r'Write $O_\tau^c=O_\tau-\langle O_\tau\rangle_\beta I$ for the actual-ground-centered Gaussian pressure average and $X_\tau=O_\tau-O_{2\tau}$ for its width increment. '
        r'For each observable $Y$, use one common unit $\sigma_0(Y)$ from the original distributed harmonic $H_0$ with all 20 declared modes. '
        r'These units are $'+number(references['ordinary']['sigma0'],9)+r'$ and $'+number(references['increment']['sigma0'],9)+r'$ for $O_\tau^c$ and $X_\tau$, respectively. '
        r'The reference supplies units and moments here, not a calculated all-mode harmonic cumulative distribution.',
        r'The hard effect is the strict event $|Y|>h\sigma_0$; equality belongs inside. '
        r'For readout width $\eta>0$, define $p_\eta(h)=\Pr(|Y/\sigma_0+\eta Z|>h)$ with independent $Z\sim N(0,1)$. '
        r'This bounded spectral effect convolves a marginal law with readout noise; it does not specify sequential measurement back-action.',
        r'\begin{table}[t]\centering\small',
        r'\caption{Threshold $h=8$ in common original-$H_0$ units. $Y=O^c$ denotes centered ordinary pressure and $Y=X$ the width increment. '
        r'$\eta=0$ is the strict hard effect and $\eta=1$ the stated Gaussian readout. '
        r'$\delta p=100(p^{Q=16}/p^{Q=14}-1)$ is combined occupation/selection sensitivity, not a CDF error bound.}\label{tab:s4-tail-eight}',
        r'\begin{tabular}{cccrrr}\toprule',r'$\beta$ & $Y$ & $\eta$ & $p^{Q=14}$ & $p^{Q=16}$ & $\delta p$ (\%)\\\midrule']
    for r in table:
        lines.append(f"{r['beta']:g} & $"+('O^c' if r['observable']=='ordinary' else 'X')+f"$ & {r['readout_sigma0']:g} & {r['Q14']:.9f} & {r['Q16']:.9f} & "+percent(r['relative_change'])+r'\\')
    lines += [r'\bottomrule\end{tabular}\end{table}',
        r'At $\beta=1,3$, the increment eighth moments change by $'+percent(moment_drift['1.0_increment']['8'],7)+r'\%$ and $'+percent(moment_drift['3.0_increment']['8'],7)+r'\%$, '
        r'while the hard threshold-eight probabilities change by $'+percent(next(r for r in table if r['beta']==1 and r['observable']=='increment' and r['readout_sigma0']==0)['relative_change'],4)+r'\%$ and $'+percent(next(r for r in table if r['beta']==3 and r['observable']=='increment' and r['readout_sigma0']==0)['relative_change'],4)+r'\%$. '
        r'Thus agreement of moments through order eight does not certify hard tails. No requested threshold contains spectral mass within its numerical eigensolve edge band; the larger changes concern the discrete finite laws, rather than floating-point placement at a boundary.',
        r'Across $h=2,4,6,8,10,12$ and $\eta=0,0.1,0.25,0.5,1$, the largest relative hard-tail change is $'+percent(hardest['relative_change'],4)+r'\%$ at $\beta=1,h=12$; '
        r'for $\beta=3$ it is $'+percent(beta3hard['relative_change'],4)+r'\%$ at $h=10$. '
        r'The largest absolute change is $'+number(largest['absolute_change'],8)+r'$ at $\beta=1,h=2,\eta=0.5$, exceeding the corresponding hard-effect difference. '
        r'Smoothing therefore does not improve every threshold monotonically. The small $\eta=1$ changes in Table~\ref{tab:s4-tail-eight} describe a different, smoother observable, not physical CDF convergence.',
        r'All 17 independent controls pass, including known discrete laws, strict-boundary and zero-noise effects, degenerate-block rotations, and complete projected harmonic-pressure controls. '
        r'All eight saved-law moment checks and 240 aggregate tail comparisons between two eigensolver drivers pass; the largest relative eigensolver tail discrepancy is $'+number(audit['maximum_tail_eigensolver_relative_difference'],4)+r'$, '
        r'and the smallest requested probability is $'+number(audit['minimum_requested_probability'],7)+r'$, above the $10^{-10}$ relative-check floor. '
        r'No filter-source deletion or overlap underflow is reported. These checks concern supplied finite matrices: they do not bound omitted-state, source, ground-state, primitive, bath or line-mode errors. '
        r'The calculation neither establishes a rare-event limit nor resolves the growing common-interior hierarchy or vacuum intermittency.']
    tex='\n'.join(lines)+'\n'
    generator_hash=sha(Path(__file__));verified[str(Path(__file__).relative_to(ROOT))]=generator_hash
    prov=dict(status='GENERATED_FROM_AUDITED_COMPLETED_RESULTS',artifact_scope='finite saved-model marginal tails; combined occupation and spectral-selection sensitivity',
        inputs=verified,generator=dict(path=str(Path(__file__).relative_to(ROOT)),sha256=generator_hash),executed_analysis_source_sha256=data['source_sha256'],
        physical_parent_source_bindings=origins,analysis_status=data['status'],controls=dict(path=CONTROL,sha256=CONTROL_SHA,passed=17),
        reference_scope='original distributed harmonic H0 at all M=20 declared modes supplies common units and moments, not an all-mode CDF',
        common_units={k:v['sigma0'] for k,v in references.items()},table_rows=table,table_source_path='comparisons[beta].observables[observable].tails[threshold_sigma0=8]',
        full_grid_extrema=dict(largest_relative_hard_change=hardest,largest_absolute_change=largest,beta3_largest_relative_hard_change=beta3hard),
        even_moment_Q14_toQ16_fractional_changes=moment_drift,numerical_audit=audit,
        limitations=data['warnings'],output_sha256={TARGET:hashlib.sha256(tex.encode()).hexdigest()})
    # Recheck every bound file immediately before writing either owned artifact.
    for name,digest in verified.items():require(sha(local(name))==digest,'Input changed during extraction: '+name)
    mode='w' if args.replace else 'x'
    with target.open(mode) as stream:stream.write(tex)
    try:
        with provenance.open(mode) as stream:json.dump(prov,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    except BaseException:
        # Do not silently remove or rewrite any artifact on error; caller sees incomplete extraction.
        raise
    print('GENERATED stage4 tail fragment and provenance',flush=True)


if __name__=='__main__':main()
