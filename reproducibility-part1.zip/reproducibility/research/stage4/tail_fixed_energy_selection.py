"""Saved R10 beta1 tails at common interacting excitation-energy ceilings.

No physical solve. Compression means Pi_E P Pi_E, not conditioning a pressure
probability law and not replaying the original active-target selection rule.
"""
from pathlib import Path
from decimal import Decimal,localcontext
import argparse,json,math,os,signal,time,zipfile
import numpy as np
from scipy.linalg import eigh
import tail_refinement as tail
from full_cosine_hierarchy import parameters

ROOT=tail.ROOT;require=tail.require;path=tail.local;sha=tail.sha
FORMAT='stage4-tail-fixed-energy-selection-v1'
CHECKS=('known_atomic_selection_effect','filter_projection_and_scalar_centering','degenerate_block_rotation','selection_and_inventory_refusals','harmonic_and_full_selection_replay')
OWN=('research/stage4/tail_fixed_energy_selection.py','research/stage4/tail_fixed_energy_selection_controls.py')
CUTS=(.45,.48,.50)

def sources(spec):
    return {**{n:sha(path(n)) for n in spec['frozen_sources']},**{n:sha(path(n)) for n in OWN}}

def runtime():return tail.runtime_info()

def validate_jobs(jobs):
    require([(j['Q'],j['beta']) for j in jobs]==[(14,1.),(16,1.)],'exact ordered Q14/Q16 beta1 inventory required')
    for key in ('label','archive','archive_sha256','input','input_sha256'):
        require(len({j[key] for j in jobs})==2,'distinct parent/archive identities required: '+key)

def load_spec(name):
    sp=path(name);s=json.loads(sp.read_text())
    require(s['format']==FORMAT and s['energy_ceilings']==list(CUTS),'declared common spectral windows changed')
    require(s['tau']==51.2 and s['ratio']==2. and s['hbar']==1. and s['threshold']==8.,'pressure/window convention changed')
    require(s['saved_dimensions']=={'14':354,'16':508} and s['tail_relative_target']==.01,'dimension/decision target changed')
    require(s['control_names']==list(CHECKS),'control inventory changed');validate_jobs(s['jobs'])
    require(s['source_sha256']==sources(s),'new or frozen source changed')
    for key in ('tail_result','tail_controls','tail_spec','design'):
        b=s[key];require(sha(path(b['path']))==b['sha256'],'bound evidence changed: '+key)
    old=json.loads(path(s['tail_result']['path']).read_text());cs=json.loads(path(s['tail_controls']['path']).read_text())
    ospec=json.loads(path(s['tail_spec']['path']).read_text())
    require(old['status']=='COMPLETED_WITH_WARNINGS' and old['spec']==ospec and old['spec_sha256']==s['tail_spec']['sha256'],'tail result/spec incomplete or mismatched')
    require(cs['status']=='PASS' and len(cs['checks'])==17 and all(r['passed'] is True for r in cs['checks']),'accepted tail controls incomplete')
    require(old['controls']['sha256']==s['tail_controls']['sha256'] and cs['spec_sha256']==s['tail_spec']['sha256'],'tail control binding differs')
    require(s['frozen_sources']=={**old['source_sha256'],**cs['source_sha256']},'frozen source union differs from executed evidence')
    for n,h in s['frozen_sources'].items():require(sha(path(n))==h,'frozen source digest changed: '+n)
    require(s['jobs']==[j for j in ospec['jobs'] if j['beta']==1.],'selected jobs differ from executed tail specification')
    return sp,s,old,ospec

def admission(memory,dimension=508):
    require(math.isfinite(memory) and memory>=1024,'at least1024MB PYSCF_MAX_MEMORY required')
    # Two H eigensystems, sequential pressure eigensystems, JSON and I/O reserve.
    estimate=1024*dimension*dimension+128*1024**2
    require(estimate<.6*memory*1024**2,'saved-matrix workspace exceeds allowance')
    return estimate

def prepare_alternate(H,P):
    anchor=float(H[0,0]);HH=(H+H.T)/2-anchor*np.eye(len(H))
    E,U=eigh(HH,driver='evd');res=float(np.linalg.norm(HH@U-U*E));Pe=U.T@P@U;Pe=(Pe+Pe.T)/2
    mean=float(Pe[0,0]);Pc=Pe-mean*np.eye(len(Pe));Pc[0,0]=0.
    require(E[1]>E[0],'alternate ground unresolved')
    return E-E[0],Pc,mean,dict(eigensolve_residual_frobenius=res,scope='alternate binary64 eigensolve, not interval enclosure')

def energy_slice(E,P,ceiling,omitted_floor,residual):
    E=np.asarray(E);P=np.asarray(P);require(E.ndim==1 and P.shape==(len(E),len(E)) and len(E)>1,'invalid energy/source shape')
    require(np.isfinite(E).all() and np.isfinite(P).all() and E[0]==0 and np.all(np.diff(E)>=0),'finite ordered ground-referenced energies required')
    guard=max(1e-12,10*float(residual)+128*np.finfo(float).eps*max(1.,float(E[-1])))
    if ceiling is None:
        count=len(E);selection=dict(rule='native complete saved lowest cluster',count=count,ceiling=None)
    else:
        require(math.isfinite(ceiling) and ceiling>0 and ceiling+guard<min(float(E[-1]),float(omitted_floor)),'common ceiling exceeds available complete spectral cluster')
        count=int(np.searchsorted(E,ceiling,side='right'))
        require(1<count<len(E),'selection needs vacuum, excitations and a represented excluded state')
        require(min(ceiling-E[count-1],E[count]-ceiling)>guard,'energy ceiling touches unresolved eigenvalue or degeneracy')
        selection=dict(rule='all interacting even states with E-E0<=common physical ceiling',count=count,ceiling=float(ceiling),last_retained_gap=float(E[count-1]),first_excluded_gap=float(E[count]),distance_to_cut=float(min(ceiling-E[count-1],E[count]-ceiling)),boundary_gap=float(E[count]-E[count-1]),arithmetic_guard=guard,parent_omitted_floor=float(omitted_floor),scope='guard uses measured residuals; not a rigorous interval spectral projector')
    A=P[:count,:count].copy();A[0,0]=0.
    return E[:count].copy(),A,selection

def probability(law,threshold=8.,noise=0.):
    r=next(x for x in law['tail_panel'] if x['threshold_sigma0']==threshold)
    e=r['hard'] if noise==0 else next(x for x in r['smooth'] if x['noise_sigma0']==noise)
    value=e['two_sided']['value'];require(value is not None and math.isfinite(value),'unrepresented tail probability')
    return value

def compare_laws(a,b,config):
    rows=[]
    for h in config['thresholds_sigma0']:
        for noise in [0.,*config['noise_sigma0']]:
            x,y=probability(a,h,noise),probability(b,h,noise);d=abs(y-x);relative=d/max(x,y) if max(x,y)>0 else 0.
            require(d<=config['probability_absolute_tolerance'],'H-driver tail disagreement')
            if min(x,y)>=config['relative_probability_floor']:require(relative<=config['probability_relative_tolerance'],'H-driver relative tail disagreement')
            rows.append(dict(threshold=h,noise=noise,absolute=d,relative=relative))
    return rows

def compare_h_moments(a,b,config):
    """Compare positive even moments across the two H eigensolve drivers.

    This is separate from each pressure law's internal spectral/recurrence
    check. Decimal scalar records avoid another small-moment division floor.
    """
    require(a['sigma0']==b['sigma0'] and math.isfinite(a['sigma0']) and a['sigma0']>0,'H drivers must use identical positive harmonic units')
    ma=a['recurrence']['even_moments'];mb=b['recurrence']['even_moments']
    require(set(ma)==set(mb)=={'2','4','6','8'},'exact H-driver even-moment inventory required')
    rows=[]
    with localcontext() as ctx:
        ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
        sigma=Decimal.from_float(a['sigma0']);tol=Decimal(str(config['moment_tolerance']))
        require(0<tol<1,'positive bounded H-driver moment tolerance required')
        for n in (2,4,6,8):
            x=Decimal(ma[str(n)]['decimal']);y=Decimal(mb[str(n)]['decimal'])
            require(x.is_finite() and y.is_finite() and x>0 and y>0,'positive finite H-driver moments required')
            delta=abs(x-y);relative=delta/max(x,y);common=delta/sigma**n
            require(relative<=tol,'H-driver even-moment disagreement')
            rows.append(dict(order=n,primary_moment=ma[str(n)],alternate_moment=mb[str(n)],
                absolute_difference_decimal=str(delta),symmetric_relative_difference=float(relative),
                difference_in_common_sigma0_power_decimal=str(common)))
    return dict(passed=True,relative_tolerance=float(tol),rows=rows,
        maximum_symmetric_relative_difference=max(r['symmetric_relative_difference'] for r in rows),
        scope='measured H-eigensolver sensitivity of positive even moments; no arithmetic interval or omitted-state bound')


def decompose(p14native,p16native,p14cut,p16cut):
    delta=p16native-p14native;within=p16cut-p14cut
    remove14=p14cut-p14native;restore16=p16native-p16cut
    error=math.fsum([restore16,within,remove14,-delta])
    require(abs(error)<2e-15,'native/common-window telescoping identity failed')
    return dict(native_difference=delta,Q_difference_at_fixed_ceiling=within,Q14_native_to_ceiling=remove14,Q16_ceiling_to_native=restore16,identity_error=error,fixed_ceiling_difference_over_native=within/delta if delta else None,fixed_ceiling_relative_Q_drift=p16cut/p14cut-1 if p14cut else None,scope='exact arithmetic decomposition along a declared comparison path, not unique physical or additive causal attribution')

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--spec',default='research/stage4/tail_fixed_energy_selection_spec.json');ap.add_argument('--controls',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    sp,s,old,ospec=load_spec(args.spec);cp=path(args.controls);control=json.loads(cp.read_text());mem=tail.memory_limit();estimate=admission(mem)
    require(control['format']==FORMAT+'-controls' and control['status']=='PASS' and tuple(r['name'] for r in control['checks'])==CHECKS and all(r['passed'] is True for r in control['checks']),'new selection controls absent/incomplete')
    require(control['source_sha256']==sources(s) and control['spec_sha256']==sha(sp) and control['runtime']==runtime(),'new control identity/runtime changed')
    rt=runtime();require(all(v=='1' for k,v in rt['declared_environment'].items() if k!='PYSCF_MAX_MEMORY'),'five one-thread declarations required')
    result=dict(format=FORMAT,status='RUNNING_NOT_RESULT',spec=s,spec_sha256=sha(sp),source_sha256=sources(s),controls=dict(path=str(cp.relative_to(ROOT)),sha256=sha(cp)),runtime=rt,memory_mb=mem,estimated_workspace_bytes=estimate,cases=[],comparisons=[],warnings=['Finite supplied matrices only; original source, graph, primitive, bath and mode errors remain.','Same posthoc interacting-energy rule does not recreate the historical active-target rule.','Neither tail stability nor smoothing provides an omitted-state CDF certificate.','This does not complete the growing common-interior scale study.'])
    dest=tail.claim_output(args.output,result);start=time.monotonic()
    def save():result['elapsed_seconds']=time.monotonic()-start;tail.save_output(dest,result)
    def stop(sig,frame):raise RuntimeError('fixed-energy tail analysis interrupted')
    signal.signal(signal.SIGTERM,stop)
    try:
        modes,_,_=parameters(10,20);refs={}
        for obs,inc in [('ordinary',False),('increment',True)]:
            with localcontext() as ctx:ctx.prec=80;mom,info=tail.controlled.harmonic(modes,51.2,inc,2.)
            sigma=float(mom[2].sqrt());require(abs(sigma/old['reference_units'][obs]['sigma0']-1)<2e-12,'original all-M harmonic units differ')
            refs[obs]=dict(sigma0=sigma,independent_harmonic=info,previous_reference=old['reference_units'][obs])
        result['reference_units']=refs;common=None;occupations=None
        config=dict(ospec['analysis']);config['thresholds_sigma0']=[8.,9.]
        for job in s['jobs']:
            pp=path(job['input']);ar=path(job['archive']);require(sha(pp)==job['input_sha256'] and sha(ar)==job['archive_sha256'],'physical parent/archive changed')
            parent=json.loads(pp.read_text());case=parent['cases'][job['case_index']]
            require(parent['status']==case['status']=='COMPLETED' and case['Q']==job['Q'],'physical case incomplete or wrong Q')
            for k,v in ospec['physical_parameters'].items():require(case.get(k,0. if k=='soft' else None)==v,'physical parameter mismatch: '+k)
            records=[r for r in case['cosine'] if r['beta']==1.];require(len(records)==1,'physical beta ambiguous');record=records[0];di=record['diagnostics']
            require(record['effective_archive']==job['archive'] and di['even_ground_certified_against_odd'] is True and di['retained_cluster_certification_margin']>di['original_hamiltonian_residual_bound'],'parent cluster/ground not accepted')
            with zipfile.ZipFile(ar) as z:require(sum(i.file_size for i in z.infolist())<.25*mem*1024**2,'archive I/O allowance exceeded')
            with np.load(ar,allow_pickle=False) as a:
                H=a['H'].copy();P=a['P'].copy();triple=tuple(a[k].copy() for k in ('omega','couplings','reference','bath_states'));low=a['low_states'].copy();sector=str(a['retained_sector'])
            require(H.shape==P.shape==(s['saved_dimensions'][str(job['Q'])],)*2 and 'even' in sector.lower(),'saved dimensions/parity differ');admission(mem,len(H))
            for a,b in zip(triple[:3],(case['omega'],case['couplings'],case['reference_variances'])):require(np.array_equal(a,np.asarray(b)),'archive calibration differs from parent')
            require(np.array_equal(triple[0],modes.omega),'declared H0 differs from saved frequencies')
            if common is None:common=triple;occupations={tuple(x) for x in low}
            else:
                require(all(np.array_equal(a,b) for a,b in zip(common,triple)),'calibration or bath coordinates changed')
                require(occupations.issubset({tuple(x) for x in low}),'bare occupation labels are not nested')
            E,Pc,mean,eig=tail.controlled.eigen_prepare(H,P);Ee,Pe,meane,eige=prepare_alternate(H,P)
            item=dict(label=job['label'],Q=job['Q'],beta=1.,parent=job,input_case={k:v for k,v in case.items() if k not in ('cosine','harmonic')},historical_physical_source_sha256=parent['source_sha256'],original_diagnostics=di,eigensolve=eig,alternate_eigensolve=eige,removed_actual_ground_mean=mean,alternate_removed_mean=meane,windows=[])
            result['cases'].append(item)
            prior=next(c for c in old['cases'] if c['label']==job['label'])
            require(prior['original_diagnostics']==di and prior['archive_sha256']==job['archive_sha256'] and prior['input_sha256']==job['input_sha256'],'saved-tail history differs from physical parent')
            for ceiling in [None,*CUTS]:
                en,pc,selection=energy_slice(E,Pc,ceiling,di['omitted_interacting_threshold_lower_bound'],eig['eigensolve_residual_frobenius']+di['original_hamiltonian_residual_bound'])
                ee,pe,se=energy_slice(Ee,Pe,ceiling,di['omitted_interacting_threshold_lower_bound'],eige['eigensolve_residual_frobenius']+di['original_hamiltonian_residual_bound']);require(selection['count']==se['count'],'H drivers choose different energy blocks')
                window=dict(ceiling=ceiling,selection=selection,alternate_selection=se,observables=[]);item['windows'].append(window)
                for obs,inc in [('ordinary',False),('increment',True)]:
                    sigma=refs[obs]['sigma0'];law=tail.law_from_prepared(pc,en,51.2,inc,2.,sigma,mem,config);alternate=tail.law_from_prepared(pe,ee,51.2,inc,2.,sigma,mem,config)
                    law['H_eigensolver_tail_comparison']=compare_laws(law,alternate,config)
                    law['H_eigensolver_even_moment_comparison']=compare_h_moments(law,alternate,config)
                    if ceiling is None:
                        previous=next(r for r in prior['observables'] if r['observable']==obs)
                        replay=[]
                        for noise in [0.,*config['noise_sigma0']]:
                            p,q=probability(law,8.,noise),probability(previous,8.,noise);require(abs(p-q)<=2e-11 and abs(p/q-1)<=1e-5,'original threshold8 tail not replayed');replay.append(dict(noise=noise,absolute=abs(p-q),relative=p/q-1))
                        err={str(n):abs(law['recurrence']['even_moments'][str(n)]['value']/previous['recurrence']['even_moments'][str(n)]['value']-1) for n in (2,4,6,8)}
                        require(max(err.values())<2e-8,'original moment replay failed');law['original_tail_replay']=replay;law['original_even_moment_relative_errors']=err
                    window['observables'].append(law);save()
            del H,P,Pc,E,Pe,Ee
        require(len(result['cases'])==2 and all(len(c['windows'])==4 and all(len(w['observables'])==2 for w in c['windows']) for c in result['cases']),'result inventory incomplete')
        for oi,obs in enumerate(('ordinary','increment')):
            c14,c16=result['cases'];by=[]
            for j,cut in enumerate(CUTS,1):
                effects=[]
                for noise in [0.,*config['noise_sigma0']]:
                    args4=[probability(c14['windows'][0]['observables'][oi],8.,noise),probability(c16['windows'][0]['observables'][oi],8.,noise),probability(c14['windows'][j]['observables'][oi],8.,noise),probability(c16['windows'][j]['observables'][oi],8.,noise)]
                    effects.append(dict(noise=noise,probabilities=dict(zip(('Q14_native','Q16_native','Q14_common','Q16_common'),args4)),**decompose(*args4)))
                by.append(dict(ceiling=cut,effects=effects))
            harddrifts=[r['effects'][0]['fixed_ceiling_relative_Q_drift'] if min(r['effects'][0]['probabilities'][k] for k in ('Q14_common','Q16_common'))>=config['relative_probability_floor'] else None for r in by]
            refinements={str(c['Q']):[probability(w['observables'][oi]) for w in c['windows'][1:]] for c in result['cases']}
            ceilingdrifts={q:[abs(b/a-1) if min(a,b)>=config['relative_probability_floor'] else None for a,b in zip(ps,ps[1:])] for q,ps in refinements.items()}
            result['comparisons'].append(dict(observable=obs,common_windows=by,hard_common_Q_drifts_below_one_percent=all(x is not None and abs(x)<=s['tail_relative_target'] for x in harddrifts),hard_within_Q_ceiling_drifts=ceilingdrifts,all_declared_hard_ceiling_drifts_below_one_percent=all(x is not None and x<=s['tail_relative_target'] for a in ceilingdrifts.values() for x in a),criterion_scope='prespecified finite-matrix sensitivity targets; passing is not a physical tail error bound'))
        require(sources(s)==result['source_sha256'] and sha(cp)==result['controls']['sha256'] and runtime()==rt,'analysis sources/control/runtime changed');load_spec(args.spec)
        for job in s['jobs']:require(sha(path(job['input']))==job['input_sha256'] and sha(path(job['archive']))==job['archive_sha256'],'physical evidence changed during run')
        result['status']='COMPLETED_WITH_SCOPE_LIMITATIONS';save()
    except BaseException as error:result.update(status='FAILED',error=repr(error));save();raise
    print('COMPLETED_WITH_SCOPE_LIMITATIONS fixed-energy tail selection',flush=True)

if __name__=='__main__':main()
