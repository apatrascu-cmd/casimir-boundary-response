"""Reconstruct and profile one pinned R10 beta1/3 linear-source tensor.

Root-launched only. Full composite pressure is replayed; mode-resolved outside
source weight is not assigned an energy or promoted to a closure certificate.
"""
from __future__ import annotations
import argparse,ast,hashlib,json,math,os,platform,signal,sys,time,uuid,zipfile
from pathlib import Path
import numpy as np
import scipy
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'research/stage3'),str(ROOT/'src')]
import linear_source_reach as core
import linear_source_reach_controls as profile_controls
from tensor_cosine import tensor_model
import tensor_wick_sources as original
from tensor_even_graph import block_parity_eigh
from full_cosine_hierarchy import spectral_moments,shape_logs
from dressed_cosine_hierarchy import parameters
FORMAT='stage4-R10-linear-source-reach-physical-v1'
WRAPPER_CHECKS=('independent_original_coordinate_transform_and_source_sign','original_H_pressure_replay_gauge_and_shift','historical_helper_identity_and_bound_roles','immutable_spec_control_and_gate_refusals')


def require(ok,message):
    if not ok:raise ValueError(message)


def path(name):
    p=(ROOT/name).resolve();require(p.is_relative_to(ROOT),'project-local path required');return p


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def runtime():
    return dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),machine=platform.machine(),declared_threads={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')})


def sources():
    files={Path(__file__).resolve(),Path(__file__).with_name('linear_source_reach_physical_controls.py')}
    for module in list(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if filename:
            p=Path(filename).resolve()
            if p.is_relative_to(ROOT) and p.suffix=='.py' and p.relative_to(ROOT).parts[0] in ('research','src'):files.add(p)
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}


def jsonable(value):
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,np.generic):return value.item()
    if isinstance(value,dict):return {str(k):jsonable(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [jsonable(v) for v in value]
    return value


def save(p,value):
    tmp=p.with_name(p.name+'.writing-'+uuid.uuid4().hex)
    with tmp.open('x') as f:json.dump(jsonable(value),f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)


def helper_identity(spec):
    histories={}
    for role in ('current','historical'):
        binding=spec['parity_helper_files'][role];p=path(binding['path']);require(sha(p)==binding['sha256'],'parity helper file changed: '+role)
        text=p.read_text();tree=ast.parse(text);histories[role]={}
        for name,h in spec['parity_helper_function_sha256'].items():
            node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
            actual=hashlib.sha256(ast.get_source_segment(text,node).encode()).hexdigest();require(actual==h,'imported parity helper body changed: '+name);histories[role][name]=actual
    require(histories['current']==histories['historical'],'historical/current imported helper functions differ')
    return histories


def load_spec(name):
    sp=path(name);spec=json.loads(sp.read_text());require(spec['format']==FORMAT,'wrong immutable specification')
    require(spec['physical']==dict(R=10,M=20,calibration_modes=24,Q=12,low_count=5,bath_dimension=128,primitive=32,tau=51.2,hard=.5,coupling_family='equal_reference_phase'),'physical specification changed')
    require(spec['taus']==[36.2038671968,51.2,72.4077343935] and spec['ratio']==2.,'fixed window inventory changed')
    require([j['beta'] for j in spec['jobs']]==[1.,3.],'beta panel changed')
    require(spec['replay_relative_tolerance']==2e-8 and spec['source_replay_scaled_tolerance']==2e-10,'replay tolerances changed')
    require(spec['graph']==dict(tolerance=2e-14,max_iterations=80,damping=1.,compress=True),'original graph settings changed')
    for name,h in spec['frozen_sources'].items():require(sha(path(name))==h,'frozen scientific source changed: '+name)
    helper_identity(spec)
    binding=spec['legacy_source_controls'];cp=path(binding['path']);require(sha(cp)==binding['sha256'],'historical source-control record changed');legacy=json.loads(cp.read_text())
    require(legacy['status']=='PASS' and [len(legacy[k]) for k in ('harmonic','degenerate','omission','tensor')]==[24,2,3,4] and 'known_non_wick_control' in legacy,'historical full source controls incomplete')
    for key,digest in legacy['source_sha256'].items():
        source_path=spec['parity_helper_files']['historical']['path'] if key=='tensor_even_graph.py' else 'research/stage3/'+key
        require(sha(path(source_path))==digest,'historically controlled scientific source differs: '+key)
    for j in spec['jobs']:
        for key in ('parent','archive'):
            b=j[key];require(sha(path(b['path']))==b['sha256'],'pinned physical input changed')
    return sp,spec


def core_control_gate(binding):
    p=path(binding['path']);require(sha(p)==binding['sha256'],'source-reach control record changed');r=json.loads(p.read_text())
    require(r['status']=='PASS' and r['format']==core.FORMAT,'completed source-reach controls required')
    require(tuple(c['name'] for c in r['checks'])==profile_controls.CONTROL_NAMES and all(c['passed'] is True for c in r['checks']),'exact five source-reach groups required')
    require(r['source_sha256']==profile_controls.identity(),'source-reach controls do not bind current core')
    expected=runtime();expected.pop('scipy');require(r['runtime']==expected,'source-reach control runtime differs')
    return r


def wrapper_record_gate(r,spec_sha):
    require(r['status']=='PASS' and r['format']==FORMAT+'-controls','complete new wrapper controls required')
    require(tuple(c['name'] for c in r['checks'])==WRAPPER_CHECKS and all(c['passed'] is True for c in r['checks']),'exact four wrapper controls required')
    require(r['source_sha256']==sources() and r['runtime']==runtime() and r['spec_sha256']==spec_sha,'wrapper source/runtime/spec controls differ')
    core_control_gate(r['core_controls']);return r


def wrapper_control_gate(p,spec_sha):
    return wrapper_record_gate(json.loads(p.read_text()),spec_sha)


def memory_plan(memory):
    require(math.isfinite(memory) and memory>=6144,'physical reconstruction requires at least 6144 MB declared memory')
    nl,nb,M=421,128,20
    estimate=12*8*nb*nl*nl+8*128*nl*nl+384*1024**2
    require(estimate<.6*memory*10**6,'physical planned workspace exceeds 60% allocation')
    return dict(memory_mb=memory,estimated_bytes=estimate,low_dimension=nl,bath_dimension=nb,odd_tensor_dimension=26934,
      scope='conservative formula allowance; original solver and source core independently enforce their own memory gates; no dense full tensor')


def graph_gate(graph,e,ep):
    require(int(ep[0])==0,'retained ground is not even')
    for key in ('retained_cluster_certification_margin','active_to_excited_bath_separation_margin','omitted_interacting_threshold_lower_bound','odd_sector_ground_block_lower_bound','omitted_odd_transition_energy_lower_bound'):
        require(math.isfinite(graph[key]) and graph[key]>0,'original graph/odd gate failed: '+key)
    require(math.isfinite(graph['original_hamiltonian_residual_bound']) and graph['original_hamiltonian_residual_bound']<1e-10,'original-H residual unresolved')
    require(graph['forbidden_parity_graph_frobenius']==0.,'forbidden graph parity is nonzero')
    require(graph['low_dimension']==421 and graph['bath_dimension']==128 and graph['active_odd_dimension']==210,'source factor/target dimensions changed')
    require(len(e)==421 and e[1]>e[0],'retained full-parity ground not simple')


def original_coordinates(w,ua,ub,g):
    rot=np.tensordot(w,g,axes=(2,0));return ub@rot@ua.T


def projected_source(w,ua,ub,left,right,sign,panel=16):
    nb,nl,nc=w.shape;l=ua.T@left@ua;b=ub.T@right@ub;result=np.empty((nc,nc));flat=w.reshape(nb*nl,nc)
    for start in range(0,nc,panel):
        stop=min(nc,start+panel);v=w[:,:,start:stop]
        action=np.matmul(l,v)+(b@v.reshape(nb,-1)).reshape(v.shape)
        result[:,start:stop]=flat.T@action.reshape(nb*nl,-1)
    defect=float(np.linalg.norm(result-sign*result.T));return (result+sign*result.T)/2,defect


def relative_replay(actual,expected,tolerance):
    require(set(actual)==set(expected),'moment inventory differs')
    errors={str(k):abs(float(actual[k])/float(expected[k])-1) for k in actual}
    require(all(math.isfinite(v) and v<tolerance for v in errors.values()),'saved moment replay failed')
    return errors


def read_inputs(spec,beta,memory):
    job=next(j for j in spec['jobs'] if j['beta']==beta);parent=json.loads(path(job['parent']['path']).read_text())
    require(parent['status']=='COMPLETED','historical parent not completed');case=parent['cases'][job['case_index']];row=case['cosine'][job['row_index']]
    require(case['status']=='COMPLETED' and row['beta']==beta and row['archive']==job['archive']['path'],'historical case/row/archive binding changed')
    for k,v in spec['physical'].items():
        if k=='bath_dimension':require(case[k]==v,'bath dimension changed')
        else:require(case.get(k)==v,'historical physical identity differs: '+k)
    require(case.get('bath_quanta',4)==4 and case.get('soft',0)==0 and case['bath_top']==24,'original finite factor rule changed')
    p=path(job['archive']['path'])
    with zipfile.ZipFile(p) as z:require(sum(x.file_size for x in z.infolist())<.05*memory*10**6,'archive exceeds small-data allocation')
    with np.load(p,allow_pickle=False) as z:saved={k:z[k].copy() for k in z.files}
    expected={'H','P','D','Z_imag','parities','omega','d','z','low_states','bath_states','reference','couplings'}
    require(set(saved)==expected,'historical source archive schema differs')
    for k in ('H','P','D','Z_imag'):require(saved[k].shape==(421,421) and np.isfinite(saved[k]).all(),'historical matrix malformed')
    require(saved['low_states'].shape==(421,20) and saved['bath_states'].shape==(128,20),'historical basis dimensions differ')
    for key,field in [('reference','reference_variances'),('couplings','couplings')]:require(np.array_equal(saved[key],case[field]),'archive calibration differs from parent')
    modes,_,_=parameters(10,20);rm,_,_=parameters(10,24);ref=np.sum(rm.branch**2*rm.p.hbar/(2*rm.omega)[None,:],axis=1)
    require(np.max(abs(ref-saved['reference'])/abs(saved['reference']))<128*np.finfo(float).eps,'regenerated reference recipe differs')
    require(np.allclose(-np.asarray(modes.p.KJ)/saved['reference'],saved['couplings'],rtol=128*np.finfo(float).eps,atol=0),'fixed reference coupling differs')
    # Freeze the original actual reference numbers for this reconstruction.
    return job,parent,case,row,saved,modes


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--spec',default='research/stage4/linear_source_reach_physical_spec.json');ap.add_argument('--controls',required=True);ap.add_argument('--beta',type=float,choices=[1.,3.],default=1.);ap.add_argument('--output',required=True);a=ap.parse_args()
    sp,spec=load_spec(a.spec);control_path=path(a.controls);control=wrapper_control_gate(control_path,sha(sp));source=sources();control_sha=sha(control_path)
    memory=float(os.environ['PYSCF_MAX_MEMORY']);plan=memory_plan(memory);job,parent,case,row,saved,modes=read_inputs(spec,a.beta,memory)
    dest=path(a.output);require(dest.is_relative_to(ROOT/'research/stage4') and dest.suffix=='.json' and dest.parent.is_dir(),'exclusive new stage4 JSON required');archive=dest.with_suffix('.npz');require(not archive.exists(),'companion archive exists')
    begin=time.monotonic();out=dict(format=FORMAT,status='RUNNING_NOT_A_RESULT',beta=a.beta,spec=spec,spec_sha256=sha(sp),source_sha256=source,runtime=runtime(),memory_plan=plan,
      controls=dict(path=str(control_path.relative_to(ROOT)),sha256=control_sha),core_controls=control['core_controls'],input_binding=job,
      historical_source_sha256=parent['source_sha256'],historical_current_parity_helpers=helper_identity(spec),physical_metadata={k:v for k,v in case.items() if k!='cosine'},
      scope='mode-resolved source covariance outside the existing tensor; no energy-placement, full-source spectral or physical closure certificate')
    with dest.open('x') as f:json.dump(out,f)
    def persist():out['elapsed_seconds']=time.monotonic()-begin;save(dest,out)
    def terminate(signum,frame):raise RuntimeError('resource admission interrupted physical source diagnostic')
    signal.signal(signal.SIGTERM,terminate)
    try:
        start=time.monotonic();model=tensor_model(modes,saved['couplings'],a.beta,saved['low_states'],saved['bath_states'],range(5),32,saved['reference'],memory)
        out['model_build_seconds']=time.monotonic()-start;persist();start=time.monotonic()
        H,P,w,ua,ub,par,e,vectors,ep,graph=original._graph_with_embedding(model,memory_mb=memory,**spec['graph'])
        graph_gate(graph,e,ep);out['graph']=graph;out['graph_seconds']=time.monotonic()-start;persist()
        psi=original_coordinates(w,ua,ub,vectors[:,0]);reduced={};source_symmetry={}
        for name,(left,right) in original.linear_group_sources(model,modes).items():
            reduced[name],source_symmetry[name]=projected_source(w,ua,ub,left,right,1 if name=='D' else -1)
        transitions=original.transitions_from_operators(H,reduced['D'],reduced['Z_imag'],par,modes.p.hbar)
        E,microscopic,_=spectral_moments(H,P,spec['taus'],modes.p.hbar,spec['ratio']);replays=[]
        for tau,actual,old in zip(spec['taus'],microscopic,row['windows']):
            require(tau==old['tau'],'saved window literal differs');wick=original.wick_pressure_increment(transitions,tau,modes.p.C0,modes.p.L0,spec['ratio'],memory_mb=memory)
            replays.append(dict(tau=tau,microscopic_relative_errors=relative_replay(actual,old['microscopic_moments'],spec['replay_relative_tolerance']),
              Wick_relative_errors=relative_replay(wick['moments'],old['wick']['moments'],spec['replay_relative_tolerance']),microscopic_moments=actual,Wick=wick,
              contrast=shape_logs(actual,wick['moments'])))
        # Spectral matrix-valued response is compared at the original quadrature
        # widths as Euclidean test functions, retaining DZ and no eigenvector gauge.
        response=[]
        for t in [0.]+spec['taus']:
            def measure(om,d,z):
                weights=np.exp(-t*om);return np.array([[np.dot(d*d,weights),np.dot(d*z,weights)],[np.dot(d*z,weights),np.dot(z*z,weights)]])
            new=measure(transitions['omega'],transitions['d'],transitions['z']);old=measure(saved['omega'],saved['d'],saved['z'])
            error=float(np.max(abs(new-old)/np.maximum(abs(old),1e-16)));require(error<spec['replay_relative_tolerance'],'retained DD/ZZ/DZ response replay failed')
            response.append(dict(Euclidean_time=t,retained_2x2_response=new,max_scaled_error=error,unit_floor=1e-16))
        out.update(retained_window_replays=replays,retained_response_replays=response,projected_source_symmetry_residuals=source_symmetry);persist()
        start=time.monotonic();profile=core.source_reach(model,modes,psi,memory_mb=memory,return_seeds=True);out['source_reach_seconds']=time.monotonic()-start
        controls=[]
        for j,name in enumerate(('D','Z_imag')):
            sd=row['source_diagnostics'][name];computed=dict(full_ground_weight=float(profile['physical_grams']['projected'][j,j]),
              independently_projected_second_moment=float(profile['physical_grams']['complete'][j,j]),outside_tensor_source_weight_raw=float(profile['physical_grams']['outside'][j,j]))
            errors={k:abs(val-sd[k])/max(1.,abs(sd[k])) for k,val in computed.items()};require(max(errors.values())<spec['source_replay_scaled_tolerance'],'historical source norm/contact replay failed')
            controls.append(dict(source=name,recomputed=computed,old_values={k:sd[k] for k in computed},scaled_errors=errors,old_upper=sd['outside_tensor_source_weight_upper'],old_allowance=sd['outside_tensor_weight_diagnostic_allowance'],unit_floor=1.))
        coefficients=profile['coefficients'];weighted=profile['weighted_modal_outside_gram'];M=20
        modal=[]
        for j in range(M):modal.append(dict(mode=j,omega=float(modes.omega[j]),group='active' if j<5 else 'bath',D_weighted_diagonal=float(weighted[j,j]),Z_weighted_diagonal=float(weighted[M+j,M+j]),diagonal_sum=float(weighted[j,j]+weighted[M+j,M+j])))
        physical=profile['physical_grams'];out.update(source_replay=controls,source_reach_diagnostics=profile['diagnostics'],physical_grams=physical,modal_diagonal_contributions=modal,
          coherent_offdiagonal_covariance_scale=float(physical['outside'][0,0]/modes.p.L0+modes.p.C0*physical['outside'][1,1]-np.trace(weighted)),
          warnings=['The original embedding and ground are approximate; source/graph/arithmetic corrections are not enclosed.','Outside source Gram retains negative floating eigenvalues, if any; no PSD clipping or spectral-energy assignment.','Diagonal modal ranking omits coherent cross terms; the full Gram is the permanent artifact.','A reconstructed original finite tensor does not establish modal/primitive/configuration completeness.'])
        arrays={k:profile[k] for k in ('modal_complete_gram','modal_projected_gram','modal_outside_gram','weighted_modal_outside_gram','coefficients','projected_physical_seeds')}
        arrays.update(ground_original_tensor=psi,orbitals=np.asarray(model['local']['orbitals']),H=H,P=P,D=reduced['D'],Z_imag=reduced['Z_imag'],retained_parities=par,
          transition_omega=transitions['omega'],transition_d=transitions['d'],transition_z=transitions['z'],omega=modes.omega,low_states=saved['low_states'],bath_states=saved['bath_states'],reference=saved['reference'],couplings=saved['couplings'])
        with archive.open('xb') as f:np.savez_compressed(f,**arrays);f.flush();os.fsync(f.fileno())
        out['archive']=dict(path=str(archive.relative_to(ROOT)),sha256=sha(archive),bytes=archive.stat().st_size,arrays={k:dict(shape=list(v.shape),dtype=str(v.dtype)) for k,v in arrays.items()})
        require(sources()==source and sha(sp)==out['spec_sha256'] and sha(control_path)==control_sha,'source/spec/control changed during run');load_spec(a.spec);core_control_gate(control['core_controls'])
        out['status']='COMPLETED_SOURCE_REACH_NOT_ENERGY_CERTIFICATE';persist()
    except BaseException as exc:out.update(status='FAILED',error=repr(exc));persist();raise
    print('COMPLETED_SOURCE_REACH_NOT_ENERGY_CERTIFICATE beta='+str(a.beta),flush=True)

if __name__=='__main__':main()
