"""Finite saved-pressure spectral effects; no physical omitted-state CDF claim.

All x, thresholds h and Gaussian readout widths s are in ONE declared original
harmonic sigma0 unit for the observable. Hard effects use the strict event
|x|>h. Smooth effects are probabilities for |x+s Z|>h with independent Z~N(0,1).
This marginal readout convolution is not a sequential quantum instrument.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import hashlib
import json
import math
import os
import platform
import scipy
import sys
import uuid
import numpy as np
from scipy.linalg import eigh
from scipy.special import log_ndtr, logsumexp

ROOT = Path(__file__).resolve().parents[2]
STAGE4 = ROOT/'research/stage4'
sys.path[:0] = [str(ROOT/'research/stage3'),str(ROOT/'src'),str(ROOT/'research'),str(ROOT/'research/stage2')]
import analyze_saved_common_widths_2026_09_15 as controlled

HELPER_SHA256 = 'bd8755753ece6786750691ad05306ac327135e3a11a7c81ca701bee565bad34b'
D = Decimal


def require(condition, message):
    if not condition:
        raise ValueError(message)


def local(name):
    path = (ROOT/name).resolve()
    require(path.is_relative_to(ROOT), 'Project-local path required')
    return path


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20), b''):
            digest.update(block)
    return digest.hexdigest()


def source_hashes():
    paths = {Path(__file__).resolve()}
    for module in list(sys.modules.values()):
        name = getattr(module, '__file__', None)
        if name:
            path = Path(name).resolve()
            if path.is_relative_to(ROOT) and path.suffix == '.py' and path.is_file():
                rel = path.relative_to(ROOT)
                if rel.parts[0] in ('research','src') and not any(p in ('tmp','__pycache__','.venv','venv') for p in rel.parts):
                    paths.add(path)
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}


def runtime_info():
    names=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','PYSCF_MAX_MEMORY')
    return dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),
                machine=platform.machine(),declared_environment={key:os.environ.get(key) for key in names},
                thread_scope='declared thread environment only; no backend thread-count measurement')


def memory_limit():
    memory = float(os.environ['PYSCF_MAX_MEMORY'])
    require(math.isfinite(memory) and memory > 0, 'Positive PYSCF_MAX_MEMORY required')
    return memory


def admit_dimension(dimension, memory):
    # Includes sequential H and two pressure eigensolves, vectors, products and LAPACK work.
    estimate = 768*dimension*dimension + 32*1024**2
    require(estimate < .6*memory*1024**2, 'Saved-matrix workspace exceeds declared allowance')
    return estimate


def claim_output(name, initial):
    path = local(name)
    require(path.is_relative_to(STAGE4), 'Prepared route writes only under research/stage4')
    require(path.suffix == '.json', 'JSON output required')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(initial, stream, indent=2, allow_nan=False)
    return path


def save_output(path, value):
    temporary = path.with_name(path.name+'.writing-'+uuid.uuid4().hex)
    with temporary.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, path)


def probability(log_value):
    """Preserve nonzero probabilities below binary64 range in logarithmic form."""
    log_value = float(log_value)
    if log_value == -math.inf:
        return dict(value=0., log_value=None, status='zero_in_supplied_discrete_law')
    require(math.isfinite(log_value), 'Nonfinite probability logarithm')
    value = math.exp(log_value)
    return dict(value=value if value else None, log_value=log_value,
                status='representable' if value else 'underflow_nonzero')


def positive_sum(values):
    value = math.fsum(float(x) for x in values)
    require(value >= 0 and math.isfinite(value), 'Invalid positive probability sum')
    return dict(value=value, log_value=math.log(value) if value else None,
                status='representable' if value else 'zero_in_supplied_discrete_law')


def log_difference(a, b):
    """log(exp(a)-exp(b)), for finite/log-zero inputs with a>=b."""
    a, b = np.asarray(a,float), np.asarray(b,float)
    require(np.all(b <= a), 'Invalid ordered logarithmic difference')
    with np.errstate(divide='ignore', invalid='ignore'):
        return a + np.log(-np.expm1(b-a))


def log_gaussian_inside(x, h, s):
    # Tail-side reflection prevents subtraction of two numbers rounded to one.
    lower, upper = (-h-x)/s, (h-x)/s
    answer = np.empty_like(x)
    left = upper <= 0
    right = lower >= 0
    middle = ~(left | right)
    answer[left] = log_difference(log_ndtr(upper[left]),log_ndtr(lower[left]))
    answer[right] = log_difference(log_ndtr(-lower[right]),log_ndtr(-upper[right]))
    answer[middle] = log_difference(log_ndtr(upper[middle]),log_ndtr(lower[middle]))
    return answer


def effects(values, weights, h, noise):
    """Hard strict event or explicitly Gaussian-noisy marginal spectral effect."""
    x, p = np.asarray(values,float), np.asarray(weights,float)
    require(x.ndim == p.ndim == 1 and x.shape == p.shape and len(x)>0, 'Invalid discrete law')
    require(np.all(np.isfinite(x)) and np.all(np.isfinite(p)) and np.all(p>=0), 'Invalid spectral values/weights')
    require(math.isfinite(h) and h>=0 and math.isfinite(noise) and noise>=0, 'Nonnegative threshold/noise required')
    mass = math.fsum(map(float,p))
    require(mass>0 and math.isfinite(mass),'Positive finite probability mass required')
    if noise == 0:
        plus, minus = positive_sum(p[x>h]), positive_sum(p[x < -h])
        outside = positive_sum(p[np.abs(x)>h])
        inside = positive_sum(p[np.abs(x)<=h])
        atom_error = 0.
    else:
        keep = p>0
        logp = np.log(p[keep]); xx = x[keep]
        lp = log_ndtr((xx-h)/noise); lm = log_ndtr((-xx-h)/noise)
        li = log_gaussian_inside(xx,h,noise)
        lo = np.logaddexp(lp,lm)
        plus = probability(logsumexp(logp+lp)); minus = probability(logsumexp(logp+lm))
        outside = probability(logsumexp(logp+lo)); inside = probability(logsumexp(logp+li))
        atom_error = float(np.max(abs(np.exp(lo)+np.exp(li)-1)))
    total = (outside['value'] or 0.)+(inside['value'] or 0.)
    complement_error = abs(total-mass)
    require(complement_error <= 2e-12*max(mass,1.) and atom_error<=2e-12, 'Effect complement identity failed')
    require(all(v['value'] is None or -1e-14 <= v['value'] <= mass+2e-12
                for v in (plus,minus,outside,inside)), 'Effect outside probability bounds')
    return dict(threshold_sigma0=float(h), noise_sigma0=float(noise), positive=plus,
        negative=minus, two_sided=outside, inside_inclusive=inside,
        probability_mass=mass, complement_absolute_error=complement_error,
        pointwise_complement_max_error=atom_error,
        event='strict abs(x)>h' if noise==0 else 'abs(x+s*Z)>h, independent standard normal Z',
        boundary_convention='hard equality belongs inside; smooth s>0 has zero boundary probability')


def quantiles(values, weights, levels, absolute=False, cluster_tolerance=0.):
    x = np.abs(values) if absolute else np.asarray(values)
    order = np.argsort(x,kind='stable'); x=x[order]; p=np.asarray(weights)[order]
    mass=math.fsum(map(float,p)); cumulative=np.cumsum(p)/mass
    rows=[]
    for level in levels:
        require(0<level<1, 'Interior quantile required')
        index=min(int(np.searchsorted(cumulative,level,side='left')),len(x)-1)
        value=float(x[index]); cluster=np.abs(x-value)<=cluster_tolerance
        rows.append(dict(level=level,value_sigma0=value,
            cumulative_strictly_below=float(np.sum(p[x<value])/mass),
            cumulative_at_or_below=float(np.sum(p[x<=value])/mass),
            nearby_cluster_interval=[float(min(x[cluster])),float(max(x[cluster]))],
            nearby_cluster_weight=float(np.sum(p[cluster])),
            convention='inf{x:F(x)>=level}; quantiles use explicitly mass-normalized weights',
            scope='discrete-law quantile and numerical cluster sensitivity; no continuum quantile error bar'))
    return rows


def clusters(values,weights,tolerance):
    rows=[];start=0
    for stop in range(1,len(values)+1):
        if stop<len(values) and values[stop]-values[start]<=tolerance:
            continue
        if stop-start>1:
            rows.append(dict(indices=[start,stop],eigenvalue_interval_sigma0=[float(values[start]),float(values[stop-1])],
                summed_weight=float(np.sum(weights[start:stop])),count=stop-start))
        start=stop
    return rows


def tail_panel(values,weights,thresholds,noises,edge_offsets,numeric_edge):
    rows=[]
    for h in thresholds:
        hard=effects(values,weights,h,0.)
        distances=abs(abs(values)-h)
        hard['nearest_absolute_eigenvalue_distance_sigma0']=float(min(distances))
        hard['numerical_edge_cluster_weight']=float(np.sum(weights[distances<=numeric_edge]))
        bands=[]
        for delta in sorted(set([*edge_offsets,numeric_edge])):
            lower=effects(values,weights,h+delta,0.)['two_sided']
            upper=effects(values,weights,max(0.,h-delta),0.)['two_sided']
            bands.append(dict(offset_sigma0=delta,lower_threshold=h+delta,upper_threshold=max(0.,h-delta),
                probability_lower=lower,probability_upper=upper,
                width=float(upper['value']-lower['value']),
                scope='threshold sensitivity only; does not bound weight/source/regulator errors'))
        rows.append(dict(threshold_sigma0=h,hard=hard,edge_sensitivity=bands,
                         smooth=[effects(values,weights,h,s) for s in noises]))
    for noise in [0.,*noises]:
        selected=[row['hard'] if noise==0 else next(a for a in row['smooth'] if a['noise_sigma0']==noise) for row in rows]
        logs=[a['two_sided']['log_value'] if a['two_sided']['log_value'] is not None else -math.inf for a in selected]
        require(all(b<=a+2e-12 for a,b in zip(logs,logs[1:])), 'Threshold monotonicity failed')
    return rows


def law_from_prepared(Pc,E,tau,increment,ratio,sigma0,memory,config):
    require(sha(Path(controlled.__file__))==HELPER_SHA256, 'Frozen arithmetic helper changed')
    require(sigma0>0 and math.isfinite(sigma0), 'Positive common harmonic sigma0 required')
    dimension=len(E);estimate=admit_dimension(dimension,memory)
    with localcontext() as context:
        context.prec=80;context.Emin=-999999999;context.Emax=999999999
        moments,recurrence=controlled.evaluate(Pc,E,tau,increment,ratio)
    require(recurrence['spectral_reconstruction']['passed'], 'Frozen direct spectral reconstruction unresolved at this tail window')
    filt=recurrence['filter_arithmetic']
    require(filt['dropped_nonzero_source_entries']==0 and filt['pressure_filter_product_underflow_entries']==0,
            'Tail study rejects any deleted filter/source product; moment-only deletion bounds are insufficient')
    # Independent assembly, without helper's exponent-floor truncation.
    z=-.5*(tau*(E[:,None]-E[None,:]))**2
    factor=np.exp(z)
    if increment:
        factor *= -np.expm1((ratio*ratio-1)*z)
        factor[E[:,None]==E[None,:]]=0.
    X=Pc*factor/sigma0;X[0,0]=0.;X=(X+X.T)/2
    scale=float(np.max(abs(X)));require(scale>0,'Zero smeared source')
    xn=X/scale
    values,vectors=eigh(xn,check_finite=False,driver='evd');values*=scale
    weights=abs(vectors[0])**2
    weight_underflow=int(np.count_nonzero((vectors[0]!=0)&(weights==0)))
    require(weight_underflow==0,'Squared spectral overlaps underflowed: tails unresolved')
    residual=float(np.linalg.norm(X@vectors-vectors*values))
    orth=float(np.linalg.norm(vectors.T@vectors-np.eye(dimension)))
    mass=math.fsum(map(float,weights))
    require(abs(mass-1)<=2e-11 and np.min(weights)>=0, 'Spectral probability normalization/positivity failed')
    moment_errors={}
    with localcontext() as context:
        context.prec=80;context.Emin=-999999999;context.Emax=999999999
        for n in range(1,9):
            spectral=math.fsum(float(p)*float(x)**n for x,p in zip(values,weights))
            reference=float(moments[n]/D.from_float(sigma0)**n)
            variance=float(moments[2]/D.from_float(sigma0)**2)
            moment_errors[str(n)]=abs(spectral-reference)/max(abs(reference),variance**(n/2),1e-300)
    require(max(moment_errors.values())<=config['moment_tolerance'], 'Independent spectrum/normalized-recurrence disagreement')
    # Matrix/eigensolver residual is diagnostic, not a bound for the saved H/P.
    numeric_edge=max(2*residual,64*np.finfo(float).eps*max(abs(values)))
    panel=tail_panel(values,weights,config['thresholds_sigma0'],config['noise_sigma0'],config['edge_offsets_sigma0'],numeric_edge)
    other_values,other_vectors=eigh(xn,check_finite=False,driver='evr');other_values*=scale
    other_weights=abs(other_vectors[0])**2
    require(not np.any((other_vectors[0]!=0)&(other_weights==0)),'Comparison squared spectral overlaps underflowed')
    other_mass=math.fsum(map(float,other_weights))
    require(abs(other_mass-1)<=2e-11,'Comparison eigensolver probability mass failed')
    other_residual=float(np.linalg.norm(X@other_vectors-other_vectors*other_values))
    other_orth=float(np.linalg.norm(other_vectors.T@other_vectors-np.eye(dimension)))
    sensitivity=[];warnings=[]
    for row in panel:
        for effect in [row['hard'],*row['smooth']]:
            alternate=effects(other_values,other_weights,row['threshold_sigma0'],effect['noise_sigma0'])['two_sided']
            p=effect['two_sided']['value'];q=alternate['value']
            absolute=abs(p-q) if p is not None and q is not None else None
            relative=absolute/max(p,q) if absolute is not None and max(p,q)>0 else None
            a_log=effect['two_sided']['log_value'];b_log=alternate['log_value']
            log_difference_value=b_log-a_log if a_log is not None and b_log is not None else None
            resolution='RESOLVED_ABSOLUTE_AND_RELATIVE' if p is not None and q is not None and min(p,q)>=config['relative_probability_floor'] else 'ABSOLUTE_ONLY_OR_LOG_REPRESENTATION'
            require(absolute is None or absolute<=config['probability_absolute_tolerance'],'Eigensolver tail probability disagreement')
            if resolution.startswith('RESOLVED'):
                require(relative<=config['probability_relative_tolerance'],'Eigensolver relative tail disagreement')
            sensitivity.append(dict(threshold_sigma0=row['threshold_sigma0'],noise_sigma0=effect['noise_sigma0'],
                evr_probability=alternate,absolute_difference=absolute,relative_difference=relative,
                log_probability_difference=log_difference_value,status=resolution))
            if not resolution.startswith('RESOLVED'):
                warnings.append('Small probability has only the stated absolute/log representation check')
    return dict(observable='increment' if increment else 'ordinary',tau=tau,ratio=ratio if increment else None,
        dimension=dimension,sigma0=sigma0,estimated_workspace_bytes=estimate,recurrence=recurrence,
        spectrum=dict(values_sigma0=values.tolist(),weights=weights.tolist(),normalization=mass,
            renormalized=False,zero_weights=int(np.count_nonzero(weights==0)),squared_overlap_underflow_count=weight_underflow,
            probability_scope='squared binary64 eigenvector overlaps; small unresolved weights are not certified by low moments'),
        spectral_eigensolve=dict(driver='evd',comparison_driver='evr',residual_frobenius_sigma0=residual,
            orthogonality_frobenius=orth,numerical_edge_scale_sigma0=numeric_edge,
            comparison_residual_frobenius_sigma0=other_residual,comparison_orthogonality_frobenius=other_orth,comparison_probability_mass=other_mass,
            scope='diagnostics for smeared supplied matrix, excluding H/P input and omitted-source errors'),
        independent_moment_scaled_errors=moment_errors,tail_panel=panel,eigensolver_tail_sensitivity=sensitivity,
        signed_quantiles=quantiles(values,weights,config['signed_quantiles'],cluster_tolerance=numeric_edge),
        absolute_quantiles=quantiles(values,weights,config['absolute_quantiles'],True,numeric_edge),
        numerical_eigenvalue_clusters=clusters(values,weights,numeric_edge),
        cluster_scope='Exact degenerate-block summed probability is basis-invariant. Nearby numerical clusters are diagnostic only; no eigenvalues or individual weights are snapped or reassigned.',
        warnings=sorted(set(warnings)),
        outside_source_scope='No omitted-state CDF, primitive/bath/mode, graph-ground or physical detector certificate')
