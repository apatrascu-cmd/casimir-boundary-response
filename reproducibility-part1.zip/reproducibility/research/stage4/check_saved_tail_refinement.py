"""Known-law and failure controls; prepared for a separate guarded launch."""
from pathlib import Path
from decimal import localcontext
import argparse
import copy
import json
import math
import os
import signal
import tempfile
import time
import numpy as np
from scipy.special import roots_genlaguerre
import tail_refinement as tail
import analyze_saved_tail_refinement as analysis
from distributed_line import quantum_quadratic_cumulants


def close(a,b,tolerance=2e-12):
    error=abs(float(a)-float(b))
    tail.require(error<=tolerance,'Known-law discrepancy: '+str((a,b,error,tolerance)))
    return error


def scalar(effect):
    # Only analytic checks use zero for values below binary64 range; the output keeps logs.
    return effect['value'] or 0.


def independent_gaussian_tail(x,p,h,s):
    if s==0:return math.fsum(w for v,w in zip(x,p) if abs(v)>h)
    return math.fsum(w*.5*(math.erfc((h-v)/(s*math.sqrt(2)))+
                          math.erfc((h+v)/(s*math.sqrt(2)))) for v,w in zip(x,p))


def raw_from_cumulants(k):
    m={0:1.}
    for n in range(1,9):m[n]=math.fsum(math.comb(n-1,j-1)*k.get(str(j),0.)*m[n-j] for j in range(1,n+1))
    return m


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec',default='research/stage4/saved_tail_refinement_spec.json')
    parser.add_argument('--output',required=True)
    args=parser.parse_args();started=time.monotonic()
    memory=tail.memory_limit();spec_path=tail.local(args.spec);spec=analysis.load_spec(spec_path)
    sources=tail.source_hashes()
    result=dict(test_suite='stage4-saved-tail-controls-v1',status='RUNNING',memory_mb=memory,
        spec_sha256=tail.sha(spec_path),tested_entrypoint_sha256=tail.sha(Path(analysis.__file__)),
        source_sha256=sources,runtime=tail.runtime_info(),checks=[],scope='independent finite-law/effect and beta-zero harmonic controls; no physical run or omitted-state CDF certificate')
    destination=tail.claim_output(args.output,result)
    def save():
        result['elapsed_seconds']=time.monotonic()-started;tail.save_output(destination,result)
    def check(name,callback):
        try:
            details=callback();result['checks'].append(dict(name=name,passed=True,details=details));save()
        except BaseException as error:
            result['checks'].append(dict(name=name,passed=False,error=str(error)));save();raise
    def rejection(callback):
        try:callback()
        except (ValueError,KeyError,FileExistsError):return dict(rejected=True)
        raise AssertionError('Expected invalid input was admitted')
    def interrupted(signum,frame):raise RuntimeError('Guard interrupted controls')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        for name,x,p in [('two_state',[-1.,1.],[.5,.5]),('three_state',[-2.,0.,3.],[.3,.5,.2])]:
            def known(x=x,p=p):
                error=0.
                for h in (0.,.5,1.,2.,2.5,3.,4.,12.):
                    for s in (0.,.1,.25,.5,1.):
                        got=tail.effects(x,p,h,s)
                        error=max(error,close(scalar(got['two_sided']),independent_gaussian_tail(x,p,h,s)))
                        close(scalar(got['positive'])+scalar(got['negative']),scalar(got['two_sided']))
                        reflected=tail.effects(-np.array(x),p,h,s)
                        close(scalar(got['positive']),scalar(reflected['negative']))
                        close(scalar(got['two_sided']),scalar(reflected['two_sided']))
                panel=tail.tail_panel(np.array(x),np.array(p),[.5,1.,2.,3.,4.],[.1,.25,.5,1.],[1e-6,.01],1e-13)
                return dict(max_erfc_discrepancy=error,threshold_monotonicity_and_complements=True,threshold_rows=len(panel))
            check(name+'_strict_and_gaussian_known_law',known)
        def hard_boundary():
            x=[-2.,0.,2.];p=[.25,.5,.25]
            at=tail.effects(x,p,2.,0.);below=tail.effects(x,p,2.-1e-9,0.)
            close(at['two_sided']['value'],0.);close(below['two_sided']['value'],.5)
            close(tail.effects(x,p,0.,0.)['two_sided']['value'],.5)
            close(tail.effects(x,p,0.,.1)['two_sided']['value'],1.)
            return dict(strict_equality_inside=True,hard_zero_noise_branch=True,smooth_zero_threshold_outside_one=True)
        check('hard_boundary_and_zero_noise',hard_boundary)
        def underflow():
            r=tail.effects([0.],[1.],100.,.1)['two_sided']
            tail.require(r['value'] is None and r['status']=='underflow_nonzero' and r['log_value']< -1e5,'Smooth nonzero underflow was erased')
            return r
        check('smooth_log_probability_below_binary64',underflow)
        def edge_quantiles():
            x=np.array([-2.,0.,3.]);p=np.array([.3,.5,.2]);levels=[.1,.4,.7,.9]
            q=tail.quantiles(x,p,levels)
            tail.require([r['value_sigma0'] for r in q]==[-2.,0.,0.,3.],'Known signed quantiles fail')
            qa=tail.quantiles(x,p,[.4,.7,.9],True)
            tail.require([r['value_sigma0'] for r in qa]==[0.,2.,3.],'Known absolute quantiles fail')
            row=tail.tail_panel(x,p,[2.],[.1],[1e-6],1e-13)[0]
            for band in row['edge_sensitivity']:
                close(band['probability_lower']['value'],.2);close(band['probability_upper']['value'],.5)
            return dict(known_generalized_inverse=True,threshold_jump_mass=.3)
        check('known_quantiles_and_threshold_atom_jump',edge_quantiles)
        def degeneracy():
            u=np.array([.3,.4,math.sqrt(.75)]);theta=.41
            rotation=np.array([[math.cos(theta),-math.sin(theta)],[math.sin(theta),math.cos(theta)]])
            v=u.copy();v[:2]=rotation@u[:2]
            x=np.array([1.,1.,3.]);p=u*u;q=v*v
            tail.require(abs(p[0]-q[0])>1e-3,'Degenerate rotation control did not change individual weights')
            close(sum(p[:2]),sum(q[:2]))
            for h in (.5,1.,2.,3.):
                for s in (0.,.25):close(tail.effects(x,p,h,s)['two_sided']['value'],tail.effects(x,q,h,s)['two_sided']['value'])
            return dict(individual_weights_changed=True,summed_block_probability_invariant=True)
        check('exact_degenerate_block_rotation_invariance',degeneracy)
        cfg=copy.deepcopy(spec['analysis']);cfg['thresholds_sigma0']=[.3,.9,1.1,2.3]
        def matrix_law(H,P,tau,increment,sigma,config=cfg):
            E,Pc,mean,diagnostics=tail.controlled.eigen_prepare(H,P)
            with localcontext() as ctx:
                ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
                law=tail.law_from_prepared(Pc,E,tau,increment,2.,sigma,memory,config)
            return law,mean,diagnostics
        def two_matrix():
            tau=.4;f=math.exp(-.5*tau*tau);P=np.array([[0.,1.],[1.,0.]])
            maximum=0.
            for inc in (False,True):
                amplitude=f*(-math.expm1(-1.5*tau*tau)) if inc else f
                law,_,_=matrix_law(np.diag([0.,1.]),P,tau,inc,amplitude)
                for row in law['tail_panel']:
                    for effect in [row['hard'],*row['smooth']]:
                        maximum=max(maximum,close(effect['two_sided']['value'],independent_gaussian_tail([-1.,1.],[.5,.5],row['threshold_sigma0'],effect['noise_sigma0'])))
            return dict(max_probability_error=maximum,ordinary_and_increment=True)
        check('two_state_filtered_matrix_positive_control',two_matrix)
        def three_matrix():
            v=np.sqrt([.3,.5,.2]);e=np.array([1.,0.,0.]);d=e-v;Q=np.eye(3)-2*np.outer(d,d)/np.dot(d,d)
            P=Q@np.diag([-2.,0.,3.])@Q.T;H=np.diag([0.,1.,2.])
            law,mean,_=matrix_law(H,P,0.,False,1.)
            maximum=abs(mean)
            for row in law['tail_panel']:
                for effect in [row['hard'],*row['smooth']]:
                    maximum=max(maximum,close(effect['two_sided']['value'],independent_gaussian_tail([-2.,0.,3.],[.3,.5,.2],row['threshold_sigma0'],effect['noise_sigma0'])))
            transformed=[]
            angle=.37;U=np.array([[math.cos(angle),-math.sin(angle),0.],[math.sin(angle),math.cos(angle),0.],[0.,0.,1.]])
            for h,p,s in [(H,P+7*np.eye(3),1.),(H,3*P,3.),(U@H@U.T,U@P@U.T,1.)]:
                alt,_,_=matrix_law(h,p,0.,False,s)
                errors=[close(a['hard']['two_sided']['value'],b['hard']['two_sided']['value']) for a,b in zip(law['tail_panel'],alt['tail_panel'])]
                transformed.append(max(errors))
            return dict(max_known_probability_error=maximum,scalar_shift_unit_scaling_and_basis_rotation_errors=transformed)
        check('three_state_matrix_centering_and_invariances',three_matrix)
        def harmonic_controls():
            N=18;n=np.arange(N);H=np.diag(n.astype(float));P=np.diag(n+.5)
            for j in range(N-2):P[j,j+2]=P[j+2,j]=.5*math.sqrt((j+1)*(j+2))
            errors=[]
            for tau,inc in [(0.,False),(.2,False),(.2,True),(1.,False),(1.,True)]:
                B=math.exp(-2*tau*tau)
                if inc:B *= -math.expm1(-6*tau*tau)
                A=0. if inc else 1.
                k=quantum_quadratic_cumulants(np.array([[A]]),np.array([[B]]),8)
                m=raw_from_cumulants(k);law,mean,_=matrix_law(H,P,tau,inc,math.sqrt(m[2]))
                close(mean,.5)
                errors.append(max(abs(law['recurrence']['moments'][str(j)]['value']-m[j])/max(abs(m[j]),m[2]**(j/2),1e-300) for j in range(1,9)))
                if tau==0:
                    for j in range(2,9):close(k[str(j)],math.factorial(j-1)/2,2e-9)
            tail.require(max(errors)<2e-9,'Beta-zero ordered harmonic moment control failed')
            return dict(max_scaled_moment_error=max(errors),complete_projected_q_squared=True,scope='all returning moments through order eight fit; finite hard CDF is not the infinite oscillator CDF')
        check('beta_zero_complete_quadratic_projection_and_ordered_cumulants',harmonic_controls)
        def laguerre():
            # The even |2j> q^2 Jacobi matrix is the alpha=-1/2 Laguerre recurrence.
            N=24;j=np.arange(N);H=np.diag(2*j.astype(float));P=np.diag(2*j+.5)
            for k in range(N-1):P[k,k+1]=P[k+1,k]=.5*math.sqrt((2*k+1)*(2*k+2))
            sigma=math.sqrt(.5);law,_,_=matrix_law(H,P,0.,False,sigma)
            nodes,weights=roots_genlaguerre(N,-.5);weights/=math.sqrt(math.pi);nodes=(nodes-.5)/sigma
            error=0.
            for row in law['tail_panel']:
                for effect in [row['hard'],*row['smooth']]:
                    exact=independent_gaussian_tail(nodes,weights,row['threshold_sigma0'],effect['noise_sigma0'])
                    error=max(error,close(effect['two_sided']['value'],exact,2e-11))
            return dict(max_probability_error=error,independent_generalized_Laguerre_nodes_and_weights=True,scope='known finite beta-zero spectral quadrature law; no unsupported continuum hard-tail error')
        check('beta_zero_pressure_spectral_law_vs_independent_Laguerre',laguerre)
        check('reject_negative_weight',lambda:rejection(lambda:tail.effects([0.,1.],[-.1,1.1],1.,.1)))
        check('reject_negative_noise',lambda:rejection(lambda:tail.effects([0.],[1.],1.,-.1)))
        check('reject_insufficient_memory',lambda:rejection(lambda:tail.admit_dimension(1000,1.)))
        check('reject_nonlocal_output',lambda:rejection(lambda:tail.claim_output('/tmp/invalid-stage4-output.json',{})))
        check('reject_zero_common_sigma',lambda:rejection(lambda:tail.law_from_prepared(np.array([[0.,1.],[1.,0.]]),np.array([0.,1.]),.4,False,2.,0.,memory,cfg)))
        def no_overwrite():
            with tempfile.TemporaryDirectory(prefix='control-output-',dir=tail.STAGE4) as directory:
                path=Path(directory)/'record.json';rel=str(path.relative_to(tail.ROOT));tail.claim_output(rel,dict(marker=1))
                result=rejection(lambda:tail.claim_output(rel,dict(marker=2)))
                tail.require(json.loads(path.read_text())==dict(marker=1),'Existing output changed')
                return result
        check('exclusive_output_preserves_existing_record',no_overwrite)
        def pinned_inputs():
            for job in spec['jobs']:
                tail.require(tail.sha(tail.local(job['input']))==job['input_sha256'],'Pinned parent mismatch')
                tail.require(tail.sha(tail.local(job['archive']))==job['archive_sha256'],'Pinned archive mismatch')
                parent=json.loads(tail.local(job['input']).read_text());case=parent['cases'][job['case_index']]
                tail.require(parent['status']==case['status']=='COMPLETED','Pinned parent incomplete')
            return dict(four_input_archive_pairs_bound=True,physical_matrices_not_loaded=True)
        check('specified_completed_parent_archive_hashes',pinned_inputs)
        tail.require(tail.source_hashes()==sources,'Source changed during controls')
        tail.require(tail.sha(spec_path)==result['spec_sha256'],'Specification changed during controls')
        result['status']='PASS';save();print('PASS stage4 saved-tail controls',len(result['checks']),flush=True)
    except BaseException as error:
        result.update(status='FAILED',failure=dict(type=type(error).__name__,message=str(error)));save();raise


if __name__=='__main__':main()
