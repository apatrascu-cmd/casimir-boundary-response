#!/usr/bin/env python3
"""Extract the executed finite-matrix pressure-propagation findings for the paper.

No Hamiltonian diagonalization, vector recurrence, fit, or numerical physical
job is run here. All quoted values come from the pinned executed diagnostic.
"""
from __future__ import annotations
import argparse,ast,hashlib,json,math,os,struct,zipfile
from collections import Counter
from decimal import Decimal,localcontext
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
RESULT='research/stage4/results/excited_pressure_propagation_v1.json'
RESULT_SHA='a8940abf7c1f4464d122a4a8729d94310cb29df01f0199b844c657d4198b0bd0'
CONTROL='research/stage4/results/excited_pressure_controls_v1.json'
CONTROL_SHA='cc229a0379bb9b7326f5d8a47e025b567f184a706b126d7c53c4adb73247279e'
SPEC='research/stage4/excited_pressure_propagation_spec.json'
SPEC_SHA='265bf8fddb21daf605139e30b810b080cce8d85a6c41c1fc95e4a172536a4efa'
TARGET='paper/stage4_excited_pressure_results.tex'
PROVENANCE='paper/stage4_excited_pressure_results_provenance.json'
METHOD='paper/stage4_excited_pressure_method.tex'
LABELS=['R10_Q14','R10_Q16','R14_current','R18_native']
CHECKS=('signed_Hermitian_block_identities','known_gapless_positive_control','zero_block_and_increment_filter','degenerate_rotation_invariance','tiny_source_positive_norm_arithmetic','source_input_and_inventory_refusals')
CENTERS={'R10_Q16':51.2,'R14_current':204.8,'R18_native':13107.2}
MOVING={'R10_Q16':[36.2038671968,51.2,72.4077343935],
        'R14_current':[579.2618751488,819.2,1158.523750296],
        'R18_native':[9268.190002368316,13107.2,18536.380004736635]}


def require(ok,message):
    if not ok:raise ValueError(message)


def path(name):
    p=(ROOT/name).resolve();require(p.is_relative_to(ROOT),'project-local path required');return p


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def pin(name,digest):
    p=path(name);require(sha(p)==digest,'input/source identity changed: '+name);return p


def dec(record):
    value=Decimal(record['decimal']);require(value.is_finite(),'nonfinite stored Decimal quantity')
    require(record['sign']==(1 if value>0 else -1 if value<0 else 0),'stored sign disagrees with Decimal quantity')
    return value


def relative(a,b):
    require(b!=0,'zero denominator in scientific extraction');return abs(a/b-1)


def header(z,name):
    """Read only a saved NPY header: no archive matrices are evaluated."""
    with z.open(name+'.npy') as f:
        require(f.read(6)==b'\x93NUMPY','invalid NPY member')
        version=tuple(f.read(2));require(version in ((1,0),(2,0),(3,0)),'unsupported NPY version')
        size=struct.unpack('<H' if version==(1,0) else '<I',f.read(2 if version==(1,0) else 4))[0]
        require(size<65536,'oversized NPY header')
        return ast.literal_eval(f.read(size).decode('utf-8' if version==(3,0) else 'latin1'))


def get_window(case,tau,observable='increment'):
    rows=[w for w in case['windows'] if w['tau']==tau and w['observable']==observable]
    require(len(rows)==1,'unique requested physical window required');return rows[0]


def validate():
    r=json.loads(pin(RESULT,RESULT_SHA).read_text());c=json.loads(pin(CONTROL,CONTROL_SHA).read_text());spec=json.loads(pin(SPEC,SPEC_SHA).read_text())
    require(r['status']=='COMPLETED_WITH_WARNINGS' and r['format']=='stage4-excited-pressure-propagation-v1','completed executed propagation record required')
    require(r['spec']==spec and r['spec_sha256']==SPEC_SHA and r['controls']==dict(path=CONTROL,sha256=CONTROL_SHA),'result/spec/control binding differs')
    require(c['status']=='PASS' and c['format']=='stage4-excited-pressure-controls-v1','completed physical diagnostic controls required')
    require(tuple(x['name'] for x in c['checks'])==CHECKS and all(x['passed'] is True for x in c['checks']),'six exact control groups required')
    require(c['source_sha256']==r['source_sha256'] and c['spec_sha256']==SPEC_SHA and c['runtime']==r['runtime'],'executed control/source/runtime closure differs')
    for name,digest in r['source_sha256'].items():pin(name,digest)
    for name,digest in spec['frozen_sources'].items():pin(name,digest)
    evidence={}
    for key,b in spec['evidence'].items():pin(b['path'],b['sha256']);evidence[key]=b
    require(spec['beta']==spec['hbar']==1. and spec['ratio']==2. and spec['scaled_energy_cuts']==[2.,4.,8.] and spec['scaled_gap_bands']==[.1,.5,1.,2.],'fixed observable/diagnostic scope changed')
    positive=json.loads(path(evidence['positive_control']['path']).read_text())
    require(positive['status']=='COMPLETED_MATHEMATICAL_POSITIVE_CONTROL' and len(positive['controls'])==4 and all(x['passed'] for x in positive['controls']),'executed quantum positive control incomplete')
    arithmetic=json.loads(path(evidence['arithmetic_control']['path']).read_text());require(arithmetic['new_arithmetic_controls']['status']=='PASS','independent arithmetic evidence incomplete')
    require([x['label'] for x in r['cases']]==[x['label'] for x in spec['jobs']]==LABELS,'four-case inventory changed')
    all_windows=[];physical=[];history=[]
    for result,job in zip(r['cases'],spec['jobs']):
        require(result['physical']==job['physical'] and result['parent_binding']==job['parent'] and result['archive_binding']==job['archive'],'case physical/archive identity differs')
        parent=json.loads(pin(job['parent']['path'],job['parent']['sha256']).read_text());archive=pin(job['archive']['path'],job['archive']['sha256'])
        require(parent['status']=='COMPLETED','incomplete physical parent');case=parent['cases'][job['case_index']]
        require(case['status']=='COMPLETED' and all(case.get(k)==v for k,v in job['physical'].items()),'parent physical parameters differ')
        rows=[x for x in case['cosine'] if x['beta']==1.];require(len(rows)==1,'unique parent beta1 calculation required');original=rows[0]
        require(original['effective_archive']==job['archive']['path'],'archive not bound to original physical row')
        if original.get('effective_archive_sha256') is not None:require(original['effective_archive_sha256']==job['archive']['sha256'],'parent archive hash differs')
        require(result['original_diagnostics']==original['diagnostics'],'original physical diagnostics altered')
        require(result['original_historical_source_sha256']==parent['source_sha256'],'historical source map altered')
        history.append(dict(label=result['label'],parent=job['parent'],historical_source_map_sha256=hashlib.sha256(json.dumps(parent['source_sha256'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),historical_map_verified_equal=True,
          scope='historical code identities remain in the strict parent/result dependencies; no comparison to current code is substituted'))
        dg=result['original_diagnostics'];require(dg['even_ground_certified_against_odd'] is True and dg['retained_cluster_certification_margin']>0 and dg['original_hamiltonian_residual_bound']>=0,'original physical ground/cluster gates failed')
        dim=result['retained_dimension']
        with zipfile.ZipFile(archive) as z:
            require({n+'.npy' for n in ('H','P','omega','couplings','reference','retained_sector')}<=set(z.namelist()),'required archive source/calibration members absent')
            require(header(z,'H')['shape']==header(z,'P')['shape']==(dim,dim),'saved pressure/H dimensions differ')
            require(header(z,'omega')['shape']==(case['M'],) and header(z,'couplings')['shape']==header(z,'reference')['shape']==(case['R'],),'calibration archive dimensions differ')
        expected=[(t,o) for t in job['taus'] for o in ('ordinary','increment')]
        require([(w['tau'],w['observable']) for w in result['windows']]==expected,'window/observable inventory differs')
        require([v['tau'] for v in result['saved_increment_replay']]==[v['tau'] for v in original['windows']],'original replay width inventory changed')
        for old in result['saved_increment_replay']:require(max(abs(v) for v in old['relative_errors'].values())<2e-8,'original moderate-width moment replay failed')
        physical.append(dict(label=result['label'],physical=result['physical'],retained_dimension=dim,parent=job['parent'],archive=job['archive'],source_diagnostics={k:dg.get(k) for k in ('original_hamiltonian_residual_bound','retained_cluster_certification_margin','even_ground_certified_against_odd','low_high_source_frobenius','pressure_frobenius_bound','pressure_gram_scope','omitted_threshold_scope')},
          eigensolve=result['eigensolve'],window_scope=result['window_scope']))
        for w in result['windows']:
            require(w['arithmetic']['status']=='POSITIVE_EVEN_NORM_RECURRENCE' and w['actual']['positive_moment_checks']['passed'] is True,'controlled positive moment recurrence/positivity failed')
            require(w['actual']['positive_moment_checks']['even_moments_strictly_positive'] is True,'nonpositive even moment')
            require(w['filter_arithmetic']['actual_ground_diagonal']==0.,'actual spectral ground was not centered exactly')
            if w['observable']=='increment':require(w['filter_arithmetic']['diagonal_exactly_zero'] is True,'increment retains zero-gap diagonal')
            require(max(w['identity_relative_errors'].values())<2e-8,'recorded excursion identity failed')
            q={int(k):dec(v) for k,v in w['q'].items()};m={int(k):dec(v) for k,v in w['actual']['moments'].items()}
            for k in (0,2,4,6):require(q[k]>0,'positive norm-source q missing')
            s=q[0];predicted={2:s,4:s*s+q[2],6:s**3+2*s*q[2]+q[1]**2+q[4],8:s**4+3*s*s*q[2]+q[2]**2+3*s*q[1]**2+2*q[1]*q[3]+2*s*q[4]+q[6]}
            for p,value in predicted.items():require(relative(value,m[p])<Decimal('2e-8'),'independent stored-number moment identity failed')
            for p,k in ((4,2),(6,4),(8,6)):
                J=dec(w['propagation_ratios'][str(p)]);require(relative(J,q[k]/s**(p//2))<Decimal('2e-8'),'stored propagation ratio differs')
                require(abs(float(J.ln())-w['propagation_ratios'][str(p)]['log_abs'])<2e-10,'stored log propagation ratio differs')
                bound=w['bound_checks'][str(p)];require(dec(bound['lower_over_M'])<=Decimal('1.00000002') and dec(bound['upper_over_M'])>=Decimal('.99999998'),'two-sided moment bounds failed')
            for diagnostic in w['q_filter_deletion_diagnostic']['quantities'].values():require(diagnostic['small_relative_to_q'] is True and diagnostic['status']=='DELETION_ENVELOPE_SMALL','deleted-entry diagnostic unresolved')
            require(all(v is None or v<math.log(1e-10) for v in w['filter_deletion_log_relative_even_bounds'].values()),'raw-moment deleted-entry diagnostic unresolved')
            spectral=w['spectral_reconstruction'];require(spectral['status'] in ('RESOLVED','UNRESOLVED_SMALL_SPECTRAL_WEIGHTS'),'unexpected spectral status')
            require(spectral['passed'] is (spectral['status']=='RESOLVED'),'spectral status/flag inconsistency')
            require([x['tau_energy_cut'] for x in w['excited_energy_cuts']]==[2.,4.,8.],'cut inventory changed')
            require([x['label'] for x in w['excited_transfer_ablations']]==['exact_zero_transfer','binary64_uncertainty_band','scaled_gap_0.1','scaled_gap_0.5','scaled_gap_1.0','scaled_gap_2.0'],'band inventory changed')
            for cut in w['excited_energy_cuts']:
                cq={int(k):dec(v) for k,v in cut['q'].items()};require(relative(dec(cut['variance_fraction']),cq[0]/s)<Decimal('2e-8') if cq[0] else dec(cut['variance_fraction'])==0,'cut variance ratio differs')
                for k in (2,4,6):
                    expected_ratio=cq[k]/q[k];observed=dec(cut['q_even_ratio_to_full'][str(k)])
                    require(relative(observed,expected_ratio)<Decimal('2e-8') if expected_ratio else observed==0,'cut source-chain ratio differs')
            all_windows.append(w)
    require(len(all_windows)==42,'42 executed physical rows required')
    statuses=Counter(w['spectral_reconstruction']['status'] for w in all_windows);require(statuses=={'RESOLVED':35,'UNRESOLVED_SMALL_SPECTRAL_WEIGHTS':7},'spectral qualification inventory differs')
    require(len(r['comparisons'])==12,'R10 occupation/selection comparison inventory differs')
    cases={x['label']:x for x in r['cases']};central=[]
    for label,tau in CENTERS.items():
        w=get_window(cases[label],tau);cut=next(x for x in w['excited_energy_cuts'] if x['tau_energy_cut']==4.)
        require(dec(cut['variance_fraction'])>Decimal('.999999') and cut['states_within_cut_uncertainty']==0,'central cut variance/edge qualification changed')
        require(w['spectral_reconstruction']['passed'] is True,'central source matrix spectral reconstruction unresolved')
        central.append(dict(label=label,tau=tau,scaled_first_even_gap=w['tau_first_retained_even_gap'],retained_excited_states=cut['states'],
          variance_fraction=cut['variance_fraction'],q6_fraction=cut['q_even_ratio_to_full']['6'],log_J8=w['propagation_ratios']['8']['log_abs']))
    moving={label:[dict(tau=tau,scaled_first_even_gap=get_window(cases[label],tau)['tau_first_retained_even_gap'],log_J8=get_window(cases[label],tau)['propagation_ratios']['8']['log_abs']) for tau in widths] for label,widths in MOVING.items()}
    for index in range(3):
        xs=[moving[k][index]['scaled_first_even_gap'] for k in MOVING];require(max(xs)-min(xs)<.003,'moving-edge scale correspondence changed')
    band_window=get_window(cases['R10_Q16'],51.2);bands={x['label']:x for x in band_window['excited_transfer_ablations']}
    band_small=dec(bands['scaled_gap_0.1']['q_even_ratio_to_full']['6']);band_middle=dec(bands['scaled_gap_0.5']['q_even_ratio_to_full']['6']);band_large=dec(bands['scaled_gap_1.0']['q_even_ratio_to_full']['6'])
    require(band_middle>1 and band_middle>band_small and band_large<band_middle,'stated nonmonotonicity example absent')
    for comparison,left,right in zip(r['comparisons'],r['cases'][0]['windows'],r['cases'][1]['windows']):
        require(comparison['labels']==LABELS[:2] and (comparison['tau'],comparison['observable'])==(left['tau'],left['observable'])==(right['tau'],right['observable']),'Q comparison labels/window differ')
        expected_q6=dec(right['q']['6'])/dec(left['q']['6'])-1
        expected_log=right['propagation_ratios']['8']['log_abs']-left['propagation_ratios']['8']['log_abs']
        require(abs(expected_q6-dec(comparison['q_relative_changes']['6']))<Decimal('2e-12') and abs(expected_log-comparison['log_J_changes']['8'])<2e-12,'Q comparison transcription differs')
    comparison_max_q6=max(abs(dec(x['q_relative_changes']['6'])) for x in r['comparisons']);comparison_max_logJ=max(abs(x['log_J_changes']['8']) for x in r['comparisons'])
    method=path(METHOD).read_text();require('eq:s4-pressure-excursions' in method and 'eq:s4-propagation-ratios' in method,'required method labels absent')
    extracted=dict(central_cut4=central,moving_edge_increment_rows=moving,nonmonotone_band_example=dict(label='R10_Q16',tau=51.2,scaled_bands=[.1,.5,1.],q6_ratios=[str(band_small),str(band_middle),str(band_large)]),
      max_R10_Q14_to_Q16_relative_q6_drift=str(comparison_max_q6),max_R10_Q14_to_Q16_log_J8_drift=comparison_max_logJ,
      maximum_excursion_identity_relative_error=max(v for w in all_windows for v in w['identity_relative_errors'].values()),
      maximum_original_moment_replay_relative_error=max(abs(v) for x in r['cases'] for w in x['saved_increment_replay'] for v in w['relative_errors'].values()),
      window_count=len(all_windows),spectral_status_counts=dict(statuses),deleted_entry_q_diagnostics=168,
      long_R10_increment=dict(tau=289.630937574,scaled_first_even_gap=get_window(cases['R10_Q16'],289.630937574)['tau_first_retained_even_gap'],log_J8=get_window(cases['R10_Q16'],289.630937574)['propagation_ratios']['8']['log_abs']))
    require(extracted['maximum_excursion_identity_relative_error']<9.53e-16 and extracted['maximum_original_moment_replay_relative_error']<2.44e-12,'rounded manuscript arithmetic ceilings no longer hold')
    require(comparison_max_q6<Decimal('1.32e-4') and comparison_max_logJ<1.37e-4,'rounded manuscript Q-sensitivity ceilings no longer hold')
    return r,extracted,physical,history,evidence


def render(e):
    names={'R10_Q16':r'$R=10$, $Q=16$','R14_current':r'$R=14$, $Q=10$','R18_native':r'$R=18$, $Q=12$'}
    rows=[]
    for row in e['central_cut4']:
        percentage=100*dec(row['variance_fraction']);qfrac=dec(row['q6_fraction'])
        rows.append(f"{names[row['label']]} & {row['tau']:.1f} & {row['scaled_first_even_gap']:.5f} & {percentage:.7f} & {qfrac:.5f} \\\\")
    moving=[]
    for i in range(3):
        values=[e['moving_edge_increment_rows'][k][i] for k in MOVING]
        moving.append(f"{min(v['scaled_first_even_gap'] for v in values):.4f}--{max(v['scaled_first_even_gap'] for v in values):.4f} & "+' & '.join(f"{v['log_J8']:.5f}" for v in values)+r' \\')
    text=r'''% Generated from excited_pressure_propagation_v1.json; provenance in stage4_excited_pressure_results_provenance.json.
\subsection{Executed pressure-chain tests in the nonlinear hierarchy}
\label{sec:s4-excited-pressure-results}

The executed finite-matrix test separates exciting the vacuum from the
subsequent action of pressure within the excited sector. With the notation
of Eq.~\eqref{eq:s4-pressure-excursions}, $s=\|g\|^2=M_2$ is the variance,
whereas $q_6=\|B^3g\|^2$ is one positive excited-chain contribution to $M_8$.
The latter measures three further pressure actions on the initial vacuum
excitation. All calculations below use the actual interacting ground and
original composite pressure projected into the supplied finite space at $\beta=1$.

As a sensitivity test, retain only excited states satisfying
$\tau(E_i-E_0)/\hbar\leq4$, replacing $g$ by $\Pi g$ and $B$ by
$\Pi B\Pi$. At the three specified central increments,
Table~\ref{tab:s4-excited-energy-cut} retains more than $99.9999\%$ of the
variance, but only about $11\%$, $43\%$, and $11\%$ of $q_6$.
Small direct vacuum excitation at higher energies therefore does not make
subsequent excited-state propagation negligible. The time filter depends
on energy \emph{differences}; pressure can still connect excited states
with nearby energies. These are ratios for a changed matrix. They are
neither probability-error bounds nor fractions of the total $M_8$,
which also contains the other terms and their interference in
Eq.~\eqref{eq:s4-pressure-excursions}.

\begin{table*}[t]
\centering
\small
\begin{tabular}{lrrrr}
\toprule
Supplied model & $\tau$ & $\tau\Delta_e$ & Variance kept (\%) & $q_6^{\rm cut}/q_6$ \\
\midrule
CUT_ROWS
\bottomrule
\end{tabular}
\caption{Joint excited-energy restriction for ratio-two pressure increments.
Here $\Delta_e=(E_1-E_0)/\hbar$ is the first gap in the supplied even sector.
The three widths are stated separately; they do not constitute a common-window
convergence test. No selected cut edge lies within the recorded eigenvalue
uncertainty diagnostic.}
\label{tab:s4-excited-energy-cut}
\end{table*}

The propagation ratio $J_8=q_6/s^4$ also exposes a repeating crossover near
the moving lowest gap. Table~\ref{tab:s4-excited-moving-gap} uses the native
$R=10$ widths, $R=14$ widths centered at $\tau=819.2$, and native
$R=18$ widths. The approximate repetition occurs when $\tau\Delta_e$ is
matched, while $\log J_8$ grows strongly across the three positions.
At the still longer $R=10$ width $\tau=LONG_TAU$,
the positive norm recurrence gives $\tau\Delta_e\simeqLONG_GAP$ and
$\log J_8\simeqLONG_LOGJ$. Direct spectral weights are unresolved in this
last case; the recurrence does not certify its pressure probability law.
The observed growth follows a finite-cutoff crossover and does not establish a persistent
moment-order exponent. The modal dimensions are $M=20,24,28$ and the fixed
reference mode counts are $24,24,28$; these records establish neither a
common-interior limit nor an unchanged-calibration depth limit.

\begin{table*}[t]
\centering
\small
\begin{tabular}{lrrr}
\toprule
Range of $\tau\Delta_e$ & $\log J_8$, $R=10$ & $\log J_8$, $R=14$ & $\log J_8$, $R=18$ \\
\midrule
MOVING_ROWS
\bottomrule
\end{tabular}
\caption{Natural logarithms of the increment propagation ratio at nearly
matched lowest-gap positions. The widths are
$(36.20387,51.2,72.40773)$ for $R=10$,
$(579.26188,819.2,1158.52375)$ for $R=14$, and
$(9268.19000,13107.2,18536.38000)$ for $R=18$.
Changing the averaging window with the lowest gap can repeat a crossover;
it does not by itself establish a scale-independent law.}
\label{tab:s4-excited-moving-gap}
\end{table*}

Deleting a band of small energy transfers from $B$ while keeping $g$ fixed
is a second, distinct matrix alteration. It is not additive attribution:
for the $R=10$, $Q=16$ increment at $\tau=51.2$, deleting
$\tau|E_i-E_j|/\hbar\leq0.1,0.5,1$ gives respective
$q_6$ ratios $0.999999081$, $1.00160184$, and $0.24678378$.
Wider deletion can first increase the chain norm because its matrix paths
interfere. It cannot be read as a monotone accounting of independent events.

Six independent control groups pass, and all $42$ ordinary/increment rows
satisfy the stored positive-moment checks. Independently evaluated block
identities agree with the full vector recurrences to better than
$9.53\times10^{-16}$; original saved increment moments replay to
$2.44\times10^{-12}$. The $R=10$ changes from $Q=14$ to $16$ are at most
$1.32\times10^{-4}$ relatively in $q_6$ and $1.37\times10^{-4}$ absolutely in
$\log J_8$ across the tested rows. These measure combined occupation and
selection sensitivity, not error bars. Direct pressure spectral reconstruction
resolves $35$ rows; seven longer-width $R=10$ rows retain unresolved small
spectral weights, so their norm recurrences do not certify a full spectral CDF.
The deleted-entry estimates are small within their stated scope and exclude
retained-entry, eigenpair and physical source errors. Outside-source,
primitive, bath, mode and hierarchy refinements remain separate. Nonzero
$q_6$ can also occur for quadratic pressure in Gaussian fields; this test
alone identifies neither irreducible nonlinear field statistics nor measured
temporal bursts.
'''
    long=e['long_R10_increment']
    return (text.replace('CUT_ROWS','\n'.join(rows)).replace('MOVING_ROWS','\n'.join(moving))
      .replace('LONG_TAU',f"{long['tau']:.5f}").replace('LONG_GAP',f"{long['scaled_first_even_gap']:.5f}")
      .replace('LONG_LOGJ',f"{long['log_J8']:.2f}"))


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--replace',action='store_true');a=ap.parse_args()
    if 'PYSCF_MAX_MEMORY' in os.environ:require(float(os.environ['PYSCF_MAX_MEMORY'])>=512,'512 MB admission for result extraction')
    with localcontext() as ctx:
        ctx.prec=90;ctx.Emin=-999999999;ctx.Emax=999999999
        r,extracted,physical,history,evidence=validate();text=render(extracted)
    target=path(TARGET);provenance=path(PROVENANCE);own=str(Path(__file__).resolve().relative_to(ROOT))
    if target.exists() or provenance.exists():
        require(a.replace and target.exists() and provenance.exists(),'exclusive outputs required; --replace only for this prior generated pair')
        old=json.loads(provenance.read_text());require(old['generator']['path']==own and old['output']['path']==TARGET and old['output']['sha256']==sha(target),'existing output pair not bound to this generator')
    record=dict(status='GENERATED_FROM_EXECUTED_QUALIFIED_FINITE_MATRIX_RESULTS',generator=dict(path=own,sha256=sha(Path(__file__))),
      inputs={RESULT:RESULT_SHA,CONTROL:CONTROL_SHA,SPEC:SPEC_SHA},current_executed_source_sha256=r['source_sha256'],evidence=evidence,
      physical_inputs=physical,historical_source_bindings=history,method_fragment=dict(path=METHOD,sha256=sha(path(METHOD))),
      extracted=extracted,source_warnings=r['warnings'],output=dict(path=TARGET,sha256=hashlib.sha256(text.encode()).hexdigest()),
      scope='Changed-matrix source-chain diagnostics in supplied finite models; no probability error, total-M8 fraction, common-interior convergence, persistent exponent or temporal-burst inference.')
    target.write_text(text);provenance.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    require(sha(target)==record['output']['sha256'],'generated fragment hash mismatch')
    print('Generated executed excited-pressure results fragment and provenance; no physical calculations performed.')

if __name__=='__main__':main()
