"""Root-run independent positive and signed Hermitian controls; no physical solve."""
from pathlib import Path
from decimal import Decimal as D,localcontext
import argparse,copy,json,math,os,time
import numpy as np
from scipy.linalg import eigh
import excited_pressure_propagation as p


def reject(call):
    try:call()
    except (ValueError,ArithmeticError):return
    raise AssertionError('bad input accepted')


def direct(X):
    v=np.eye(len(X),dtype=X.dtype)[:,0];m={}
    for k in range(1,9):
        v=X@v
        if k%2==0:
            assert abs(v[0].imag)<2e-10*max(abs(v[0].real),1.)
            m[k]=D(str(v[0].real))
    return m


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--spec',default='research/stage4/excited_pressure_propagation_spec.json');ap.add_argument('--output',required=True);a=ap.parse_args()
    sp=p.path(a.spec);spec=json.loads(sp.read_text());p.spec_gate(spec);source=p.source_hashes();begin=time.monotonic()
    memory=float(os.environ['PYSCF_MAX_MEMORY']);p.require(memory>=256,'256MB minimum control allowance')
    out=dict(format='stage4-excited-pressure-controls-v1',status='RUNNING',source_sha256=source,spec_sha256=p.sha(sp),runtime=p.runtime(),checks=[])
    dest=p.path(a.output);p.claim(dest,out)
    def passed(name,**details):
        assert name==p.CHECKS[len(out['checks'])];out['checks'].append(dict(name=name,passed=True,**details));p.save(dest,out)
    try:
        with localcontext() as ctx:
            ctx.prec=80;ctx.Emin=-999999999;ctx.Emax=999999999
            rng=np.random.default_rng(9152026);largest=0.;count=0
            for complex_case in (False,True):
                for n in (3,5,9):
                    for _ in range(12):
                        Z=rng.normal(size=(n,n))
                        if complex_case:Z=Z+1j*rng.normal(size=(n,n))
                        X=(Z+Z.conj().T)/2;X[0,0]=0.;q,_=p.propagation(X[1:,0],X[1:,1:]);prediction=p.identities(q);m=direct(X)
                        err=max(float(abs(prediction[k]-m[k])/m[k]) for k in (2,4,6,8));largest=max(largest,err);assert err<2e-11
                        s=q[0];assert m[6]>=(s**3+q[4])*(1-D('1e-11')) and m[6]<=D('2.5')*(s**3+q[4])*(1+D('1e-11'))
                        assert m[8]>=D(2)/3*(s**4+q[6])*(1-D('1e-11')) and m[8]<=13*(s**4+q[6])*(1+D('1e-11'))
                        if not complex_case:p.diagnose(X)
                        count+=1
            X=np.array([[0.,math.sqrt(.9),math.sqrt(.1)],[math.sqrt(.9),-1.,0.],[math.sqrt(.1),0.,3.]])
            _,q,_=p.diagnose(X);assert q[1]*q[3]<0
            passed(p.CHECKS[0],matrices=count,max_relative_identity_error=largest,explicit_negative_q1_q3=float(q[1]*q[3]),scope='real symmetric and complex Hermitian independent full powers')

            records=[]
            for tau in (1.,16.,2.**16,2.**24):
                aa=p.positive.channel(1.,tau);bb=p.positive.channel(2.5,tau)
                X=np.array([[0.,math.sqrt(aa),math.sqrt(bb)],[math.sqrt(aa),0.,0.],[math.sqrt(bb),0.,1.]])
                m,q,report=p.diagnose(X)
                assert max(float(abs(q[k]/D.from_float(bb)-1)) for k in (1,2,3,4,5,6))<2e-14
                record=p.positive.law(1.,2.5,tau,1.)
                assert max(abs(float(m[k])/record['moments'][str(k)]-1) for k in (2,4,6,8))<2e-13
                records.append(dict(tau=tau,log_J={str(k):report['propagation_ratios'][str(k)]['log_abs'] for k in (4,6,8)}))
            a0,b0=records[-2:];dlog=math.log(b0['tau']/a0['tau']);js={k:(b0['log_J'][k]-a0['log_J'][k])/dlog for k in ('4','6','8')}
            assert max(abs(js[k]-target) for k,target in [('4',-.5),('6',.5),('8',1.5)])<1e-5
            passed(p.CHECKS[1],asymptotic_signed_log_J_slopes=js,expected={'4':-.5,'6':.5,'8':1.5},scope='known exact continuum quantum control, not a Casimir mechanism claim')

            E=np.array([0.,1.,1.]);Pc=np.array([[0.,.3,.4],[.3,1.,.2],[.4,.2,-.5]])
            X,_,_=p.ar.filtered(Pc,E,.7,True,2.);assert np.all(X[1:,1:]==0.)
            m,q,report=p.diagnose(X);assert all(q[k]==0 for k in range(1,7))
            assert max(float(abs(m[k]/m[2]**(k//2)-1)) for k in (4,6,8))<1e-14
            assert Pc[1,2]!=0 and X[1,2]==0
            passed(p.CHECKS[2],all_zero_transfer_entries_removed=True,exact_degenerate_offdiagonal_removed=True,propagation_ratios_zero=True)

            E=np.array([0.,1.,1.,2.]);Z=rng.normal(size=(4,4));Pc=(Z+Z.T)/2;Pc[0,0]=0
            angle=.71;c,s=math.cos(angle),math.sin(angle);U=np.eye(4);U[1:3,1:3]=[[c,-s],[s,c]]
            rotated=U.T@Pc@U;largest=0.
            for inc in (False,True):
                A,_,_=p.ar.filtered(Pc,E,.4,inc,2.);B,_,_=p.ar.filtered(rotated,E,.4,inc,2.)
                _,qa,_=p.diagnose(A);_,qb,_=p.diagnose(B)
                largest=max(largest,max(float(abs(qa[k]-qb[k])/max(abs(qa[k]),qa[0]**(1+D(k)/2))) for k in range(7)))
                mask=E[1:,None]==E[None,1:]
                for matrix in (A,B):matrix[1:,1:][mask]=0
                _,qa,_=p.diagnose(A);_,qb,_=p.diagnose(B)
                largest=max(largest,max(float(abs(qa[k]-qb[k])/max(abs(qa[k]),qa[0]**(1+D(k)/2))) for k in range(7)))
            assert largest<2e-12
            passed(p.CHECKS[3],max_scaled_difference=largest,scope='summed exact-energy-block quantities; no individual eigenvector matching')

            tiny=[]
            for epsilon,diagonal in [(1e-120,1.),(1e-80,1e-80)]:
                X=np.array([[0.,epsilon],[epsilon,diagonal]]);m,q,_=p.diagnose(X)
                s0=D.from_float(epsilon)**2
                for j in (1,2,3):assert abs(q[2*j]/(s0*D.from_float(diagonal)**(2*j))-1)<D('2e-14')
                tiny.append(dict(epsilon=epsilon,B=diagonal,q6=p.ar.value(q[6]),M8=p.ar.value(m[8])))
            gg=np.array([.03]);BB=np.array([[.7]]);delta=D('1e-9');qq,_=p.propagation(gg,BB)
            changed,_=p.propagation(gg+float(delta),BB+float(delta));enclosure=p.deletion_q_bounds(gg,BB,qq,delta)
            for k in (0,2,4,6):assert abs(changed[k]-qq[k])<=D(enclosure['quantities'][str(k)]['absolute_deleted_entry_envelope']['decimal'])*(1+D('1e-6'))
            passed(p.CHECKS[4],cases=tiny,deleted_entry_telescoping_control=True,scope='positive norm/log arithmetic; no repair of inaccurate input eigenpairs or deleted entries')

            bad=copy.deepcopy(spec);bad['jobs'][0]['archive']['sha256']='0'*64;reject(lambda:p.spec_gate(bad))
            bad=copy.deepcopy(spec);bad['jobs']=bad['jobs'][:-1];reject(lambda:p.spec_gate(bad))
            bad=copy.deepcopy(spec);bad['beta']=3.;reject(lambda:p.spec_gate(bad))
            counterfeit=dict(out,status='PASS');reject(lambda:p.control_gate(counterfeit,source,p.sha(sp)))
            reject(lambda:p.diagnose(np.array([[1.,.1],[.1,0.]])))
            passed(p.CHECKS[5],wrong_archive_rejected=True,incomplete_jobs_rejected=True,changed_beta_rejected=True,false_PASS_rejected=True,uncentered_source_rejected=True)
        assert p.source_hashes()==source and len(out['checks'])==len(p.CHECKS)
        out.update(status='PASS',elapsed_seconds=time.monotonic()-begin);p.save(dest,out)
    except BaseException as exc:out.update(status='FAILED',error=repr(exc),elapsed_seconds=time.monotonic()-begin);p.save(dest,out);raise


if __name__=='__main__':main()
