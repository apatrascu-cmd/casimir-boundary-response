"""Validate and extract completed fixed-energy saved-tail evidence; no matrix solve."""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import hashlib
import json
import math
import os

ROOT = Path(__file__).resolve().parents[2]
INPUT = 'research/stage4/results/tail_fixed_energy_selection_beta1.json'
INPUT_SHA = '5fd8cb2435b11348a68356f728f8dc03aeb0b10b480db243c83e8c9c7c9a8311'
CONTROL = 'research/stage4/results/tail_fixed_energy_selection_controls.json'
CONTROL_SHA = 'a700aca6740cf77f82c5458edd1827b6edce3223dc3714f3161c03384bbe489a'
SPEC = 'research/stage4/tail_fixed_energy_selection_spec.json'
SPEC_SHA = 'b7a6b31b78545e7f1a0792a9552e17fd58a4ae18db8106292efc6ec5fc77803d'
AUDIT = 'research/stage4/TAIL_FIXED_ENERGY_EXECUTED_AUDIT_2026-09-15.md'
AUDIT_SHA = 'd93130092757d3685f8ba4f5558fd1c897480fe4751127d8e8772001b7d579c6'
TARGET = 'paper/stage4_tail_fixed_energy_results.tex'
PROVENANCE = 'paper/stage4_tail_fixed_energy_provenance.json'
CHECKS = ['known_atomic_selection_effect', 'filter_projection_and_scalar_centering',
          'degenerate_block_rotation', 'selection_and_inventory_refusals',
          'harmonic_and_full_selection_replay']


def require(test, message):
    if not test:
        raise ValueError(message)


def local(name):
    p = (ROOT / name).resolve()
    require(p.is_relative_to(ROOT), 'Project-local paths required')
    return p


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def one(rows, predicate, label):
    found = [r for r in rows if predicate(r)]
    require(len(found) == 1, 'Expected one ' + label)
    return found[0]


def probability(law, threshold, noise=0.):
    row = one(law['tail_panel'], lambda r: r['threshold_sigma0'] == threshold, 'threshold')
    effect = row['hard'] if noise == 0 else one(row['smooth'], lambda r: r['noise_sigma0'] == noise, 'noise')
    return effect['two_sided']['value']


def extended_probability(record):
    """Decode declared zeros and log-only nonzeros without treating None as zero."""
    status = record['status']; value = record['value']; log_value = record['log_value']
    if status == 'zero_in_supplied_discrete_law':
        require(value == 0 and log_value is None, 'Malformed declared zero probability')
        return Decimal(0)
    require(status in ('representable', 'underflow_nonzero') and
            log_value is not None and math.isfinite(log_value) and log_value <= 1e-12,
            'Invalid extended probability status/logarithm')
    with localcontext() as ctx:
        ctx.prec = 80; ctx.Emin = -999999999; ctx.Emax = 999999999
        via_log = Decimal.from_float(log_value).exp()
        require(via_log > 0, 'Log-only probability lost in extended arithmetic')
        if status == 'underflow_nonzero':
            require(value is None and math.exp(log_value) == 0, 'Malformed nonzero-underflow record')
            return +via_log
        require(value is not None and math.isfinite(value) and 0 < value <= 1 + 2e-12,
                'Malformed representable probability')
        represented = Decimal.from_float(value)
        require(abs(via_log-represented) / represented < Decimal('5e-12'), 'Probability/log representation mismatch')
        return represented


def percent(x):
    return f'{100*x:+.5f}'


def scientific(x, digits=5):
    mantissa, exponent = f'{x:.{digits}e}'.split('e')
    return mantissa + r'\times10^{' + str(int(exponent)) + '}'


def validate():
    verified = {}
    def verify(name, expected):
        require(sha(local(name)) == expected, 'Digest mismatch: ' + name)
        verified[name] = expected
    for p, h in [(INPUT, INPUT_SHA), (CONTROL, CONTROL_SHA), (SPEC, SPEC_SHA), (AUDIT, AUDIT_SHA)]:
        verify(p, h)
    data = json.loads(local(INPUT).read_text())
    control = json.loads(local(CONTROL).read_text())
    spec = json.loads(local(SPEC).read_text())
    require(data['format'] == 'stage4-tail-fixed-energy-selection-v1' and
            data['status'] == 'COMPLETED_WITH_SCOPE_LIMITATIONS', 'Completed fixed-energy evidence required')
    require(data['spec'] == spec and data['spec_sha256'] == SPEC_SHA, 'Embedded spec mismatch')
    require(data['controls'] == {'path': CONTROL, 'sha256': CONTROL_SHA}, 'Control binding mismatch')
    require(control['format'] == data['format'] + '-controls' and control['status'] == 'PASS', 'Accepted controls required')
    require([x['name'] for x in control['checks']] == CHECKS and
            all(x['passed'] is True for x in control['checks']), 'Complete PASS5 required')
    require(control['spec_sha256'] == SPEC_SHA and control['source_sha256'] == data['source_sha256'] == spec['source_sha256'], 'Tested numerical source identity mismatch')
    require(control['runtime'] == data['runtime'], 'Control/result runtime mismatch')
    for name, h in data['source_sha256'].items():
        verify(name, h)
    for key in ('tail_result', 'tail_controls', 'tail_spec', 'design'):
        b = spec[key]
        verify(b['path'], b['sha256'])
    prior = json.loads(local(spec['tail_result']['path']).read_text())
    prior_spec = json.loads(local(spec['tail_spec']['path']).read_text())
    prior_control = json.loads(local(spec['tail_controls']['path']).read_text())
    require(prior['status'] == 'COMPLETED_WITH_WARNINGS' and prior['spec'] == prior_spec and
            prior['spec_sha256'] == spec['tail_spec']['sha256'], 'Prior tail evidence mismatch')
    require(prior_control['status'] == 'PASS' and len(prior_control['checks']) == 17 and
            all(c['passed'] is True for c in prior_control['checks']), 'Prior PASS17 required')
    require(prior['controls']['sha256'] == spec['tail_controls']['sha256'] and
            prior_control['spec_sha256'] == spec['tail_spec']['sha256'], 'Prior controls mismatch')
    require(spec['frozen_sources'] == {**prior['source_sha256'], **prior_control['source_sha256']}, 'Historical tail source union mismatch')
    for name, h in spec['frozen_sources'].items():
        verify(name, h)
    require(spec['energy_ceilings'] == [.45, .48, .5] and spec['tau'] == 51.2 and
            spec['ratio'] == 2 and spec['hbar'] == 1 and spec['threshold'] == 8 and
            spec['tail_relative_target'] == .01, 'Physical observation/decision grid changed')
    require([(j['Q'], j['beta']) for j in spec['jobs']] == [(14, 1.), (16, 1.)], 'Exact physical inventory required')
    require(spec['jobs'] == [j for j in prior_spec['jobs'] if j['beta'] == 1.], 'Prior job binding changed')
    require(len(data['cases']) == 2 and len(data['comparisons']) == 2, 'Complete two-Q comparison required')
    require(set(data['reference_units']) == {'ordinary', 'increment'}, 'Both common reference units required')
    for obs, ref in data['reference_units'].items():
        require(ref['previous_reference'] == prior['reference_units'][obs] and
                ref['sigma0'] > 0 and abs(ref['sigma0'] / ref['previous_reference']['sigma0'] - 1) < 2e-12,
                'Original all-M harmonic units mismatch')
        require(ref['previous_reference']['moments']['modes'] == 20, 'All-M20 reference required')
    statistics = dict(laws=0, effects=0, normalization_error=0., hard_replay_error=0.,
        smooth_replay_error=0., independent_moment_error=0., H_moment_error=0.,
        H_tail_absolute_error=0., H_tail_relative_error=0., P_tail_absolute_error=0.,
        P_tail_relative_error=0., numerical_edge_mass=0., minimum_edge_distance=math.inf,
        within_Q_even_moment_drift=0., spectrum_moment_replay_error=0.,
        log_only_one_sided_probabilities=0, minimum_retained_one_sided_log=None)
    laws = {}
    for case, job in zip(data['cases'], spec['jobs']):
        require(case['parent'] == job and case['Q'] == job['Q'] and case['beta'] == 1., 'Result/physical job mismatch')
        verify(job['input'], job['input_sha256'])
        verify(job['archive'], job['archive_sha256'])
        parent = json.loads(local(job['input']).read_text())
        physical = parent['cases'][job['case_index']]
        require(parent['status'] == physical['status'] == 'COMPLETED', 'Completed physical parent required')
        require(case['historical_physical_source_sha256'] == parent['source_sha256'], 'Historical physical source map altered')
        expected_case = {k: v for k, v in physical.items() if k not in ('cosine', 'harmonic')}
        require(case['input_case'] == expected_case, 'Physical-case transcription mismatch')
        for key, value in prior_spec['physical_parameters'].items():
            require(physical.get(key, 0. if key == 'soft' else None) == value, 'Physical calibration mismatch: ' + key)
        record = one(physical['cosine'], lambda x: x['beta'] == 1., 'physical beta')
        require(record['effective_archive'] == job['archive'] and record['diagnostics'] == case['original_diagnostics'], 'Archive/diagnostics mismatch')
        diag = case['original_diagnostics']
        require(diag['even_ground_certified_against_odd'] is True and
                diag['retained_cluster_certification_margin'] > diag['original_hamiltonian_residual_bound'], 'Original physical ground/cluster gate failed')
        require([w['ceiling'] for w in case['windows']] == [None, .45, .48, .5], 'Exact energy grid required')
        for window in case['windows']:
            cut = window['ceiling']; selection = window['selection']
            require(selection['count'] == window['alternate_selection']['count'], 'H drivers select different counts')
            if cut is not None:
                require(selection['last_retained_gap'] < cut < selection['first_excluded_gap'] and
                        selection['distance_to_cut'] > selection['arithmetic_guard'] and
                        cut + selection['arithmetic_guard'] < selection['parent_omitted_floor'], 'Unresolved selection boundary')
            else:
                require(selection['count'] == spec['saved_dimensions'][str(case['Q'])], 'Native dimension changed')
            require([a['observable'] for a in window['observables']] == ['ordinary', 'increment'], 'Both ordered observables required')
            for law in window['observables']:
                obs = law['observable']; key = (case['Q'], cut, obs); laws[key] = law
                require(law['dimension'] == selection['count'] and law['tau'] == 51.2 and law['ratio'] == (2.0 if obs == 'increment' else None) and
                        law['sigma0'] == data['reference_units'][obs]['sigma0'], 'Law dimension/window/units mismatch')
                require(law['warnings'] == [], 'Unexpected arithmetic warning in audited law')
                rec = law['recurrence']; require(rec['positive_moment_checks']['passed'] is True and
                    rec['spectral_reconstruction']['passed'] is True and rec['spectral_reconstruction']['status'] == 'RESOLVED', 'Moment/spectral gate unresolved')
                require(rec['filter_arithmetic']['actual_ground_diagonal'] == 0 and
                    rec['filter_arithmetic']['dropped_nonzero_source_entries'] == 0 and
                    rec['filter_arithmetic']['pressure_filter_product_underflow_entries'] == 0, 'Centering/filter gate failed')
                if obs == 'increment': require(rec['filter_arithmetic']['diagonal_exactly_zero'] is True, 'Increment diagonal not zero')
                spectrum = law['spectrum']; xs = spectrum['values_sigma0']; weights = spectrum['weights']
                require(len(xs) == len(weights) == law['dimension'] and all(math.isfinite(x) for x in xs) and
                        all(math.isfinite(p) and p >= 0 for p in weights) and xs == sorted(xs), 'Invalid spectral law')
                require(spectrum['squared_overlap_underflow_count'] == 0, 'Unresolved overlap underflow')
                mass = math.fsum(weights); err = abs(mass - 1)
                require(err <= 2e-11 and abs(mass - spectrum['normalization']) <= 2e-15, 'Probability normalization failed')
                statistics['normalization_error'] = max(statistics['normalization_error'], err)
                with localcontext() as ctx:
                    ctx.prec = 80
                    sigma = Decimal.from_float(law['sigma0'])
                    ms = {n: Decimal(rec['moments'][str(n)]['decimal']) / sigma**n for n in range(1, 9)}
                    require(ms[1] == 0 and all(ms[n] > 0 for n in (2, 4, 6, 8)), 'Centered/positive moments required')
                    for n in range(1, 9):
                        spectral = math.fsum(p*x**n for x, p in zip(xs, weights))
                        error = abs(spectral - float(ms[n])) / max(abs(float(ms[n])), float(ms[2])**(n/2), 1e-300)
                        require(error <= 2e-8, 'Saved spectrum/moment replay failed')
                        statistics['spectrum_moment_replay_error'] = max(statistics['spectrum_moment_replay_error'], error)
                require([t['threshold_sigma0'] for t in law['tail_panel']] == [8., 9.], 'Threshold inventory mismatch')
                for tail in law['tail_panel']:
                    h = tail['threshold_sigma0']; require(tail['hard']['event'] == 'strict abs(x)>h', 'Hard boundary convention changed')
                    require([e['noise_sigma0'] for e in tail['smooth']] == [.1, .25, .5, 1.], 'Resolution inventory changed')
                    for effect in [tail['hard'], *tail['smooth']]:
                        s = effect['noise_sigma0']; value = effect['two_sided']['value']
                        require(value is not None and 0 < value < 1 and value >= 1e-10, 'Relative probability below accepted floor')
                        if s == 0:
                            replay = math.fsum(p for x, p in zip(xs, weights) if abs(x) > h)
                            error_key = 'hard_replay_error'
                        else:
                            replay = math.fsum(p * .5 * (math.erfc((h-x)/(math.sqrt(2)*s)) + math.erfc((h+x)/(math.sqrt(2)*s))) for x, p in zip(xs, weights))
                            error_key = 'smooth_replay_error'
                        error = abs(replay - value)
                        require(error <= 2e-11 and error / max(value, replay) <= 1e-5, 'Independent scalar effect replay failed')
                        with localcontext() as ctx:
                            ctx.prec = 80; ctx.Emin = -999999999; ctx.Emax = 999999999
                            decoded = {k: extended_probability(effect[k]) for k in ('positive', 'negative', 'two_sided', 'inside_inclusive')}
                            require(abs(decoded['positive'] + decoded['negative'] - decoded['two_sided']) <= Decimal('2e-14') and
                                    abs(decoded['inside_inclusive'] + decoded['two_sided'] - Decimal.from_float(mass)) <= Decimal('2e-11'), 'Extended tail/complement identity failed')
                            for side in ('positive', 'negative'):
                                if effect[side]['status'] == 'underflow_nonzero':
                                    statistics['log_only_one_sided_probabilities'] += 1
                                    old_log = statistics['minimum_retained_one_sided_log']
                                    statistics['minimum_retained_one_sided_log'] = effect[side]['log_value'] if old_log is None else min(old_log, effect[side]['log_value'])
                        statistics[error_key] = max(statistics[error_key], error); statistics['effects'] += 1
                    statistics['minimum_edge_distance'] = min(statistics['minimum_edge_distance'], tail['hard']['nearest_absolute_eigenvalue_distance_sigma0'])
                    statistics['numerical_edge_mass'] = max(statistics['numerical_edge_mass'], tail['hard']['numerical_edge_cluster_weight'])
                require(len(law['eigensolver_tail_sensitivity']) == len(law['H_eigensolver_tail_comparison']) == 10, 'Both eigensolver effect inventories required')
                for x in law['eigensolver_tail_sensitivity']:
                    require(x['status'] == 'RESOLVED_ABSOLUTE_AND_RELATIVE' and x['absolute_difference'] <= 2e-11 and x['relative_difference'] <= 1e-5, 'Pressure eigensolver disagreement')
                    statistics['P_tail_absolute_error'] = max(statistics['P_tail_absolute_error'], x['absolute_difference'])
                    statistics['P_tail_relative_error'] = max(statistics['P_tail_relative_error'], x['relative_difference'])
                for x in law['H_eigensolver_tail_comparison']:
                    require(x['absolute'] <= 2e-11 and x['relative'] <= 1e-5, 'H eigensolver tail disagreement')
                    statistics['H_tail_absolute_error'] = max(statistics['H_tail_absolute_error'], x['absolute'])
                    statistics['H_tail_relative_error'] = max(statistics['H_tail_relative_error'], x['relative'])
                hm = law['H_eigensolver_even_moment_comparison']
                require(hm['passed'] is True and hm['maximum_symmetric_relative_difference'] <= 2e-8 and
                        [x['order'] for x in hm['rows']] == [2, 4, 6, 8], 'H even-moment gate failed')
                statistics['H_moment_error'] = max(statistics['H_moment_error'], hm['maximum_symmetric_relative_difference'])
                statistics['independent_moment_error'] = max(statistics['independent_moment_error'], *law['independent_moment_scaled_errors'].values())
                if cut is None:
                    require(max(law['original_even_moment_relative_errors'].values()) <= 2e-8 and
                            all(x['absolute'] <= 2e-11 and abs(x['relative']) <= 1e-5 for x in law['original_tail_replay']), 'Native tail/moment replay failed')
                for n in (2, 4, 6, 8):
                    native = case['windows'][0]['observables'][0 if obs == 'ordinary' else 1]
                    drift = abs(rec['even_moments'][str(n)]['value'] / native['recurrence']['even_moments'][str(n)]['value'] - 1)
                    statistics['within_Q_even_moment_drift'] = max(statistics['within_Q_even_moment_drift'], drift)
                statistics['laws'] += 1
    require(statistics['laws'] == 16 and statistics['effects'] == 160, 'Complete law/effect inventory required')
    table = []
    for cut in (None, .45, .48, .5):
        a = laws[(14, cut, 'increment')]; b = laws[(16, cut, 'increment')]
        p14, p16 = probability(a, 8), probability(b, 8)
        q14, q16 = probability(a, 9), probability(b, 9)
        table.append(dict(ceiling=cut, count14=a['dimension'], count16=b['dimension'], hard8_Q14=p14,
            hard8_Q16=p16, hard8_Q_drift=p16/p14-1, hard9_Q_drift=q16/q14-1,
            smooth8_s1_Q_drift=probability(b, 8, 1)/probability(a, 8, 1)-1,
            band8to9_Q14=p14-q14, band8to9_Q16=p16-q16,
            band_share_of_Q_hard8_difference=((p16-q16)-(p14-q14))/(p16-p14)))
    for comp in data['comparisons']:
        obs = comp['observable']; qdrifts = []; drifts = {}
        for window in comp['common_windows']:
            cut = window['ceiling']
            for effect in window['effects']:
                noise = effect['noise']; ps = {f'Q{q}_{kind}': probability(laws[(q, None if kind == 'native' else cut, obs)], 8, noise) for q in (14, 16) for kind in ('native', 'common')}
                require(ps == effect['probabilities'], 'Comparison probability transcription differs')
                actual = ps['Q16_common']/ps['Q14_common']-1
                require(abs(actual - effect['fixed_ceiling_relative_Q_drift']) <= 2e-15, 'Comparison drift transcription differs')
                telescoping = math.fsum([ps['Q16_native']-ps['Q16_common'], ps['Q16_common']-ps['Q14_common'], ps['Q14_common']-ps['Q14_native'], -(ps['Q16_native']-ps['Q14_native'])])
                require(abs(telescoping) <= 2e-15, 'Signed comparison identity failed')
                if noise == 0: qdrifts.append(actual)
        for q in (14, 16):
            ps = [probability(laws[(q, cut, obs)], 8) for cut in (.45, .48, .5)]
            drifts[str(q)] = [abs(b/a-1) for a, b in zip(ps, ps[1:])]
        require(drifts == comp['hard_within_Q_ceiling_drifts'], 'Within-Q ceiling transcription differs')
        require(comp['hard_common_Q_drifts_below_one_percent'] == all(abs(x) <= .01 for x in qdrifts) and
                comp['all_declared_hard_ceiling_drifts_below_one_percent'] == all(x <= .01 for v in drifts.values() for x in v), 'Prespecified decision changed')
        require(comp['hard_common_Q_drifts_below_one_percent'] == (obs == 'ordinary') and
                comp['all_declared_hard_ceiling_drifts_below_one_percent'] == (obs == 'ordinary'), 'Audited scientific verdict changed')
    return data, laws, table, statistics, verified


def fragment(data, laws, rows, checks):
    lines = [r'% Generated from completed saved-data evidence; see provenance JSON.',
        r'\subsection{A common energy ceiling does not stabilize the increment tail}',
        r'\label{sec:tail-fixed-energy}',
        r'At fixed $R=10$, $M=20$, reference mode count $24$, $\beta=1$ and $\tau=51.2$, we applied the same interacting excitation-energy ceiling to the saved $Q=14$ and $Q=16$ models. The construction retains every represented even state below the ceiling and replaces the original composite pressure, projected into the supplied space, by its further compression $\Pi_E P\Pi_E$. This changes the operator whose vacuum spectral law is evaluated; it is not conditioning the original pressure law. The native models also differ in their historical target selection. The original all-$M$ harmonic $H_0$ supplies a common standard deviation $\sigma_0$ for each observable, not a computed all-mode reference CDF.',
        r'\begin{table*}[t]', r'\centering', r'\small',
        r'\begin{tabular}{c r r r r r r}', r'\hline',
        r'Ceiling & States $Q14/Q16$ & $p_8(Q14)$ & $p_8(Q16)$ & $\Delta p_8$ (\%) & $\Delta p_9$ (\%) & $\Delta p_{8,1}$ (\%) \\', r'\hline']
    for row in rows:
        label = 'Native' if row['ceiling'] is None else f"{row['ceiling']:.2f}"
        lines.append(f"{label} & {row['count14']}/{row['count16']} & ${scientific(row['hard8_Q14'])}$ & ${scientific(row['hard8_Q16'])}$ & {percent(row['hard8_Q_drift'])} & {percent(row['hard9_Q_drift'])} & {percent(row['smooth8_s1_Q_drift'])} " + r'\\')
    lines += [r'\hline', r'\end{tabular}',
        r'\caption{Increment tails in the supplied finite matrices. Here $p_h=\Pr(|X|>h\sigma_0)$, with equality inside, and $p_{8,1}=\Pr(|X/\sigma_0+Z|>8)$ for independent standard-normal readout noise $Z$. Relative differences are $100[p(Q16)/p(Q14)-1]$. A common energy ceiling changes the compressed pressure operator; these differences are sensitivity measurements, not probability error bounds.}',
        r'\label{tab:tail-fixed-energy}', r'\end{table*}']
    ordinary = probability(laws[(16, None, 'ordinary')], 8)/probability(laws[(14, None, 'ordinary')], 8)-1
    native = rows[0]; last = rows[-1]
    within16 = rows[-1]['hard8_Q16'] / rows[-2]['hard8_Q16'] - 1
    lines += [
        f"The ordinary hard tail changes by only ${percent(ordinary)}\\%$ between $Q14$ and $Q16$, at all three ceilings; its probabilities at thresholds $8$ and $9$ coincide. It passes both prespecified $1\\%$ finite-matrix sensitivity targets. The increment fails both: the common-ceiling difference at threshold $8$ ranges from ${percent(rows[1]['hard8_Q_drift'])}\\%$ to ${percent(last['hard8_Q_drift'])}\\%$. Within $Q16$, raising the ceiling from $0.48$ to $0.50$ changes this probability by ${percent(within16)}\\%$. Smoothing is a different resolution-dependent effect and is not uniformly stabilizing: even noise width $\\sigma_0$ leaves a ${percent(rows[2]['smooth8_s1_Q_drift'])}\\%$ difference at ceiling $0.48$.",
        f"Within each $Q$, all four positive even moments through order eight change by at most ${scientific(checks['within_Q_even_moment_drift'], 2)}$ relative when the ceiling changes. Nevertheless the hard increment tail moves substantially. The spectral mass in $8<|X|/\\sigma_0\\le9$ accounts for ${100*native['band_share_of_Q_hard8_difference']:.2f}\\%$ of the native threshold-$8$ difference and ${100*last['band_share_of_Q_hard8_difference']:.2f}\\%$ at ceiling $0.50$. This identifies a probability band without matching individual eigenvectors across dimensions. The stored signed telescoping comparison is not a unique causal attribution.",
        f"All $16$ laws pass the recorded positivity, normalization and independent moment-reconstruction checks; all $160$ threshold/noise comparisons resolve across the pressure eigensolvers. The largest independent moment discrepancy is ${scientific(checks['independent_moment_error'], 2)}$ in the declared scale; the largest relative tail change across Hamiltonian eigensolvers is ${scientific(checks['H_tail_relative_error'], 2)}$. No filter-product or squared-overlap underflow occurs, and no probability mass lies in the numerical threshold-edge clusters. These arithmetic checks do not bound errors outside the supplied $H/P$ matrices.",
        r'The same energy rule therefore does not remove the increment-tail uncertainty. A further retained-cluster test at fixed occupation and calibration would restore pressure paths absent from the saved native cluster; no such extension receives credit here. Bath, primitive, source and mode errors, the growing common-interior scaling limit and measurement interpretation remain separate. Neither moment agreement nor this finite tail test establishes a CDF certificate or persistent intermittency.', '']
    begin = lines.index(r'\begin{table*}[t]')
    end = lines.index(r'\end{table*}')
    blocks = lines[:begin] + ['\n'.join(lines[begin:end+1])] + lines[end+1:]
    return '\n\n'.join(blocks)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--replace', action='store_true')
    args = ap.parse_args()
    memory = float(os.environ['PYSCF_MAX_MEMORY'])
    require(math.isfinite(memory) and memory >= 64, 'Declare at least64 MiB for saved-data formatting')
    target, provenance = local(TARGET), local(PROVENANCE)
    require(args.replace or (not target.exists() and not provenance.exists()), 'Derived outputs exist; --replace required')
    data, laws, rows, checks, verified = validate()
    content = fragment(data, laws, rows, checks)
    own = str(Path(__file__).resolve().relative_to(ROOT)); verified[own] = sha(Path(__file__))
    evidence = dict(format='stage4-tail-fixed-energy-paper-provenance-v1', status='EXTRACTED_FROM_COMPLETED_FINITE_DATA',
        input=dict(path=INPUT, sha256=INPUT_SHA), controls=dict(path=CONTROL, sha256=CONTROL_SHA),
        generator=dict(path=own, sha256=verified[own]), input_sha256=verified,
        output=dict(path=TARGET, sha256=hashlib.sha256(content.encode()).hexdigest()), table=rows,
        extraction_checks=checks, physical_runtime=data['runtime'], scope_warnings=data['warnings'],
        statement_scope='finite changed compressed pressure operators; no full-source CDF certificate, unique attribution or intermittency claim')
    # Recheck all dependencies immediately before replacing only our two derived files.
    for name, expected in verified.items(): require(sha(local(name)) == expected, 'Input changed during extraction: ' + name)
    for p, value in [(target, content), (provenance, json.dumps(evidence, indent=2, sort_keys=True)+'\n')]:
        tmp = p.with_name(p.name + '.new-tmp')
        with tmp.open('x') as f: f.write(value)
        tmp.replace(p)
    print(json.dumps(dict(status='EXTRACTED', fragment=TARGET, fragment_sha256=sha(target), provenance=PROVENANCE, provenance_sha256=sha(provenance), laws=checks['laws'], effects=checks['effects'])))


if __name__ == '__main__':
    main()
