"""Exact coherent one-field reach of a saved bath, plus nested row selection.

Prepared for root-owned execution. Selection weights describe the OLD supplied
ground, not the ground or spectral energies after a larger nonlinear solve.
"""
from __future__ import annotations
import itertools,math,os
import numpy as np

FORMAT='stage4-coherent-bath-source-reach-v1'


def require(ok,message):
    if not ok:raise ValueError(message)


def downward_closure(state):
    active=[j for j,n in enumerate(state) if n]
    for values in itertools.product(*(range(int(state[j])+1) for j in active)):
        out=[0]*len(state)
        for j,n in zip(active,values):out[j]=n
        yield tuple(out)


def check_states(states):
    states=np.asarray(states);require(states.ndim==2 and states.dtype.kind in 'iu' and np.all(states>=0),'nonnegative integer states required')
    items={tuple(map(int,s)) for s in states};require(len(items)==len(states),'duplicate states')
    require(tuple(states[0])==(0,)*states.shape[1],'vacuum must be first')
    for s in items:
        for j,n in enumerate(s):
            if n:
                predecessor=list(s);predecessor[j]-=1
                require(tuple(predecessor) in items,'input basis is not downward closed')
    return items


def padded_local_fields(orbitals):
    U=np.asarray(orbitals);require(U.ndim==3 and U.dtype.kind=='f' and np.isfinite(U).all() and U.shape[1]==U.shape[2],'finite real square local orbitals required')
    M,N,_=U.shape;a=np.diag(np.sqrt(np.arange(1,N+1)),1);x=a+a.T;yi=a.T-a
    xp=[];yp=[];orth=0.
    for u in U:
        orth=max(orth,float(np.linalg.norm(u.T@u-np.eye(N))))
        ext=np.zeros((N+1,N+1));ext[:N,:N]=u;ext[N,N]=1.
        xp.append(ext.T@x@ext);yp.append(ext.T@yi@ext)
    require(orth<1e-10,'local orbitals not orthogonal to roundoff')
    return np.asarray(xp),np.asarray(yp),orth


def coherent_reach(bath,psi,orbitals,coefficients,source_modes,C0=1.,L0=1.,memory_mb=None,resident_bytes=0,return_retained_amplitudes=True):
    """Enumerate every nonzero local source matrix entry, with no threshold.

    Rows <primitive_size are dressed configurations. One new padded primitive
    orbital at index N accounts exactly for a single canonical field acting on
    the original primitive-supported state. It is reported separately and is
    not silently offered as an ordinary dressed-configuration extension.
    """
    bath=np.asarray(bath);items=check_states(bath);p=np.asarray(psi);U=np.asarray(orbitals);coeff=np.asarray(coefficients)
    require(p.dtype.kind=='f' and p.ndim==2 and p.shape[0]==len(bath) and np.isfinite(p).all(),'real original bath-by-active ground required')
    require(abs(float(np.sum(p*p))-1)<1e-9,'ground not normalized; no normalization repair')
    M,N,_=U.shape;require(bath.shape[1]==M and np.max(bath)<N and coeff.shape==(M,2) and np.isfinite(coeff).all(),'source dimensions differ')
    modes=tuple(int(j) for j in source_modes);require(len(modes)==len(set(modes)) and all(0<=j<M for j in modes),'invalid source-mode set')
    require(C0>0 and L0>0 and math.isfinite(C0+L0),'positive finite pressure units required')
    memory=float(os.environ['PYSCF_MAX_MEMORY'] if memory_mb is None else memory_mb)
    require(isinstance(resident_bytes,(int,np.integer)) and resident_bytes>=0,'nonnegative integer resident-byte estimate required')
    possible=len(bath)*(1+len(modes)*(N+1));possible_transitions=len(bath)*len(modes)*(N+1)
    # Row tuples/index dictionaries and transition tuples are Python objects.
    # Output/candidate copies coexist with amplitudes; their storage is included.
    # Prior physical panels enter separately, with conservative alias double count.
    memory_plan=dict(runtime_and_misc_reserve=256*1024**2,resident_inputs=int(resident_bytes),
      amplitudes=8*2*possible*p.shape[1],python_rows=possible*(512+32*M),
      python_transitions=256*possible_transitions,row_arrays_and_copies=possible*(16*M+128),
      padded_field_work=8*8*M*(N+1)**2,underflow_chunk_work=4*1024**2,
      retained_amplitude_copy=8*2*len(bath)*p.shape[1] if return_retained_amplitudes else 0)
    estimate=sum(memory_plan.values())
    require(math.isfinite(memory) and memory>0 and estimate<.6*memory*10**6,'coherent source enumeration exceeds declared memory')
    X,Yi,orth=padded_local_fields(U)
    rows=[tuple(map(int,s)) for s in bath];index={s:i for i,s in enumerate(rows)};transitions=[]
    zero_local=0
    for b,state in enumerate(bath):
        for j in modes:
            for target in range(N+1):
                dx=float(coeff[j,0]*X[j,target,state[j]]);zy=float(coeff[j,1]*Yi[j,target,state[j]])
                if dx==0 and zy==0:
                    zero_local+=1;continue
                s=list(map(int,state));s[j]=target;s=tuple(s)
                if s not in index:index[s]=len(rows);rows.append(s)
                transitions.append((index[s],b,dx,zy))
    amplitudes=np.zeros((len(rows),p.shape[1],2))
    for row,b,dx,zy in transitions:
        amplitudes[row,:,0]+=dx*p[b];amplitudes[row,:,1]+=zy*p[b]
    gram=np.einsum('nla,nlb->nab',amplitudes,amplitudes,optimize=True)
    weights=gram[:,0,0]/L0+C0*gram[:,1,1]
    require(np.all(weights>=0) and np.isfinite(gram).all(),'nonfinite or negative positive source weights')
    # Never create a second full amplitude tensor just to count lost squares.
    chunk_rows=max(1,(1024**2)//max(1,p.shape[1]*2*8));square_underflow=0
    with np.errstate(under='ignore'):
        for begin in range(0,len(amplitudes),chunk_rows):
            block=amplitudes[begin:begin+chunk_rows]
            square_underflow+=int(np.count_nonzero((block!=0)&(block*block==0)))
    states=np.asarray(rows,dtype=bath.dtype);missing=np.arange(len(rows))>=len(bath);boundary=np.any(states>=N,axis=1);config=missing&~boundary
    total_missing=gram[missing].sum(axis=0);config_gram=gram[config].sum(axis=0);boundary_gram=gram[boundary].sum(axis=0)
    return dict(format=FORMAT,states=states,gram_by_row=gram,weight_by_row=weights,configuration_missing_mask=config,primitive_boundary_mask=boundary,
      missing_configuration_states=states[config],missing_configuration_grams=gram[config],missing_configuration_weights=weights[config],
      retained_bath_source_amplitudes=amplitudes[:len(bath)].copy() if return_retained_amplitudes else None,total_missing_gram=total_missing,configuration_missing_gram=config_gram,primitive_boundary_gram=boundary_gram,
      diagnostics=dict(original_bath_count=len(bath),enumerated_row_count=len(rows),missing_configuration_count=int(sum(config)),primitive_boundary_row_count=int(sum(boundary)),
        transition_count=len(transitions),exact_zero_local_entries_skipped=zero_local,positive_amplitude_square_underflow_count=square_underflow,
        orbital_orthogonality_error=orth,memory_mb=memory,estimated_bytes=estimate,memory_plan_bytes=memory_plan,underflow_chunk_rows=chunk_rows,retained_amplitudes_returned=bool(return_retained_amplitudes),primitive_size=N,source_modes=list(modes)),
      scope='coherent canonical one-source reach from the supplied fixed real state; no interacting-energy assignment or recomputed-ground completeness claim')


def common_nested_selection(bath,panels,fraction,max_bath_count):
    """Deterministic source-weight-ordered row/closure selection.

    Priority is the maximum normalized row weight over the supplied strengths,
    with fixed occupation tie breaks. Closures are constructed only as visited,
    avoiding a potentially huge cache. This is not a globally minimal basis.
    """
    bath=np.asarray(bath);base=check_states(bath);require(0<fraction<1 and max_bath_count>=len(base),'invalid selection controls')
    maps=[];totals=[];all_candidates=set()
    for panel in panels:
        ss=np.asarray(panel['missing_configuration_states']);ww=np.asarray(panel['missing_configuration_weights'])
        require(ss.ndim==2 and ss.shape[1]==bath.shape[1] and ww.shape==(len(ss),) and np.isfinite(ww).all() and np.all(ww>=0),'candidate panel malformed')
        mm={tuple(map(int,s)):float(w) for s,w in zip(ss,ww)};require(len(mm)==len(ss) and not (set(mm)&base),'candidate states duplicate or retained')
        maps.append(mm);totals.append(math.fsum(mm.values()));all_candidates.update(s for s,w in mm.items() if w>0)
    require(panels and all(t>0 for t in totals),'positive missing configuration weights required')
    priority=lambda state:(-max(mm.get(state,0.)/t for mm,t in zip(maps,totals)),sum(state),state)
    ordered=sorted(all_candidates,key=priority);selected=set(base);captures=[0.]*len(panels);history=[];budget_skipped=0
    for candidate in ordered:
        if all(c>=fraction*t for c,t in zip(captures,totals)):break
        if candidate in selected:continue
        new=set(downward_closure(candidate))-selected
        if len(selected)+len(new)>max_bath_count:budget_skipped+=1;continue
        selected.update(new);captures=[math.fsum(mm.get(s,0.) for s in selected-base) for mm in maps]
        history.append(dict(seed=list(candidate),added_rows=len(new),bath_count=len(selected),captured_fractions=[c/t for c,t in zip(captures,totals)]))
    added=sorted(selected-base,key=lambda s:(sum(s),s));states=np.concatenate([bath,np.asarray(added,dtype=bath.dtype).reshape(-1,bath.shape[1])])
    check_states(states)
    residuals=[math.fsum(w for s,w in mm.items() if s not in selected) for mm in maps]
    return dict(bath_states=states,fraction=float(fraction),max_bath_count=int(max_bath_count),history=history,added_states=np.asarray(added,dtype=bath.dtype).reshape(-1,bath.shape[1]),
      original_count=len(bath),new_count=len(states),added_even=sum(sum(s)%2==0 for s in added),added_odd=sum(sum(s)%2==1 for s in added),budget_skipped_candidates=budget_skipped,
      original_configuration_deficit=totals,residual_configuration_deficit=residuals,captured_fractions=[1-r/t for r,t in zip(residuals,totals)],
      status='TARGET_CAPTURED_FOR_SUPPLIED_OLD_STATES' if all(r<=(1-fraction)*t for r,t in zip(residuals,totals)) else 'BUDGET_LIMITED_TARGET_NOT_CAPTURED',
      scope='same ordered bath prefix, full downward closure, common occupation set across strengths; every new bath row must accompany EVERY active row in a subsequent solve')
