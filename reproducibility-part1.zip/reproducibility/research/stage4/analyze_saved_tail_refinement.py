"""Q14/Q16 finite-pressure tail sensitivity at fixed original-H0 pressure units.

Prepared for separate guarded execution after controls. No tensor solve, archive
mutation, omitted-state CDF certificate or common-interior scaling claim.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import json
import math
import os
import signal
import time
import zipfile
import numpy as np
import tail_refinement as tail
from full_cosine_hierarchy import parameters

FORMAT='stage4-saved-tail-refinement-v1'
SPEC_FORMAT='stage4-saved-tail-refinement-spec-v1'


def load_spec(path):
    spec=json.loads(path.read_text())
    tail.require(spec['format']==SPEC_FORMAT,'Wrong stage4 specification')
    expected=dict(R=10,M=20,calibration_modes=24,coupling_family='equal_reference_phase',
                  tau=51.2,hard=.5,soft=0.,low_count=5,bath_top=24,primitive=32,even_only=True)
    tail.require(spec['physical_parameters']==expected,'Unexpected physical study')
    tail.require(spec['tau']==51.2 and spec['ratio']==2. and spec['hbar']==1.,'Unexpected window/units')
    tail.require(sorted((j['Q'],j['beta']) for j in spec['jobs'])==[(14,1.),(14,3.),(16,1.),(16,3.)], 'Exactly four specified Q/beta cases required')
    for name,digest in spec['frozen_analysis_sources'].items():
        tail.require(tail.sha(tail.local(name))==digest,'Frozen dependency changed: '+name)
    config=spec['analysis']
    for key in ('thresholds_sigma0','noise_sigma0','edge_offsets_sigma0'):
        values=config[key]
        tail.require(values==sorted(set(values)) and all(math.isfinite(x) and x>0 for x in values),'Positive sorted unique '+key+' required')
    return spec


def validate_controls(path,spec_path,current_sources):
    controls=json.loads(path.read_text())
    tail.require(controls.get('status')=='PASS' and controls.get('test_suite')=='stage4-saved-tail-controls-v1','Required stage4 controls absent/failed')
    tail.require(controls['spec_sha256']==tail.sha(spec_path),'Controls used another specification')
    tail.require(controls['tested_entrypoint_sha256']==tail.sha(Path(__file__)),'Controls do not cover this entrypoint')
    tail.require(controls['checks'] and all(row['passed'] for row in controls['checks']),'Individual controls failed')
    current_runtime=tail.runtime_info()
    for key in ('python','numpy','scipy','platform','machine'):
        tail.require(controls.get('runtime',{}).get(key)==current_runtime[key],'Control/runtime mismatch: '+key)
    for name,digest in current_sources.items():
        tail.require(controls['source_sha256'].get(name)==digest,'Current source lacks accepted control binding: '+name)
    control_source=tail.local('research/stage4/check_saved_tail_refinement.py')
    tail.require(controls['source_sha256'].get(str(control_source.relative_to(tail.ROOT)))==tail.sha(control_source),'Control implementation changed')
    return dict(path=str(path.relative_to(tail.ROOT)),sha256=tail.sha(path),checks=len(controls['checks']),status='PASS')


def compare_probabilities(a,b):
    x,y=a['value'],b['value']
    return dict(Q14=a,Q16=b,signed_change_Q16_minus_Q14=(y-x) if x is not None and y is not None else None,
        relative_change=(y/x-1) if x is not None and y is not None and x>0 else None,
        log_ratio=(b['log_value']-a['log_value']) if a['log_value'] is not None and b['log_value'] is not None else None,
        scope='measured occupation/selection sensitivity, not a CDF truncation certificate')


def compare_rows(left,right):
    tail.require(left['beta']==right['beta'],'Comparison beta mismatch')
    result=dict(beta=left['beta'],left_label=left['label'],right_label=right['label'],observables=[])
    for a,b in zip(left['observables'],right['observables'],strict=True):
        tail.require(a['observable']==b['observable'] and a['sigma0']==b['sigma0'],'Comparison units/observable mismatch')
        rows=[]
        for x,y in zip(a['tail_panel'],b['tail_panel'],strict=True):
            tail.require(x['threshold_sigma0']==y['threshold_sigma0'],'Comparison threshold mismatch')
            record=dict(threshold_sigma0=x['threshold_sigma0'],hard=compare_probabilities(x['hard']['two_sided'],y['hard']['two_sided']),smooth=[])
            for u,v in zip(x['smooth'],y['smooth'],strict=True):
                tail.require(u['noise_sigma0']==v['noise_sigma0'],'Comparison noise mismatch')
                record['smooth'].append(dict(noise_sigma0=u['noise_sigma0'],**compare_probabilities(u['two_sided'],v['two_sided'])))
            rows.append(record)
        qs={}
        for key in ('signed_quantiles','absolute_quantiles'):
            qs[key]=[dict(level=x['level'],Q14_sigma0=x['value_sigma0'],Q16_sigma0=y['value_sigma0'],
                signed_change_sigma0=y['value_sigma0']-x['value_sigma0'],
                scope='discrete quantile sensitivity; changes can reflect jumps') for x,y in zip(a[key],b[key],strict=True)]
        result['observables'].append(dict(observable=a['observable'],sigma0=a['sigma0'],tails=rows,**qs))
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec',default='research/stage4/saved_tail_refinement_spec.json')
    parser.add_argument('--controls',default='research/stage4/results/tail_refinement_controls.json')
    parser.add_argument('--output',required=True)
    args=parser.parse_args();spec_path=tail.local(args.spec);controls_path=tail.local(args.controls)
    spec=load_spec(spec_path);memory=tail.memory_limit();sources=tail.source_hashes()
    controls=validate_controls(controls_path,spec_path,sources)
    started=time.monotonic()
    result=dict(format=FORMAT,status='RUNNING',spec=spec,spec_path=str(spec_path.relative_to(tail.ROOT)),
        spec_sha256=tail.sha(spec_path),source_sha256=sources,controls=controls,runtime=tail.runtime_info(),memory_mb=memory,cases=[],comparisons=[],
        scope='finite saved-matrix marginal spectral/readout effects; no nonlinear solver run',
        warnings=['Q drift is not an omitted-state CDF bound.',
                  'Original ground/source, primitive, bath and line-mode uncertainties remain separate.',
                  'A Gaussian readout convolution is not a causal detector or a sequential Kraus measurement.',
                  'This stage4 task does not complete the growing common-interior scale study.'])
    destination=tail.claim_output(args.output,result)
    def save():
        result['elapsed_seconds']=time.monotonic()-started;tail.save_output(destination,result)
    def interrupted(signum,frame):
        raise RuntimeError('Guard interrupted saved-tail analysis')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        modes,_,_=parameters(10,20)
        references={}
        with localcontext() as context:
            context.prec=80;context.Emin=-999999999;context.Emax=999999999
            for observable,inc in [('ordinary',False),('increment',True)]:
                m,ref=tail.controlled.harmonic(modes,51.2,inc,2.)
                sigma=float(m[2].sqrt())
                A,B=modes.matrices();z=-.5*(51.2*(modes.omega[:,None]+modes.omega[None,:]))**2
                f=np.exp(z)
                if inc:f *= -np.expm1(3*z)
                direct=float(np.sum((B*f)**2)/2)
                tail.require(abs(direct/float(m[2])-1)<2e-12,'Common sigma0 pair-creation variance check failed')
                references[observable]=dict(sigma0=sigma,variance=tail.controlled.value(m[2]),moments=ref,
                    independent_pair_creation_variance=direct,
                    scope='original distributed harmonic H0 at all 20 declared modes; only unit/moment reference, not an all-mode harmonic CDF')
            result['reference_units']=references;save()
            common_arrays=None
            for job in spec['jobs']:
                parent_path=tail.local(job['input']);archive=tail.local(job['archive'])
                tail.require(tail.sha(parent_path)==job['input_sha256'] and tail.sha(archive)==job['archive_sha256'],'Pinned physical input/archive changed')
                parent=json.loads(parent_path.read_text());case=parent['cases'][job['case_index']]
                tail.require(parent['status']==case['status']=='COMPLETED','Incomplete physical parent')
                for key,value in spec['physical_parameters'].items():
                    tail.require(case.get(key,0. if key=='soft' else None)==value,'Physical parameter mismatch: '+key)
                tail.require(case['Q']==job['Q'],'Unexpected occupation regulator')
                matches=[v for v in case['cosine'] if v['beta']==job['beta']]
                tail.require(len(matches)==1,'Missing/ambiguous beta record');record=matches[0]
                tail.require(record['effective_archive']==job['archive'],'Record/archive identity mismatch')
                if 'effective_archive_sha256' in record:
                    tail.require(record['effective_archive_sha256']==job['archive_sha256'],'Physical record/archive hash mismatch')
                diagnostics=record['diagnostics']
                tail.require(diagnostics['even_ground_certified_against_odd'] is True,'Physical ground not certified')
                with zipfile.ZipFile(archive) as zipped:
                    tail.require(sum(v.file_size for v in zipped.infolist())<.3*memory*1024**2,'Archive exceeds memory allowance')
                with np.load(archive,allow_pickle=False) as arrays:
                    H=np.array(arrays['H']);P=np.array(arrays['P'])
                    omega=np.array(arrays['omega']);couplings=np.array(arrays['couplings']);reference=np.array(arrays['reference'])
                    sector=str(arrays['retained_sector'])
                tail.require(H.shape==P.shape and H.ndim==2 and H.shape[0]==H.shape[1] and len(H)>1,'Invalid H/P dimensions')
                estimate=tail.admit_dimension(len(H),memory)
                tail.require('even' in sector.lower(),'Unexpected saved parity sector')
                for saved,declared in [(omega,case['omega']),(couplings,case['couplings']),(reference,case['reference_variances'])]:
                    tail.require(np.array_equal(saved,np.asarray(declared)),'Archive differs from physical parameter record')
                tail.require(np.allclose(omega,modes.omega,rtol=2e-12,atol=2e-14),'Declared original-H0 frequencies differ')
                triple=(omega,couplings,reference)
                if common_arrays is None:common_arrays=tuple(x.copy() for x in triple)
                else:tail.require(all(np.array_equal(a,b) for a,b in zip(common_arrays,triple)),'Physical calibration/units differ across jobs')
                E,Pc,mean,eigen=tail.controlled.eigen_prepare(H,P)
                row=dict(label=job['label'],beta=job['beta'],Q=job['Q'],input=job['input'],input_sha256=job['input_sha256'],
                    archive=job['archive'],archive_sha256=job['archive_sha256'],dimension=len(H),retained_sector=sector,
                    historical_physical_source_sha256=parent.get('source_sha256',{}),
                    original_case={k:v for k,v in case.items() if k not in ('cosine','harmonic')},
                    original_diagnostics=diagnostics,eigensolve=eigen,removed_actual_ground_mean=mean,
                    pressure_centering='Pc=P-<g|P|g>I with spectral Pc00 set to exactly zero',
                    estimated_workspace_bytes=estimate,observables=[])
                for observable,inc in [('ordinary',False),('increment',True)]:
                    law=tail.law_from_prepared(Pc,E,51.2,inc,2.,references[observable]['sigma0'],memory,spec['analysis'])
                    if inc:
                        old=[w for w in record['windows'] if abs(w['tau']-51.2)<1e-10]
                        tail.require(len(old)==1,'Original increment window missing')
                        errors={str(n):abs(law['recurrence']['even_moments'][str(n)]['value']/old[0]['moments'][str(n)]-1) for n in (2,4,6,8)}
                        tail.require(max(errors.values())<=2e-8,'Original increment moments not replayed')
                        law['original_increment_moment_relative_errors']=errors
                    row['observables'].append(law)
                result['cases'].append(row);save()
                del H,P,Pc,E
            for beta in (1.,3.):
                left=next(c for c in result['cases'] if c['beta']==beta and c['Q']==14)
                right=next(c for c in result['cases'] if c['beta']==beta and c['Q']==16)
                result['comparisons'].append(compare_rows(left,right))
        tail.require(tail.source_hashes()==sources,'Analysis source changed during execution')
        tail.require(tail.sha(spec_path)==result['spec_sha256'] and tail.sha(controls_path)==controls['sha256'],'Spec/control input changed')
        for job in spec['jobs']:
            tail.require(tail.sha(tail.local(job['input']))==job['input_sha256'] and tail.sha(tail.local(job['archive']))==job['archive_sha256'],'Physical inputs changed during analysis')
        result.update(status='COMPLETED_WITH_WARNINGS',completion_scope='All declared finite spectral/readout arithmetic checks passed; physical omissions and common-interior scaling remain unresolved')
        save();print('COMPLETED_WITH_WARNINGS saved tail refinement',flush=True)
    except BaseException as error:
        result.update(status='FAILED',failure=dict(type=type(error).__name__,message=str(error)));save();raise


if __name__=='__main__':main()
