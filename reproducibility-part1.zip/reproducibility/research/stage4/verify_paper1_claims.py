#!/usr/bin/env python3
"""Verify the frozen Paper-I claim/evidence bindings without rerunning physics.

This verifier is intentionally narrower than a reproduction run.  It checks
the TeX dependency graph, references and labels, binds every generated result
fragment to its provenance record, verifies the provenance-selected input
hashes, and independently reconstructs the headline numerical comparisons
from the saved result records.  It does not promote finite-model calculations
to continuum or intermittency claims.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def close(actual: float, expected: float, *, rtol: float = 5e-10,
          atol: float = 5e-14) -> None:
    require(math.isclose(actual, expected, rel_tol=rtol, abs_tol=atol),
            f"numeric mismatch: {actual!r} != {expected!r}")


def tex_closure(entry: Path) -> list[Path]:
    seen: list[Path] = []

    def visit(path: Path) -> None:
        path = path.resolve()
        require(path.is_relative_to(ROOT), f"TeX input escapes project: {path}")
        require(path.exists(), f"missing TeX input: {path}")
        if path in seen:
            return
        seen.append(path)
        text = path.read_text(encoding="utf-8")
        for match in re.finditer(r"\\input\{([^}]+)\}", text):
            child = path.parent / match.group(1)
            if child.suffix != ".tex":
                child = child.with_suffix(".tex")
            visit(child)

    visit(entry)
    return seen


def path_hash_pairs(value: object) -> list[tuple[str, str]]:
    """Find explicit path/hash bindings in heterogeneous provenance JSON."""
    pairs: list[tuple[str, str]] = []
    if isinstance(value, dict):
        path = value.get("path")
        digest = value.get("sha256")
        if isinstance(path, str) and isinstance(digest, str):
            pairs.append((path, digest))
        for key, item in value.items():
            if (isinstance(key, str) and isinstance(item, str)
                    and "/" in key and re.fullmatch(r"[0-9a-f]{64}", item)):
                pairs.append((key, item))
            pairs.extend(path_hash_pairs(item))
    elif isinstance(value, list):
        for item in value:
            pairs.extend(path_hash_pairs(item))
    return pairs


def archived_source_index() -> dict[str, list[str]]:
    """Index immutable/source-history locations by content hash.

    Current implementations may legitimately be newer than the code recorded
    by an executed result.  Such a mismatch is acceptable only when the exact
    historical bytes are still present at an explicit snapshot/executed-source
    location.  This prevents a current file from being silently relabeled as
    the historical calculation source.
    """
    roots = [
        ROOT / "research/stage2/snapshots",
        ROOT / "research/stage3/source_snapshots",
        ROOT / "research/stage4/snapshots",
        ROOT / "research/stage4/candidate_snapshots",
        ROOT / "results/autonomous_2026-09-14/executed_source",
        ROOT / "results/continuation_2026-09-14/executed_source",
    ]
    index: dict[str, list[str]] = {}
    for base in roots:
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if path.is_file() and path.suffix in {".py", ".md", ".json"}:
                index.setdefault(sha256(path), []).append(str(path.relative_to(ROOT)))
    return index


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default="paper/paper1_main.tex")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    source = (ROOT / args.source).resolve()
    output = (ROOT / args.output).resolve()
    require(source.is_relative_to(ROOT) and output.is_relative_to(ROOT),
            "source/output must remain inside the project")
    require(not output.exists(), f"refusing to replace {output}")
    started = time.monotonic()
    source_archive = archived_source_index()

    tex_files = tex_closure(source)
    texts = {str(path.relative_to(ROOT)): path.read_text(encoding="utf-8")
             for path in tex_files}
    joined = "\n".join(texts.values())

    # Submission hygiene and the Paper-I scope freeze.
    for marker in ("TODO", "PLACEHOLDER", "??"):
        require(marker not in joined, f"unresolved marker {marker!r}")
    excluded = {
        "paper/stage4_remainder_results.tex",
        "paper/stage4_heldout_results.tex",
        "paper/stage4_heldout_occupation_results.tex",
        "paper/stage4_topology_mode_results.tex",
        "paper/stage4_topology_occupation_results.tex",
        "paper/stage4_topology_potential.tex",
    }
    included = set(texts)
    require(not (included & excluded),
            f"Paper-II/unfinished fragments included: {sorted(included & excluded)}")
    require("persistent Casimir-pressure intermittency" in joined,
            "abstract/conclusion intermittency limitation is missing")
    require("undisturbed" in joined and "vacuum bursts" in joined,
            "operational/natural-vacuum distinction is missing")

    # Cross-references and bibliography keys over the actual input graph.
    labels = re.findall(r"\\label\{([^}]+)\}", joined)
    refs = re.findall(r"\\(?:eqref|ref)\{([^}]+)\}", joined)
    require(len(labels) == len(set(labels)), "duplicate TeX labels")
    missing_refs = sorted(set(refs) - set(labels))
    require(not missing_refs, f"undefined TeX labels: {missing_refs}")
    citations: set[str] = set()
    for body in re.findall(r"\\cite\{([^}]+)\}", joined):
        citations.update(key.strip() for key in body.split(","))
    bib = (ROOT / "paper/references.bib").read_text(encoding="utf-8")
    bib_keys = set(re.findall(r"@\w+\{([^,]+),", bib))
    require(citations <= bib_keys,
            f"missing bibliography keys: {sorted(citations - bib_keys)}")
    require(all("title" in block.lower() for block in re.split(r"(?=@\w+\{)", bib)
                if block.lstrip().startswith("@")), "bibliography entry without title")

    # Bind each generated fragment used by Paper I to its provenance record.
    provenance_names = [
        "stage2_closure_provenance.json",
        "stage2_geometry_provenance.json",
        "stage2_moment_spectrum_provenance.json",
        "stage2_second_order_provenance.json",
        "stage2_window_ratio_provenance.json",
        "stage3_common_depth_provenance.json",
        "stage3_common_width_provenance.json",
        "stage3_depth_provenance.json",
        "stage3_finite_gap_provenance.json",
        "stage3_results_provenance.json",
        "stage4_cosine_arithmetic_provenance.json",
        "stage4_excited_pressure_method_provenance.json",
        "stage4_excited_pressure_results_provenance.json",
        "stage4_geometry_validation_provenance.json",
        "stage4_source_completion_provenance.json",
        "stage4_source_frequency_extension_provenance.json",
        "stage4_source_frequency_refinement_provenance.json",
        "stage4_tail_fixed_energy_provenance.json",
        "stage4_tail_provenance.json",
    ]
    provenance_checks: list[dict[str, object]] = []
    for name in provenance_names:
        path = ROOT / "paper" / name
        require(path.exists(), f"missing provenance record: {path}")
        data = json.loads(path.read_text(encoding="utf-8"))
        status = str(data.get("status", data.get("analysis_status", "")))
        require("FAILED" not in status and "RUNNING" not in status,
                f"inadmissible provenance status for {name}: {status}")
        checked: list[str] = []
        archived_source_bindings: list[dict[str, object]] = []
        for rel, digest in sorted(set(path_hash_pairs(data))):
            candidate = ROOT / rel
            # Some historical records bind no-longer-present runtime logs or
            # snapshots.  Only present files are asserted here; missing items
            # remain visible in the provenance and package inventory.
            if candidate.exists() and candidate.is_file():
                actual = sha256(candidate)
                if actual == digest:
                    checked.append(rel)
                else:
                    snapshots = source_archive.get(digest, [])
                    require(candidate.suffix in {".py", ".md"} and snapshots,
                            f"provenance hash mismatch without archived bytes: "
                            f"{name}: {rel}")
                    archived_source_bindings.append({
                        "declared_path": rel,
                        "recorded_sha256": digest,
                        "current_sha256": actual,
                        "matching_archived_files": snapshots,
                    })
        provenance_checks.append({
            "path": str(path.relative_to(ROOT)),
            "sha256": sha256(path),
            "status": status,
            "present_hash_bindings_verified": checked,
            "historical_source_bindings_verified": archived_source_bindings,
        })

    fragment_receipt_path = ROOT / "paper/PAPER_I_FRAGMENT_PROVENANCE_FINAL_2026-09-16.json"
    require(fragment_receipt_path.exists(), "missing Paper-I fragment extraction receipt")
    fragment_receipt = json.loads(fragment_receipt_path.read_text(encoding="utf-8"))
    require(fragment_receipt.get("status") == "PASS",
            "Paper-I fragment extraction receipt is not PASS")
    for row in fragment_receipt.get("fragments", []):
        for key, hash_key in (("source", "source_sha256"),
                              ("output", "output_sha256")):
            path = ROOT / row[key]
            require(path.exists() and sha256(path) == row[hash_key],
                    f"Paper-I fragment binding mismatch: {row[key]}")

    # Exact reverse coverage: every live TeX dependency is either a
    # provenance-bound numerical fragment or an explicitly non-numerical
    # derivation/method fragment.  This closes the converse direction that a
    # forward provenance inventory alone cannot establish.
    evidence_binding_path = (
        ROOT / "paper/PAPER_I_EVIDENCE_BINDINGS_FINAL_2026-09-16.json"
    )
    require(evidence_binding_path.exists(),
            "missing Paper-I evidence-fragment binding receipt")
    evidence_binding = json.loads(
        evidence_binding_path.read_text(encoding="utf-8")
    )
    require(evidence_binding.get("status") == "PASS",
            "Paper-I evidence-fragment binding receipt is not PASS")
    require(evidence_binding.get("reverse_coverage_complete") is True,
            "Paper-I evidence-fragment reverse coverage is incomplete")
    require(evidence_binding.get("source") == str(source.relative_to(ROOT)),
            "evidence binding source path differs from the verified source")
    require(evidence_binding.get("source_sha256") == sha256(source),
            "evidence binding source hash differs from the verified source")
    require(evidence_binding.get("tex_dependency_count") == len(tex_files),
            "evidence binding TeX dependency count differs from the live graph")

    live_fragment_set = {
        str(path.relative_to(ROOT)) for path in tex_files if path != source
    }
    evidence_rows = evidence_binding.get("evidence_fragments", [])
    require(isinstance(evidence_rows, list),
            "evidence binding fragment rows are malformed")
    evidence_fragment_set = {
        row.get("fragment") for row in evidence_rows if isinstance(row, dict)
    }
    require(None not in evidence_fragment_set,
            "evidence binding contains a fragment row without a path")
    analytic_fragment_set = set(
        evidence_binding.get("analytic_or_method_fragments", [])
    )
    require(not (evidence_fragment_set & analytic_fragment_set),
            "evidence and analytic/method fragment classes overlap")
    require(evidence_fragment_set | analytic_fragment_set == live_fragment_set,
            "evidence binding does not exactly partition the live TeX graph: "
            f"missing={sorted(live_fragment_set - evidence_fragment_set - analytic_fragment_set)}, "
            f"extra={sorted((evidence_fragment_set | analytic_fragment_set) - live_fragment_set)}")
    require(evidence_binding.get("evidence_fragment_count")
            == len(evidence_fragment_set) == len(evidence_rows),
            "evidence fragment count is inconsistent")
    require(evidence_binding.get("analytic_or_method_fragment_count")
            == len(analytic_fragment_set),
            "analytic/method fragment count is inconsistent")

    for fragment in sorted(analytic_fragment_set):
        path = ROOT / fragment
        require(path.is_file(), f"missing analytic/method fragment: {fragment}")

    for row in evidence_rows:
        fragment = row["fragment"]
        fragment_path = ROOT / fragment
        require(fragment_path.is_file(),
                f"missing evidence-bound fragment: {fragment}")
        require(sha256(fragment_path) == row.get("fragment_sha256"),
                f"evidence-bound fragment hash mismatch: {fragment}")
        provenance_rows = row.get("provenance", [])
        require(isinstance(provenance_rows, list) and provenance_rows,
                f"evidence-bound fragment has no provenance: {fragment}")
        for provenance_row in provenance_rows:
            provenance_path = ROOT / provenance_row["path"]
            require(provenance_path.is_file(),
                    f"missing fragment provenance: {provenance_row['path']}")
            require(sha256(provenance_path) == provenance_row.get("sha256"),
                    f"fragment provenance hash mismatch: {provenance_row['path']}")
            provenance_data = json.loads(
                provenance_path.read_text(encoding="utf-8")
            )
            provenance_status = str(
                provenance_data.get(
                    "status", provenance_data.get("analysis_status", "")
                )
            )
            require("FAILED" not in provenance_status
                    and "RUNNING" not in provenance_status,
                    f"inadmissible fragment provenance status: "
                    f"{provenance_row['path']}: {provenance_status}")
            require(provenance_status == provenance_row.get("status"),
                    f"fragment provenance status changed: "
                    f"{provenance_row['path']}")

        adaptation = row.get("adaptation")
        if adaptation is not None:
            adaptation_receipt_path = ROOT / adaptation["receipt"]
            require(adaptation_receipt_path.is_file(),
                    f"missing adaptation receipt for {fragment}")
            require(sha256(adaptation_receipt_path)
                    == adaptation.get("receipt_sha256"),
                    f"adaptation receipt hash mismatch for {fragment}")
            adaptation_source_path = ROOT / adaptation["source"]
            require(adaptation_source_path.is_file(),
                    f"missing adaptation source for {fragment}")
            require(sha256(adaptation_source_path)
                    == adaptation.get("source_sha256"),
                    f"adaptation source hash mismatch for {fragment}")
            matching_rows = [
                candidate for candidate in fragment_receipt.get("fragments", [])
                if candidate.get("output") == fragment
            ]
            require(len(matching_rows) == 1,
                    f"adapted fragment is not uniquely bound in the "
                    f"fragment receipt: {fragment}")
            require(matching_rows[0].get("output_sha256")
                    == row.get("fragment_sha256"),
                    f"adapted fragment output hash mismatch: {fragment}")
            require(matching_rows[0].get("source")
                    == adaptation.get("source")
                    and matching_rows[0].get("source_sha256")
                    == adaptation.get("source_sha256"),
                    f"adapted fragment source binding changed: {fragment}")

    evidence_binding_summary = {
        "path": str(evidence_binding_path.relative_to(ROOT)),
        "sha256": sha256(evidence_binding_path),
        "source_sha256": evidence_binding["source_sha256"],
        "tex_dependency_count": evidence_binding["tex_dependency_count"],
        "evidence_fragment_count": len(evidence_fragment_set),
        "analytic_or_method_fragment_count": len(analytic_fragment_set),
        "reverse_coverage_complete": True,
    }

    # Headline closure result from the frozen manuscript table.
    source_text = source.read_text(encoding="utf-8")
    require("3.75606\\times10^{-7}" in source_text,
            "closure separation value missing")
    require("3.86629\\times10^{-9}" in source_text,
            "closure tail bound missing")
    separation = 3.75606e-7
    tail_bound = 3.86629e-9
    require(separation > 90 * tail_bound,
            "headline closure separation no longer dominates its tail bound")

    # Complete second cosine order: independent oscillator control.
    second = json.loads((ROOT / "results/stage2_2026-09-15/"
                         "cosine_occupation14_16_checks.json").read_text())
    osc = second["oscillator_control"]
    require(osc["status"] == "PASS", "second-order oscillator control failed")
    close(osc["repeated_quartic"], 47 / 3072, rtol=5e-8)
    close(osc["sextic_and_contractions"], -3 / 128)
    close(osc["total"], -25 / 3072, rtol=5e-8)

    # Fourteen-resonance scale test and the finite-window negative outcome.
    spectrum = json.loads((ROOT / "paper/stage2_moment_spectrum_provenance.json").read_text())
    require(spectrum["scope"].startswith("finite-window"),
            "moment-spectrum scope changed")
    row8 = next(row for row in spectrum["rows"] if row["order"] == 8)
    close(row8["shape_window_slope"], -5.414837416787752e-6)
    require(abs(row8["adjacent_shape_slopes"][-1])
            < abs(row8["adjacent_shape_slopes"][0]) / 7,
            "eighth-order adjacent shape slope does not decay across the window")
    hierarchy = json.loads((ROOT / "results/stage2_2026-09-15/"
                            "infrared_r14_modes24_fixed.json").read_text())
    poles = hierarchy["cases"][0]["bare_poles"]
    close(max(poles) / min(poles), 8192.0, rtol=0, atol=1e-9)

    # Rare-tail claim is reconstructed from the audited saved-law record.
    tail = json.loads((ROOT / "paper/stage4_tail_provenance.json").read_text())
    require(tail["status"] == "GENERATED_FROM_AUDITED_COMPLETED_RESULTS",
            "tail evidence is not in the admitted status")
    moment_change = tail["even_moment_Q14_toQ16_fractional_changes"]["1.0_increment"]["8"]
    hard = next(row for row in tail["table_rows"]
                if row["beta"] == 1.0 and row["observable"] == "increment"
                and row["readout_sigma0"] == 0.0 and row["threshold_sigma0"] == 8.0)
    close(moment_change, -5.2058915732677846e-5)
    close(hard["relative_change"], 0.2359456323689264)
    require(abs(hard["relative_change"]) > 4000 * abs(moment_change),
            "tail/moment sensitivity separation is no longer resolved")

    # The response-matched Gaussian source comparison must remain explicitly open.
    source_extension = json.loads((ROOT / "paper/"
                                   "stage4_source_frequency_extension_provenance.json").read_text())
    require(source_extension["necessary_two_edge_gate_accepted"] is False,
            "source comparator was silently promoted to converged")
    require(source_extension["panel_pass_pattern"] == [[False, False, False],
                                                         [True, False, False]],
            "source-extension pass pattern changed")

    receipt = {
        "format": "casimir-paper-I-claim-verification-v1",
        "status": "PASS",
        "source": str(source.relative_to(ROOT)),
        "source_sha256": sha256(source),
        "tex_dependency_count": len(tex_files),
        "tex_dependencies": {str(path.relative_to(ROOT)): sha256(path)
                             for path in tex_files},
        "labels": len(labels),
        "references": len(refs),
        "citations": sorted(citations),
        "bibliography_sha256": sha256(ROOT / "paper/references.bib"),
        "provenance": provenance_checks,
        "evidence_bindings": evidence_binding_summary,
        "headline_checks": {
            "closure_separation": separation,
            "closure_tail_bound": tail_bound,
            "second_order_oscillator": {
                "repeated_quartic": osc["repeated_quartic"],
                "next_potential": osc["sextic_and_contractions"],
                "total": osc["total"],
            },
            "R14_frequency_span": max(poles) / min(poles),
            "R14_order8_shape_window_slope": row8["shape_window_slope"],
            "Q14_Q16_increment_M8_fractional_change": moment_change,
            "Q14_Q16_increment_h8_tail_fractional_change": hard["relative_change"],
            "response_matched_source_two_edge_gate": False,
        },
        "scope": (
            "Evidence and manuscript binding for Paper I. This receipt does not "
            "establish a common-interior nonlinear hierarchy, a converged tail "
            "law, persistent intermittency, or natural vacuum bursts."
        ),
        "elapsed_seconds": time.monotonic() - started,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_suffix(output.suffix + ".tmp")
    tmp.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    tmp.replace(output)
    print(json.dumps({"status": "PASS", "output": str(output.relative_to(ROOT)),
                      "dependencies": len(tex_files), "citations": len(citations)}))


if __name__ == "__main__":
    main()
