"""An exact gapless quantum positive control; this is not a Casimir pressure model.

The continuum Hamiltonian/source are defined in the bound analytic note. At each
width the vacuum orbit of the smeared source has an exact 3x3 representation.
Changing width changes that orbit: no fixed three-level Hamiltonian is assumed.
"""
from pathlib import Path
from datetime import datetime
import argparse, hashlib, json, math, os, platform, signal, sys, time
import numpy as np
import scipy
from scipy.integrate import quad
from scipy.linalg import eigh
from scipy.special import gammainc, gamma
ROOT=Path(__file__).resolve().parents[2]
NOTE='research/stage4/DILATION_COVARIANCE_AND_MOMENT_SCALING_2026-09-15.md'
NOTE_SHA='6653eaa706e427cd69da2393d9356b915e8332118da9db1d4c576f0df8cb80d2'
ORDERS=(2,4,6,8)

def require(ok,msg):
    if not ok:raise ValueError(msg)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def channel(alpha,tau,increment=False,rho=2.):
    require(alpha>0 and tau>0 and rho>1,'positive alpha/tau, rho>1 required')
    def ordinary(t):return gamma(1+alpha/2)*t**(-alpha)*gammainc(alpha/2,t*t)
    if not increment:return float(ordinary(tau))
    v=ordinary(tau)-2*ordinary(tau*math.sqrt((1+rho*rho)/2))+ordinary(rho*tau)
    require(v>0,'increment channel norm lost positivity')
    return float(v)

def independent_channel(alpha,tau,increment=False,rho=2.):
    top=min(tau,16.)
    def f(u):
        filt=math.exp(-u*u/2)
        if increment:filt*=-math.expm1(-(rho*rho-1)*u*u/2)
        return u**(alpha-1)*filt*filt
    v,err=quad(f,0,top,epsabs=2e-13,epsrel=2e-13,limit=200)
    # The omitted u>16 Gaussian tail is below 1e-107 for the declared alphas.
    return alpha*tau**(-alpha)*v,alpha*tau**(-alpha)*err

def law(alpha1,alpha2,tau,d,increment=False,rho=2.,threshold=None):
    aa=channel(alpha1,tau,increment,rho);bb=channel(alpha2,tau,increment,rho)
    diagonal=0. if increment else d
    X=np.array([[0.,math.sqrt(aa),math.sqrt(bb)],[math.sqrt(aa),0.,0.],[math.sqrt(bb),0.,diagonal]])
    v=np.array([1.,0.,0.]);moments={}
    for n in range(1,9):
        v=X@v
        if n in ORDERS:moments[str(n)]=float(v[0])
    ev,V=eigh(X,driver='evd');w=V[0,:]**2
    spectral={str(n):float(np.dot(w,ev**n)) for n in ORDERS}
    errors={str(n):abs(spectral[str(n)]/moments[str(n)]-1) for n in ORDERS}
    require(max(errors.values())<2e-8,'spectral law does not reproduce vacuum moments')
    shapes={str(n):moments[str(n)]/moments['2']**(n/2) for n in ORDERS}
    require(abs(moments['2']/(aa+bb)-1)<2e-14,'M2 identity failed')
    require(abs(moments['4']/((aa+bb)**2+diagonal**2*bb)-1)<2e-14,'M4 path identity failed')
    if diagonal==0:require(max(abs(x-1) for x in shapes.values())<2e-13,'two-point-law endpoint failed')
    result=dict(tau=tau,d=d,observable='width_increment' if increment else 'ordinary_centered',channel_squared_norms=[aa,bb],moments=moments,standardized_moments=shapes,eigenvalues=ev.tolist(),vacuum_weights=w.tolist(),spectral_moment_relative_errors=errors)
    if threshold is not None:
        result['strict_positive_tail']=dict(threshold=threshold,probability=float(w[ev>threshold].sum()),scope='single-observable spectral event; not a sequential measurement record')
    return result

def controls():
    rows=[]
    errors=[]
    for alpha in (1.,2.5):
        for tau in (.5,1.,4.,32.,2.**32):
            for increment in (False,True):
                a=channel(alpha,tau,increment);b,err=independent_channel(alpha,tau,increment)
                delta=abs(a/b-1);require(delta<2e-11,'independent positive integral mismatch');errors.append(delta)
    rows.append(dict(name='independent_positive_continuum_integrals',passed=True,max_relative_difference=max(errors)))
    for tau in (.5,4.,128.,2.**32):
        a=law(1.,2.5,tau,0.);b=law(1.,2.5,tau,1.,True)
        require(max(abs(x-1) for r in (a,b) for x in r['standardized_moments'].values())<2e-13,'d=0/increment control failed')
    rows.append(dict(name='vanishing_excited_diagonal_and_increment_endpoints',passed=True))
    a=law(1.,2.5,2.**30,1.,threshold=.5);b=law(1.,2.5,2.**32,1.,threshold=.5)
    slopes={str(p):-math.log(b['moments'][str(p)]/a['moments'][str(p)])/math.log(4) for p in ORDERS}
    require(max(abs(slopes[str(p)]-min(p/2,2.5)) for p in ORDERS)<2e-4,'known quantum multiscaling positive control failed')
    ratio=b['strict_positive_tail']['probability']/b['channel_squared_norms'][1]
    require(abs(ratio-1)<2e-8,'rare spectral weight asymptotic failed')
    rows.append(dict(name='known_true_nonproportional_quantum_spectrum',passed=True,positive_decay_exponents=slopes,tail_over_b_squared=ratio))
    for alpha in (-1,0):
        try:channel(alpha,1.)
        except ValueError:pass
        else:raise AssertionError('invalid alpha admitted')
    rows.append(dict(name='invalid_channel_parameters_rejected',passed=True))
    return rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args()
    out=(ROOT/args.output).resolve();require(out.is_relative_to(ROOT/'research/stage4/results') and out.suffix=='.json','new stage4 result required')
    require(not out.exists(),'output already exists');require(sha(ROOT/NOTE)==NOTE_SHA,'analytic source note changed')
    memory=float(os.environ['PYSCF_MAX_MEMORY']);require(memory>=256,'at least256MB declared workspace required')
    begin=time.monotonic();source=sha(__file__)
    record=dict(status='RUNNING_NOT_A_RESULT',format='quantum-gapless-multiscaling-control-v1',created_at=datetime.now().astimezone().isoformat(timespec='seconds'),analytic_note=dict(path=NOTE,sha256=NOTE_SHA),source_sha256=source,runtime=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),PYSCF_MAX_MEMORY=memory),parameters=dict(alpha1=1.,alpha2=2.5,rho=2.,diagonal_strengths=[0.,.1,.3,1.],widths='2**k for k=0..32'),controls=[],families=[],scope='Exact continuum quantum mathematical positive control. The bounded source is not a derived local Casimir pressure; no evidence for the transmission-line model or natural bursts is supplied.')
    def save():
        record['elapsed_seconds']=time.monotonic()-begin;tmp=out.with_suffix('.writing');tmp.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');tmp.replace(out)
    with out.open('x') as f:json.dump(record,f)
    def interrupted(signum,frame):raise RuntimeError('resource guard interrupted quantum positive control')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        record['controls']=controls()
        for d in record['parameters']['diagonal_strengths']:
            for inc in (False,True):
                series=[law(1.,2.5,2.**k,d,inc,threshold=d/2 if d>0 and not inc else None) for k in range(33)]
                intervals=[]
                for left,right in zip(series,series[1:]):
                    slopes={str(p):-math.log(right['moments'][str(p)]/left['moments'][str(p)])/math.log(2) for p in ORDERS}
                    intervals.append(dict(widths=[left['tau'],right['tau']],positive_decay_exponents=slopes,manuscript_signed_slopes={p:-v for p,v in slopes.items()}))
                expected={str(p):(p/2 if inc or d==0 else min(p/2,2.5)) for p in ORDERS}
                record['families'].append(dict(d=d,increment=inc,series=series,intervals=intervals,analytic_asymptotic_exponents=expected,last_interval_max_exponent_error=max(abs(intervals[-1]['positive_decay_exponents'][p]-v) for p,v in expected.items())))
                save()
        require(len(record['controls'])==4 and all(c['passed'] for c in record['controls']) and len(record['families'])==8 and all(len(f['series'])==33 for f in record['families']),'incomplete control panel')
        require(sha(__file__)==source and sha(ROOT/NOTE)==NOTE_SHA,'source changed during execution')
        record['status']='COMPLETED_MATHEMATICAL_POSITIVE_CONTROL';save()
    except BaseException as exc:record.update(status='FAILED',error=repr(exc));save();raise
    print(record['status'],flush=True)

if __name__=='__main__':main()
