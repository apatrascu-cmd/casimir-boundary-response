"""Exact finite-factor projection in an old bath plus source-generated vectors.

New sibling: production primitives, fixed orbitals and complete contacts. No
ambient Hamiltonian, conditional active space or stable-primitive substitution.
"""
from __future__ import annotations
import math
import numpy as np
from scipy.linalg import eigh
import source_compressed_bath as rank_core
import source_directed_bath_model as frozen

require=rank_core.require
norm=rank_core.norm


def parity_gate(matrix,parities,change,hermitian=1,tolerance=2e-10):
    a=np.asarray(matrix);p=np.asarray(parities)
    require(a.shape==(len(p),len(p)) and np.all(np.isfinite(a)),'finite projected factor required')
    forbidden=(p[:,None]^p[None,:])!=change
    err=norm(a[forbidden]);sym=norm(a-hermitian*a.conj().T) if hermitian else 0.
    scale=max(1.,norm(a));require(max(err,sym)<tolerance*scale,'projected factor parity/adjoint unresolved')
    out=a.copy();out[forbidden]=0
    if hermitian:out=(out+hermitian*out.conj().T)/2
    return out,dict(forbidden_norm=err,adjoint_norm=sym,scale=scale)


def cross_factor_rules(branch_count):
    """Construction-known parity/adjoint contracts, valid even for zero factors.

    Each cosine branch contributes C_L C_B and four odd/odd sine-coordinate
    factors; all are real symmetric. Pressure contributes D_L D_B (symmetric)
    and (Z_L/i)(Z_B/i) (real antisymmetric on each factor).
    """
    require(isinstance(branch_count,int) and branch_count>0,'positive branch count required')
    return dict(hterms=[(0,1),(1,1),(1,1),(1,1),(1,1)]*branch_count,
                pterms=[(1,1),(1,-1)])


def reconstruction(generators,coefficients,old_count,parities):
    """Explicit sparse generator replay; polar correction within each parity.

    generators map old coordinate states into the exact padded row inventory.
    coefficients has shape (source families, old_count, added_count).
    """
    C=np.asarray(coefficients,float).copy();require(C.ndim==3 and C.shape[:2]==(len(generators),old_count),'source coefficients malformed')
    k=C.shape[-1];p=np.asarray(parities,int);require(p.shape==(k,) and np.isin(p,[0,1]).all(),'explicit new parity required')
    old_blocks=np.asarray([g[:old_count,:].toarray() for g in generators])
    T=-sum((b@c for b,c in zip(old_blocks,C)),np.zeros((old_count,k)))
    W=sum((g@c for g,c in zip(generators,C)),np.zeros((generators[0].shape[0],k)))
    W[:old_count]+=T
    old_error=norm(W[:old_count]);require(old_error<2e-10,'source complement failed old-space removal')
    W[:old_count]=0.
    metric=W.T@W;require(norm(metric-np.eye(k))<2e-8,'stored source vectors have unresolved metric')
    rotation=np.zeros((k,k))
    for parity in (0,1):
        ix=np.flatnonzero(p==parity)
        if len(ix):
            e,u=eigh(metric[np.ix_(ix,ix)],check_finite=False)
            require(e[0]>.999999 and e[-1]<1.000001,'source metric loses rank')
            rotation[np.ix_(ix,ix)]=(u/np.sqrt(e))@u.T
    C=C@rotation;T=T@rotation;W=W@rotation
    residual=norm(W.T@W-np.eye(k));require(residual<2e-11,'polar source metric unresolved')
    return dict(C=C,T=T,W=W,source_old_blocks=old_blocks,parities=p,
      metric_diagnostics=dict(old_projection_roundoff=old_error,raw_overlap=metric,polar_rotation=rotation,final_orthogonality=residual,
        scope='measured binary64 metric and generator replay; no interval enclosure'))


def local_fields(orbitals,coefficients,source_modes):
    X,Yi,_=rank_core.frozen.padded_local_fields(orbitals)
    mask=np.zeros(len(X));mask[list(source_modes)]=1.
    c=np.asarray(coefficients);return np.asarray([c[:,0,None,None]*mask[:,None,None]*X,c[:,1,None,None]*mask[:,None,None]*Yi])


def extended_local(modes,u,beta,reference,orbitals):
    """The extra ordinal label is bare |N>, with old dressed orbitals unchanged."""
    N=orbitals.shape[1];M=len(orbitals);Us=np.tile(np.eye(N+1),(M,1,1));Us[:,:N,:N]=orbitals
    small=frozen.local_from_orbitals(modes,u,beta,reference,orbitals)
    large=frozen.local_from_orbitals(modes,u,beta,reference,Us)
    reports={}
    for key in ('local_hamiltonians','X','Y','X2','Y2'):
        err=norm(large[key][:,:N,:N]-small[key]);reports[key]=err
        require(err<2e-10*max(1.,norm(small[key])),'primitive padding changed old local factor: '+key)
        large[key][:,:N,:N]=small[key]
    for r in range(len(u)):
        for j in range(M):
            error=norm(large['D'][r][j][:N,:N]-small['D'][r][j]);reports['D_%s_%s'%(r,j)]=error
            require(error<2e-10,'primitive padding changed old complete displacement')
            large['D'][r][j][:N,:N]=small['D'][r][j]
    return small,large,dict(old_primitive=N,new_primitive=N+1,old_local_replay=reports,
      common_blocks_copied_only_after_replay=True,scope='same analytic complete projection; binary64 old block retained verbatim after independent padding replay')


def mpo(kind,locals_,identity=None):
    """Small finite-state target automata; no expansion in cosine strength."""
    N=locals_[0].shape[0];I=np.eye(N,dtype=complex) if identity is None else identity
    if kind=='product':return [[(0,0,K)] for K in locals_],1,0
    if kind in ('sum','pair'):
        degree=1 if kind=='sum' else 2
        return [[*[(d,d,I) for d in range(degree+1)],*[(d+1,d,K) for d in range(degree)]] for K in locals_],degree+1,degree
    require(kind in ('cos_ge1','cos_ge2'),'unknown target automaton')
    degree=1 if kind=='cos_ge1' else 2;targets=[]
    for D in locals_:
        dc=float(D[0,0].real);ref=(1+dc)*I;delta=D-dc*I
        trans=[(d,d,ref) for d in range(degree)]+[(d+1,d,delta) for d in range(degree)]+[(degree,degree,ref+delta)]
        targets.append(trans)
    return targets,degree+1,degree


def ordered_pair_mpo(left,right,contact):
    """Complete product (sum left)(sum right), including same-mode contact."""
    I=np.eye(left[0].shape[0],dtype=complex);targets=[]
    for L,R,C in zip(left,right,contact):
        targets.append([(d,d,I) for d in range(4)]+[(1,0,L),(2,0,R),(3,1,R),(3,2,L),(3,0,C)])
    return targets,4,3


def contract(states,automaton,sources):
    """All K, O_s†K, KO_t, O_s†KO_t old-coordinate blocks in one sweep.

    The last two axes are only old bath pairs. Sources on the same mode are
    multiplied around the COMPLETE projected K, after source padding.
    """
    states=np.asarray(states);sources=np.asarray(sources);targets,dstates,last=automaton
    m,n=states.shape[1],len(states);fcount=len(sources)
    require(sources.ndim==4 and sources.shape[1]==m and len(targets)==m,'factor/source mode inventory differs')
    require(np.all(states>=0) and np.max(states)<sources.shape[2],'source factor ordinal labels invalid')
    f=np.zeros((fcount+1,fcount+1,dstates,n,n),complex);f[0,0,0]=1.
    for j,transitions in enumerate(targets):
        nxt=np.zeros_like(f);occ=states[:,j];ix=np.ix_(occ,occ);L=sources[:,j].conj().transpose(0,2,1);R=sources[:,j]
        for dest,origin,K in transitions:
            a=K[ix];lk=L@K;kr=K@R;both=lk[:,None]@R[None,:]
            b=lk[:,occ[:,None],occ[None,:]];c=kr[:,occ[:,None],occ[None,:]];d=both[:,:,occ[:,None],occ[None,:]]
            old=f[:,:,origin]
            nxt[:,:,dest]+=old*a
            nxt[1:,:,dest]+=old[0,:][None,:,:,:]*b[:,None,:,:]
            nxt[:,1:,dest]+=old[:,0][:,None,:,:]*c[None,:,:,:]
            nxt[1:,1:,dest]+=old[0,0][None,None,:,:]*d
        f=nxt
    return f[:,:,last]


def compress_contractions(blocks,representation):
    """Old E plus W=sum O_s E C_s + E T, with E†W=0 by construction."""
    C,T=representation['C'],representation['T'];nb=T.shape[0];k=T.shape[1]
    K=blocks[0,0];right=K@T;left=T.conj().T@K
    for i in range(len(C)):
        right+=blocks[0,i+1]@C[i];left+=C[i].conj().T@blocks[i+1,0]
    corner=T.conj().T@K@T
    for i in range(len(C)):
        corner+=C[i].conj().T@blocks[i+1,0]@T+T.conj().T@blocks[0,i+1]@C[i]
        for j in range(len(C)):corner+=C[i].conj().T@blocks[i+1,j+1]@C[j]
    out=np.empty((nb+k,nb+k),complex);out[:nb,:nb]=K;out[:nb,nb:]=right;out[nb:,:nb]=left;out[nb:,nb:]=corner
    return out


class Projector:
    """Small old-coordinate contractions; optional immutable per-factor cache."""
    def __init__(self,states,sources,representation,cache=None):
        self.states=states;self.sources=sources;self.rep=representation;self.cache=cache;self.timings={}
    def target(self,key,automaton):
        import time
        if self.cache is not None:
            value=self.cache.load_array(key)
            if value is not None:self.timings[key]=dict(reused=True,seconds=0.);return value
        begin=time.monotonic();value=compress_contractions(contract(self.states,automaton,self.sources),self.rep)
        require(np.isfinite(value).all(),'projected target is nonfinite')
        self.timings[key]=dict(reused=False,seconds=time.monotonic()-begin)
        if self.cache is not None:self.cache.save_array(key,value)
        return value


def one_body(states,matrices):
    return frozen.dressed.one_body(states,frozen.dressed.difference_structure(states),np.asarray(matrices))


def linear_complete_contacts(local):
    N=local['X'].shape[1];x,yi=rank_core.frozen.padded_local_fields(local['orbitals'])[0:2]
    # padded_local_fields extends N->N+1 and transforms diag(U,1).
    # Restrict AFTER multiplication; this contains the primitive-boundary term.
    return np.asarray([(x[j]@yi[j])[:N,:N] for j in range(len(x))])


def assemble(modes,low,old_bath,active_indices,small,large,projector,memory_mb,preflight=False):
    """Literal production-factor Hamiltonian, with bath blocks projected by MPO.

    The cosine automata count centered mode factors, never Taylor powers. Their
    absorbing state sums all product terms and retains the entire cosine.
    """
    local=large;M=len(modes.omega);active=list(active_indices);other=[j for j in range(M) if j not in active];N=local['X'].shape[1]
    old=frozen.tensor_from_local(modes,low,old_bath,active,small,memory_mb) if not preflight else None
    nb=len(old_bath);par=np.r_[np.sum(old_bath,axis=1)%2,projector.rep['parities']];count=len(par);I=np.eye(count);Im=np.eye(N)
    def project(key,kind,matrices):return projector.target(key,mpo(kind,matrices))
    def support(matrices):return [matrices[j] if j in other else np.zeros_like(matrices[j]) for j in range(M)]
    # Identity is an independent generator/metric/complement contraction.
    metric=project('identity','product',[Im]*M);require(norm(metric-I)<3e-8,'factored source metric disagrees with sparse replay')
    r=0;Ds=support(local['D'][r]);sample=project('branch0_characteristic','cos_ge1',Ds)
    if preflight:
        project('branch0_centered_ge2','cos_ge2',Ds)
        c=local['c'][0];project('branch0_quadratic_pair','pair',support([c[j]*local['X'][j] for j in range(M)]))
        project('branch0_linear','sum',support([c[j]*local['X'][j] for j in range(M)]))
        return dict(identity_error=norm(metric-I),branch0_characteristic_norm=norm(sample),timings=projector.timings,
       target_count_full=4*len(modes.p.KJ)+10,scope='timing/metric only; no Hamiltonian or physical result')
    HB=project('bath_local_h','sum',local['local_hamiltonians']);hterms=[];reports={};oldscalar={}
    for r,kj in enumerate(modes.p.KJ):
        t2=float(local['theta2'][r]);theta=math.sqrt(t2);v=local['reference'][r];Ds=support(local['D'][r]);c=local['c'][r]
        characteristic=project('branch%d_characteristic'%r,'cos_ge1',Ds)
        centered2=project('branch%d_centered_ge2'%r,'cos_ge2',Ds)
        pair=project('branch%d_quadratic_pair'%r,'pair',support([c[j]*local['X'][j] for j in range(M)]))
        qB=project('branch%d_linear'%r,'sum',support([c[j]*local['X'][j] for j in range(M)])).real
        frozen_factor=float(np.prod([1+local['D'][r][j][0,0].real for j in active]))
        HB-=kj/t2*(frozen_factor*centered2.real+t2*pair.real);HB+=kj*t2*v/2*pair.real
        CL,SL=frozen.original.characteristic(low,small,r,active);qL=frozen.original.group_operator(low,small,active,c,'X').real
        CB=characteristic.real;SB=characteristic.imag;rL=SL-theta*qL;rB=SB-theta*qB
        hterms.extend([(CL,-kj/t2*CB),(rL,kj/t2*rB),(qL,kj/theta*rB),(rL,kj/theta*qB),(qL,kj*t2*v/2*qB)])
    d=modes.slope*np.sqrt(modes.p.hbar/(2*modes.omega));z=modes.endpoint*np.sqrt(modes.p.hbar*modes.omega/2)
    Dlocal=support([d[j]*local['X'][j] for j in range(M)]);Zlocal=support([z[j]*local['Y'][j].imag for j in range(M)])
    DB=project('D','sum',Dlocal).real;ZB=project('Z_imag','sum',Zlocal).real
    DB,dd=parity_gate(DB,par,1,1);ZB,zz=parity_gate(ZB,par,1,-1);reports.update(D=dd,Z_imag=zz)
    DB=DB.real;ZB=ZB.real
    qx=support([d[j]**2*local['X2'][j] for j in range(M)]);qy=support([z[j]**2*local['Y2'][j] for j in range(M)])
    D2B=project('D2_contact','sum',qx).real+2*project('D2_pair','pair',Dlocal).real
    Z2B=project('Z2_contact','sum',qy).real-2*project('Z2_pair','pair',Zlocal).real
    # The production bath pressure also carries scalar variance from active
    # vacuum modes, then subtracts its original product-vacuum expectation.
    contact=[d[j]**2/(2*modes.p.L0)*local['X2'][j]+modes.p.C0*z[j]**2/2*local['Y2'][j] for j in range(M)]
    PB=project('pressure_contact','sum',contact).real+project('D2_pair','pair',Dlocal).real/modes.p.L0-modes.p.C0*project('Z2_pair','pair',Zlocal).real
    scalar=float(PB[0,0]);PB-=scalar*I;oldscalar['PB_product_vacuum_mean']=scalar
    # Full physical D/Z source Gram, not projected squares. Cross contact is
    # computed using one further primitive level and keeps operator ordering.
    xy=linear_complete_contacts(local)
    cross=support([d[j]*z[j]*xy[j] for j in range(M)])
    DZB=projector.target('DZ_complete',ordered_pair_mpo(Dlocal,Zlocal,cross)).real
    DL=frozen.original.group_operator(low,small,active,d,'X').real;ZL=frozen.original.group_operator(low,small,active,z,'Y').imag
    active_mask=np.zeros(M);active_mask[active]=1.
    D2L=one_body(low,d[:,None,None]**2*active_mask[:,None,None]*small['X2'])+2*frozen.dressed.pair_matrix(low,frozen.dressed.difference_structure(low),small['X'],np.outer(d*active_mask,d*active_mask))
    Z2L=one_body(low,z[:,None,None]**2*active_mask[:,None,None]*small['Y2'])+2*frozen.dressed.pair_matrix(low,frozen.dressed.difference_structure(low),small['Y'],np.outer(z*active_mask,z*active_mask))
    # Mixed product on the low coordinate factor uses a source-free automaton;
    # the same contraction independently avoids products of projected fields.
    low_sources=np.zeros((0,M,N,N));low_rep=dict(C=np.zeros((0,len(low),0)),T=np.zeros((len(low),0)))
    lmask=[j in active for j in range(M)]
    lx=[d[j]*local['X'][j] if lmask[j] else np.zeros((N,N)) for j in range(M)]
    lz=[z[j]*local['Y'][j].imag if lmask[j] else np.zeros((N,N)) for j in range(M)]
    lc=[d[j]*z[j]*xy[j] if lmask[j] else np.zeros((N,N)) for j in range(M)]
    DZL=compress_contractions(contract(low,ordered_pair_mpo(lx,lz,lc),low_sources),low_rep).real
    pterms=[(DL,DB/modes.p.L0),(ZL,-modes.p.C0*ZB)]
    new=dict(HL=old['HL'],PL=old['PL'],HB=HB.real,PB=PB,hterms=hterms,pterms=pterms,local=large,low_states=low,
      old_bath_states=old_bath,bath_parities=par.astype(int),low_parities=(np.sum(low,axis=1)%2).astype(int),
      bath_dimension=count,source_representation=projector.rep,linear_sources=dict(D=(DL,DB),Z_imag=(ZL,ZB)),
      complete_sources=dict(DD=(np.asarray(D2L.real),D2B),ZZ=(np.asarray(Z2L.real),Z2B),DZ=(DZL,DZB)))
    # Replay is mandatory BEFORE retaining exact old production common blocks.
    checks=[]
    for key in ('HB','PB'):
        a=new[key];err=norm(a[:nb,:nb]-old[key]);scale=max(1.,norm(old[key]));require(err<3e-9*scale,'compressed old '+key+' replay failed')
        a,diag=parity_gate(a,par,0,1);a=a.real;a[:nb,:nb]=old[key];new[key]=a;reports[key]=diag;checks.append(dict(factor=key,error=err,scale=scale))
    rules=cross_factor_rules(len(modes.p.KJ))
    for kind in ('hterms','pterms'):
        require(len(new[kind])==len(old[kind])==len(rules[kind]),'construction cross-factor inventory differs')
        replaced=[]
        for i,((a,b),(ao,bo)) in enumerate(zip(new[kind],old[kind])):
            require(np.array_equal(a,ao),'active cross factor changed');err=norm(b[:nb,:nb]-bo);scale=max(1.,norm(bo));require(err<3e-9*scale,'compressed old cross factor replay failed')
            # A zero active factor has no inferable parity or adjoint sign.
            # Use the operator construction for both factors, including zeros.
            change,sign=rules[kind][i]
            _,active_diag=parity_gate(a,new['low_parities'],change,sign)
            b,diag=parity_gate(b,par,change,sign);b=b.real;b[:nb,:nb]=bo;replaced.append((a,b))
            checks.append(dict(factor=kind+str(i),error=err,scale=scale,declared_parity_change=change,declared_adjoint_sign=sign,active_gate=active_diag,bath_gate=diag))
        new[kind]=replaced
    require(all(np.array_equal(new[k][:nb,:nb],old[k]) for k in ('HB','PB')),'exact old local blocks lost')
    require(all(np.array_equal(b[:nb,:nb],bo) for key in ('hterms','pterms') for (_,b),(_,bo) in zip(new[key],old[key])),'exact old cross blocks lost')
    return new,old,dict(common_block_replay=checks,old_common_blocks_exact_after_replay=True,metric_error=norm(metric-I),parity_diagnostics=reports,scalar_convention=oldscalar,
       bath_parity_counts=[int(np.sum(par==p)) for p in (0,1)],timings=projector.timings,
       scope='full cosine and complete composite pressure in declared padded factor subspace; no omitted-state or new-ground source certificate')


def source_gram(model,psi):
    """Complete physical one-source Gram vs its finite tensor projection."""
    p=np.asarray(psi);require(p.dtype.kind=='f' and np.isfinite(p).all(),'finite real floating source state required');require(p.shape==(len(model['HB']),len(model['HL'])),'ground factor shape differs')
    D,Z=model['linear_sources']['D'],model['linear_sources']['Z_imag']
    da=D[1]@p+p@D[0].T;za=Z[1]@p+p@Z[0].T
    projected=np.array([[np.vdot(da,da).real,np.vdot(da,za).real],[np.vdot(za,da).real,np.vdot(za,za).real]])
    def exp_pair(name):
        a,b=model['complete_sources'][name];return float(np.sum(p*(b@p+p@a.T)))
    dd=exp_pair('DD')+2*float(np.sum(p*(D[1]@p@D[0].T)))
    zz=exp_pair('ZZ')-2*float(np.sum(p*(Z[1]@p@Z[0].T)))
    dz=exp_pair('DZ')+float(np.sum(p*(Z[1]@p@D[0].T+D[1]@p@Z[0].T)))
    complete=np.array([[dd,dz],[dz,zz]]);outside=complete-projected;scale=max(1.,norm(complete))
    require(np.isfinite(outside).all() and np.linalg.eigvalsh(outside)[0]>-2e-9*scale,'complete outside-source Gram not positive within declared arithmetic tolerance')
    return dict(complete=complete,projected=projected,outside=outside,minimum_outside_eigenvalue=float(np.linalg.eigvalsh(outside)[0]),
      scope='complete physical DD/ZZ/DZ contacts minus compressed tensor source Gram in supplied state; binary64 cancellation estimate, no spectral energy assignment or interval enclosure')
