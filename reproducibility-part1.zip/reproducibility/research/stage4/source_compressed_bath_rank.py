"""Saved-source rank diagnostic; no enlarged physical Hamiltonian is solved."""
from __future__ import annotations
import argparse,hashlib,json,math,os,platform,signal,sys,time,uuid,zipfile
from pathlib import Path
import numpy as np
import scipy
import source_compressed_bath as core
import source_directed_bath_select as frozen_consumer
ROOT=Path(__file__).resolve().parents[2]
CHECKS=('independent_padded_fock_source_and_qr','joint_singular_values_and_per_beta_tails','bright_source_coordinate_separator','factored_complete_cosine_and_contact_contractions','old_common_block_and_parity','input_and_numerical_scope_controls')


def require(ok,message):
    if not ok:raise ValueError(message)


def path(name):
    p=(ROOT/name).resolve();require(p.is_relative_to(ROOT),'project-local path required');return p


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def sources():
    names=['source_compressed_bath.py','source_compressed_bath_controls.py','source_compressed_bath_rank.py','source_directed_bath.py','source_directed_bath_select.py']
    return {str((Path(__file__).parent/n).relative_to(ROOT)):sha(Path(__file__).parent/n) for n in names}


def runtime():
    return dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),machine=platform.machine(),declared_threads={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')})


def jsonable(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,dict):return {str(k):jsonable(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [jsonable(x) for x in v]
    return v


def save(p,value):
    temp=p.with_name(p.name+'.writing-'+uuid.uuid4().hex)
    with temp.open('x') as f:json.dump(jsonable(value),f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(temp,p)


def load_spec(name):
    sp=path(name);s=json.loads(sp.read_text());require(s['format']==core.FORMAT,'wrong compressed-source spec')
    require(s['beta']==[1.,3.] and s['source_modes']==list(range(5,20)) and s['C0']==s['L0']==1.,'physical source normalization changed')
    require(s['include_primitive_boundary'] is True and s['preserve_every_active_state'] is True,'complete padded source and full active factor required')
    frozen_consumer.validate_job_inventory(s)
    for job in s['jobs']:
        for kind in ('profile','archive'):require(sha(path(job[kind]['path']))==job[kind]['sha256'],'source parent/archive pin changed')
    for kind in ('selector','selector_controls'):
        b=s[kind];require(sha(path(b['path']))==b['sha256'],'executed selection binding changed')
    selected=json.loads(path(s['selector']['path']).read_text())
    require(selected['status']=='COMPLETED_SELECTION_NOT_ENLARGED_PHYSICAL_RESULT','completed source selection required')
    require(selected['spec']['jobs']==s['jobs'] and selected['controls']==s['selector_controls'],'selection physical/control identity differs')
    require(selected['spec_sha256']==sha(path(s['selector_spec_path'])),'selector spec identity differs')
    require(selected['source_sha256']==frozen_consumer.source_identity(),'executed selector source changed')
    controls=json.loads(path(s['selector_controls']['path']).read_text())
    require(controls['status']=='PASS' and tuple(x['name'] for x in controls['checks'])==frozen_consumer.CONTROL_NAMES and all(x['passed'] is True for x in controls['checks']),'exact executed source selector controls required')
    require(controls['source_sha256']==selected['source_sha256'],'selection control source identity differs')
    b=selected['archive'];require(sha(path(b['path']))==b['sha256'],'selection array archive changed')
    return sp,s,selected


def control_gate(p):
    r=json.loads(p.read_text());require(r['format']==core.FORMAT+'-controls' and r['status']=='PASS','completed compressed-source controls required')
    require(tuple(x['name'] for x in r['checks'])==CHECKS and all(x['passed'] is True for x in r['checks']),'exact six compressed-source groups required')
    require(r['source_sha256']==sources() and r['runtime']==runtime(),'compressed-source controls/source/runtime differ')
    return r


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--spec',default='research/stage4/source_compressed_bath_rank_spec.json');ap.add_argument('--controls',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
    sp,spec,selection=load_spec(a.spec);cp=path(a.controls);control_gate(cp);control_sha=sha(cp);source=sources()
    memory=float(os.environ['PYSCF_MAX_MEMORY']);require(math.isfinite(memory) and memory>=3072,'3072MB minimum source-rank admission')
    nrows=max(p['diagnostics']['enumerated_row_count'] for p in selection['panels']);max_columns=512
    estimate=512*1024**2+8*6*nrows*max_columns+16*max_columns**2+64*1024**2
    require(estimate<.6*memory*1e6,'rank workspace/resident panel allowance exceeds memory')
    dest=path(a.output);require(dest.is_relative_to(ROOT/'research/stage4') and dest.parent.is_dir() and dest.suffix=='.json','new stage4 JSON required');archive=dest.with_suffix('.npz');require(not archive.exists(),'rank archive exists')
    start=time.monotonic();out=dict(format=core.FORMAT,status='RUNNING_NOT_A_RESULT',spec=spec,spec_sha256=sha(sp),source_sha256=source,runtime=runtime(),controls=dict(path=str(cp.relative_to(ROOT)),sha256=control_sha),memory_mb=memory,estimated_bytes=estimate,panels=[],scope='rank of coherent padded old-state bath source; no new physical ground, pressure moments, or completeness certificate')
    with dest.open('x') as f:json.dump(out,f)
    def persist():out['elapsed_seconds']=time.monotonic()-start;save(dest,out)
    def terminate(signum,frame):raise RuntimeError('rank diagnostic admission interrupted')
    signal.signal(signal.SIGTERM,terminate)
    try:
        az=path(selection['archive']['path'])
        with zipfile.ZipFile(az) as z:require(sum(v.file_size for v in z.infolist())<.1*memory*1e6,'selection archive exceeds input allowance')
        with np.load(az,allow_pickle=False) as z:
            row_inventory=z['beta1_states'].copy();require(np.array_equal(row_inventory,z['beta3_states']),'strength source row labels differ')
            saved_grams=[z['beta'+str(int(beta))+'_gram_by_row'].copy() for beta in spec['beta']]
        require(row_inventory.shape==(nrows,20) and all(g.shape==(nrows,2,2) for g in saved_grams),'source row/Gram inventory differs from admitted dimensions')
        panels=[];arrays={'row_states':row_inventory};previous=None
        for i,job in enumerate(spec['jobs']):
            record,data=frozen_consumer.profile_inputs(job,memory)
            if previous is not None:
                for k in ('bath_states','low_states','omega','reference','couplings'):require(np.array_equal(previous[k],data[k]),'common physical ordinal/calibration labels differ: '+k)
            previous=data
            generators=core.source_generators(data['bath_states'],data['orbitals'],data['coefficients'],spec['source_modes'],row_inventory)
            panel=core.reduce_ground(generators,data['low_states'],data['ground_original_tensor'],spec['C0'],spec['L0'])
            error=float(np.max(abs(panel['gram_by_row']-saved_grams[i])));require(error<2e-10,'untruncated QR source does not replay independent coherent row Grams')
            boundary=np.any(row_inventory>=32,axis=1);missing=np.arange(len(row_inventory))>=128
            direct=panel['gram_by_row'][missing].sum(axis=0);expected=selection['panels'][i]['direct_complete_missing_bath_gram']
            total_error=float(np.max(abs(direct-expected)));require(total_error<2e-10,'complete missing source Gram changed')
            expected_scale=selection['panels'][i]['configuration_deficit']+selection['panels'][i]['primitive_boundary_deficit']
            require(abs(panel['deficit']-expected_scale)<2e-10,'positive complete source norm changed')
            prefix='beta'+str(int(job['beta']))+'_'
            for name in ('D','Z_imag'):
                mat=generators[name];arrays[prefix+name+'_csr_data']=mat.data;arrays[prefix+name+'_csr_indices']=mat.indices;arrays[prefix+name+'_csr_indptr']=mat.indptr
            for parity,factor in panel['factors'].items():
                for key,value in factor.items():arrays[prefix+'qr_oldparity'+str(parity)+'_'+key]=value
            out['panels'].append(dict(beta=job['beta'],input_binding=job,profile_source_sha256=record['source_sha256'],source_generator_diagnostics=generators['diagnostics'],qr_checks=panel['qr_checks'],
              source_generator_shape=[len(row_inventory),128],per_row_gram_max_absolute_replay_error=error,total_missing_gram_max_absolute_replay_error=total_error,
              complete_missing_gram=direct,complete_padded_source_deficit=panel['deficit'],primitive_boundary_gram=panel['gram_by_row'][boundary].sum(axis=0),
              active_factor_raw_deficit_unchanged=selection['panels'][i]['active_factor_raw_deficit'],
              scope='positive padded source norm from the original saved state; generation/QR errors measured, no interval enclosure'))
            panels.append(panel);persist()
        decompositions=core.decompose(panels);out['decompositions']={}
        for parity,d in decompositions.items():
            for key in ('U','s','Vh','row_indices'):arrays['svd_bathparity'+str(parity)+'_'+key]=d[key]
            out['decompositions'][str(parity)]={k:v for k,v in d.items() if k not in ('U','s','Vh','row_indices','beta_weights')}
            out['decompositions'][str(parity)]['singular_values']=d['s'];out['decompositions'][str(parity)]['right_singular_beta_weights']=d['beta_weights']
        out['rank_analysis']=core.rank_panel(decompositions,spec['rank_grid'],spec['fractions'],128)
        # Any coordinate selection is an admissible bath subspace of that rank.
        # Joint SVD optimality constrains the SUM of beta-normalized deficits,
        # not each beta separately and not the newly solved physical ground.
        comparisons=[]
        rank_records={r['added_rank']:r for r in out['rank_analysis']['rank_grid']}
        for cap in (192,256,320,384):
            old=next(c for c in selection['selections'] if c['max_bath_count']==cap and c['fraction']==.99);rank=old['new_count']-128
            if rank not in rank_records:continue
            coordinate=[(old['residual_configuration_deficit'][i]+selection['panels'][i]['primitive_boundary_deficit'])/panels[i]['deficit'] for i in range(2)]
            spectral=rank_records[rank]['relative_discarded_singular_weight_by_beta'];violation=sum(spectral)-sum(coordinate)
            require(violation<2e-8,'source SVD violates coordinate-subspace optimality replay')
            comparisons.append(dict(added_rank=rank,bath_dimension=128+rank,coordinate_relative_remaining_by_beta=coordinate,singular_relative_remaining_by_beta=spectral,
              joint_optimality_violation=violation,scope='joint normalized old-source objective only; no per-beta domination or physical convergence inference'))
        out['coordinate_comparisons']=comparisons
        arrays.update(old_bath_states=previous['bath_states'],active_states=previous['low_states'],omega=previous['omega'],reference=previous['reference'],couplings=previous['couplings'])
        with archive.open('xb') as f:np.savez_compressed(f,**arrays);f.flush();os.fsync(f.fileno())
        out['archive']=dict(path=str(archive.relative_to(ROOT)),sha256=sha(archive),bytes=archive.stat().st_size,arrays={k:dict(shape=list(v.shape),dtype=str(v.dtype)) for k,v in arrays.items()})
        out['warnings']=['All capture fractions describe only the supplied old-state bath sources; the active deficit remains, and new ground/source/graph gates must be recomputed.',
          'Common beta subspaces use identical ordinal dressed labels. The underlying frozen orbitals differ with beta; this is not one identical physical subspace across strengths.',
          'Both complete one-field primitive boundary rows and configuration rows enter the compression. Future H/P contractions need the extended frozen local basis and complete projected contacts.',
          'Numerical upper/lower estimates use measured QR/SVD and orthogonality diagnostics, not rigorous floating-point or physical-source enclosures. Singular vectors below the reported resolution cannot be used as validated generator directions.',
          'Degenerate singular clusters define invariant subspaces. Individual singular vectors have arbitrary signs/rotations; physical comparisons must use projectors and full clusters.',
          'The executed source selector counted tiny nonzero amplitudes whose binary64 squares underflowed. The new rank test does not turn those microscopic source weights into a certified zero.',
          'No dense ambient Hamiltonian was constructed. Factorized source generators and QR/SVD ingredients are saved for a separately controlled future full-cosine contraction.']
        require(sources()==source and sha(sp)==out['spec_sha256'] and sha(cp)==control_sha,'rank source/spec/control changed');load_spec(a.spec);control_gate(cp)
        out['status']='COMPLETED_RANK_DIAGNOSTIC_NOT_PHYSICAL_COMPLETION';persist()
    except BaseException as exc:out.update(status='FAILED',error=repr(exc));persist();raise
    print('COMPLETED_RANK_DIAGNOSTIC_NOT_PHYSICAL_COMPLETION',flush=True)

if __name__=='__main__':main()
