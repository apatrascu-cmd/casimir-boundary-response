"""First-order pressure ranges given ideal nonlinear-response data.

The admissible set is {w>=0: A w=A w_true}. A centered orthonormal-nullspace
parameterization removes the equalities from the linear program while keeping
the same polytope in exact arithmetic. Full column rank gives an ideal-data
singleton without optimization; it is not a clipped computed LP width.
Every numerical witness is checked against the ORIGINAL response matrix.
The executed equality-LP source is preserved in research/stage2/snapshots.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import linprog

SOLVER_TOLERANCE = 1e-10
WITNESS_TOLERANCE = 1e-10
SMALL_MATRIX_VALUE = 1e-12


def calibration_matrix(poles, frequencies):
    """Rows sample Gamma4(i xi,-i xi,0,0)/G in normalized branch weights."""
    poles = np.asarray(poles, dtype=float)
    frequencies = np.asarray(frequencies, dtype=float)
    if (poles.ndim != 1 or not len(poles) or np.any(poles <= 0)
            or frequencies.ndim != 1 or np.any(frequencies < 0)
            or not np.all(np.isfinite(poles)) or not np.all(np.isfinite(frequencies))):
        raise ValueError('Finite positive poles and nonnegative Euclidean frequencies required')
    return (poles[None, :] ** 2 / (poles[None, :] ** 2 + frequencies[:, None] ** 2)) ** 2


def closure_interval(coefficient, poles, frequencies, true_weights):
    """Numerical sharp range of c dot w over an ideal-response allocation set.

    The targets are synthesized as y=A w_true. After a full SVD, N contains
    orthonormal nullspace columns, and w=w_true+N z. Min/max LPs use
    -N z<=w_true with unconstrained z, including when w_true is on a face.
    Absolute witness checks are 1e-10 in the original normalized responses,
    total weight, and nonnegativity. These are not pressure or continuum bounds.
    """
    c = np.asarray(coefficient, dtype=float)
    w = np.asarray(true_weights, dtype=float)
    poles = np.asarray(poles, dtype=float)
    if (c.shape != poles.shape or w.shape != poles.shape or c.ndim != 1
            or not len(c) or np.any(w < 0) or abs(w.sum() - 1) > 1e-12):
        raise ValueError('Matching branch vectors and nonnegative normalized weights required')
    if not np.all(np.isfinite(c)) or not np.all(np.isfinite(w)):
        raise ValueError('Finite coefficients and weights required')
    frequencies = np.unique(np.r_[0.0, np.asarray(frequencies, dtype=float)])
    A = calibration_matrix(poles, frequencies)
    y = A @ w
    _, singular_values, vh = np.linalg.svd(A, full_matrices=True)
    rank_tolerance = max(A.shape) * np.finfo(float).eps * singular_values[0]
    rank = int(np.sum(singular_values > rank_tolerance))
    N = vh[rank:].T
    nullity = len(w) - rank
    nullspace_residual = float(np.max(abs(A @ N))) if nullity else 0.0
    orthogonality_residual = float(np.max(abs(N.T @ N - np.eye(nullity)))) if nullity else 0.0
    decomposition_tolerance = 256 * np.finfo(float).eps * max(A.shape) * max(1.0, singular_values[0])
    if max(nullspace_residual, orthogonality_residual) > decomposition_tolerance:
        raise ArithmeticError('SVD nullspace failed its residual or orthogonality check')
    actual = float(c @ w)

    def endpoint(weights, method, details=None):
        weights = np.asarray(weights, dtype=float)
        if not np.all(np.isfinite(weights)):
            raise ArithmeticError('Nonfinite extremizing allocation')
        residual = float(np.max(abs(A @ weights - y)))
        normalization = abs(float(weights.sum() - 1))
        minimum = float(weights.min())
        if (residual > WITNESS_TOLERANCE or normalization > WITNESS_TOLERANCE
                or minimum < -WITNESS_TOLERANCE):
            raise ArithmeticError(
                f'Original-constraint witness failure: response={residual:.17g}, '
                f'normalization={normalization:.17g}, min_weight={minimum:.17g}, '
                f'tolerance={WITNESS_TOLERANCE:.17g}')
        return {'observable': float(c @ weights), 'weights': weights.tolist(),
                'calibration_residual': residual, 'normalization_residual': normalization,
                'minimum_weight': minimum, 'method': method, 'solver': details}

    if nullity == 0:
        # y=A w_true and full column rank imply the unique weight w_true.
        # No two numerical LP solutions are subtracted in this structural case.
        lower = endpoint(w, 'structural_full_column_rank_singleton')
        upper = endpoint(w, 'structural_full_column_rank_singleton')
        solution_kind = 'structural_full_column_rank_singleton'
    elif np.all(c == c[0]):
        lower = endpoint(w, 'constant_observable_on_normalized_simplex')
        upper = endpoint(w, 'constant_observable_on_normalized_simplex')
        solution_kind = 'constant_observable_on_normalized_simplex'
    elif len(frequencies) == 1:
        unit = np.eye(len(w)) * w.sum()
        lower = endpoint(unit[int(np.argmin(c))], 'analytic_static_simplex')
        upper = endpoint(unit[int(np.argmax(c))], 'analytic_static_simplex')
        solution_kind = 'analytic_static_simplex'
    else:
        scale = max(float(np.max(abs(c))), 1e-300)
        projected = N.T @ (c / scale)
        inequalities = -N
        solutions = []
        for sign in (1.0, -1.0):
            objective = sign * projected
            fit = linprog(objective, A_ub=inequalities, b_ub=w,
                bounds=[(None, None)] * nullity, method='highs',
                options={'threads': 1, 'presolve': True,
                         'primal_feasibility_tolerance': SOLVER_TOLERANCE,
                         'dual_feasibility_tolerance': SOLVER_TOLERANCE,
                         'small_matrix_value': SMALL_MATRIX_VALUE})
            if not fit.success:
                raise ArithmeticError('Centered-nullspace LP: ' + fit.message)
            witness = w + N @ fit.x
            marginals = np.asarray(fit.ineqlin.marginals)
            dual_value = float(w @ marginals)
            details = {
                'status': int(fit.status), 'message': fit.message, 'iterations': int(fit.nit),
                'nullspace_coordinates': fit.x.tolist(), 'objective_scale': scale,
                'normalized_primal_objective': float(fit.fun),
                'normalized_dual_objective': dual_value,
                'normalized_primal_dual_gap': float(fit.fun - dual_value),
                'dual_stationarity_residual': float(np.max(abs(objective - inequalities.T @ marginals))),
                'inequality_dual_marginals': marginals.tolist(),
            }
            solutions.append(endpoint(witness, 'centered_nullspace_linear_program', details))
        lower, upper = solutions
        solution_kind = 'centered_nullspace_linear_program'
    return {
        'lower': lower, 'upper': upper,
        # Do not clip, sort, or silently replace a negative computed LP width.
        'width': upper['observable'] - lower['observable'], 'actual_value': actual,
        'frequencies': frequencies.tolist(), 'calibration_rank': rank,
        'singular_values': singular_values.tolist(), 'rank_tolerance': float(rank_tolerance),
        'nullity': nullity, 'nullspace_residual': nullspace_residual,
        'nullspace_orthogonality_residual': orthogonality_residual,
        'decomposition_check_tolerance': float(decomposition_tolerance),
        'solution_kind': solution_kind,
        'witness_absolute_tolerance': WITNESS_TOLERANCE,
        'solver_feasibility_tolerance': SOLVER_TOLERANCE,
        'small_matrix_value': SMALL_MATRIX_VALUE,
        'interpretation': 'ideal finite-family first-order information interval; structural singleton or numerical nullspace optimization with original-constraint checks',
    }
