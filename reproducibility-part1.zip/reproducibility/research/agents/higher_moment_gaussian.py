"""Finite-mode first-order ordered pressure moments by Gaussian insertions.

No Fock/occupation cutoff. A formal power series is used throughout; existence
of an exponential moment at positive source is neither needed nor asserted.
The new O(R (2M)^5) tensor construction retains state and real-time dynamics.
See docs/HIGHER_MOMENT_DERIVATION_2026-09-14.md for conventions and proof.
"""
from __future__ import annotations
import math
import time
import numpy as np


def _filter(x, tau, increment):
    value = np.exp(-0.5 * (tau * x) ** 2)
    if increment:
        value = value * (-np.expm1(-1.5 * (tau * x) ** 2))
    return value


def _gaussian_divided(x, y, tau):
    """Continuous [g(x)-g(y)]/(x-y), including x=y and x=-y."""
    x, y = np.broadcast_arrays(x, y)
    rate = 0.5 * tau * tau
    if rate == 0:
        return np.zeros_like(x)
    separation = np.abs((x-y) * (x+y))
    exponent = -rate * separation
    relative = np.ones_like(exponent)
    np.divide(np.expm1(exponent), exponent, out=relative, where=exponent != 0)
    return -rate * (x+y) * np.exp(-rate*np.minimum(x*x, y*y)) * relative


def _divided(x, y, tau, increment):
    value = _gaussian_divided(x, y, tau)
    if increment:
        value = value - _gaussian_divided(x, y, 2*tau)
    return value


def _riccati(A, B, order):
    """Ordinary-series Z_j and log-vacuum-amplitude coefficients k_j/j!."""
    z = np.zeros((order, len(A), len(A)))
    z[1] = B
    for n in range(1, order-1):
        value = A @ z[n] + z[n] @ A.T
        for j in range(1, n):
            value += z[j] @ B @ z[n-j]
        z[n+1] = (value + value.T) / (2*(n+1))
    log = np.zeros(order+1)
    for n in range(2, order+1):
        log[n] = np.trace(B @ z[n-1]) / (2*n)
    return z, log


def _state_log_coefficients(omega, branch_c, z, hbar, order):
    pairs = (omega[:, None] + omega[None, :]).ravel()
    kernel = 1.0 / (pairs[:, None] + pairs[None, :])
    coefficients = np.zeros((len(branch_c), order+1))
    for r, c in enumerate(branch_c):
        weighted = (z * c[None, :, None] * c[None, None, :]).reshape(order, -1)
        contractions = weighted @ kernel @ weighted.T
        for n in range(2, order+1):
            coefficients[r, n] = -sum(contractions[j, n-j]
                for j in range(1, n)) / (4*hbar)
    return coefficients


def _dynamics_weyl(omega, d, velocity, branch_c, tau, C0, L0, hbar, increment):
    """Coupling-independent T4,T2 in D=sum_r u_r(T4_r:R^4:+T2_r:R^2:).

    Colons in this docstring denote Weyl ordering, not normal ordering.
    T4 is symmetric in its first three indices; its last index is singled out
    by the pressure field in the interaction-picture commutator.
    """
    count = len(omega)
    signed = np.r_[-omega, omega]
    signs = np.r_[-np.ones(count), np.ones(count)]
    d = np.tile(d, 2)
    velocity = np.tile(velocity, 2)
    c = np.tile(branch_c, (1, 2))
    size = 2*count
    quartic = np.zeros((len(c), size, size, size, size))
    quadratic = np.zeros((len(c), size, size))
    if tau == 0:
        return quartic, quadratic
    triple = signed[:, None, None] + signed[None, :, None] + signed[None, None, :]
    triple_c = c[:, :, None, None] * c[:, None, :, None] * c[:, None, None, :]
    vacuum_variance = np.sum(branch_c**2, axis=1)
    for ell in range(size):
        transferred4 = np.zeros((len(c), size, size, size))
        transferred2 = np.zeros((len(c), size))
        x4 = triple + signed[ell]
        x2 = signed + signed[ell]
        for internal in range(size):
            y = signed[ell] - signed[internal]
            weight = -c[:, internal] * (
                signs[internal]*d[ell]*d[internal]/L0
                + signs[ell]*C0*velocity[ell]*velocity[internal])
            divided4 = _divided(x4, y, tau, increment)
            transferred4 += weight[:, None, None, None]*divided4[None, :, :, :]
            transferred2 += weight[:, None]*_divided(x2, y, tau, increment)[None, :]
        quartic[:, :, :, :, ell] = triple_c*transferred4/(6*hbar)
        quadratic[:, :, ell] = -vacuum_variance[:, None]*c*transferred2/(2*hbar)
    return quartic, quadratic


def _sandwich_covariance(z, generator, t, order):
    """Coefficients of <e^(sS) Weyl(e^-tsS R e^tsS)^2>/ <e^(sS)>."""
    size = len(generator)
    count = size//2
    exponent = np.zeros((order, size, size))
    exponent[0] = np.eye(size)
    for j in range(1, order):
        exponent[j] = exponent[j-1] @ (-t*generator) / j
    left = np.zeros_like(exponent)
    left[0, :count, count:] = np.eye(count)/2
    left[0, count:, :count] = np.eye(count)/2
    left[1:, count:, count:] = z[1:]
    intermediate = np.zeros_like(exponent)
    covariance = np.zeros_like(exponent)
    for k in range(order):
        for j in range(k+1):
            intermediate[k] += exponent[j] @ left[k-j]
        for j in range(k+1):
            covariance[k] += intermediate[k-j] @ exponent[j].T
        covariance[k] = (covariance[k] + covariance[k].T)/2
    return covariance


def _dynamics_log_coefficients(A, B, z, quartic, quadratic, order, nodes):
    # [S,R]=generator R for R=(a,a-dagger). The inverse conjugation in
    # e^((s-z)S) D e^(zS) supplies exp(-z*generator), including this sign.
    generator = np.block([[-A, -B], [B, A.T]])
    points, weights = np.polynomial.legendre.leggauss(nodes)
    points, weights = (points+1)/2, weights/2
    coefficients = np.zeros((len(quartic), order+1))
    size = len(generator)
    for t, weight in zip(points, weights):
        covariance = _sandwich_covariance(z, generator, t, order)
        flattened = covariance.reshape(order, size*size)
        for r in range(len(quartic)):
            four = flattened @ quartic[r].reshape(size*size, size*size) @ flattened.T
            two = flattened @ quadratic[r].ravel()
            for n in range(1, order+1):
                m = n-1
                coefficients[r, n] += weight*(
                    3*sum(four[j, m-j] for j in range(m+1)) + two[m])
    return coefficients


def _exp_series(log):
    value = np.zeros_like(log)
    value[0] = 1
    for n in range(1, len(log)):
        value[n] = sum(j*log[j]*value[n-j] for j in range(1, n+1))/n
    return value


def first_order_gaussian(omega, endpoint, slope, branches, couplings, tau,
                         order=8, C0=1.0, L0=1.0, hbar=1.0, increment=False,
                         memory_limit_mb=512.0, quadrature_nodes=None):
    """Finite-mode ordered spectral cumulants and raw moment derivatives.

    Couplings multiply :q_r^4:/24. All branch coefficients are returned before
    multiplication by couplings. They can be reused for calibrated allocations.
    The quadrature is exact for the truncated formal series: at order n its
    integrand has degree <=n-1 in the insertion fraction. ceil(order/2) nodes
    integrate all terms. This is not a convergence result as mode count grows.
    """
    begin = time.monotonic()
    omega, endpoint, slope = (np.asarray(x, dtype=float) for x in (omega, endpoint, slope))
    branches, couplings = np.asarray(branches, dtype=float), np.asarray(couplings, dtype=float)
    if omega.ndim != 1 or not len(omega) or np.any(omega <= 0):
        raise ValueError('A nonempty vector of positive mode frequencies is required')
    count = len(omega)
    if endpoint.shape != (count,) or slope.shape != (count,):
        raise ValueError('Endpoint and slope must have one entry per mode')
    if branches.ndim != 2 or branches.shape[1] != count or couplings.shape != (len(branches),):
        raise ValueError('Branches must have shape (branches,modes), one coupling per branch')
    if not 2 <= order <= 12 or tau < 0 or C0 <= 0 or L0 <= 0 or hbar <= 0:
        raise ValueError('Require 2<=order<=12, nonnegative tau and positive C0,L0,hbar')
    if not all(np.all(np.isfinite(x)) for x in (omega, endpoint, slope, branches, couplings)):
        raise ValueError('All mode and coupling data must be finite')
    nodes = (order+1)//2 if quadrature_nodes is None else int(quadrature_nodes)
    if nodes < (order+1)//2:
        raise ValueError('Too few quadrature nodes for algebraic exactness at requested order')
    # Conservative accounting for tensors, construction temporaries, and BLAS
    # products. Runtime-library overhead is not included in this estimate.
    size = 2*count
    estimate = 8*(len(branches)*size**4 + count**4
                  + (8*len(branches)+8)*size**3 + 20*order*size**2)/1e6
    if memory_limit_mb <= 0 or estimate > memory_limit_mb:
        raise MemoryError(f'Estimated array memory {estimate:.1f} MB exceeds {memory_limit_mb:.1f} MB')
    d = slope*np.sqrt(hbar/(2*omega))
    velocity = endpoint*np.sqrt(hbar*omega/2)
    branch_c = branches*np.sqrt(hbar/(2*omega))[None, :]
    A0 = np.outer(d,d)/L0 + C0*np.outer(velocity,velocity)
    B0 = np.outer(d,d)/L0 - C0*np.outer(velocity,velocity)
    A = A0*_filter(omega[:, None]-omega[None, :], tau, increment)
    B = B0*_filter(omega[:, None]+omega[None, :], tau, increment)
    z, harmonic_log = _riccati(A, B, order)
    state = _state_log_coefficients(omega, branch_c, z, hbar, order)
    tensor_started = time.monotonic()
    quartic, quadratic = _dynamics_weyl(omega, d, velocity, branch_c, tau, C0, L0, hbar, increment)
    tensor_seconds = time.monotonic()-tensor_started
    dynamics = _dynamics_log_coefficients(A, B, z, quartic, quadratic, order, nodes)
    factorials = np.asarray([math.factorial(n) for n in range(order+1)], dtype=float)
    state_k, dynamics_k = state*factorials, dynamics*factorials
    harmonic_k = harmonic_log*factorials
    state_delta, dynamics_delta = couplings @ state_k, couplings @ dynamics_k
    harmonic_m_series = _exp_series(harmonic_log)
    branch_state_m = np.asarray([np.convolve(harmonic_m_series, x)[:order+1]*factorials for x in state])
    branch_dynamics_m = np.asarray([np.convolve(harmonic_m_series, x)[:order+1]*factorials for x in dynamics])
    harmonic_m = harmonic_m_series*factorials
    delta_m = couplings @ (branch_state_m+branch_dynamics_m)
    def series(values):
        return {str(n):float(values[n]) for n in range(1, order+1)}
    def branch_series(values):
        return [series(value) for value in values]
    return {
        'harmonic_cumulants': series(harmonic_k),
        'delta_cumulants': series(state_delta+dynamics_delta),
        'state_delta_cumulants': series(state_delta),
        'dynamics_delta_cumulants': series(dynamics_delta),
        'first_order_cumulants': series(harmonic_k+state_delta+dynamics_delta),
        'harmonic_moments': series(harmonic_m), 'delta_moments': series(delta_m),
        'state_delta_moments': series(couplings @ branch_state_m),
        'dynamics_delta_moments': series(couplings @ branch_dynamics_m),
        'first_order_moments': series(harmonic_m+delta_m),
        'branch_cumulant_coefficients': branch_series(state_k+dynamics_k),
        'branch_state_cumulant_coefficients': branch_series(state_k),
        'branch_dynamics_cumulant_coefficients': branch_series(dynamics_k),
        'branch_moment_coefficients': branch_series(branch_state_m+branch_dynamics_m),
        'mean_delta': float(state_delta[1]+dynamics_delta[1]),
        'modes': count, 'order': order, 'tau': tau, 'increment': increment,
        'quadrature_nodes': nodes, 'estimated_array_memory_mb': estimate,
        'tensor_construction_seconds': tensor_seconds, 'runtime_seconds': time.monotonic()-begin,
        'occupation_cutoff': None, 'energy_cutoff': None,
        'method': 'formal Riccati series with state resolvent and ordered Weyl-quartic insertion',
        'scope': 'exact algebra at fixed selected modes; floating-point evaluation; no higher-cumulant continuum claim'
    }
