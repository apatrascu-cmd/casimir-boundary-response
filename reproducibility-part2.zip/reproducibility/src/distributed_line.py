"""Distributed line + passive two-branch quantum boundary, hbar=1 by default.

New in this stage:
* consistent-mass finite elements with mesh refinement;
* exact continuum imaginary-frequency boundary susceptibility;
* quantum (not commuting-Gaussian) harmonic quadratic-observable cumulants;
* first-order, tadpole-matched connected fourth cumulant of endpoint flux.

No claim of nonlinear continuum force cumulants or intermittency is made.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from numpy.typing import NDArray
from scipy.linalg import eigh, solve
from scipy.integrate import quad

Array = NDArray[np.float64]

@dataclass(frozen=True)
class Parameters:
    a: float = 1.0
    C0: float = 1.0
    L0: float = 1.0
    Cb: float = 0.5
    Kb: float = 0.5
    Cr: tuple[float, ...] = (1.0, 0.25)
    Kc: tuple[float, ...] = (0.5, 0.8)
    Kg: tuple[float, ...] = (0.25, 1.2)
    KJ: tuple[float, ...] = (0.25, 2.0)
    hbar: float = 1.0

    def validate(self) -> None:
        if any(v <= 0 for v in (self.a, self.C0, self.L0, self.Cb, self.hbar)):
            raise ValueError('a, C0, L0, Cb, hbar must be positive.')
        n = len(self.Cr)
        if n == 0 or any(len(t) != n for t in (self.Kc,self.Kg,self.KJ)):
            raise ValueError('Boundary parameter tuples must have equal, nonzero lengths.')
        if any(v <= 0 for t in (self.Cr,self.Kc,self.KJ) for v in t):
            raise ValueError('Branch capacitances, coupling and Josephson stiffnesses must be positive.')
        if self.Kb < 0 or any(v < 0 for v in self.Kg):
            raise ValueError('Ground stiffnesses cannot be negative.')

    @property
    def v(self) -> float:
        return 1.0 / math.sqrt(self.C0*self.L0)

@dataclass
class LinearModel:
    p: Parameters
    elements: int
    C: Array
    K: Array
    Cline: Array
    Kline: Array
    omega: Array
    T: Array

    @property
    def end(self) -> int:
        return self.elements-1

    def susceptibility(self, xi: float) -> Array:
        if xi < 0:
            raise ValueError('xi must be nonnegative.')
        return (self.T/(self.omega**2 + xi**2)) @ self.T.T

    def variances(self) -> Array:
        return self.p.hbar*np.sum(self.T**2/(2*self.omega),axis=1)


def build_model(elements: int, p: Parameters = Parameters()) -> LinearModel:
    """Dirichlet at x=0; endpoint and internal branch variables are dynamical."""
    p.validate()
    if not isinstance(elements,int) or elements < 1:
        raise ValueError('elements must be a positive integer.')
    n=elements; b=len(p.Cr); h=p.a/n
    cl=np.zeros((n+1,n+1)); kl=np.zeros_like(cl)
    for j in range(n):
        sl=np.ix_([j,j+1],[j,j+1])
        cl[sl]+=p.C0*h/6*np.array([[2.,1.],[1.,2.]])
        kl[sl]+=1/(p.L0*h)*np.array([[1.,-1.],[-1.,1.]])
    Cline=np.zeros((n+b,n+b)); Kline=np.zeros_like(Cline)
    Cline[:n,:n]=cl[1:,1:]; Kline[:n,:n]=kl[1:,1:]
    C=Cline.copy(); K=Kline.copy(); e=n-1
    C[e,e]+=p.Cb; K[e,e]+=p.Kb
    for r in range(b):
        j=n+r
        C[j,j]+=p.Cr[r]
        K[j,j]+=p.Kc[r]+p.Kg[r]+p.KJ[r]
        K[e,e]+=p.Kc[r]
        K[e,j]=K[j,e]=-p.Kc[r]
    w2,T=eigh(K,C,check_finite=True)
    if w2[0] <= 0:
        raise ValueError('Unstable harmonic model.')
    return LinearModel(p,n,C,K,Cline,Kline,np.sqrt(w2),T)


def gamma2(xi: float, p: Parameters = Parameters()) -> float:
    """Harmonic boundary stiffness after eliminating internal oscillators."""
    if xi < 0:
        raise ValueError('xi must be nonnegative.')
    out=p.Cb*xi*xi+p.Kb
    for C,Kc,Kg,KJ in zip(p.Cr,p.Kc,p.Kg,p.KJ):
        out+=Kc-Kc*Kc/(C*xi*xi+Kc+Kg+KJ)
    return float(out)


def continuum_boundary_green(xi: float, p: Parameters = Parameters(), *, isolated: bool=False) -> Array:
    """Inverse action kernel on (endpoint, internal branches); covariance = hbar*g.

    The finite line contributes k*coth(k*a)/L0; isolated means a half-line.
    """
    p.validate()
    if xi < 0:
        raise ValueError('xi must be nonnegative.')
    k=xi/p.v; z=k*p.a
    if isolated:
        line=k/p.L0
    elif abs(z)<1e-5:
        line=(1+z*z/3-z**4/45)/(p.L0*p.a)
    else:
        line=k/(p.L0*np.tanh(z))
    d=np.array(p.Cr)*xi**2+np.array(p.Kc)+np.array(p.Kg)+np.array(p.KJ)
    h=np.array(p.Kc)/d
    end=1.0/(line+gamma2(xi,p))
    g=np.empty((len(d)+1,len(d)+1))
    g[0,0]=end; g[0,1:]=g[1:,0]=h*end
    g[1:,1:]=np.diag(1/d)+np.outer(h,h)*end
    return g


def continuum_variances(p: Parameters = Parameters(), *, isolated: bool=False) -> dict:
    values=[]; errors=[]
    for i in range(1+len(p.Cr)):
        val,err=quad(lambda x:continuum_boundary_green(x,p,isolated=isolated)[i,i],
                     0,np.inf,epsabs=2e-11,epsrel=2e-11,limit=300)
        values.append(p.hbar*val/np.pi); errors.append(p.hbar*err/np.pi)
    return {'values':values,'quadrature_error_estimates':errors}


def casimir_interaction(p: Parameters = Parameters()) -> dict:
    """T=0 harmonic Dirichlet-left / network-right scattering interaction.

    Not an absolute vacuum energy or a probability distribution.
    """
    def integrand(t: float, energy: bool) -> float:
        if t>700:
            return 0.0
        xi=t*p.v/(2*p.a); k=xi/p.v; eta=p.L0*gamma2(xi,p)
        r=(k-eta)/(k+eta)
        # 1 + r*exp(-t), written to avoid small-t cancellation.
        den=-np.expm1(-t)+(1+r)*np.exp(-t)
        if energy:
            return float(np.log(den))
        return float(t*r*np.exp(-t)/den)
    ei,ee=quad(lambda t:integrand(t,True),0,np.inf,epsabs=2e-11,limit=250)
    fi,fe=quad(lambda t:integrand(t,False),0,np.inf,epsabs=2e-11,limit=250)
    scale_e=p.hbar*p.v/(4*np.pi*p.a)
    scale_f=p.hbar*p.v/(4*np.pi*p.a**2)
    return {'energy':scale_e*ei,'force':scale_f*fi,
            'energy_quad_error_estimate':scale_e*ee,'force_quad_error_estimate':scale_f*fe}


def matched_flux_fourth(model: LinearModel, alpha: float=.25, array_size: int=1) -> dict:
    """Leading connected endpoint-flux fourth moment, with matched tadpoles.

    All external flux insertions have the same time. This is not a real-time
    force-distribution calculation. u4=-KJ*alpha**2/N**2.
    """
    if alpha <= 0 or array_size < 1:
        raise ValueError('alpha and array_size must be positive.')
    p=model.p; w=model.omega; T=model.T; e=model.end
    parts=[]; errs=[]
    for r in range(len(p.Cr)):
        c=p.hbar*T[e]*T[model.elements+r]/(2*w)
        u=-p.KJ[r]*alpha**2/array_size**2
        scale=max(float(np.sum(abs(c))),1e-20)
        # Scale the integrand to keep QUADPACK's absolute tolerance meaningful.
        def f(t: float) -> float:
            return float(np.dot(c/scale,np.exp(-w*t)))**4
        integ,err=quad(f,0,np.inf,epsabs=2e-12,epsrel=2e-11,limit=200)
        parts.append(-u/p.hbar*2*scale**4*integ)
        errs.append(abs(u)/p.hbar*2*scale**4*err)
    return {'array_size':array_size,'alpha':alpha,'delta_kappa4':sum(parts),
            'branch_parts':parts,'quad_error_estimate':sum(errs)}


def quadratic_matrices(model: LinearModel, observable: str='boundary_pressure') -> tuple[Array,Array,float]:
    """O = mean + a† A a + (a† B a† + a B a)/2, real matrices.

    boundary_pressure: reconstructed from the *linear* boundary equation.
    generalized_force: -dH/da at fixed normalized mesh coordinates.
    The two observables are deliberately not identified with one another.
    """
    p=model.p; w=model.omega; T=model.T; e=model.end
    if observable=='generalized_force':
        M=T.T@(model.Cline/p.a)@T
        U=T.T@(model.Kline/p.a)@T
        ww=np.sqrt(np.outer(w,w))
        Aq=p.hbar*U/(2*ww); Ap=p.hbar*M*ww/2
        A=Aq+Ap; B=Aq-Ap
    elif observable=='boundary_pressure':
        # Linear endpoint equation: Phi_x/L0 +(Kb+sumKc-Cb*w²)Phi-sumKc*q=0.
        deriv=p.L0*((p.Cb*w*w-p.Kb-sum(p.Kc))*T[e]
                    +sum(p.Kc[r]*T[model.elements+r] for r in range(len(p.Cr))))
        slope=deriv*np.sqrt(p.hbar/(2*w))
        velocity=T[e]*np.sqrt(p.hbar*w/2)
        Aq=np.outer(slope,slope)/p.L0
        Ap=p.C0*np.outer(velocity,velocity)
        A=Aq+Ap; B=Aq-Ap
    else:
        raise ValueError('Unknown observable.')
    return (A+A.T)/2,(B+B.T)/2,float(np.trace(A)/2)


def quantum_quadratic_cumulants(A: Array, B: Array, order: int=8) -> dict[str,float]:
    """Centered vacuum cumulants of a real Hermitian quadratic operator.

    Algebraic series, not an assumption that an MGF converges for positive s.
    e^(sO)|0> = c(s) exp[a†Z(s)a†/2]|0>,
    Z'=B+AZ+ZA^T+ZBZ, (log c)'=Tr(BZ)/2.
    In particular B=0 gives zero vacuum variance, as required for H0.
    """
    A=np.asarray(A,dtype=float); B=np.asarray(B,dtype=float)
    if A.shape != B.shape or A.ndim != 2 or A.shape[0] != A.shape[1]:
        raise ValueError('A and B must be same-sized square matrices.')
    if order < 2:
        raise ValueError('order must be >=2.')
    if not np.allclose(A,A.T) or not np.allclose(B,B.T):
        raise ValueError('This implementation expects real symmetric A,B.')
    # z[n] is coefficient of s^n, not nth derivative.
    z=[np.zeros_like(B),B.copy()]
    out={'1':0.0,'2':float(np.sum(B*B)/2)}
    for n in range(1,order-1):
        val=A@z[n]+z[n]@A.T
        for j in range(1,n):
            val+=z[j]@B@z[n-j]
        z.append((val+val.T)/(2*(n+1)))
        m=n+2
        out[str(m)]=math.factorial(m-1)/2*float(np.sum(B*z[m-1].T))
    return out


def sampled_cumulants(model: LinearModel, tau: float, observable: str='boundary_pressure',
                      increment: bool=False, order: int=8) -> dict:
    if tau <= 0:
        raise ValueError('tau must be positive.')
    A,B,mean=quadratic_matrices(model,observable)
    w=model.omega; diff=w[:,None]-w[None,:]; plus=w[:,None]+w[None,:]
    fa=np.exp(-.5*(tau*diff)**2); fb=np.exp(-.5*(tau*plus)**2)
    if increment:
        fa-=np.exp(-.5*(2*tau*diff)**2)
        fb-=np.exp(-.5*(2*tau*plus)**2)
    k=quantum_quadratic_cumulants(A*fa,B*fb,order)
    return {'observable':observable,'tau':tau,'increment':increment,
            'unsubtracted_mean':0.0 if increment else mean,
            'cumulants_centered':k,
            'warning':'Mean is regulator dependent; no isolated-boundary subtraction. Harmonic only.'}
