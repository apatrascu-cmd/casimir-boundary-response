"""Ordered first-order spectral cumulants of explicit, regulated line pressure.

H(lambda)=H0+lambda V with tadpole-matched normal-ordered quartic V.
The real-time Gaussian smearing is f_tau(ad_H/hbar), not Euclidean smearing.
Finite Fock matrices are projections of already ordered polynomials; products
of truncated position matrices are deliberately avoided.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import brentq
from scipy.sparse import csr_matrix, eye
from distributed_line import Parameters, LinearModel, quantum_quadratic_cumulants

@dataclass
class PressureModes:
    p: Parameters
    omega: np.ndarray
    endpoint: np.ndarray
    branch: np.ndarray
    slope: np.ndarray
    regulator: str

    def matrices(self):
        d=self.slope*np.sqrt(self.p.hbar/(2*self.omega))
        v=self.endpoint*np.sqrt(self.p.hbar*self.omega/2)
        aq=np.outer(d,d)/self.p.L0
        ap=self.p.C0*np.outer(v,v)
        return aq+ap,aq-ap


def fem_pressure_modes(model: LinearModel, count=None):
    """Explicit last-element derivative; no harmonic boundary reconstruction."""
    n=model.elements
    if count is None: count=len(model.omega)
    if not 1<=count<=len(model.omega): raise ValueError('Invalid mode count')
    previous=np.zeros_like(model.T[model.end]) if n==1 else model.T[model.end-1]
    return PressureModes(model.p,model.omega[:count].copy(),
        model.T[model.end,:count].copy(),model.T[n:,:count].copy(),
        ((model.T[model.end]-previous)/(model.p.a/n))[:count],f'FEM explicit slope, {n} elements')


def continuum_pressure_modes(count, p=Parameters()):
    """Independent continuum shooting roots, exact sine profiles and C norm.

    Between endpoint-impedance poles its secular function is strictly decreasing.
    Coincident branch/Dirichlet poles can carry dark modes and are rejected;
    they require an explicit nullspace solver, not silent omission.
    """
    p.validate()
    if count<1: raise ValueError('Positive count required')
    cr=np.asarray(p.Cr); kc=np.asarray(p.Kc)
    stiff=kc+np.asarray(p.Kg)+np.asarray(p.KJ)
    poles=np.sort(np.r_[np.sqrt(stiff/cr),np.arange(1,count+2)*np.pi*p.v/p.a])
    if np.any(np.diff(poles)<1e-9):
        raise ValueError('Coincident secular poles require a dark-mode treatment')
    def secular(w):
        k=w/p.v
        return p.Kb+sum(kc)-p.Cb*w*w+k/np.tan(k*p.a)/p.L0-np.sum(kc*kc/(stiff-cr*w*w))
    roots=[]; end=[]; branches=[]; slopes=[]
    left=0.
    for right in poles[:count]:
        eps=min(1e-9, (right-left)*1e-7)
        root=brentq(secular,left+eps,right-eps,xtol=2e-14,rtol=1e-14)
        k=root/p.v; z=k*p.a
        q=kc/(stiff-cr*root*root)
        norm=p.C0*(p.a/2-np.sin(2*z)/(4*k))/np.sin(z)**2+p.Cb+np.sum(cr*q*q)
        e=1/np.sqrt(norm)
        roots.append(root); end.append(e); branches.append(q*e); slopes.append(k/np.tan(z)*e)
        left=right
    return PressureModes(p,np.asarray(roots),np.asarray(end),np.asarray(branches).T,
                         np.asarray(slopes),'continuum sine modes; frequency-count regulator')


def gaussian_filter(gap, tau, increment=False):
    out=np.exp(-.5*(tau*gap)**2)
    if increment: out-=np.exp(-.5*(2*tau*gap)**2)
    return out


def gaussian_filter_prime(gap,tau,increment=False):
    out=-tau*tau*gap*np.exp(-.5*(tau*gap)**2)
    if increment: out+=4*tau*tau*gap*np.exp(-.5*(2*tau*gap)**2)
    return out


def harmonic_pressure(modes,tau,order=8,increment=False):
    A,B=modes.matrices(); w=modes.omega
    return quantum_quadratic_cumulants(A*gaussian_filter(w[:,None]-w[None,:],tau,increment),
                                       B*gaussian_filter(w[:,None]+w[None,:],tau,increment),order)


class FockRegulator:
    """Downward-closed basis, bounded by total quanta and optionally energy.

    The normal-ordered projection is exact within the retained basis. Convergence
    of products and perturbative propagation remains a separate cutoff test.
    """
    def __init__(self,omega,max_quanta=8,energy_cutoff=None,hbar=1.,max_dimension=1600):
        self.omega=np.asarray(omega); self.hbar=hbar; self.max_quanta=max_quanta
        if max_quanta<1 or np.any(self.omega<=0): raise ValueError('Invalid Fock regulator')
        cutoff=np.inf if energy_cutoff is None else energy_cutoff
        states=[]
        def enumerate_states(prefix,j,left,energy):
            if j==len(self.omega):
                states.append(tuple(prefix)); return
            for n in range(left+1):
                e=energy+n*hbar*self.omega[j]
                if e>cutoff+1e-12: break
                enumerate_states(prefix+[n],j+1,left-n,e)
                if len(states)>2*max_dimension: raise ValueError('Fock dimension budget exceeded')
        enumerate_states([],0,max_quanta,0.)
        states.sort(key=lambda s:(sum(s),s))
        self.states=np.asarray(states,dtype=int)
        self.energies=self.states@(hbar*self.omega)
        self.dimension=len(states)
        if self.dimension>max_dimension: raise ValueError(f'Fock dimension {self.dimension} exceeds {max_dimension}')
        index={s:i for i,s in enumerate(states)}
        self.ann=[]
        for j in range(len(self.omega)):
            rows=[]; cols=[]; data=[]
            for col,state in enumerate(states):
                if state[j]:
                    lower=list(state); lower[j]-=1
                    rows.append(index[tuple(lower)]); cols.append(col); data.append(np.sqrt(state[j]))
            self.ann.append(csr_matrix((data,(rows,cols)),shape=(self.dimension,self.dimension)))
        self.identity=eye(self.dimension,format='csr')

    def collective(self,coefficients):
        return sum((c*a for c,a in zip(coefficients,self.ann)),csr_matrix(self.identity.shape))

    def normal_power(self,b,degree):
        """P :(b+b†)^degree: P; lower first, then raise, without top-edge loss."""
        powers=[self.identity]
        for _ in range(degree): powers.append(powers[-1]@b)
        return sum((math.comb(degree,j)*(powers[j].T@powers[degree-j])
                    for j in range(degree+1)),csr_matrix(self.identity.shape))

    def quadratic(self,A,B):
        out=csr_matrix(self.identity.shape)
        for i,ai in enumerate(self.ann):
            for j,aj in enumerate(self.ann):
                out+=A[i,j]*(ai.T@aj)+.5*B[i,j]*(ai.T@aj.T+ai@aj)
        return (out+out.T).toarray()/2

    def branch_data(self,modes):
        coefficients=modes.branch*np.sqrt(modes.p.hbar/(2*modes.omega))[None,:]
        return [(self.collective(c),float(c@c)) for c in coefficients]

    def quartic(self,modes,alpha=.25,array_size=1):
        if alpha<0 or array_size<1: raise ValueError('Invalid nonlinear parameters')
        out=csr_matrix(self.identity.shape)
        for KJ,(b,var) in zip(modes.p.KJ,self.branch_data(modes)):
            u=-KJ*alpha*alpha/array_size**2
            out+=u/24*self.normal_power(b,4)
        return (out+out.T).toarray()/2

    def cosine_residual(self,modes,alpha=.25,array_size=1):
        """Exact projected cosine, harmonic term removed, same O(alpha²) calibration.

        exp(i c q)=exp(-c²<q²>/2) exp(i c b†)exp(i c b).
        This differs at the cutoff from cos(c PqP), which is not P cos(cq) P.
        """
        if alpha==0: return np.zeros(self.identity.shape)
        c=alpha/array_size; ident=self.identity.toarray(); out=np.zeros_like(ident)
        for KJ,(b,var) in zip(modes.p.KJ,self.branch_data(modes)):
            lower=b.toarray(); series=np.eye(self.dimension,dtype=complex); term=series.copy()
            for n in range(1,self.max_quanta+1):
                term=(1j*c/n)*(term@lower); series+=term
            cosine=np.exp(-c*c*var/2)*(series.T@series).real
            q2=self.normal_power(b,2).toarray()+var*ident
            delta_K=KJ*c*c*var/2
            out+=KJ/c**2*(ident-cosine)-KJ*q2/2+delta_K*q2/2
        out-=out[0,0]*ident
        return (out+out.T)/2


def smear_frechet(energies,P,V,tau,hbar=1.,increment=False,P1=None):
    """Value and exact first derivative of f_tau(ad_H/hbar)P at diagonal H0.

    Excited degeneracies are retained as blocks, with the f' contribution.
    This is equivalent to the divided-difference Fréchet formula and avoids an
    O(D^4) Liouville-space matrix. No division across degenerate levels occurs.
    """
    if tau<0: raise ValueError('tau must be nonnegative')
    E=np.asarray(energies); gap=E[:,None]-E[None,:]
    # Use direct divided differences if a coupled pair is nearly degenerate;
    # a large eigenvector-rotation generator would otherwise cause cancellation.
    tolerance=64*np.finfo(float).eps*max(1.,float(np.max(abs(E))))
    degenerate=abs(gap)<=tolerance
    near=(~degenerate)&(abs(gap)<1e-7*hbar/max(tau,1.))&(V!=0)
    if np.any(near):
        S,D=smear_frechet_divided(E,P,V,tau,hbar,increment)
        if P1 is not None: D+=gaussian_filter(gap/hbar,tau,increment)*P1
        return (S+S.T)/2,(D+D.T)/2
    K=np.zeros_like(V); np.divide(-V,gap,out=K,where=~degenerate)
    Vdeg=np.where(degenerate,V,0.)
    filt=gaussian_filter(gap/hbar,tau,increment)
    S=filt*P
    D=K@S-S@K+filt*(P@K-K@P)
    D+=gaussian_filter_prime(gap/hbar,tau,increment)*(Vdeg@P-P@Vdeg)/hbar
    if P1 is not None: D+=filt*P1
    if not np.all(np.isfinite(D)): raise FloatingPointError('Non-finite smearing derivative')
    return (S+S.T)/2,(D+D.T)/2


def smear_frechet_divided(energies,P,V,tau,hbar=1.,increment=False):
    """Slower, cancellation-resistant independent divided-difference implementation."""
    E=np.asarray(energies); gap=(E[:,None]-E[None,:])/hbar
    def divided(x,y):
        x,y=np.broadcast_arrays(x,y); delta=x-y
        near=abs(delta)<1e-5/max(tau,1.)
        ans=np.empty_like(delta)
        np.divide(gaussian_filter(x,tau,increment)-gaussian_filter(y,tau,increment),
                  delta,out=ans,where=~near)
        ans[near]=gaussian_filter_prime(((x+y)/2)[near],tau,increment)
        return ans
    D=np.zeros_like(P)
    for c in range(len(E)):
        D+=V[:,c,None]*P[c,None,:]*divided(gap,gap[c,None,:])/hbar
        D-=P[:,c,None]*V[c,None,:]*divided(gap,gap[:,c,None])/hbar
    return gaussian_filter(gap,tau,increment)*P,(D+D.T)/2


def moment_cumulant_series(moments,derivatives):
    nmax=len(moments)-1
    k=np.zeros(nmax+1); dk=np.zeros_like(k)
    for n in range(1,nmax+1):
        k[n]=moments[n]; dk[n]=derivatives[n]
        for j in range(1,n):
            c=math.comb(n-1,j-1)
            k[n]-=c*k[j]*moments[n-j]
            dk[n]-=c*(dk[j]*moments[n-j]+k[j]*derivatives[n-j])
    return k,dk


def first_order_cumulants(energies,P,V,tau,order=4,hbar=1.,increment=False,P1=None):
    E=np.asarray(energies)
    if abs(E[0])>1e-12 or np.any(E[1:]<=0): raise ValueError('Unique ground vacuum at index 0 required')
    S,D=smear_frechet(E,P,V,tau,hbar,increment,P1)
    chi=np.zeros(len(E)); chi[1:]=-V[1:,0]/E[1:]
    vec=np.eye(1,len(E))[0]; tangent=np.zeros(len(E))
    moments=[1.]; state=[0.]; dynamics=[0.]
    for n in range(1,order+1):
        tangent=D@vec+S@tangent
        vec=S@vec
        moments.append(float(vec[0]))
        state.append(float(2*chi@vec)); dynamics.append(float(tangent[0]))
    k,ds=moment_cumulant_series(moments,state)
    _,dd=moment_cumulant_series(moments,dynamics)
    def series(v): return {str(j):float(v[j]) for j in range(1,order+1)}
    return {'harmonic_cumulants':series(k),'delta_cumulants':series(ds+dd),
            'state_delta_cumulants':series(ds),'dynamics_delta_cumulants':series(dd),
            'first_order_cumulants':series(k+ds+dd),'state_tangent_norm':float(np.linalg.norm(chi)),
            'smearing_derivative_norm':float(np.linalg.norm(D)),
            'mean_delta':float(ds[1]+dd[1])}


def exact_spectral_cumulants(H,P,tau,order=4,hbar=1.,increment=False):
    energies,U=eigh(H)
    transformed=U.T@P@U
    S=transformed*gaussian_filter((energies[:,None]-energies[None,:])/hbar,tau,increment)
    # Center before taking powers to reduce cancellation from a raw vacuum mean.
    mean=float(S[0,0]); S=S-mean*np.eye(len(energies))
    vec=np.eye(1,len(energies))[0]; moments=[1.]
    for _ in range(order):
        vec=S@vec; moments.append(float(vec[0]))
    k,_=moment_cumulant_series(moments,np.zeros(order+1)); k[1]=mean
    return {str(j):float(k[j]) for j in range(1,order+1)}


def pressure_problem(modes,max_quanta=8,energy_cutoff=None,alpha=.25,array_size=1,max_dimension=1600):
    fock=FockRegulator(modes.omega,max_quanta,energy_cutoff,modes.p.hbar,max_dimension)
    A,B=modes.matrices()
    P=fock.quadratic(A,B) # harmonic mean removed; all k>=2 invariant under this constant
    V=fock.quartic(modes,alpha,array_size)
    # Even pressure and quartic interaction preserve total-number parity.
    even=np.flatnonzero(np.sum(fock.states,axis=1)%2==0)
    return fock,even,fock.energies[even],P[np.ix_(even,even)],V[np.ix_(even,even)]
